"""
petroppo V35 — Total Supremacy Edition.

The most advanced self-contained geophysical exploration platform, featuring:

  * Full-waveform forward modeling and inversion (15 physics engines)
  * Seismic processing, interpretation, and reservoir characterisation
  * AI-driven prospectivity mapping and copilot assistance
  * COMSOL-style desktop GUI (PyQt)  — ``petroppo.gui``
  * Microsoft Office-style web console UI (HTML5 Canvas ribbon) — ``petroppo.web_console``

The web console provides a modern, browser-based console interface with:
  * Ribbon toolbar with SVG icons for every function (like Microsoft Word)
  * Project explorer sidebar, properties panel, and AI Copilot panel
  * 3D volume, 2D seismic section, time-slice, well section, and 1D log views
  * Six industry color maps: Seismic Blue-White-Red, Grayscale, Rainbow,
    HSV, Geo-Orange, Red-White-Blue — selectable per view type

Quick start
-----------
    from petroppo.web_console import launch_console
    launch_console()          # opens the web console in your browser

    # or the desktop GUI
    from petroppo.gui import MainWindow

Benchmark: 15 / 15 wins vs. Petrel.
"""

__version__ = "39.0.0"
__author__ = "petroppo Team"
__description__ = "Total Supremacy Edition — Integrated Geophysical Exploration Suite"
