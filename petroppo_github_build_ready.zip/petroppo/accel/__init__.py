"""petroppo acceleration package -- GPU + Numba JIT kernels for performance.

V37 adds a device-abstract GPU acceleration layer (``petroppo.accel.gpu``)
that uses a CUDA GPU via Numba when present and **transparently falls back
to NumPy** otherwise.  Every GPU kernel is verified against its NumPy
reference by a bit-exactness gate, so the physics never changes when the
device does.  See :class:`petroppo.accel.gpu.BitExactnessGate`.

Usage::

    from petroppo.accel import (
        accel_coherence_c1,          # V35 Numba/NumPy dispatch
        gpu_coherence_c1,            # V37 GPU/Numba-CPU/NumPy dispatch
        gpu_available,               # True iff a CUDA GPU is usable
        active_backend_name,         # "cuda" | "numba-cpu" | "numpy"
        BitExactnessGate,            # GPU-vs-CPU bit-exactness verifier
    )
    coh = accel_coherence_c1(seismic)        # uses Numba if available
    coh = gpu_coherence_c1(seismic)          # uses GPU if available
"""

from .dispatch import (
    NUMBA_AVAILABLE,
    accel_coherence_c1,
    accel_coherence_eigen,
    accel_spectral_decomp,
    accel_instantaneous,
    accel_gradient_2d,
    accel_auto_pick_horizon,
    accel_fault_coherence,
)

from .gpu import (
    DeviceBackend,
    CUDABackend,
    NumbaCPUBackend,
    NumPyBackend,
    select_backend,
    active_backend_name,
    gpu_available,
    numba_cpu_available,
    gpu_threshold,
    BitExactnessGate,
    GateResult,
    GpuKernelRegistry,
    KernelSpec,
    gpu_coherence_c1,
    gpu_gradient_3d,
    gpu_rbf_eval,
    gpu_flux_assemble,
    benchmark_speedup,
)

__all__ = [
    # V35 Numba dispatch
    "NUMBA_AVAILABLE",
    "accel_coherence_c1",
    "accel_coherence_eigen",
    "accel_spectral_decomp",
    "accel_instantaneous",
    "accel_gradient_2d",
    "accel_auto_pick_horizon",
    "accel_fault_coherence",
    # V37 GPU acceleration
    "DeviceBackend",
    "CUDABackend",
    "NumbaCPUBackend",
    "NumPyBackend",
    "select_backend",
    "active_backend_name",
    "gpu_available",
    "numba_cpu_available",
    "gpu_threshold",
    "BitExactnessGate",
    "GateResult",
    "GpuKernelRegistry",
    "KernelSpec",
    "gpu_coherence_c1",
    "gpu_gradient_3d",
    "gpu_rbf_eval",
    "gpu_flux_assemble",
    "benchmark_speedup",
]

__version__ = "37.0.0"
