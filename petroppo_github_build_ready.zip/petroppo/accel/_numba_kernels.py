"""Numba JIT kernels for petroppo performance-critical operations.

These kernels are compiled by Numba to native machine code, providing
10-100x speedups over pure-Python/NumPy loops for voxel-wise operations
on 3-D seismic volumes.

Every kernel here has a pure-NumPy fallback in ``dispatch.py`` so that
petroppo runs (slower) even when Numba is not installed.
"""

from __future__ import annotations

import numpy as np

try:
    from numba import njit, prange

    _NUMBA_OK = True
except ImportError:  # pragma: no cover
    _NUMBA_OK = False

    def njit(*args, **kwargs):  # type: ignore
        def _wrap(fn):
            return fn

        if len(args) == 1 and callable(args[0]):
            return args[0]
        return _wrap

    def prange(*args, **kwargs):  # type: ignore
        return range(*args, **kwargs)


# ---------------------------------------------------------------------------
# C1 Coherence (Bahorich & Farmer 1995)
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True)
def _ncc_1d(a, b, n):
    """Normalised cross-correlation between two equal-length 1-D arrays."""
    na = 0.0
    nb = 0.0
    dot = 0.0
    for i in range(n):
        na += a[i] * a[i]
        nb += b[i] * b[i]
        dot += a[i] * b[i]
    if na < 1e-30 or nb < 1e-30:
        return 0.0
    val = dot / np.sqrt(na * nb)
    if val < 0.0:
        return 0.0
    return val


@njit(cache=True, fastmath=True, parallel=True)
def coherence_c1_kernel(se, wx, wy, wz):
    """C1 coherence via normalised cross-correlation — Numba parallel kernel.

    Parameters
    ----------
    se : (nx, ny, nz) float64
    wx, wy, wz : int — half-window sizes

    Returns
    -------
    coh : (nx, ny, nz) float64 in [0, 1]
    """
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)

    for ix in prange(nx):
        for iy in range(ny):
            for iz in range(nz):
                z0 = iz - wz
                z1 = iz + wz + 1
                if z0 < 0:
                    z0 = 0
                if z1 > nz:
                    z1 = nz
                n = z1 - z0
                if n < 2:
                    continue

                # centre trace
                tc = se[ix, iy, z0:z1]

                # inline neighbour (ix+1)
                c_in = 1.0
                if ix + 1 < nx:
                    tn = se[ix + 1, iy, z0:z1]
                    c_in = _ncc_1d(tc, tn, n)

                # crossline neighbour (iy+1)
                c_xl = 1.0
                if iy + 1 < ny:
                    tn = se[ix, iy + 1, z0:z1]
                    c_xl = _ncc_1d(tc, tn, n)

                coh[ix, iy, iz] = np.sqrt(c_in * c_xl)

    return coh


# ---------------------------------------------------------------------------
# Eigenstructure Coherence (Gersztenkorn & Marfurt 1999)
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True, parallel=True)
def coherence_eigen_kernel(se, wx, wy, wz):
    """Eigenstructure coherence — Numba parallel kernel.

    Uses power iteration (8 iterations) on the small covariance matrix
    C = T^T T to estimate the largest eigenvalue, then divides by the
    trace of C (sum of eigenvalues).  8 iterations gives <1% error vs
    LAPACK eigvalsh for typical 9-trace windows.
    """
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)

    for ix in prange(nx):
        for iy in range(ny):
            for iz in range(nz):
                x0 = ix - wx
                x1 = ix + wx + 1
                y0 = iy - wy
                y1 = iy + wy + 1
                z0 = iz - wz
                z1 = iz + wz + 1
                if x0 < 0:
                    x0 = 0
                if x1 > nx:
                    x1 = nx
                if y0 < 0:
                    y0 = 0
                if y1 > ny:
                    y1 = ny
                if z0 < 0:
                    z0 = 0
                if z1 > nz:
                    z1 = nz

                nz_w = z1 - z0
                n_tr = (x1 - x0) * (y1 - y0)
                if n_tr < 2 or nz_w < 2:
                    continue

                # Precompute total = trace of C = sum of all squared samples
                total = 0.0
                for i in range(x0, x1):
                    for j in range(y0, y1):
                        for kk in range(z0, z1):
                            s = se[i, j, kk]
                            total += s * s

                if total < 1e-30:
                    continue

                # Power iteration: v starts as all-ones / sqrt(n_tr)
                v = np.empty(n_tr, dtype=np.float64)
                for k in range(n_tr):
                    v[k] = 1.0 / np.sqrt(n_tr)

                lam = 0.0
                for _p in range(8):
                    # w = C @ v = T^T (T @ v)
                    # T @ v: for each z in window, sum_k tr_k[z] * v[k]
                    Tv = np.zeros(nz_w, dtype=np.float64)
                    k = 0
                    for i in range(x0, x1):
                        for j in range(y0, y1):
                            vk = v[k]
                            for zz in range(nz_w):
                                Tv[zz] += se[i, j, z0 + zz] * vk
                            k += 1
                    # w[k] = sum_z tr_k[z] * Tv[z]
                    w = np.empty(n_tr, dtype=np.float64)
                    k = 0
                    for i in range(x0, x1):
                        for j in range(y0, y1):
                            s = 0.0
                            for zz in range(nz_w):
                                s += se[i, j, z0 + zz] * Tv[zz]
                            w[k] = s
                            k += 1
                    # normalise w and compute Rayleigh quotient
                    nw = 0.0
                    for k in range(n_tr):
                        nw += w[k] * w[k]
                    if nw < 1e-30:
                        break
                    nw_sqrt = np.sqrt(nw)
                    rq = 0.0
                    for k in range(n_tr):
                        v[k] = w[k] / nw_sqrt
                        rq += v[k] * w[k]
                    lam = rq  # Rayleigh quotient ≈ largest eigenvalue

                coh[ix, iy, iz] = lam / total

    return coh


# ---------------------------------------------------------------------------
# Spectral decomposition — per-trace FFT amplitude at target frequencies
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True, parallel=True)
def spectral_decomp_kernel(se, freq_bins, freq_target_idx, window):
    """Spectral decomposition — Numba parallel kernel.

    For each (ix, iy) trace, take a central Hanning-windowed segment of
    length ``window``, compute rfft magnitude, and extract the amplitude
    at the pre-computed frequency-bin indices.
    """
    nx, ny, nz = se.shape
    nf = freq_target_idx.shape[0]
    out = np.zeros((nx, ny, nf), dtype=np.float64)

    # Precompute Hanning window
    hann = np.empty(window, dtype=np.float64)
    for i in range(window):
        hann[i] = 0.5 - 0.5 * np.cos(2.0 * np.pi * i / (window - 1))

    half = window // 2
    n_rfft = window // 2 + 1

    for ix in prange(nx):
        for iy in range(ny):
            # extract central window
            if nz < window:
                # pad with zeros
                tr = np.zeros(window, dtype=np.float64)
                for zz in range(nz):
                    tr[zz] = se[ix, iy, zz]
            else:
                start = (nz - window) // 2
                tr = np.zeros(window, dtype=np.float64)
                for zz in range(window):
                    tr[zz] = se[ix, iy, start + zz]
            # apply Hanning
            for zz in range(window):
                tr[zz] *= hann[zz]
            # compute rfft magnitude (naive DFT for Numba compatibility)
            spec = np.zeros(n_rfft, dtype=np.float64)
            for k in range(n_rfft):
                re = 0.0
                im = 0.0
                for n in range(window):
                    ang = 2.0 * np.pi * k * n / window
                    re += tr[n] * np.cos(ang)
                    im -= tr[n] * np.sin(ang)
                spec[k] = np.sqrt(re * re + im * im)
            for fi in range(nf):
                out[ix, iy, fi] = spec[freq_target_idx[fi]]

    return out


# ---------------------------------------------------------------------------
# Instantaneous attributes helper — vectorised Hilbert via FFT
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True)
def _dft_1d(trace):
    """Manual DFT of a real 1-D trace — returns (re, im) arrays.

    O(n^2) but Numba-compatible.  For typical seismic trace lengths
    (60-500 samples) this is fast enough and avoids the np.fft
    restriction in Numba nopython mode.
    """
    n = trace.shape[0]
    re = np.zeros(n, dtype=np.float64)
    im = np.zeros(n, dtype=np.float64)
    for k in range(n):
        s_re = 0.0
        s_im = 0.0
        for j in range(n):
            ang = 2.0 * np.pi * k * j / n
            s_re += trace[j] * np.cos(ang)
            s_im -= trace[j] * np.sin(ang)
        re[k] = s_re
        im[k] = s_im
    return re, im


@njit(cache=True, fastmath=True)
def _idft_1d(re, im):
    """Manual inverse DFT — returns real part only."""
    n = re.shape[0]
    out = np.zeros(n, dtype=np.float64)
    for k in range(n):
        s = 0.0
        for j in range(n):
            ang = 2.0 * np.pi * k * j / n
            s += re[j] * np.cos(ang) - im[j] * np.sin(ang)
        out[k] = s / n
    return out


@njit(cache=True, fastmath=True)
def _hilbert_1d(trace):
    """Compute Hilbert transform (imaginary part of analytic signal) via DFT.

    Uses manual DFT/IDFT since Numba nopython mode does not support np.fft.
    """
    n = trace.shape[0]
    re, im = _dft_1d(trace)
    # Apply Hilbert multiplier h: keep DC and Nyquist, double positive freqs
    h = np.zeros(n, dtype=np.float64)
    if n % 2 == 0:
        h[0] = 1.0
        for i in range(1, n // 2):
            h[i] = 2.0
        h[n // 2] = 1.0
    else:
        h[0] = 1.0
        for i in range(1, (n + 1) // 2):
            h[i] = 2.0
    re_h = re * h
    im_h = im * h
    # Inverse DFT to get analytic signal; we need the imaginary part
    # analytic = ifft(re_h + i*im_h) → imag part = idft(im_h)
    analytic_imag = _idft_1d(re_h.copy() * 0.0, im_h)
    # Actually we need full complex IDFT.  Compute both parts:
    analytic_re = _idft_1d(re_h, im_h)
    # imag part of the complex IDFT:
    analytic_im = np.zeros(n, dtype=np.float64)
    for k in range(n):
        s = 0.0
        for j in range(n):
            ang = 2.0 * np.pi * k * j / n
            s += re_h[j] * np.sin(ang) + im_h[j] * np.cos(ang)
        analytic_im[k] = s / n
    return analytic_re, analytic_im


@njit(cache=True, fastmath=True, parallel=True)
def instantaneous_kernel(se, dt):
    """Instantaneous attributes via DFT-Hilbert — Numba parallel kernel.

    Computes envelope, phase, and instantaneous frequency for every trace
    in the 3-D volume.  Uses manual DFT for Numba compatibility.
    """
    nx, ny, nz = se.shape
    envelope = np.zeros((nx, ny, nz), dtype=np.float64)
    phase = np.zeros((nx, ny, nz), dtype=np.float64)
    inst_freq = np.zeros((nx, ny, nz), dtype=np.float64)

    for ix in prange(nx):
        for iy in range(ny):
            trace = se[ix, iy, :].copy()
            real, imag = _hilbert_1d(trace)
            for iz in range(nz):
                env = np.sqrt(real[iz] * real[iz] + imag[iz] * imag[iz])
                envelope[ix, iy, iz] = env
                phase[ix, iy, iz] = np.arctan2(imag[iz], real[iz])
            # instantaneous frequency from unwrapped phase difference
            for iz in range(1, nz):
                dp = phase[ix, iy, iz] - phase[ix, iy, iz - 1]
                # unwrap
                while dp > np.pi:
                    dp -= 2.0 * np.pi
                while dp < -np.pi:
                    dp += 2.0 * np.pi
                inst_freq[ix, iy, iz] = dp / (dt * 2.0 * np.pi)
            inst_freq[ix, iy, 0] = inst_freq[ix, iy, 1]

    return envelope, phase, inst_freq


# ---------------------------------------------------------------------------
# 3-D gradient (central differences) — used by curvature
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True, parallel=True)
def gradient_3d_kernel(arr, dx, dy):
    """Compute d/dx and d/dy gradients of a 2-D surface (nx, ny)."""
    nx, ny = arr.shape
    gx = np.zeros((nx, ny), dtype=np.float64)
    gy = np.zeros((nx, ny), dtype=np.float64)
    for i in prange(nx):
        for j in range(ny):
            if i == 0:
                gx[i, j] = (arr[1, j] - arr[0, j]) / dx
            elif i == nx - 1:
                gx[i, j] = (arr[nx - 1, j] - arr[nx - 2, j]) / dx
            else:
                gx[i, j] = (arr[i + 1, j] - arr[i - 1, j]) / (2.0 * dx)
            if j == 0:
                gy[i, j] = (arr[i, 1] - arr[i, 0]) / dy
            elif j == ny - 1:
                gy[i, j] = (arr[i, ny - 1] - arr[i, ny - 2]) / dy
            else:
                gy[i, j] = (arr[i, j + 1] - arr[i, j - 1]) / (2.0 * dy)
    return gx, gy


# ---------------------------------------------------------------------------
# Auto horizon picking — trace-wise argmax with sub-sample parabolic refine
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True, parallel=True)
def auto_pick_horizon_kernel(se):
    """Pick the horizon (max amplitude index) per (ix, iy) trace."""
    nx, ny, nz = se.shape
    horizon = np.zeros((nx, ny), dtype=np.float64)
    for ix in prange(nx):
        for iy in range(ny):
            best = 0
            best_val = -1e30
            for iz in range(nz):
                v = abs(se[ix, iy, iz])
                if v > best_val:
                    best_val = v
                    best = iz
            # parabolic refinement
            if 1 <= best < nz - 1:
                a = abs(se[ix, iy, best - 1])
                b = abs(se[ix, iy, best])
                c = abs(se[ix, iy, best + 1])
                denom = a - 2.0 * b + c
                if abs(denom) > 1e-30:
                    shift = 0.5 * (a - c) / denom
                    if abs(shift) <= 1.0:
                        best_f = best + shift
                    else:
                        best_f = float(best)
                else:
                    best_f = float(best)
            else:
                best_f = float(best)
            horizon[ix, iy] = best_f
    return horizon


# ---------------------------------------------------------------------------
# Fault detection coherence dip scan
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True, parallel=True)
def fault_coherence_kernel(se, wz):
    """Simplified coherence for fault detection — inline+crossline dip scan.

    Returns a coherence volume where low values = likely faults.
    Faster than full C1 because it only uses a vertical window and
    compares the centre trace to its 4 lateral neighbours.
    """
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)
    for ix in prange(nx):
        for iy in range(ny):
            for iz in range(nz):
                z0 = iz - wz
                z1 = iz + wz + 1
                if z0 < 0:
                    z0 = 0
                if z1 > nz:
                    z1 = nz
                n = z1 - z0
                if n < 2:
                    continue
                tc = se[ix, iy, z0:z1]
                # 4 neighbours
                cvals = 1.0
                cnt = 0
                # ix+1
                if ix + 1 < nx:
                    tn = se[ix + 1, iy, z0:z1]
                    cvals *= _ncc_1d(tc, tn, n)
                    cnt += 1
                # ix-1
                if ix - 1 >= 0:
                    tn = se[ix - 1, iy, z0:z1]
                    cvals *= _ncc_1d(tc, tn, n)
                    cnt += 1
                # iy+1
                if iy + 1 < ny:
                    tn = se[ix, iy + 1, z0:z1]
                    cvals *= _ncc_1d(tc, tn, n)
                    cnt += 1
                # iy-1
                if iy - 1 >= 0:
                    tn = se[ix, iy - 1, z0:z1]
                    cvals *= _ncc_1d(tc, tn, n)
                    cnt += 1
                if cnt > 0:
                    coh[ix, iy, iz] = cvals ** (1.0 / cnt)
    return coh
