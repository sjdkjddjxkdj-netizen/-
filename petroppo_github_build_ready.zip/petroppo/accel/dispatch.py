"""Acceleration dispatch — auto-selects Numba kernels when available.

Public API mirrors the kernels but transparently falls back to pure
NumPy implementations when Numba is not installed, so petroppo always
runs (just slower without Numba).
"""

from __future__ import annotations

import numpy as np

from ._numba_kernels import (
    _NUMBA_OK,
    coherence_c1_kernel,
    coherence_eigen_kernel,
    spectral_decomp_kernel,
    instantaneous_kernel,
    gradient_3d_kernel,
    auto_pick_horizon_kernel,
    fault_coherence_kernel,
)

__all__ = [
    "NUMBA_AVAILABLE",
    "accel_coherence_c1",
    "accel_coherence_eigen",
    "accel_spectral_decomp",
    "accel_instantaneous",
    "accel_gradient_2d",
    "accel_auto_pick_horizon",
    "accel_fault_coherence",
]

NUMBA_AVAILABLE = _NUMBA_OK


def accel_coherence_c1(se, window=(5, 5, 9)):
    """C1 coherence — Numba if available, else NumPy fallback."""
    se = np.ascontiguousarray(se, dtype=np.float64)
    wx, wy, wz = window
    if _NUMBA_OK:
        return coherence_c1_kernel(se, wx, wy, wz)
    return _coherence_c1_numpy(se, wx, wy, wz)


def accel_coherence_eigen(se, window=(3, 3, 5)):
    """Eigenstructure coherence — Numba if available, else NumPy fallback."""
    se = np.ascontiguousarray(se, dtype=np.float64)
    wx, wy, wz = window
    if _NUMBA_OK:
        return coherence_eigen_kernel(se, wx, wy, wz)
    return _coherence_eigen_numpy(se, wx, wy, wz)


def accel_spectral_decomp(se, dt, frequencies, window=64):
    """Spectral decomposition — NumPy FFT (fastest available).

    NumPy's FFT is O(n log n) and already highly optimised via
    pocketfft.  The Numba manual-DFT kernel is O(n^2) and slower,
    so we always use the NumPy vectorised path here.
    """
    se = np.ascontiguousarray(se, dtype=np.float64)
    if se.ndim != 3:
        raise ValueError("accel_spectral_decomp expects 3-D seismic")
    freq_bins = np.fft.rfftfreq(window, d=dt)
    freq_target_idx = np.array(
        [int(np.argmin(np.abs(freq_bins - f))) for f in frequencies],
        dtype=np.int64,
    )
    return _spectral_decomp_numpy(se, freq_bins, freq_target_idx, window)


def accel_instantaneous(se, dt):
    """Instantaneous attributes — scipy Hilbert (already vectorised & fast).

    Note: scipy.signal.hilbert uses FFT and is O(n log n) per trace,
    fully vectorised across all axes — this is already optimal.
    Numba's manual DFT would be O(n^2) and slower for typical trace
    lengths, so we keep the scipy implementation.
    """
    se = np.ascontiguousarray(se, dtype=np.float64)
    return _instantaneous_numpy(se, dt)


def accel_gradient_2d(surface, dx=1.0, dy=1.0):
    """2-D gradient — Numba if available, else np.gradient."""
    surface = np.ascontiguousarray(surface, dtype=np.float64)
    if _NUMBA_OK:
        return gradient_3d_kernel(surface, dx, dy)
    gx = np.gradient(surface, dx, axis=0)
    gy = np.gradient(surface, dy, axis=1)
    return gx, gy


def accel_auto_pick_horizon(se):
    """Auto horizon pick — Numba if available, else NumPy fallback."""
    se = np.ascontiguousarray(se, dtype=np.float64)
    if _NUMBA_OK:
        return auto_pick_horizon_kernel(se)
    return _auto_pick_horizon_numpy(se)


def accel_fault_coherence(se, wz=5):
    """Fault coherence — Numba if available, else NumPy fallback."""
    se = np.ascontiguousarray(se, dtype=np.float64)
    if _NUMBA_OK:
        return fault_coherence_kernel(se, wz)
    return _fault_coherence_numpy(se, wz)


# ---------------------------------------------------------------------------
# Pure-NumPy fallbacks (kept simple — only used when Numba absent)
# ---------------------------------------------------------------------------

def _coherence_c1_numpy(se, wx, wy, wz):
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)

    def ncc(a, b):
        na = np.sum(a * a)
        nb = np.sum(b * b)
        if na < 1e-30 or nb < 1e-30:
            return 0.0
        v = float(np.sum(a * b) / np.sqrt(na * nb))
        return max(0.0, v)

    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                z0 = max(iz - wz, 0)
                z1 = min(iz + wz + 1, nz)
                n = z1 - z0
                if n < 2:
                    continue
                tc = se[ix, iy, z0:z1]
                c_in = 1.0
                if ix + 1 < nx:
                    c_in = ncc(tc, se[ix + 1, iy, z0:z1])
                c_xl = 1.0
                if iy + 1 < ny:
                    c_xl = ncc(tc, se[ix, iy + 1, z0:z1])
                coh[ix, iy, iz] = np.sqrt(c_in * c_xl)
    return coh


def _coherence_eigen_numpy(se, wx, wy, wz):
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                x0 = max(ix - wx, 0); x1 = min(ix + wx + 1, nx)
                y0 = max(iy - wy, 0); y1 = min(iy + wy + 1, ny)
                z0 = max(iz - wz, 0); z1 = min(iz + wz + 1, nz)
                traces = []
                for i in range(x0, x1):
                    for j in range(y0, y1):
                        traces.append(se[i, j, z0:z1])
                if len(traces) < 2:
                    continue
                T = np.column_stack(traces)
                if T.shape[0] < 2:
                    continue
                C = T.T @ T
                eigs = np.linalg.eigvalsh(C)
                total = np.sum(eigs)
                if total > 1e-30:
                    coh[ix, iy, iz] = float(eigs[-1] / total)
    return coh


def _spectral_decomp_numpy(se, freq_bins, freq_target_idx, window):
    """Vectorised spectral decomposition using batch FFT."""
    nx, ny, nz = se.shape
    nf = freq_target_idx.shape[0]
    hann = np.hanning(window)
    # Extract central window for all traces at once
    if nz < window:
        tr = np.zeros((nx, ny, window))
        tr[:, :, :nz] = se
    else:
        start = (nz - window) // 2
        tr = se[:, :, start:start + window]
    # Apply Hanning window and compute rFFT for all traces
    spec = np.abs(np.fft.rfft(tr * hann, axis=-1))  # (nx, ny, window//2+1)
    # Extract target frequencies
    out = spec[:, :, freq_target_idx]  # (nx, ny, nf)
    return np.ascontiguousarray(out, dtype=np.float64)


def _instantaneous_numpy(se, dt):
    from scipy.signal import hilbert
    analytic = hilbert(se, axis=-1)
    envelope = np.abs(analytic)
    phase = np.unwrap(np.angle(analytic), axis=-1)
    inst_freq = np.gradient(phase, dt, axis=-1) / (2.0 * np.pi)
    return envelope, np.angle(analytic), inst_freq


def _auto_pick_horizon_numpy(se):
    env = np.abs(se)
    horizon = np.argmax(env, axis=-1).astype(np.float64)
    # parabolic refinement
    nx, ny, nz = se.shape
    for ix in range(nx):
        for iy in range(ny):
            b = int(horizon[ix, iy])
            if 1 <= b < nz - 1:
                a = abs(se[ix, iy, b - 1])
                c = abs(se[ix, iy, b + 1])
                bb = abs(se[ix, iy, b])
                denom = a - 2.0 * bb + c
                if abs(denom) > 1e-30:
                    shift = 0.5 * (a - c) / denom
                    if abs(shift) <= 1.0:
                        horizon[ix, iy] = b + shift
    return horizon


def _fault_coherence_numpy(se, wz):
    nx, ny, nz = se.shape
    coh = np.ones((nx, ny, nz), dtype=np.float64)

    def ncc(a, b):
        na = np.sum(a * a)
        nb = np.sum(b * b)
        if na < 1e-30 or nb < 1e-30:
            return 0.0
        v = float(np.sum(a * b) / np.sqrt(na * nb))
        return max(0.0, v)

    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                z0 = max(iz - wz, 0)
                z1 = min(iz + wz + 1, nz)
                n = z1 - z0
                if n < 2:
                    continue
                tc = se[ix, iy, z0:z1]
                cvals = 1.0
                cnt = 0
                if ix + 1 < nx:
                    cvals *= ncc(tc, se[ix + 1, iy, z0:z1]); cnt += 1
                if ix - 1 >= 0:
                    cvals *= ncc(tc, se[ix - 1, iy, z0:z1]); cnt += 1
                if iy + 1 < ny:
                    cvals *= ncc(tc, se[ix, iy + 1, z0:z1]); cnt += 1
                if iy - 1 >= 0:
                    cvals *= ncc(tc, se[ix, iy - 1, z0:z1]); cnt += 1
                if cnt > 0:
                    coh[ix, iy, iz] = cvals ** (1.0 / cnt)
    return coh
