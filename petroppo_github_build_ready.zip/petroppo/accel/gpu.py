"""petroppo V37 -- GPU acceleration layer (device-abstract, CPU-fallback).

This module provides a *device-abstract* acceleration framework that uses a
GPU (CUDA via Numba, when present) for the heavy data-parallel kernels of
petroppo -- coherence, gradient, RBF surrogate evaluation, and reservoir
flux assembly -- and **transparently falls back to NumPy** when no GPU is
available.  The critical design property is **bit-exactness**: the CPU and
GPU code paths must produce numerically identical (within a tight tolerance)
outputs, verified by an offline :class:`BitExactnessGate`.  This makes the
GPU an *accelerator of the same answer*, never a *source of different
answers* -- which is the only way GPU acceleration is acceptable in a
reservoir-engineering code that competes on provable results.

Why a device abstraction instead of ``@cuda.jit`` everywhere
------------------------------------------------------------

A two-person team cannot maintain three code paths (NumPy, Numba-CUDA,
CuPy) for every kernel.  The :class:`DeviceBackend` abstraction presents a
single interface -- ``launch(kernel, args, grid)`` -- and three concrete
backends:

* :class:`CUDABackend`  -- real GPU via Numba-CUDA (only if ``numba.cuda``
  imports and ``cuda.is_available()`` is true).
* :class:`NumbaCPUBackend` -- JIT-compiled CPU kernels via ``@numba.njit``
  (multi-core vectorisation; works without a GPU).
* :class:`NumPyBackend` -- pure NumPy reference implementation; always
  available; the ground truth for the bit-exactness gate.

The active backend is chosen at import time by :func:`select_backend` and
can be queried with :func:`active_backend_name`.  No call site ever needs
to know which backend is active -- it just calls the public kernel
functions in this module, which dispatch through the active backend.

Bit-exactness contract
----------------------

Every GPU kernel in this module is paired with a NumPy reference whose
output is used as the ground truth.  The :class:`BitExactnessGate` runs a
representative workload on both the GPU and the CPU reference and asserts
``np.max(|gpu - cpu| <= atol`` (default ``atol=1e-12`` for float64).  The
gate is part of the V37 verification suite (``test_v37_gates.py``) so a
numerical regression on the GPU path is a test failure, not a silent
discrepancy.  This is what makes GPU acceleration safe to ship: the
physics does not change when the device does.

Performance model
-----------------

The GPU backend is only beneficial above a minimum problem size (the
kernel-launch and H2D/D2H copy overhead dominates for small arrays).
:func:`gpu_threshold` returns the per-kernel crossover size, and the
dispatch functions automatically stay on the CPU for sub-threshold work.
This avoids the classic "GPU is slower than CPU for small problems"
regression.

References
----------
* Numba CUDA documentation, ``numba.cuda``.
* Harris, M. (2005). *Mapping Computational Concepts to GPUs*, GPU Gems 2.
* Nickolls, J. et al. (2010). *The Scalability and Efficiency of
  GPUs*, IEEE Micro.
"""

from __future__ import annotations

import os
import time
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Tuple

__all__ = [
    "DeviceBackend",
    "CUDABackend",
    "NumbaCPUBackend",
    "NumPyBackend",
    "select_backend",
    "active_backend_name",
    "gpu_available",
    "numba_cpu_available",
    "gpu_threshold",
    "BitExactnessGate",
    "GateResult",
    "gpu_coherence_c1",
    "gpu_gradient_3d",
    "gpu_rbf_eval",
    "gpu_flux_assemble",
    "GpuKernelRegistry",
]


# ---------------------------------------------------------------------------
# Backend availability probes (import-time, cached)
# ---------------------------------------------------------------------------

def _probe_cuda() -> bool:
    """True iff Numba-CUDA imports AND reports a usable GPU."""
    try:
        from numba import cuda  # type: ignore
        return bool(cuda.is_available())
    except Exception:
        return False


def _probe_numba_cpu() -> bool:
    """True iff Numba (CPU jit) is importable."""
    try:
        import numba  # noqa: F401  type: ignore
        return True
    except Exception:
        return False


_CUDA_AVAILABLE = _probe_cuda()
_NUMBA_CPU_AVAILABLE = _probe_numba_cpu()


def gpu_available() -> bool:
    """Return True if a CUDA GPU is usable via Numba."""
    return _CUDA_AVAILABLE


def numba_cpu_available() -> bool:
    """Return True if Numba CPU JIT is available."""
    return _NUMBA_CPU_AVAILABLE


# ---------------------------------------------------------------------------
# Backend abstraction
# ---------------------------------------------------------------------------

class DeviceBackend:
    """Abstract device backend.

    Subclasses implement :meth:`launch` -- dispatch a kernel over a grid
    -- and report their name via :meth:`name`.  The backend never raises
    on missing hardware; an unavailable backend simply is not selected.
    """

    name: str = "abstract"

    def launch(self, kernel: Callable, args: tuple, grid: Tuple[int, int, int],
               block: Tuple[int, int, int]) -> Any:
        raise NotImplementedError

    def synchronize(self) -> None:
        """Wait for all queued work to finish (no-op on CPU backends)."""
        return None

    def to_device(self, arr: np.ndarray) -> Any:
        """Copy a host array to the device.  CPU backends return as-is."""
        return arr

    def to_host(self, arr: Any) -> np.ndarray:
        """Copy a device array back to host.  CPU backends return as-is."""
        return np.asarray(arr)


class NumPyBackend(DeviceBackend):
    """Pure-NumPy reference backend -- always available, always the ground truth."""

    name = "numpy"

    def launch(self, kernel, args, grid, block):
        # NumPy kernels are plain Python functions; "launch" is just a call.
        return kernel(*args)

    def synchronize(self):
        return None


class NumbaCPUBackend(DeviceBackend):
    """Numba-CPU (multi-core njit) backend.

    Kernels are JIT-compiled on first call and run on all cores.  Falls
    back to NumPyBackend if numba is not installed.
    """

    name = "numba-cpu"

    def launch(self, kernel, args, grid, block):
        return kernel(*args)


class CUDABackend(DeviceBackend):
    """Numba-CUDA GPU backend.

    Only selected when ``numba.cuda.is_available()`` is true.  Kernels
    are ``@cuda.jit`` device functions dispatched over a 3-D grid.
    """

    name = "cuda"

    def __init__(self):
        from numba import cuda  # type: ignore
        self._cuda = cuda

    def launch(self, kernel, args, grid, block):
        kernel[grid, block](*args)
        self._cuda.synchronize()

    def synchronize(self):
        self._cuda.synchronize()

    def to_device(self, arr):
        return self._cuda.to_device(np.ascontiguousarray(arr))

    def to_host(self, arr):
        if hasattr(arr, "copy_to_host"):
            return arr.copy_to_host()
        return np.asarray(arr)


# ---------------------------------------------------------------------------
# Backend selection
# ---------------------------------------------------------------------------

_BACKEND: Optional[DeviceBackend] = None


def select_backend(preferred: Optional[str] = None) -> DeviceBackend:
    """Select and cache the active device backend.

    Parameters
    ----------
    preferred : str or None
        One of ``"cuda"``, ``"numba-cpu"``, ``"numpy"``, or ``None`` for
        automatic selection (highest available performance).

    Returns
    -------
    DeviceBackend
        The active backend.  Subsequent calls return the same cached
        instance unless ``preferred`` is explicitly changed.
    """
    global _BACKEND
    if preferred is not None:
        if preferred == "cuda":
            if not _CUDA_AVAILABLE:
                raise RuntimeError("CUDA backend requested but not available")
            _BACKEND = CUDABackend()
        elif preferred == "numba-cpu":
            if not _NUMBA_CPU_AVAILABLE:
                _BACKEND = NumPyBackend()
            else:
                _BACKEND = NumbaCPUBackend()
        elif preferred == "numpy":
            _BACKEND = NumPyBackend()
        else:
            raise ValueError(f"unknown backend {preferred!r}")
        return _BACKEND

    if _BACKEND is None:
        if _CUDA_AVAILABLE:
            try:
                _BACKEND = CUDABackend()
            except Exception:
                _BACKEND = NumbaCPUBackend() if _NUMBA_CPU_AVAILABLE else NumPyBackend()
        elif _NUMBA_CPU_AVAILABLE:
            _BACKEND = NumbaCPUBackend()
        else:
            _BACKEND = NumPyBackend()
    return _BACKEND


def active_backend_name() -> str:
    """Return the name of the currently active backend."""
    return select_backend().name


# ---------------------------------------------------------------------------
# GPU-vs-CPU crossover thresholds (per kernel)
# ---------------------------------------------------------------------------

# Below these element counts the GPU is slower than CPU (launch + copy
# overhead dominates).  Values are conservative defaults; tunable via env.
_DEFAULT_THRESHOLDS = {
    "coherence_c1": int(os.environ.get("PETROPPO_GPU_THRESH_COHERENCE", "262144")),
    "gradient_3d": int(os.environ.get("PETROPPO_GPU_THRESH_GRADIENT", "131072")),
    "rbf_eval": int(os.environ.get("PETROPPO_GPU_THRESH_RBF", "65536")),
    "flux_assemble": int(os.environ.get("PETROPPO_GPU_THRESH_FLUX", "524288")),
}


def gpu_threshold(kernel: str) -> int:
    """Return the minimum element count above which the GPU is worth using."""
    return _DEFAULT_THRESHOLDS.get(kernel, 131072)


# ---------------------------------------------------------------------------
# NumPy reference kernels (the ground truth for bit-exactness)
# ---------------------------------------------------------------------------

def _coherence_c1_numpy(se: np.ndarray, wx: int, wy: int, wz: int) -> np.ndarray:
    """C1 coherence -- NumPy reference (matches accel._numba_kernels)."""
    se = np.ascontiguousarray(se, dtype=np.float64)
    nx, ny, nz = se.shape
    out = np.ones((nx, ny, nz), dtype=np.float64)
    hwx, hwy, hwz = wx // 2, wy // 2, wz // 2
    for i in range(hwx, nx - hwx):
        for j in range(hwy, ny - hwy):
            for k in range(hwz, nz - hwz):
                cube = se[i - hwx:i + hwx + 1, j - hwy:j + hwy + 1,
                          k - hwz:k + hwz + 1]
                c = cube - cube.mean()
                denom = float(np.sum(c * c))
                if denom <= 1e-30:
                    out[i, j, k] = 1.0
                else:
                    center = c[hwx, hwy, hwz]
                    out[i, j, k] = float(center * center / denom)
    return np.clip(out, 0.0, 1.0)


def _gradient_3d_numpy(vol: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Central-difference 3-D gradient -- NumPy reference."""
    vol = np.ascontiguousarray(vol, dtype=np.float64)
    gx = np.zeros_like(vol)
    gy = np.zeros_like(vol)
    gz = np.zeros_like(vol)
    gx[1:-1, :, :] = (vol[2:, :, :] - vol[:-2, :, :]) * 0.5
    gy[:, 1:-1, :] = (vol[:, 2:, :] - vol[:, :-2, :]) * 0.5
    gz[:, :, 1:-1] = (vol[:, :, 2:] - vol[:, :, :-2]) * 0.5
    return gx, gy, gz


def _rbf_eval_numpy(centers: np.ndarray, x: np.ndarray,
                    weights: np.ndarray, lengthscale: float) -> np.ndarray:
    """Gaussian RBF evaluation -- NumPy reference.

    Parameters
    ----------
    centers : (M, D) array of RBF centers.
    x : (N, D) query points.
    weights : (M,) RBF weights.
    lengthscale : float, Gaussian sigma.
    """
    centers = np.ascontiguousarray(centers, dtype=np.float64)
    x = np.ascontiguousarray(x, dtype=np.float64)
    weights = np.ascontiguousarray(weights, dtype=np.float64)
    # (N, M) squared-distance matrix via broadcast.
    diff = x[:, None, :] - centers[None, :, :]
    d2 = np.einsum("nmd,nmd->nm", diff, diff)
    k = np.exp(-d2 / (lengthscale * lengthscale))
    return k @ weights


def _flux_assemble_numpy(trans: np.ndarray, press: np.ndarray) -> np.ndarray:
    """Reservoir inter-cell flux assembly -- NumPy reference.

    Computes ``flux = T * (P neighbour - P cell)`` for the X-faces of a
    structured grid (shape ``(nx-1, ny, nz)`` face transmissibility and
    ``(nx, ny, nz)`` cell pressure).  This is the inner kernel of every
    finite-volume reservoir simulator -- assembling it on the GPU is the
    single biggest win for large models.
    """
    trans = np.ascontiguousarray(trans, dtype=np.float64)
    press = np.ascontiguousarray(press, dtype=np.float64)
    flux = trans * (press[1:, :, :] - press[:-1, :, :])
    return flux


# ---------------------------------------------------------------------------
# Public GPU-accelerated kernel dispatchers
# ---------------------------------------------------------------------------

def gpu_coherence_c1(se: np.ndarray, window: Tuple[int, int, int] = (5, 5, 9)
                      ) -> np.ndarray:
    """C1 coherence -- GPU if available and large enough, else CPU.

    Bit-exact with the NumPy reference (see :class:`BitExactnessGate`).
    """
    se = np.ascontiguousarray(se, dtype=np.float64)
    n = se.size
    backend = select_backend()
    if backend.name == "cuda" and n >= gpu_threshold("coherence_c1"):
        return _coherence_c1_cuda(se, window)
    if backend.name == "numba-cpu" and _NUMBA_CPU_AVAILABLE:
        return _coherence_c1_numba_cpu(se, window)
    wx, wy, wz = window
    return _coherence_c1_numpy(se, wx, wy, wz)


def gpu_gradient_3d(vol: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """3-D central-difference gradient -- GPU if available and large, else CPU."""
    vol = np.ascontiguousarray(vol, dtype=np.float64)
    n = vol.size
    backend = select_backend()
    if backend.name == "cuda" and n >= gpu_threshold("gradient_3d"):
        return _gradient_3d_cuda(vol)
    if backend.name == "numba-cpu" and _NUMBA_CPU_AVAILABLE:
        return _gradient_3d_numba_cpu(vol)
    return _gradient_3d_numpy(vol)


def gpu_rbf_eval(centers: np.ndarray, x: np.ndarray, weights: np.ndarray,
                 lengthscale: float) -> np.ndarray:
    """Gaussian RBF evaluation -- GPU for large query batches, else CPU."""
    centers = np.ascontiguousarray(centers, dtype=np.float64)
    x = np.ascontiguousarray(x, dtype=np.float64)
    weights = np.ascontiguousarray(weights, dtype=np.float64)
    n = x.shape[0] * centers.shape[0]
    backend = select_backend()
    if backend.name == "cuda" and n >= gpu_threshold("rbf_eval"):
        return _rbf_eval_cuda(centers, x, weights, lengthscale)
    return _rbf_eval_numpy(centers, x, weights, lengthscale)


def gpu_flux_assemble(trans: np.ndarray, press: np.ndarray) -> np.ndarray:
    """Reservoir X-face flux assembly -- GPU for large grids, else CPU."""
    trans = np.ascontiguousarray(trans, dtype=np.float64)
    press = np.ascontiguousarray(press, dtype=np.float64)
    n = trans.size
    backend = select_backend()
    if backend.name == "cuda" and n >= gpu_threshold("flux_assemble"):
        return _flux_assemble_cuda(trans, press)
    if backend.name == "numba-cpu" and _NUMBA_CPU_AVAILABLE:
        return _flux_assemble_numba_cpu(trans, press)
    return _flux_assemble_numpy(trans, press)


# ---------------------------------------------------------------------------
# Numba-CPU JIT variants (multi-core, no GPU required)
# ---------------------------------------------------------------------------

def _coherence_c1_numba_cpu(se, window):
    try:
        from numba import njit, prange  # type: ignore
    except Exception:
        wx, wy, wz = window
        return _coherence_c1_numpy(se, wx, wy, wz)

    @njit(cache=True, fastmath=False)
    def _kern(se, wx, wy, wz):
        nx, ny, nz = se.shape
        out = np.ones((nx, ny, nz), dtype=np.float64)
        hwx, hwy, hwz = wx // 2, wy // 2, wz // 2
        wvol = wx * wy * wz
        for i in range(hwx, nx - hwx):
            for j in range(hwy, ny - hwy):
                for k in range(hwz, nz - hwz):
                    s = 0.0
                    for a in range(wx):
                        for b in range(wy):
                            for c in range(wz):
                                s += se[i - hwx + a, j - hwy + b, k - hwz + c]
                    mean = s / wvol
                    denom = 0.0
                    center = 0.0
                    for a in range(wx):
                        for b in range(wy):
                            for c in range(wz):
                                d = se[i - hwx + a, j - hwy + b,
                                       k - hwz + c] - mean
                                denom += d * d
                                if a == hwx and b == hwy and c == hwz:
                                    center = d
                    if denom <= 1e-30:
                        out[i, j, k] = 1.0
                    else:
                        v = center * center / denom
                        if v < 0.0:
                            v = 0.0
                        elif v > 1.0:
                            v = 1.0
                        out[i, j, k] = v
        return out

    wx, wy, wz = window
    return _kern(se, wx, wy, wz)


def _gradient_3d_numba_cpu(vol):
    try:
        from numba import njit  # type: ignore
    except Exception:
        return _gradient_3d_numpy(vol)

    @njit(cache=True)
    def _kern(vol):
        nx, ny, nz = vol.shape
        gx = np.zeros_like(vol)
        gy = np.zeros_like(vol)
        gz = np.zeros_like(vol)
        for i in range(1, nx - 1):
            for j in range(ny):
                for k in range(nz):
                    gx[i, j, k] = 0.5 * (vol[i + 1, j, k] - vol[i - 1, j, k])
        for i in range(nx):
            for j in range(1, ny - 1):
                for k in range(nz):
                    gy[i, j, k] = 0.5 * (vol[i, j + 1, k] - vol[i, j - 1, k])
        for i in range(nx):
            for j in range(ny):
                for k in range(1, nz - 1):
                    gz[i, j, k] = 0.5 * (vol[i, j, k + 1] - vol[i, j, k - 1])
        return gx, gy, gz

    return _kern(vol)


def _flux_assemble_numba_cpu(trans, press):
    try:
        from numba import njit, prange  # type: ignore
    except Exception:
        return _flux_assemble_numpy(trans, press)

    @njit(cache=True, parallel=True)
    def _kern(trans, press):
        nxf, ny, nz = trans.shape
        flux = np.empty((nxf, ny, nz), dtype=np.float64)
        for f in prange(nxf):
            for j in range(ny):
                for k in range(nz):
                    flux[f, j, k] = trans[f, j, k] * (
                        press[f + 1, j, k] - press[f, j, k])
        return flux

    return _kern(trans, press)


# ---------------------------------------------------------------------------
# CUDA kernel variants (only compiled if a GPU is present)
# ---------------------------------------------------------------------------

def _coherence_c1_cuda(se, window):
    """CUDA C1 coherence via Numba-CUDA.  Bit-exact with NumPy reference."""
    from numba import cuda, njit  # type: ignore
    wx, wy, wz = window
    hwx, hwy, hwz = wx // 2, wy // 2, wz // 2

    @cuda.jit
    def _kern(se, out, wx, wy, wz, hwx, hwy, hwz):
        i, j, k = cuda.grid(3)
        nx, ny, nz = se.shape
        if hwx <= i < nx - hwx and hwy <= j < ny - hwy and hwz <= k < nz - hwz:
            s = 0.0
            for a in range(wx):
                for b in range(wy):
                    for c in range(wz):
                        s += se[i - hwx + a, j - hwy + b, k - hwz + c]
            wvol = wx * wy * wz
            mean = s / wvol
            denom = 0.0
            center = 0.0
            for a in range(wx):
                for b in range(wy):
                    for c in range(wz):
                        d = se[i - hwx + a, j - hwy + b, k - hwz + c] - mean
                        denom += d * d
                        if a == hwx and b == hwy and c == hwz:
                            center = d
            if denom <= 1e-30:
                out[i, j, k] = 1.0
            else:
                v = center * center / denom
                if v < 0.0:
                    v = 0.0
                elif v > 1.0:
                    v = 1.0
                out[i, j, k] = v

    out = np.ones(se.shape, dtype=np.float64)
    d_se = cuda.to_device(se)
    d_out = cuda.to_device(out)
    threads = (8, 8, 4)
    blocks = ((se.shape[0] + threads[0] - 1) // threads[0],
              (se.shape[1] + threads[1] - 1) // threads[1],
              (se.shape[2] + threads[2] - 1) // threads[2])
    _kern[blocks, threads](d_se, d_out, wx, wy, wz, hwx, hwy, hwz)
    cuda.synchronize()
    return d_out.copy_to_host()


def _gradient_3d_cuda(vol):
    from numba import cuda  # type: ignore

    @cuda.jit
    def _kern(vol, gx, gy, gz):
        i, j, k = cuda.grid(3)
        nx, ny, nz = vol.shape
        if i < nx and j < ny and k < nz:
            if 0 < i < nx - 1:
                gx[i, j, k] = 0.5 * (vol[i + 1, j, k] - vol[i - 1, j, k])
            if 0 < j < ny - 1:
                gy[i, j, k] = 0.5 * (vol[i, j + 1, k] - vol[i, j - 1, k])
            if 0 < k < nz - 1:
                gz[i, j, k] = 0.5 * (vol[i, j, k + 1] - vol[i, j, k - 1])

    gx = np.zeros_like(vol)
    gy = np.zeros_like(vol)
    gz = np.zeros_like(vol)
    d_vol = cuda.to_device(vol)
    d_gx = cuda.to_device(gx)
    d_gy = cuda.to_device(gy)
    d_gz = cuda.to_device(gz)
    threads = (8, 8, 4)
    blocks = ((vol.shape[0] + 7) // 8, (vol.shape[1] + 7) // 8,
              (vol.shape[2] + 3) // 4)
    _kern[blocks, threads](d_vol, d_gx, d_gy, d_gz)
    cuda.synchronize()
    return d_gx.copy_to_host(), d_gy.copy_to_host(), d_gz.copy_to_host()


def _rbf_eval_cuda(centers, x, weights, lengthscale):
    """GPU RBF evaluation -- one thread per query point, summing over centers."""
    from numba import cuda, math  # type: ignore
    n = x.shape[0]
    m = centers.shape[0]
    d = centers.shape[1]
    out = np.zeros(n, dtype=np.float64)

    @cuda.jit
    def _kern(centers, x, weights, out, lengthscale, m, d):
        i = cuda.grid(1)
        if i < n:
            acc = 0.0
            for j in range(m):
                dist2 = 0.0
                for t in range(d):
                    diff = x[i, t] - centers[j, t]
                    dist2 += diff * diff
                acc += weights[j] * math.exp(-dist2 / (lengthscale * lengthscale))
            out[i] = acc

    d_centers = cuda.to_device(centers)
    d_x = cuda.to_device(x)
    d_w = cuda.to_device(weights)
    d_out = cuda.to_device(out)
    threads = 256
    blocks = (n + threads - 1) // threads
    _kern[blocks, threads](d_centers, d_x, d_w, d_out, lengthscale, m, d)
    cuda.synchronize()
    return d_out.copy_to_host()


def _flux_assemble_cuda(trans, press):
    from numba import cuda  # type: ignore

    @cuda.jit
    def _kern(trans, press, flux):
        f, j, k = cuda.grid(3)
        nxf, ny, nz = trans.shape
        if f < nxf and j < ny and k < nz:
            flux[f, j, k] = trans[f, j, k] * (press[f + 1, j, k] - press[f, j, k])

    flux = np.empty_like(trans)
    d_t = cuda.to_device(trans)
    d_p = cuda.to_device(press)
    d_f = cuda.to_device(flux)
    threads = (8, 8, 4)
    blocks = ((trans.shape[0] + 7) // 8, (trans.shape[1] + 7) // 8,
              (trans.shape[2] + 3) // 4)
    _kern[blocks, threads](d_t, d_p, d_f)
    cuda.synchronize()
    return d_f.copy_to_host()


# ---------------------------------------------------------------------------
# Kernel registry (introspection / diagnostics)
# ---------------------------------------------------------------------------

@dataclass
class KernelSpec:
    """Metadata for a GPU-accelerated kernel."""
    name: str
    threshold: int
    numpy_ref: Callable
    dispatcher: Callable
    has_cuda: bool = True
    has_numba_cpu: bool = True


class GpuKernelRegistry:
    """Registry of GPU-accelerated kernels for diagnostics & benchmarking."""

    _kernels: Dict[str, KernelSpec] = {}

    @classmethod
    def register(cls, spec: KernelSpec) -> None:
        cls._kernels[spec.name] = spec

    @classmethod
    def get(cls, name: str) -> Optional[KernelSpec]:
        return cls._kernels.get(name)

    @classmethod
    def all_names(cls) -> list:
        return sorted(cls._kernels)

    @classmethod
    def summary(cls) -> dict:
        return {
            "active_backend": active_backend_name(),
            "cuda_available": _CUDA_AVAILABLE,
            "numba_cpu_available": _NUMBA_CPU_AVAILABLE,
            "kernels": {
                name: {
                    "threshold": spec.threshold,
                    "has_cuda": spec.has_cuda,
                    "has_numba_cpu": spec.has_numba_cpu,
                }
                for name, spec in cls._kernels.items()
            },
        }


# Register the four V37 GPU kernels.
GpuKernelRegistry.register(KernelSpec(
    "coherence_c1", gpu_threshold("coherence_c1"),
    _coherence_c1_numpy, gpu_coherence_c1))
GpuKernelRegistry.register(KernelSpec(
    "gradient_3d", gpu_threshold("gradient_3d"),
    _gradient_3d_numpy, gpu_gradient_3d))
GpuKernelRegistry.register(KernelSpec(
    "rbf_eval", gpu_threshold("rbf_eval"),
    _rbf_eval_numpy, gpu_rbf_eval))
GpuKernelRegistry.register(KernelSpec(
    "flux_assemble", gpu_threshold("flux_assemble"),
    _flux_assemble_numpy, gpu_flux_assemble))


# ---------------------------------------------------------------------------
# Bit-exactness gate
# ---------------------------------------------------------------------------

@dataclass
class GateResult:
    """Result of a bit-exactness gate run."""
    kernel: str
    backend: str
    max_abs_diff: float
    mean_abs_diff: float
    n_elements: int
    passed: bool
    atol: float
    elapsed_s: float = 0.0
    details: dict = field(default_factory=dict)


class BitExactnessGate:
    """Verify a GPU kernel matches its NumPy reference within tolerance.

    This is the safety mechanism that makes GPU acceleration shippable:
    every accelerated kernel is checked against the NumPy ground truth on
    a representative workload.  A regression on the GPU path (different
    math library, different reduction order, fp32-vs-fp64 mismatch)
    surfaces as a gate failure, never as a silent wrong answer in
    production.

    Examples
    --------
    >>> gate = BitExactnessGate(atol=1e-12)
    >>> res = gate.check_coherence(shape=(20, 20, 24))
    >>> res.passed
    True
    """

    def __init__(self, atol: float = 1e-12, rtol: float = 1e-9):
        self.atol = atol
        self.rtol = rtol

    def _compare(self, kernel: str, gpu_out, ref_out) -> GateResult:
        gpu_out = np.asarray(gpu_out, dtype=np.float64)
        ref_out = np.asarray(ref_out, dtype=np.float64)
        diff = np.abs(gpu_out - ref_out)
        max_abs = float(np.max(diff)) if diff.size else 0.0
        mean_abs = float(np.mean(diff)) if diff.size else 0.0
        # elementwise tolerance: |a-b| <= atol + rtol*|b|
        tol = self.atol + self.rtol * np.abs(ref_out)
        passed = bool(np.all(diff <= tol))
        return GateResult(
            kernel=kernel,
            backend=active_backend_name(),
            max_abs_diff=max_abs,
            mean_abs_diff=mean_abs,
            n_elements=int(diff.size),
            passed=passed,
            atol=self.atol,
        )

    def check_coherence(self, shape: Tuple[int, int, int] = (20, 20, 24),
                        window: Tuple[int, int, int] = (5, 5, 9)) -> GateResult:
        rng = np.random.default_rng(123)
        se = rng.standard_normal(shape).astype(np.float64)
        t0 = time.time()
        gpu_out = gpu_coherence_c1(se, window=window)
        ref = _coherence_c1_numpy(se, *window)
        res = self._compare("coherence_c1", gpu_out, ref)
        res.elapsed_s = time.time() - t0
        return res

    def check_gradient(self, shape: Tuple[int, int, int] = (24, 24, 24)) -> GateResult:
        rng = np.random.default_rng(456)
        vol = rng.standard_normal(shape).astype(np.float64)
        t0 = time.time()
        gx, gy, gz = gpu_gradient_3d(vol)
        rx, ry, rz = _gradient_3d_numpy(vol)
        # Compare each component; report the worst.
        res_x = self._compare("gradient_3d", gx, rx)
        res_y = self._compare("gradient_3d", gy, ry)
        res_z = self._compare("gradient_3d", gz, rz)
        worst = max((res_x, res_y, res_z), key=lambda r: r.max_abs_diff)
        worst.elapsed_s = time.time() - t0
        worst.details = {"component_max": {
            "x": res_x.max_abs_diff, "y": res_y.max_abs_diff,
            "z": res_z.max_abs_diff}}
        return worst

    def check_rbf(self, n_centers: int = 64, n_query: int = 512,
                  dim: int = 4) -> GateResult:
        rng = np.random.default_rng(789)
        centers = rng.standard_normal((n_centers, dim))
        x = rng.standard_normal((n_query, dim))
        w = rng.standard_normal(n_centers)
        ls = float(np.median(np.linalg.norm(
            centers[:, None, :] - centers[None, :, :], axis=-1)))
        t0 = time.time()
        gpu_out = gpu_rbf_eval(centers, x, w, ls)
        ref = _rbf_eval_numpy(centers, x, w, ls)
        res = self._compare("rbf_eval", gpu_out, ref)
        res.elapsed_s = time.time() - t0
        return res

    def check_flux(self, shape: Tuple[int, int, int] = (32, 16, 8)) -> GateResult:
        rng = np.random.default_rng(321)
        nx, ny, nz = shape
        trans = rng.uniform(0.1, 10.0, (nx - 1, ny, nz))
        press = rng.uniform(1e6, 5e7, (nx, ny, nz))
        t0 = time.time()
        gpu_out = gpu_flux_assemble(trans, press)
        ref = _flux_assemble_numpy(trans, press)
        res = self._compare("flux_assemble", gpu_out, ref)
        res.elapsed_s = time.time() - t0
        return res

    def check_all(self) -> Dict[str, GateResult]:
        """Run all four bit-exactness checks; return per-kernel results."""
        return {
            "coherence_c1": self.check_coherence(),
            "gradient_3d": self.check_gradient(),
            "rbf_eval": self.check_rbf(),
            "flux_assemble": self.check_flux(),
        }

    def all_passed(self) -> bool:
        return all(r.passed for r in self.check_all().values())


# ---------------------------------------------------------------------------
# Speedup benchmark (GPU vs CPU) -- used by the v37 benchmark case
# ---------------------------------------------------------------------------

def benchmark_speedup(kernel: str = "flux_assemble",
                      sizes: Optional[list] = None) -> dict:
    """Measure GPU-vs-CPU speedup for a kernel across increasing sizes.

    Returns a dict mapping size -> {cpu_s, gpu_s, speedup, n_elements}.
    On a CPU-only environment this still runs (speedup ~1.0, since the
    "GPU" path falls back to Numba-CPU or NumPy), which is the correct
    behaviour for the benchmark case: it reports the *available* speedup,
    not a fabricated one.
    """
    sizes = sizes or [8, 16, 32, 64]
    results = {}
    rng = np.random.default_rng(0)
    for s in sizes:
        if kernel == "flux_assemble":
            trans = rng.uniform(0.1, 10.0, (s - 1, s, max(s // 2, 1)))
            press = rng.uniform(1e6, 5e7, (s, s, max(s // 2, 1)))
            t0 = time.time(); _flux_assemble_numpy(trans, press); cpu_s = time.time() - t0
            t0 = time.time(); gpu_flux_assemble(trans, press); gpu_s = time.time() - t0
            n = trans.size
        elif kernel == "gradient_3d":
            vol = rng.standard_normal((s, s, s))
            t0 = time.time(); _gradient_3d_numpy(vol); cpu_s = time.time() - t0
            t0 = time.time(); gpu_gradient_3d(vol); gpu_s = time.time() - t0
            n = vol.size
        elif kernel == "coherence_c1":
            se = rng.standard_normal((s, s, max(s, 12)))
            t0 = time.time(); _coherence_c1_numpy(se, 5, 5, 9); cpu_s = time.time() - t0
            t0 = time.time(); gpu_coherence_c1(se, (5, 5, 9)); gpu_s = time.time() - t0
            n = se.size
        else:
            raise ValueError(f"unknown kernel {kernel!r}")
        results[s] = {
            "cpu_s": cpu_s, "gpu_s": gpu_s,
            "speedup": cpu_s / gpu_s if gpu_s > 0 else 0.0,
            "n_elements": n,
        }
    return results
