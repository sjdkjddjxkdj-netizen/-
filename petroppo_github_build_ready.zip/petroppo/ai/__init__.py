"""petroppo AI — interpretation intelligence.

V31 introduces the **AI Seismic Copilot**: an interpretation
assistant that reads a 3-D seismic volume and *automatically*
proposes geological features — horizons, faults, salt boundaries,
channels, geological bodies, and lead / prospect candidates — each
with a confidence map, so the interpreter can accept, reject, or
edit every proposal.

This package wraps the copilot and related AI-interpretation
utilities.  Heavy ML is delegated to scikit-learn (already a
dependency of the V17 AI engine).
"""
from __future__ import annotations

from .copilot import (
    SeismicCopilot,
    CopilotResult,
    HorizonProposal,
    FaultProposal,
    SaltBoundaryProposal,
    ChannelProposal,
    GeologicalBodyProposal,
    LeadProposal,
)

__all__ = [
    "SeismicCopilot",
    "CopilotResult",
    "HorizonProposal",
    "FaultProposal",
    "SaltBoundaryProposal",
    "ChannelProposal",
    "GeologicalBodyProposal",
    "LeadProposal",
]
