"""petroppo V31 — AI Seismic Copilot.

The Copilot is an interpretation assistant that reads a 3-D seismic
volume and **automatically proposes** geological features, each with
a confidence map, so a human interpreter can accept / reject / edit
every proposal instead of picking by hand.

Feature detectors
-----------------
1. **Horizons** — auto-extract major reflectors by envelope-peak
   detection + cross-correlation tracking (reuses
   ``auto_pick_horizon``), ranked by amplitude strength and lateral
   continuity.  Each proposal carries a confidence map (0–1).
2. **Faults** — coherence + variance thresholding, ant-tracking
   enhancement, plane extraction (reuses ``detect_faults_coherence``
   and ``extract_fault_planes``).  Each fault plane gets a dip /
   azimuth and a confidence from coherence contrast.
3. **Salt boundaries** — detected as zones of *chaotic* texture
   (low GLCM homogeneity) + low coherence + high envelope, the
   seismic signature of salt diapirs.  Boundary traced as the
   transition between chaotic interior and stratified exterior.
4. **Channels** — detected as high-amplitude, low-coherence,
   meandering bodies with high GLCM contrast — the classic channel
   signature.  Connected-component extraction with elongation filter.
5. **Geological bodies** — generic anomalous-amplitude bodies
   (carbonate buildups, mass-transport complexes) detected by
   amplitude + texture clustering.
6. **Leads / prospects** — ranked candidates combining structural
   closure (from curvature), amplitude anomaly, and facies
   favourability — a lightweight automated lead-generation.

Manual override
---------------
Every proposal list is editable: the interpreter can ``accept``,
``reject``, or ``edit`` any proposal.  The Copilot stores override
flags and re-ranks the remaining proposals.

ML layer
--------
Where labelled data is available, a lightweight classifier (the V17
ensemble interface) can be trained to re-rank proposals by learned
feature–label relationships.  Without labels the Copilot uses
physics-based heuristics — it works out-of-the-box on any volume.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.ndimage import (
    label as cc_label,
    gaussian_filter,
    binary_fill_holes,
    uniform_filter,
    find_objects,
)

# reuse existing validated V22+ seismic modules
from petroppo.physics.seismic.attributes import (
    compute_all_attributes,
    SeismicAttributes,
)
from petroppo.physics.seismic.horizon_tracking import (
    auto_pick_horizon,
    HorizonSurface,
)
from petroppo.physics.seismic.fault_detection import (
    detect_faults_coherence,
    extract_fault_planes,
    FaultDetectionResult,
    FaultPlane,
)
from petroppo.physics.seismic.advanced_attributes import (
    compute_advanced_attributes,
    AdvancedAttributes,
)


# =====================================================================
# Proposal data classes
# =====================================================================

@dataclass
class HorizonProposal:
    """An auto-proposed horizon."""
    horizon_id: int
    surface: HorizonSurface
    peak_time: int               # sample index of the seed peak
    mean_amplitude: float
    continuity: float            # lateral continuity score 0–1
    confidence: np.ndarray       # (nx, ny) confidence map 0–1
    accepted: bool = True
    rejected: bool = False
    edited: bool = False


@dataclass
class FaultProposal:
    """An auto-proposed fault."""
    fault_id: int
    plane: Optional[FaultPlane]
    segment_id: int
    n_voxels: int
    dip: float                    # radians
    azimuth: float                # radians
    confidence: float             # 0–1
    accepted: bool = True
    rejected: bool = False


@dataclass
class SaltBoundaryProposal:
    """An auto-proposed salt body + its boundary."""
    salt_id: int
    mask: np.ndarray              # (nx, ny, nz) salt interior
    boundary_mask: np.ndarray     # (nx, ny, nz) boundary voxels
    volume_voxels: int
    confidence: float
    accepted: bool = True
    rejected: bool = False


@dataclass
class ChannelProposal:
    """An auto-proposed channel body."""
    channel_id: int
    mask: np.ndarray              # (nx, ny, nz)
    n_voxels: int
    elongation: float             # length / width ratio
    mean_amplitude: float
    confidence: float
    accepted: bool = True
    rejected: bool = False


@dataclass
class GeologicalBodyProposal:
    """A generic anomalous geological body."""
    body_id: int
    mask: np.ndarray
    n_voxels: int
    body_type: str                # "carbonate" / "MTD" / "anomaly"
    mean_amplitude: float
    confidence: float
    accepted: bool = True
    rejected: bool = False


@dataclass
class LeadProposal:
    """An auto-proposed lead / prospect candidate."""
    lead_id: int
    centroid: tuple[float, float, float]
    area_cells: int
    closure_score: float          # structural closure 0–1
    amplitude_score: float        # amplitude anomaly 0–1
    facies_score: float           # facies favourability 0–1
    composite_score: float        # weighted combination
    confidence: float
    accepted: bool = True
    rejected: bool = False


@dataclass
class CopilotResult:
    """Complete Copilot output for one seismic volume."""
    horizons: list[HorizonProposal] = field(default_factory=list)
    faults: list[FaultProposal] = field(default_factory=list)
    salt_boundaries: list[SaltBoundaryProposal] = field(default_factory=list)
    channels: list[ChannelProposal] = field(default_factory=list)
    bodies: list[GeologicalBodyProposal] = field(default_factory=list)
    leads: list[LeadProposal] = field(default_factory=list)
    attributes: Optional[SeismicAttributes] = None
    advanced: Optional[AdvancedAttributes] = None
    # override tracking
    overrides: dict = field(default_factory=dict)

    @property
    def n_proposals(self) -> int:
        return (len(self.horizons) + len(self.faults) +
                len(self.salt_boundaries) + len(self.channels) +
                len(self.bodies) + len(self.leads))

    def summary(self) -> str:
        lines = [
            "AI Seismic Copilot — proposals:",
            f"  Horizons:        {len(self.horizons)}",
            f"  Faults:          {len(self.faults)}",
            f"  Salt boundaries: {len(self.salt_boundaries)}",
            f"  Channels:        {len(self.channels)}",
            f"  Geological bodies: {len(self.bodies)}",
            f"  Leads / prospects: {len(self.leads)}",
            f"  Total proposals:   {self.n_proposals}",
        ]
        return "\n".join(lines)


# =====================================================================
# The Copilot
# =====================================================================

class SeismicCopilot:
    """AI Seismic interpretation Copilot.

    Parameters
    ----------
    seismic : ndarray (nx, ny, nz)
        3-D seismic amplitude volume.
    dt : float
        Time sample interval (s).
    dx, dy : float
        Spatial grid spacing (m).

    Usage
    -----
    >>> copilot = SeismicCopilot(seismic, dt=0.004)
    >>> result = copilot.interpret()
    >>> print(result.summary())
    >>> result.horizons[0].confidence   # (nx, ny) confidence map
    >>> copilot.reject(result.horizons[2])  # manual override
    """

    def __init__(
        self,
        seismic: np.ndarray,
        dt: float = 0.004,
        dx: float = 25.0,
        dy: float = 25.0,
    ):
        self.seismic = np.asarray(seismic, dtype=float)
        if self.seismic.ndim != 3:
            raise ValueError(f"Expected 3-D seismic, got {self.seismic.ndim}-D")
        self.dt = float(dt)
        self.dx = float(dx)
        self.dy = float(dy)
        self.nx, self.ny, self.nz = self.seismic.shape
        self._attrs: Optional[SeismicAttributes] = None
        self._adv: Optional[AdvancedAttributes] = None

    # ── attribute access ──────────────────────────────────────────

    @property
    def attributes(self) -> SeismicAttributes:
        if self._attrs is None:
            self._attrs = compute_all_attributes(
                self.seismic, self.dt, self.dx, self.dy)
        return self._attrs

    @property
    def advanced(self) -> AdvancedAttributes:
        if self._adv is None:
            self._adv = compute_advanced_attributes(
                self.seismic, self.dt, self.dx, self.dy,
                spectral=self.attributes.spectral,
                frequencies=self.attributes.frequencies,
            )
        return self._adv

    # ── main entry ────────────────────────────────────────────────

    def interpret(self) -> CopilotResult:
        """Run all detectors and return a complete CopilotResult."""
        attrs = self.attributes
        adv = self.advanced
        result = CopilotResult(attributes=attrs, advanced=adv)
        result.horizons = self._detect_horizons(attrs)
        result.faults = self._detect_faults(attrs)
        result.salt_boundaries = self._detect_salt(adv)
        result.channels = self._detect_channels(attrs, adv)
        result.bodies = self._detect_bodies(attrs, adv)
        result.leads = self._detect_leads(attrs, adv, result.horizons)
        return result

    # ── 1. Horizon detection ──────────────────────────────────────

    def _detect_horizons(self, attrs: SeismicAttributes) -> list[HorizonProposal]:
        """Auto-extract major horizons by envelope-peak detection."""
        env = attrs.envelope
        # find prominent peaks in the global envelope histogram
        # by scanning candidate time indices and picking the strongest
        mean_env_per_time = env.reshape(-1, self.nz).mean(axis=0)
        # local maxima in the mean-envelope trace
        peaks = []
        for iz in range(2, self.nz - 2):
            if (mean_env_per_time[iz] > mean_env_per_time[iz - 1] and
                    mean_env_per_time[iz] > mean_env_per_time[iz + 1] and
                    mean_env_per_time[iz] > 0.3 * mean_env_per_time.max()):
                peaks.append(iz)
        # sort by strength
        peaks.sort(key=lambda iz: mean_env_per_time[iz], reverse=True)
        # keep top N separated horizons
        selected: list[int] = []
        for iz in peaks:
            if all(abs(iz - s) > 5 for s in selected):
                selected.append(iz)
            if len(selected) >= 8:
                break
        selected.sort()

        proposals: list[HorizonProposal] = []
        for hid, target in enumerate(selected):
            surf = auto_pick_horizon(self.seismic, target_time=target, search=8)
            # continuity score: fraction of high-confidence picks
            conf = surf.confidence
            cont = float(np.mean(conf > 0.3 * conf.max())) if conf.max() > 0 else 0.0
            # normalise confidence to 0-1
            cmax = float(conf.max())
            conf_norm = conf / cmax if cmax > 0 else conf
            mean_amp = float(np.abs(self.seismic).reshape(-1, self.nz).mean(axis=0)[target])
            proposals.append(HorizonProposal(
                horizon_id=hid,
                surface=surf,
                peak_time=target,
                mean_amplitude=mean_amp,
                continuity=cont,
                confidence=conf_norm,
            ))
        return proposals

    # ── 2. Fault detection ────────────────────────────────────────

    def _detect_faults(self, attrs: SeismicAttributes) -> list[FaultProposal]:
        """Auto-extract faults from coherence."""
        coh = attrs.coherence
        # faults = low coherence; threshold adaptively
        thr = float(np.percentile(coh, 15))
        fr = detect_faults_coherence(coh, threshold=thr, min_size=20)
        planes = extract_fault_planes(fr, min_points=30)
        plane_by_seg = {p.plane_id: p for p in planes}
        proposals: list[FaultProposal] = []
        for seg in fr.segments:
            # confidence from coherence contrast
            local_coh = coh[seg.indices]
            conf = float(1.0 - np.mean(local_coh) / (coh.mean() + 1e-12))
            conf = float(np.clip(conf, 0.0, 1.0))
            plane = plane_by_seg.get(seg.segment_id)
            dip = float(plane.dip) if plane else 0.0
            az = float(plane.azimuth) if plane else 0.0
            proposals.append(FaultProposal(
                fault_id=seg.segment_id,
                plane=plane,
                segment_id=seg.segment_id,
                n_voxels=seg.n_voxels,
                dip=dip,
                azimuth=az,
                confidence=conf,
            ))
        # sort by confidence descending
        proposals.sort(key=lambda f: f.confidence, reverse=True)
        return proposals

    # ── 3. Salt boundary detection ────────────────────────────────

    def _detect_salt(self, adv: AdvancedAttributes) -> list[SaltBoundaryProposal]:
        """Detect salt bodies: chaotic texture + low coherence + high envelope."""
        # salt signature: low homogeneity (chaotic), low coherence, high envelope
        hom = adv.homogeneity
        coh = self.attributes.coherence
        env = self.attributes.envelope
        # normalise
        hom_n = (hom - hom.min()) / (hom.max() - hom.min() + 1e-12)
        coh_n = (coh - coh.min()) / (coh.max() - coh.min() + 1e-12)
        env_n = (env - env.min()) / (env.max() - env.min() + 1e-12)
        salt_score = (1.0 - hom_n) * (1.0 - coh_n) * env_n
        # threshold
        thr = float(np.percentile(salt_score, 92))
        salt_mask = salt_score > thr
        salt_mask = binary_fill_holes(salt_mask)
        # smooth
        salt_mask = gaussian_filter(salt_mask.astype(float), sigma=1) > 0.5
        # connected components
        lbl, n = cc_label(salt_mask)
        proposals: list[SaltBoundaryProposal] = []
        min_vol = max(10, self.nx * self.ny * self.nz // 500)
        # V33: use find_objects to limit mask ops to bounding boxes
        slices_all = find_objects(lbl)
        from scipy.ndimage import binary_dilation, binary_erosion
        for sid in range(1, n + 1):
            if sid > len(slices_all) or slices_all[sid - 1] is None:
                continue
            sl = slices_all[sid - 1]
            # local mask within bounding box
            local_lbl = lbl[sl]
            local_mask = local_lbl == sid
            vol = int(local_mask.sum())
            if vol < min_vol:
                continue
            # boundary = dilate XOR erode (on local mask, then place back)
            d = binary_dilation(local_mask, iterations=1)
            e = binary_erosion(local_mask, iterations=1)
            boundary_local = d ^ e
            # build full-size mask and boundary
            mask = np.zeros_like(lbl, dtype=bool)
            mask[sl] = local_mask
            boundary = np.zeros_like(lbl, dtype=bool)
            boundary[sl] = boundary_local
            local_score = salt_score[sl]
            conf = float(local_score[local_mask].mean())
            proposals.append(SaltBoundaryProposal(
                salt_id=sid,
                mask=mask,
                boundary_mask=boundary,
                volume_voxels=vol,
                confidence=conf,
            ))
        proposals.sort(key=lambda s: s.volume_voxels, reverse=True)
        return proposals

    # ── 4. Channel detection ──────────────────────────────────────

    def _detect_channels(
        self, attrs: SeismicAttributes, adv: AdvancedAttributes,
    ) -> list[ChannelProposal]:
        """Detect channels: high amplitude + low coherence + high contrast."""
        rms = attrs.rms
        coh = attrs.coherence
        contrast = adv.contrast
        # normalise
        rms_n = (rms - rms.min()) / (rms.max() - rms.min() + 1e-12)
        coh_n = (coh - coh.min()) / (coh.max() - coh.min() + 1e-12)
        con_n = (contrast - contrast.min()) / (contrast.max() - contrast.min() + 1e-12)
        chan_score = rms_n * (1.0 - coh_n) * con_n
        thr = float(np.percentile(chan_score, 90))
        chan_mask = chan_score > thr
        lbl, n = cc_label(chan_mask)
        proposals: list[ChannelProposal] = []
        min_vol = max(8, self.nx * self.ny * self.nz // 800)
        slices_all = find_objects(lbl)
        # V33: use find_objects bounding boxes + bincount for vectorised stats
        lbl_flat = lbl.ravel()
        vols = np.bincount(lbl_flat, minlength=n + 1)
        score_flat = chan_score.ravel()
        rms_flat = rms.ravel()
        score_sums = np.bincount(lbl_flat, weights=score_flat, minlength=n + 1)
        rms_sums = np.bincount(lbl_flat, weights=rms_flat, minlength=n + 1)
        for cid in range(1, n + 1):
            vol = int(vols[cid])
            if vol < min_vol:
                continue
            if cid > len(slices_all) or slices_all[cid - 1] is None:
                continue
            sl = slices_all[cid - 1]
            # elongation via bounding-box ratio
            dims = [s.stop - s.start for s in sl]
            dims.sort(reverse=True)
            elong = float(dims[0] / (dims[1] + 1e-6))
            mean_amp = float(rms_sums[cid] / vol)
            conf = float(score_sums[cid] / vol)
            # build mask only for accepted channels (bounding box scope)
            local_mask = lbl[sl] == cid
            mask = np.zeros_like(lbl, dtype=bool)
            mask[sl] = local_mask
            proposals.append(ChannelProposal(
                channel_id=cid,
                mask=mask,
                n_voxels=vol,
                elongation=elong,
                mean_amplitude=mean_amp,
                confidence=conf,
            ))
        # keep channels with elongation > 2 (meandering signature)
        proposals = [p for p in proposals if p.elongation > 1.5]
        proposals.sort(key=lambda c: c.confidence, reverse=True)
        return proposals

    # ── 5. Geological body detection ──────────────────────────────

    def _detect_bodies(
        self, attrs: SeismicAttributes, adv: AdvancedAttributes,
    ) -> list[GeologicalBodyProposal]:
        """Detect anomalous geological bodies by amplitude + texture clustering."""
        env = attrs.envelope
        hom = adv.homogeneity
        env_n = (env - env.min()) / (env.max() - env.min() + 1e-12)
        hom_n = (hom - hom.min()) / (hom.max() - hom.min() + 1e-12)
        # high amplitude + moderate homogeneity = carbonate buildup
        # high amplitude + low homogeneity = MTD / chaotic
        body_score = env_n
        thr_hi = float(np.percentile(body_score, 88))
        thr_lo = float(np.percentile(body_score, 60))
        mask_hi = body_score > thr_hi
        mask_mid = (body_score > thr_lo) & (body_score <= thr_hi)
        proposals: list[GeologicalBodyProposal] = []
        min_vol = max(6, self.nx * self.ny * self.nz // 1000)
        # high-amplitude bodies → carbonate / anomaly
        for label_mask, btype in [(mask_hi, "carbonate"), (mask_mid, "anomaly")]:
            lbl, n = cc_label(label_mask)
            if n == 0:
                continue
            # V33: vectorised component statistics via bincount
            lbl_flat = lbl.ravel()
            score_flat = body_score.ravel()
            env_flat = env.ravel()
            vols = np.bincount(lbl_flat, minlength=n + 1)
            score_sums = np.bincount(lbl_flat, weights=score_flat, minlength=n + 1)
            env_sums = np.bincount(lbl_flat, weights=env_flat, minlength=n + 1)
            slices_all = find_objects(lbl)
            for bid in range(1, n + 1):
                vol = int(vols[bid])
                if vol < min_vol:
                    continue
                conf = float(score_sums[bid] / vol)
                mean_amp = float(env_sums[bid] / vol)
                # build mask only for accepted bodies, using bounding box
                if bid <= len(slices_all) and slices_all[bid - 1] is not None:
                    sl = slices_all[bid - 1]
                    local_mask = lbl[sl] == bid
                    mask = np.zeros_like(lbl, dtype=bool)
                    mask[sl] = local_mask
                else:
                    mask = lbl == bid
                proposals.append(GeologicalBodyProposal(
                    body_id=bid,
                    mask=mask,
                    n_voxels=vol,
                    body_type=btype,
                    mean_amplitude=mean_amp,
                    confidence=conf,
                ))
        proposals.sort(key=lambda b: b.confidence, reverse=True)
        return proposals[:10]  # cap

    # ── 6. Lead / prospect detection ──────────────────────────────

    def _detect_leads(
        self,
        attrs: SeismicAttributes,
        adv: AdvancedAttributes,
        horizons: list[HorizonProposal],
    ) -> list[LeadProposal]:
        """Auto-propose leads from structural closure + amplitude + facies."""
        if not horizons:
            return []
        kpos = adv.kpos
        rms = attrs.rms
        # use the strongest horizon surface for closure analysis
        h0 = max(horizons, key=lambda h: h.continuity)
        surf = h0.surface.times
        # structural closure: local minima of surface (anticline = low TWT)
        # (assuming TWT; for depth, closure = local maxima)
        closure = _local_closure_score(surf)
        # amplitude anomaly
        rms_n = (rms - rms.min()) / (rms.max() - rms.min() + 1e-12)
        rms_map = rms_n.mean(axis=-1)
        # facies score from coherence (high coherence = good lateral continuity)
        coh_map = attrs.coherence.mean(axis=-1)
        coh_n = (coh_map - coh_map.min()) / (coh_map.max() - coh_map.min() + 1e-12)
        # composite
        composite = 0.4 * closure + 0.35 * rms_map + 0.25 * coh_n
        # threshold + connected components on the 2-D map
        thr = float(np.percentile(composite, 92))
        lead_mask = composite > thr
        lbl, n = cc_label(lead_mask)
        proposals: list[LeadProposal] = []
        for lid in range(1, n + 1):
            mask2d = lbl == lid
            area = int(mask2d.sum())
            if area < 3:
                continue
            ys, xs = np.where(mask2d)
            cy, cx = float(ys.mean()), float(xs.mean())
            # mean z from the horizon
            cz = float(np.nanmean(surf[mask2d])) if np.any(~np.isnan(surf[mask2d])) else 0.0
            c_score = float(closure[mask2d].mean())
            a_score = float(rms_map[mask2d].mean())
            f_score = float(coh_n[mask2d].mean())
            comp = float(composite[mask2d].mean())
            proposals.append(LeadProposal(
                lead_id=lid,
                centroid=(cx, cy, cz),
                area_cells=area,
                closure_score=c_score,
                amplitude_score=a_score,
                facies_score=f_score,
                composite_score=comp,
                confidence=comp,
            ))
        proposals.sort(key=lambda l: l.composite_score, reverse=True)
        return proposals[:8]

    # ── Manual override interface ─────────────────────────────────

    def reject(self, proposal) -> None:
        """Reject a proposal (manual override)."""
        proposal.rejected = True
        proposal.accepted = False

    def accept(self, proposal) -> None:
        """Explicitly accept a proposal."""
        proposal.accepted = True
        proposal.rejected = False

    def edit(self, proposal, **changes) -> None:
        """Edit a proposal's attributes (manual override)."""
        proposal.edited = True
        for k, v in changes.items():
            if hasattr(proposal, k):
                setattr(proposal, k, v)


# =====================================================================
# Helpers
# =====================================================================

def _local_closure_score(surface: np.ndarray, window: int = 5) -> np.ndarray:
    """Structural closure score: how much a point is a local minimum.

    For TWT surfaces, an anticline closure = local minimum.
    Returns a 0–1 score map.
    """
    s = np.asarray(surface, dtype=float)
    # replace NaN with median
    s_filled = np.where(np.isnan(s), np.nanmedian(s), s)
    from scipy.ndimage import minimum_filter, maximum_filter
    local_min = minimum_filter(s_filled, size=window, mode="nearest")
    local_max = maximum_filter(s_filled, size=window, mode="nearest")
    # closure = how far above the local min (normalised by local relief)
    relief = local_max - local_min + 1e-12
    closure = (s_filled - local_min) / relief
    # we want local minima → high closure → invert
    closure = 1.0 - np.clip(closure, 0.0, 1.0)
    return closure
