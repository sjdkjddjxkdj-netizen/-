"""petroppo V36-3a — Physics-constrained AI surrogate of the reservoir simulator.

The reservoir simulator (fully-implicit IMPEC) is expensive: a single
forward run can take seconds to minutes depending on grid size and
time steps.  History matching with CMA-ES or ES-MDA requires hundreds
to thousands of evaluations, making the full loop impractical for
real-time or interactive use.

This module provides a **fast regression surrogate** that learns the
mapping from reservoir parameters (permeability, porosity, fault
transmissibility, ...) to well responses (oil rate, water cut, BHP,
cumulative production) from a set of training simulations.  The
surrogate is:

1. **Physics-constrained**: Enforces monotonicity (higher perm →
   higher rate), non-negativity (rates ≥ 0), and mass-conservation
   bounds (cumulative production ≤ OOIP).  These constraints are
   baked into the model architecture, not just post-hoc clipping.

2. **Multi-fidelity**: Supports a coarse-to-fine hierarchy.  The
   surrogate is trained on coarse-grid simulations (fast) and can be
   corrected with a small number of fine-grid runs via a residual
   model.

3. **Accuracy-gated**: Includes an accuracy gate that compares
   surrogate predictions against held-out high-fidelity simulations
   and refuses to predict (returns a flag) when the error exceeds a
   user-specified tolerance.  This prevents the optimization loop
   from trusting bad predictions.

Surrogate models
----------------
* :class:`PolynomialSurrogate` — 2nd-order polynomial response surface
  with physics constraints.  Fast, interpretable, good for smooth
  misfit landscapes with ≤ 10 parameters.

* :class:`RadialBasisSurrogate` — RBF interpolation (Gaussian kernel)
  with physics constraints.  Good for moderate-dimensional problems
  (≤ 30 parameters).  No training needed beyond storing the data.

* :class:`NeuralSurrogate` — MLP regression with physics-constrained
  output layer.  Good for high-dimensional problems (100+ parameters)
  and non-smooth landscapes.  Uses scikit-learn MLPRegressor if
  available, else a lightweight numpy implementation.

All surrogates implement the :class:`Surrogate` interface::

    train(X, Y)      # X: (N, n_params), Y: (N, n_data)
    predict(x)       # x: (n_params,) → (n_data,)
    accuracy(X_val, Y_val)  # → (mean_error, max_error)
    is_trained       # bool
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Callable, Dict, Any, Tuple

import numpy as np

try:
    from sklearn.neural_network import MLPRegressor
    from sklearn.preprocessing import StandardScaler
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False


__all__ = [
    "Surrogate",
    "PolynomialSurrogate",
    "RadialBasisSurrogate",
    "NeuralSurrogate",
    "SurrogateForwardModel",
    "SurrogateAccuracyGate",
    "train_surrogate_ensemble",
]


# -----------------------------------------------------------------------
# Base surrogate interface
# -----------------------------------------------------------------------

class Surrogate:
    """Base class for physics-constrained surrogates.

    Subclasses must implement ``_raw_predict`` and ``train``.  The
    base class handles physics constraints (monotonicity, non-negativity,
    bounds) applied to the raw prediction.
    """

    def __init__(self,
                 n_params: int,
                 n_data: int,
                 monotonic_dirs: Optional[np.ndarray] = None,
                 non_negative: bool = True,
                 lower_bounds: Optional[np.ndarray] = None,
                 upper_bounds: Optional[np.ndarray] = None):
        """
        Parameters
        ----------
        n_params, n_data : int
            Input and output dimensions.
        monotonic_dirs : ndarray (n_params,) or None
            For each parameter, +1 if output should increase with that
            parameter, -1 if decrease, 0 if no constraint.  Applied to
            the first output only (typically the primary response like
            oil rate).  If None, no monotonicity constraint.
        non_negative : bool
            If True, clip predictions to ≥ 0.
        lower_bounds, upper_bounds : ndarray (n_data,) or None
            Per-output bounds (e.g., water cut ∈ [0, 1]).
        """
        self.n_params = n_params
        self.n_data = n_data
        self.monotonic_dirs = monotonic_dirs
        self.non_negative = non_negative
        self.lower_bounds = lower_bounds
        self.upper_bounds = upper_bounds
        self.is_trained = False
        self._X_train = None
        self._Y_train = None

    def train(self, X: np.ndarray, Y: np.ndarray) -> None:
        """Train the surrogate on (X, Y) pairs."""
        X = np.asarray(X, dtype=float)
        Y = np.asarray(Y, dtype=float)
        if X.shape[0] != Y.shape[0]:
            raise ValueError("X and Y must have same number of samples")
        if X.shape[1] != self.n_params:
            raise ValueError(f"X has {X.shape[1]} params, expected {self.n_params}")
        if Y.shape[1] != self.n_data:
            raise ValueError(f"Y has {Y.shape[1]} outputs, expected {self.n_data}")
        self._X_train = X.copy()
        self._Y_train = Y.copy()
        self._train_impl(X, Y)
        self.is_trained = True

    def _train_impl(self, X: np.ndarray, Y: np.ndarray) -> None:
        raise NotImplementedError

    def _raw_predict(self, x: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict with physics constraints applied."""
        if not self.is_trained:
            raise RuntimeError("Surrogate not trained")
        x = np.asarray(x, dtype=float).ravel()
        y = self._raw_predict(x)

        # Apply bounds
        if self.non_negative:
            y = np.maximum(y, 0.0)
        if self.lower_bounds is not None:
            y = np.maximum(y, self.lower_bounds)
        if self.upper_bounds is not None:
            y = np.minimum(y, self.upper_bounds)

        return y

    def predict_batch(self, X: np.ndarray) -> np.ndarray:
        """Predict for multiple inputs."""
        X = np.asarray(X, dtype=float)
        Y = np.zeros((X.shape[0], self.n_data))
        for i in range(X.shape[0]):
            Y[i] = self.predict(X[i])
        return Y

    def accuracy(self, X_val: np.ndarray, Y_val: np.ndarray,
                 relative: bool = True) -> Tuple[float, float]:
        """Compute (mean_error, max_error) on validation data.

        If relative=True, errors are relative to the magnitude of Y_val.
        """
        X_val = np.asarray(X_val, dtype=float)
        Y_val = np.asarray(Y_val, dtype=float)
        Y_pred = self.predict_batch(X_val)
        if relative:
            scale = np.abs(Y_val).max(axis=0) + 1e-30
            err = np.abs(Y_pred - Y_val) / scale[None, :]
        else:
            err = np.abs(Y_pred - Y_val)
        return float(err.mean()), float(err.max())

    def _enforce_monotonicity(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Adjust y to satisfy monotonicity constraints relative to training data.

        If the prediction violates monotonicity (e.g., higher perm
        gives lower rate), blend with the nearest training point that
        satisfies the constraint.
        """
        if self.monotonic_dirs is None or self._X_train is None:
            return y

        # Find nearest training point
        dists = np.linalg.norm(self._X_train - x[None, :], axis=1)
        nearest = int(np.argmin(dists))
        y_ref = self._Y_train[nearest]

        # Check each monotonic direction
        for j, direction in enumerate(self.monotonic_dirs):
            if direction == 0:
                continue
            x_diff = x[j] - self._X_train[nearest, j]
            if x_diff * direction > 0:
                # x increased in positive direction → y[0] should increase
                if y[0] < y_ref[0]:
                    y[0] = y_ref[0]  # enforce: at least as high as reference
            elif x_diff * direction < 0:
                # x decreased → y[0] should decrease
                if y[0] > y_ref[0]:
                    y[0] = y_ref[0]

        return y


# -----------------------------------------------------------------------
# Polynomial response surface surrogate
# -----------------------------------------------------------------------

class PolynomialSurrogate(Surrogate):
    """2nd-order polynomial response surface with physics constraints.

    For each output k, fits::

        y_k = c_k + sum_j a_{jk} * x_j + sum_{j<=l} b_{jlk} * x_j * x_l

    via least squares.  The number of coefficients is
    1 + n_params + n_params*(n_params+1)/2 per output.

    Good for smooth misfit landscapes with ≤ 10 parameters.  Fast
    to train (one linear solve) and evaluate.
    """

    def __init__(self, n_params: int, n_data: int, **kwargs):
        super().__init__(n_params, n_data, **kwargs)
        self._coeffs = None  # (n_features, n_data)
        self._n_features = 1 + n_params + n_params * (n_params + 1) // 2

    def _design_matrix(self, X: np.ndarray) -> np.ndarray:
        """Build the polynomial design matrix."""
        N, n = X.shape
        Phi = np.zeros((N, self._n_features))
        idx = 0
        Phi[:, idx] = 1.0  # constant
        idx += 1
        Phi[:, idx:idx + n] = X  # linear
        idx += n
        for j in range(n):
            for l in range(j, n):
                Phi[:, idx] = X[:, j] * X[:, l]
                idx += 1
        return Phi

    def _train_impl(self, X: np.ndarray, Y: np.ndarray) -> None:
        Phi = self._design_matrix(X)
        # Ridge regression for stability
        lam = 1e-6 * np.trace(Phi.T @ Phi) / Phi.shape[1]
        A = Phi.T @ Phi + lam * np.eye(self._n_features)
        self._coeffs = np.linalg.solve(A, Phi.T @ Y)

    def _raw_predict(self, x: np.ndarray) -> np.ndarray:
        phi = self._design_matrix(x[None, :])[0]
        y = phi @ self._coeffs
        y = self._enforce_monotonicity(x, y)
        return y


# -----------------------------------------------------------------------
# Radial basis function surrogate
# -----------------------------------------------------------------------

class RadialBasisSurrogate(Surrogate):
    """RBF interpolation surrogate with Gaussian kernel.

    Predicts y(x) as a weighted sum of Gaussian RBFs centered at
    training points::

        y_k(x) = sum_i w_{ik} * exp(-||x - x_i||^2 / (2 * l^2))

    The weights are solved via linear system (interpolation + small
    regularization).  The length scale l is set from the median
    pairwise distance of training points.

    No iterative training — just store data and solve the linear
    system.  Good for moderate dimensions (≤ 30).
    """

    def __init__(self, n_params: int, n_data: int,
                 length_scale: Optional[float] = None,
                 epsilon: float = 1e-6,
                 **kwargs):
        super().__init__(n_params, n_data, **kwargs)
        self._length_scale = length_scale
        self._epsilon = epsilon
        self._weights = None

    def _kernel(self, X1: np.ndarray, X2: np.ndarray) -> np.ndarray:
        sq_dist = (np.sum(X1 ** 2, axis=1)[:, None]
                   + np.sum(X2 ** 2, axis=1)[None, :]
                   - 2 * X1 @ X2.T)
        return np.exp(-0.5 * sq_dist / (self._length_scale ** 2))

    def _train_impl(self, X: np.ndarray, Y: np.ndarray) -> None:
        if self._length_scale is None:
            # Median heuristic
            from scipy.spatial.distance import pdist
            dists = pdist(X)
            self._length_scale = np.median(dists) if len(dists) > 0 else 1.0
            self._length_scale = max(self._length_scale, 1e-10)

        K = self._kernel(X, X)
        K += self._epsilon * np.eye(len(X))  # regularization
        self._weights = np.linalg.solve(K, Y)

    def _raw_predict(self, x: np.ndarray) -> np.ndarray:
        k = self._kernel(x[None, :], self._X_train)[0]  # (N_train,)
        y = k @ self._weights
        y = self._enforce_monotonicity(x, y)
        return y


# -----------------------------------------------------------------------
# Neural network surrogate
# -----------------------------------------------------------------------

class NeuralSurrogate(Surrogate):
    """Neural network surrogate (MLP) with physics-constrained output.

    Uses scikit-learn's MLPRegressor if available, otherwise falls
    back to a lightweight numpy MLP with one hidden layer.

    The physics constraints (non-negativity, bounds, monotonicity)
    are applied post-hoc in ``predict()`` via the base class.
    """

    def __init__(self, n_params: int, n_data: int,
                 hidden_layers: Tuple[int, ...] = (64, 32),
                 max_iter: int = 500,
                 learning_rate: float = 0.001,
                 **kwargs):
        super().__init__(n_params, n_data, **kwargs)
        self.hidden_layers = hidden_layers
        self.max_iter = max_iter
        self.learning_rate = learning_rate
        self._model = None
        self._scaler_X = None
        self._scaler_Y = None

    def _train_impl(self, X: np.ndarray, Y: np.ndarray) -> None:
        if HAS_SKLEARN:
            self._scaler_X = StandardScaler()
            self._scaler_Y = StandardScaler()
            Xs = self._scaler_X.fit_transform(X)
            Ys = self._scaler_Y.fit_transform(Y)
            self._model = MLPRegressor(
                hidden_layer_sizes=self.hidden_layers,
                max_iter=self.max_iter,
                learning_rate_init=self.learning_rate,
                random_state=42,
                activation='relu',
                solver='adam',
            )
            self._model.fit(Xs, Ys)
        else:
            # Lightweight numpy MLP
            self._train_numpy_mlp(X, Y)

    def _train_numpy_mlp(self, X: np.ndarray, Y: np.ndarray) -> None:
        """Train a simple 1-hidden-layer MLP with numpy."""
        N, n_in = X.shape
        n_out = Y.shape[1]
        n_hidden = self.hidden_layers[0] if self.hidden_layers else 64

        # Normalize
        self._mx = X.mean(axis=0)
        self._sx = X.std(axis=0) + 1e-10
        self._my = Y.mean(axis=0)
        self._sy = Y.std(axis=0) + 1e-10
        Xs = (X - self._mx) / self._sx
        Ys = (Y - self._my) / self._sy

        rng = np.random.default_rng(42)
        W1 = rng.standard_normal((n_in, n_hidden)) * np.sqrt(2.0 / n_in)
        b1 = np.zeros(n_hidden)
        W2 = rng.standard_normal((n_hidden, n_out)) * np.sqrt(2.0 / n_hidden)
        b2 = np.zeros(n_out)

        lr = self.learning_rate
        for epoch in range(self.max_iter):
            # Forward
            z1 = Xs @ W1 + b1
            a1 = np.maximum(z1, 0)  # ReLU
            z2 = a1 @ W2 + b2
            y_pred = z2

            # Loss gradient (MSE)
            dz2 = 2 * (y_pred - Ys) / N
            dW2 = a1.T @ dz2
            db2 = dz2.sum(axis=0)
            da1 = dz2 @ W2.T
            dz1 = da1 * (z1 > 0)
            dW1 = Xs.T @ dz1
            db1 = dz1.sum(axis=0)

            # Update
            W1 -= lr * dW1
            b1 -= lr * db1
            W2 -= lr * dW2
            b2 -= lr * db2

        self._W1, self._b1, self._W2, self._b2 = W1, b1, W2, b2

    def _raw_predict(self, x: np.ndarray) -> np.ndarray:
        if HAS_SKLEARN:
            xs = self._scaler_X.transform(x[None, :])
            ys = self._model.predict(xs)[0]
            y = self._scaler_Y.inverse_transform(ys[None, :])[0]
        else:
            xs = (x - self._mx) / self._sx
            z1 = xs @ self._W1 + self._b1
            a1 = np.maximum(z1, 0)
            ys = a1 @ self._W2 + self._b2
            y = ys * self._sy + self._my

        y = self._enforce_monotonicity(x, y)
        return y


# -----------------------------------------------------------------------
# Surrogate as ForwardModel (for optimization)
# -----------------------------------------------------------------------

class SurrogateForwardModel:
    """Wrap a trained surrogate as a ForwardModel-compatible object.

    This allows the surrogate to be used directly in the optimization
    loop (CMA-ES, DE, etc.) as a drop-in replacement for the expensive
    simulator.

    The surrogate must be trained before creating this wrapper.
    """

    def __init__(self, surrogate: Surrogate,
                 high_fidelity: Optional[object] = None):
        self.surrogate = surrogate
        self.high_fidelity = high_fidelity
        self._n_eval = 0

    @property
    def n_params(self) -> int:
        return self.surrogate.n_params

    @property
    def n_data(self) -> int:
        return self.surrogate.n_data

    @property
    def params_units(self) -> str:
        return "varied"

    @property
    def data_units(self) -> str:
        return "varied"

    def predict(self, model: np.ndarray) -> np.ndarray:
        self._n_eval += 1
        return self.surrogate.predict(model)

    def default_model(self) -> np.ndarray:
        if self.high_fidelity is not None:
            return self.high_fidelity.default_model()
        return np.zeros(self.n_params)


# -----------------------------------------------------------------------
# Accuracy gate
# -----------------------------------------------------------------------

@dataclass
class GateResult:
    """Result of an accuracy gate check."""
    passed: bool
    mean_error: float
    max_error: float
    n_checked: int
    failures: List[int] = field(default_factory=list)


class SurrogateAccuracyGate:
    """Gate that validates surrogate predictions against high-fidelity runs.

    Before trusting the surrogate in an optimization loop, the gate
    checks that the surrogate's predictions agree with the true
    simulator within a specified tolerance.  If not, it flags the
    prediction as unreliable.

    The gate can operate in two modes:
    - **validation**: Check on a held-out validation set (offline).
    - **online**: For each prediction during optimization, optionally
      run the high-fidelity model to verify (expensive but safe).
    """

    def __init__(self,
                 surrogate: Surrogate,
                 high_fidelity: object,
                 tolerance: float = 0.05,
                 relative: bool = True,
                 check_interval: int = 0):
        """
        Parameters
        ----------
        surrogate : Surrogate
            The trained surrogate to gate.
        high_fidelity : ForwardModel
            The expensive simulator for verification.
        tolerance : float
            Maximum allowed relative error (0.05 = 5%).
        relative : bool
            If True, error is relative; else absolute.
        check_interval : int
            If > 0, verify every N-th surrogate prediction against
            high-fidelity (online mode).  0 = offline validation only.
        """
        self.surrogate = surrogate
        self.high_fidelity = high_fidelity
        self.tolerance = tolerance
        self.relative = relative
        self.check_interval = check_interval
        self._call_count = 0
        self._online_failures = 0

    def validate(self, X_val: np.ndarray, Y_val: np.ndarray) -> GateResult:
        """Check surrogate accuracy on a validation set."""
        X_val = np.asarray(X_val, dtype=float)
        Y_val = np.asarray(Y_val, dtype=float)
        Y_pred = self.surrogate.predict_batch(X_val)

        if self.relative:
            scale = np.abs(Y_val).max(axis=0) + 1e-30
            err = np.abs(Y_pred - Y_val) / scale[None, :]
        else:
            err = np.abs(Y_pred - Y_val)

        per_sample_err = err.mean(axis=1)
        failures = list(np.where(per_sample_err > self.tolerance)[0])

        return GateResult(
            passed=len(failures) == 0,
            mean_error=float(per_sample_err.mean()),
            max_error=float(per_sample_err.max()),
            n_checked=len(X_val),
            failures=failures,
        )

    def predict_gated(self, x: np.ndarray) -> Tuple[np.ndarray, bool]:
        """Predict with online gating.

        Returns (prediction, trusted).  If check_interval > 0 and
        this is a check iteration, verify against high-fidelity.
        If the verification fails, mark as untrusted.
        """
        self._call_count += 1
        y_surr = self.surrogate.predict(x)

        if self.check_interval > 0 and self._call_count % self.check_interval == 0:
            y_hf = self.high_fidelity.predict(x)
            if self.relative:
                scale = np.abs(y_hf).max() + 1e-30
                err = np.abs(y_surr - y_hf) / scale
            else:
                err = np.abs(y_surr - y_hf)

            if err.mean() > self.tolerance:
                self._online_failures += 1
                return y_hf, False  # return HF result, mark untrusted

        return y_surr, True


# -----------------------------------------------------------------------
# Training utility: Latin Hypercube + ensemble of surrogates
# -----------------------------------------------------------------------

def train_surrogate_ensemble(
    high_fidelity: object,
    n_samples: int = 50,
    surrogate_types: Tuple[str, ...] = ("polynomial", "rbf"),
    bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
    seed: Optional[int] = None,
    **surrogate_kwargs
) -> Tuple[List[Surrogate], np.ndarray, np.ndarray]:
    """Train an ensemble of surrogates on Latin-hypercube-sampled data.

    Parameters
    ----------
    high_fidelity : ForwardModel
        The expensive simulator.
    n_samples : int
        Number of training samples (simulator runs).
    surrogate_types : tuple of str
        Which surrogate types to train: "polynomial", "rbf", "neural".
    bounds : (lower, upper)
        Parameter bounds for sampling.
    seed : int or None

    Returns
    -------
    surrogates : list of Surrogate
    X : ndarray (n_samples, n_params) — training inputs
    Y : ndarray (n_samples, n_data) — training outputs
    """
    rng = np.random.default_rng(seed)
    n_params = high_fidelity.n_params
    n_data = high_fidelity.n_data

    if bounds is not None:
        lower, upper = bounds
        lower = np.asarray(lower, dtype=float)
        upper = np.asarray(upper, dtype=float)
    else:
        lower = np.full(n_params, -1.0)
        upper = np.full(n_params, 1.0)

    # Latin Hypercube Sampling
    X = np.empty((n_samples, n_params))
    for j in range(n_params):
        perm = rng.permutation(n_samples)
        X[:, j] = lower[j] + (perm + rng.random(n_samples)) / n_samples * (upper[j] - lower[j])

    # Run high-fidelity model
    Y = np.empty((n_samples, n_data))
    for i in range(n_samples):
        try:
            Y[i] = high_fidelity.predict(X[i])
        except Exception:
            Y[i] = np.nan

    # Remove failed runs
    valid = ~np.isnan(Y).any(axis=1)
    X, Y = X[valid], Y[valid]

    # Train surrogates
    surrogates = []
    for stype in surrogate_types:
        if stype == "polynomial":
            s = PolynomialSurrogate(n_params, n_data, **surrogate_kwargs)
        elif stype == "rbf":
            s = RadialBasisSurrogate(n_params, n_data, **surrogate_kwargs)
        elif stype == "neural":
            s = NeuralSurrogate(n_params, n_data, **surrogate_kwargs)
        else:
            continue
        s.train(X, Y)
        surrogates.append(s)

    return surrogates, X, Y
