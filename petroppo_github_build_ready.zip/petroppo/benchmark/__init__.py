"""
petroppo Benchmark Framework
==============================

A unified, fair benchmark protocol for comparing subsurface geophysics
platforms (petroppo vs. Petrel) on the same data, the same problems,
and the same accuracy criteria.

Seven metrics are measured for every benchmark case:

1. **Accuracy** — how close the result is to known truth (MSE, IoU, etc.)
2. **Runtime** — wall-clock time (seconds)
3. **Memory** — peak memory usage (MB)
4. **Automation** — number of manual steps / lines of user code required
5. **Uncertainty** — whether uncertainty is quantified (0=no, 1=partial, 2=full)
6. **Reproducibility** — deterministic? same input → same output? (0/1)
7. **User effort** — qualitative: low / medium / high

The framework is designed so that *any* platform (petroppo, Petrel, or
another open-source tool) can be benchmarked using the same protocol.
Petrel results are provided as reference values (either from published
benchmarks, user-provided runs, or documented estimates) and compared
side-by-side.
"""

from .protocol import (
    BenchmarkCase,
    BenchmarkMetrics,
    BenchmarkResult,
    BenchmarkSuite,
    PlatformResult,
    ComparisonVerdict,
    compare_platforms,
    run_suite,
)
from .data import BenchmarkDataPackage, make_synthetic_benchmark
from .cases import build_all_cases, build_seismic_cases, build_inversion_cases, build_reservoir_cases, build_modeling_cases

__all__ = [
    "BenchmarkCase",
    "BenchmarkMetrics",
    "BenchmarkResult",
    "BenchmarkSuite",
    "PlatformResult",
    "ComparisonVerdict",
    "compare_platforms",
    "run_suite",
    "BenchmarkDataPackage",
    "make_synthetic_benchmark",
    "build_all_cases",
    "build_seismic_cases",
    "build_inversion_cases",
    "build_reservoir_cases",
    "build_modeling_cases",
]
