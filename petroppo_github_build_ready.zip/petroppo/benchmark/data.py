"""
Benchmark data package — a synthetic subsurface model with known ground
truth, designed for fair, reproducible benchmarking of petroppo against
Petrel (or any other platform).

The model contains features that exercise every major subsurface workflow:
  - 3D seismic with 3 reflectors, a normal fault, a channel, and a salt body
  - 4 wells with impedance logs and formation tops
  - A 4-layer acoustic impedance model (for inversion testing)
  - A reservoir model (porosity, permeability, saturation, NTG)

All features have known ground truth stored in ``seismic_truth``, enabling
exact accuracy scoring.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Any


@dataclass
class BenchmarkDataPackage:
    """Complete synthetic benchmark data with known ground truth.

    Attributes
    ----------
    seismic : np.ndarray (nx, ny, nz)
        3D seismic reflectivity volume.
    seismic_truth : dict
        Known ground truth: reflector depths, fault location, channel mask,
        salt mask, true impedance, etc.
    well_logs : dict
        Well log data for each well (impedance, formation tops).
    well_locations : list[tuple[int, int]]
        (x, y) grid coordinates of each well.
    impedance_model : np.ndarray (nx, ny, nz)
        True acoustic impedance model (for inversion benchmarking).
    reservoir_model : dict
        Reservoir properties: porosity, permeability, saturation, NTG.
    grid_params : dict
        Grid dimensions and cell sizes.
    """

    seismic: np.ndarray
    seismic_truth: dict
    well_logs: dict
    well_locations: list
    impedance_model: np.ndarray
    reservoir_model: dict
    grid_params: dict


def make_synthetic_benchmark(
    nx: int = 48,
    ny: int = 48,
    nz: int = 60,
    dt: float = 0.004,
    dx: float = 25.0,
    dy: float = 25.0,
    seed: int = 42,
) -> BenchmarkDataPackage:
    """Generate a complete synthetic benchmark package with known truth.

    The model contains:
      - 3 reflectors at z = 0.25*nz, 0.50*nz, 0.75*nz (known horizons)
      - A normal fault at x = nx//2 with 3-sample throw (known fault)
      - A channel at x=[nx//3, 2*nx//3), y=[ny*0.42, ny*0.58), z=0.5*nz
      - A salt diapir at x=[nx*0.08, nx*0.29), y=[ny*0.08, ny*0.29),
        z=[0.8*nz, nz) (known salt)
      - Acoustic impedance model with 4 layers
      - 4 wells at corners + center
      - Reservoir: porosity/perm/saturation in layer 3

    All features are stored in ``seismic_truth`` for exact accuracy scoring.

    Parameters
    ----------
    nx, ny, nz : int
        Grid dimensions.  Default 48×48×60.  Smaller grids (e.g. 24×24×30)
        are supported for faster testing.
    seed : int
        Random seed for reproducibility.
    """
    rng = np.random.default_rng(seed)

    # ── Compute proportional indices ────────────────────────────────────
    # Reflectors at 25%, 50%, 75% of depth
    r1 = int(nz * 0.25)
    r2 = int(nz * 0.50)
    r3 = int(nz * 0.75)
    reflector_depths = [r1, r2, r3]

    # Fault at center
    fault_x = nx // 2
    throw = min(3, nz // 20)  # scale throw for small grids

    # Channel
    ch_x0, ch_x1 = int(nx * 0.33), int(nx * 0.67)
    ch_y0, ch_y1 = int(ny * 0.42), int(ny * 0.58)
    ch_z0, ch_z1 = r2 - 1, r2 + 2  # around middle reflector

    # Salt
    salt_x0, salt_x1 = int(nx * 0.08), int(nx * 0.29)
    salt_y0, salt_y1 = int(ny * 0.08), int(ny * 0.29)
    salt_z0, salt_z1 = int(nz * 0.80), nz

    # Layer boundaries (proportional)
    lb1 = 0
    lb2 = r1
    lb3 = r2
    lb4 = r3
    lb5 = nz

    # ── Seismic volume ───────────────────────────────────────────────────
    seismic = rng.standard_normal((nx, ny, nz)) * 0.05

    # Reflectors (known horizons)
    reflector_amps = [1.0, -0.8, 0.9]
    for z_r, amp in zip(reflector_depths, reflector_amps):
        # Add a gentle dip so horizons are not perfectly flat
        for x in range(nx):
            for y in range(ny):
                dip = 0.02 * (x - nx / 2) + 0.01 * (y - ny / 2)
                z_local = int(z_r + dip)
                if 0 <= z_local < nz:
                    seismic[x, y, z_local] += amp
                    if z_local - 1 >= 0:
                        seismic[x, y, z_local - 1] += amp * 0.3
                    if z_local + 1 < nz:
                        seismic[x, y, z_local + 1] += amp * 0.3

    # Fault (normal fault, throw samples)
    seismic[fault_x:, :, :] = np.roll(seismic[fault_x:, :, :], throw, axis=2)
    # Add fault-zone incoherence
    fault_zone = slice(max(0, fault_x - 1), min(nx, fault_x + 2))
    fz_size = fault_zone.stop - fault_zone.start
    seismic[fault_zone, :, :] += rng.standard_normal(
        (fz_size, ny, nz)) * 0.15

    # Channel
    channel_mask = np.zeros((nx, ny, nz), dtype=bool)
    channel_mask[ch_x0:ch_x1, ch_y0:ch_y1, ch_z0:ch_z1] = True
    seismic[channel_mask] += 0.6

    # Salt diapir
    salt_mask = np.zeros((nx, ny, nz), dtype=bool)
    salt_mask[salt_x0:salt_x1, salt_y0:salt_y1, salt_z0:salt_z1] = True
    seismic[salt_mask] += rng.standard_normal(salt_mask.sum()) * 0.3

    # ── Acoustic impedance model (for inversion) ─────────────────────────
    impedance = np.zeros((nx, ny, nz))
    layer_boundaries = [lb1, lb2, lb3, lb4, lb5]
    layer_impedances = [2.5, 3.2, 4.1, 5.5]  # km/s * g/cc
    for i in range(len(layer_impedances)):
        z0, z1 = layer_boundaries[i], layer_boundaries[i + 1]
        if z0 < z1:
            impedance[:, :, z0:z1] = layer_impedances[i]
    # Add the fault offset
    impedance[fault_x:, :, :] = np.roll(
        impedance[fault_x:, :, :], throw, axis=2)
    # Add salt (high impedance)
    impedance[salt_mask] = 6.5
    # Add channel (slightly lower)
    impedance[channel_mask] = 3.5

    # ── Well logs ────────────────────────────────────────────────────────
    # Ensure wells are within grid bounds
    w_off = max(2, nx // 6)
    well_locations = [
        (w_off, w_off),               # NW corner
        (nx - 1 - w_off, w_off),      # NE corner
        (w_off, ny - 1 - w_off),      # SW corner
        (nx // 2, ny // 2),           # Center
    ]
    well_logs = {}
    salt_top = salt_z0
    for i, (wx, wy) in enumerate(well_locations):
        # Check if this well is over salt
        has_salt = (salt_x0 <= wx < salt_x1 and
                    salt_y0 <= wy < salt_y1 and
                    salt_z0 < nz)
        well_logs[f"well_{i}"] = {
            "x": wx, "y": wy,
            "impedance": impedance[wx, wy, :].copy(),
            "depth_samples": np.arange(nz),
            "formation_tops": {
                "layer_1": lb1,
                "layer_2": lb2,
                "layer_3": lb3,
                "layer_4": lb4,
                "salt": salt_top if has_salt else None,
            },
        }

    # ── Reservoir model (layer 3 = reservoir) ────────────────────────────
    reservoir_mask = np.zeros((nx, ny, nz), dtype=bool)
    res_z0, res_z1 = lb3, lb4
    if res_z0 < res_z1:
        reservoir_mask[:, :, res_z0:res_z1] = True
    porosity = np.where(reservoir_mask, 0.22, 0.05)
    porosity += rng.normal(0, 0.02, (nx, ny, nz)) * reservoir_mask
    porosity = np.clip(porosity, 0.01, 0.35)

    permeability = np.where(reservoir_mask, 100.0, 1.0)  # mD
    permeability *= (porosity / 0.22) ** 3  # Kozeny-Carman-ish

    saturation = np.where(reservoir_mask, 0.75, 0.0)
    ntg = np.where(reservoir_mask, 0.85, 0.0)

    # ── Truth dictionary ─────────────────────────────────────────────────
    truth = {
        "reflector_depths": reflector_depths,
        "reflector_amps": reflector_amps,
        "fault_x": fault_x,
        "fault_throw": throw,
        "fault_dip_deg": 90.0,
        "channel_mask": channel_mask,
        "channel_location": (ch_x0, ch_x1, ch_y0, ch_y1, ch_z0, ch_z1),
        "salt_mask": salt_mask,
        "salt_location": (salt_x0, salt_x1, salt_y0, salt_y1,
                          salt_z0, salt_z1),
        "impedance": impedance,
        "layer_boundaries": layer_boundaries,
        "layer_impedances": layer_impedances,
        "nx": nx,
        "ny": ny,
        "nz": nz,
    }

    return BenchmarkDataPackage(
        seismic=seismic,
        seismic_truth=truth,
        well_logs=well_logs,
        well_locations=well_locations,
        impedance_model=impedance,
        reservoir_model={
            "porosity": porosity,
            "permeability": permeability,
            "saturation": saturation,
            "ntg": ntg,
            "reservoir_mask": reservoir_mask,
        },
        grid_params={
            "nx": nx, "ny": ny, "nz": nz,
            "dx": dx, "dy": dy, "dt": dt,
        },
    )
