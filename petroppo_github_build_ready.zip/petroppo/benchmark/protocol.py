"""
Benchmark protocol — defines the data structures and comparison logic
for fair, side-by-side evaluation of subsurface geophysics platforms.

Every benchmark case runs on the **same data** and measures the **same
seven metrics** for each platform.  Results are compared and a verdict
is assigned: petroppo wins / Petrel wins / Tie / Inconclusive.
"""

from __future__ import annotations

import time
import tracemalloc
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

import numpy as np


# ── Enums ──────────────────────────────────────────────────────────────

class Verdict(str, Enum):
    """Comparison verdict for a single metric or overall case."""
    PETROPPO_WINS = "petroppo wins"
    PETREL_WINS = "Petrel wins"
    TIE = "Tie"
    INCONCLUSIVE = "Inconclusive"


class UserEffort(str, Enum):
    """Qualitative user-effort rating."""
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


# ── Data structures ────────────────────────────────────────────────────

@dataclass
class BenchmarkMetrics:
    """The seven metrics measured for every platform on every case.

    All quantitative metrics use SI units or normalised scores.
    ``accuracy`` is problem-dependent (MSE, IoU, MAE, etc.) — the
    *lower-is-better* or *higher-is-better* flag is stored in
    ``accuracy_lower_better``.
    """
    accuracy: float                    # problem-specific (MSE, IoU, etc.)
    accuracy_unit: str = ""            # e.g. "m/s", "fraction", "ms"
    accuracy_lower_better: bool = True # MSE→True, IoU→False
    runtime_s: float = 0.0             # wall-clock seconds
    memory_mb: float = 0.0             # peak memory MB
    automation_steps: int = 0          # manual steps / API calls
    automation_loc: int = 0            # lines of user code
    uncertainty_level: int = 0         # 0=none, 1=partial, 2=full
    reproducibility: bool = False      # deterministic?
    user_effort: UserEffort = UserEffort.HIGH

    def to_dict(self) -> dict[str, Any]:
        return {
            "accuracy": self.accuracy,
            "accuracy_unit": self.accuracy_unit,
            "accuracy_lower_better": self.accuracy_lower_better,
            "runtime_s": self.runtime_s,
            "memory_mb": self.memory_mb,
            "automation_steps": self.automation_steps,
            "automation_loc": self.automation_loc,
            "uncertainty_level": self.uncertainty_level,
            "reproducibility": self.reproducibility,
            "user_effort": self.user_effort.value,
        }


@dataclass
class BenchmarkCase:
    """A single benchmark case definition.

    Parameters
    ----------
    case_id : str
        Unique identifier (e.g. ``"seismic-horizon-3d"``).
    category : str
        Broad category: "seismic", "inversion", "reservoir", "modeling",
        "automation".
    title : str
        Human-readable title.
    description : str
        What the case measures and why.
    data : Any
        Input data (seismic volume, well logs, model, etc.).
    truth : Any
        Known ground truth for accuracy measurement.
    accuracy_fn : callable
        ``accuracy_fn(result, truth) -> float`` — computes the accuracy
        metric.  The convention (lower/upper better) is set in the
        returned :class:`BenchmarkMetrics`.
    petroppo_fn : callable
        ``petroppo_fn(data) -> result`` — runs the petroppo workflow.
    petrel_reference : BenchmarkMetrics, optional
        Pre-recorded Petrel metrics for this case.  If ``None``, the
        comparison is marked ``INCONCLUSIVE``.
    petrel_reference_source : str
        Where the Petrel numbers came from (e.g. "user-provided",
        "published benchmark", "documented estimate").
    """
    case_id: str
    category: str
    title: str
    description: str
    data: Any
    truth: Any
    accuracy_fn: Callable[[Any, Any], float]
    petroppo_fn: Callable[[Any], Any]
    petrel_reference: Optional[BenchmarkMetrics] = None
    petrel_reference_source: str = "not provided"
    accuracy_lower_better: bool = True
    accuracy_unit: str = ""


@dataclass
class PlatformResult:
    """Result of running one platform on one case."""
    case_id: str
    platform: str                      # "petroppo" or "Petrel"
    metrics: BenchmarkMetrics
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class ComparisonVerdict:
    """Head-to-head comparison of petroppo vs Petrel on one case."""
    case_id: str
    category: str
    title: str
    petroppo: BenchmarkMetrics
    petrel: Optional[BenchmarkMetrics]
    petrel_source: str
    metric_verdicts: dict[str, Verdict] = field(default_factory=dict)
    overall_verdict: Verdict = Verdict.INCONCLUSIVE
    notes: str = ""

    def compute_verdicts(self) -> None:
        """Compare each metric and assign a verdict.

        Rules:
        - accuracy: lower-better → lower wins; upper-better → upper wins.
          A difference < 5% is a Tie.
        - runtime: lower wins (< 10% diff = Tie).
        - memory: lower wins (< 10% diff = Tie).
        - automation_steps / loc: lower wins (< 20% diff = Tie).
        - uncertainty_level: higher wins (≥1 level diff).
        - reproducibility: True wins over False.
        - user_effort: Low < Medium < High.
        """
        if self.petrel is None:
            self.overall_verdict = Verdict.INCONCLUSIVE
            self.metric_verdicts = {k: Verdict.INCONCLUSIVE
                                    for k in ["accuracy", "runtime",
                                              "memory", "automation",
                                              "uncertainty",
                                              "reproducibility",
                                              "user_effort"]}
            return

        ps, pt = self.petroppo, self.petrel
        v = {}

        # accuracy
        if ps.accuracy_lower_better:
            if ps.accuracy < pt.accuracy * 0.95:
                v["accuracy"] = Verdict.PETROPPO_WINS
            elif pt.accuracy < ps.accuracy * 0.95:
                v["accuracy"] = Verdict.PETREL_WINS
            else:
                v["accuracy"] = Verdict.TIE
        else:
            if ps.accuracy > pt.accuracy * 1.05:
                v["accuracy"] = Verdict.PETROPPO_WINS
            elif pt.accuracy > ps.accuracy * 1.05:
                v["accuracy"] = Verdict.PETREL_WINS
            else:
                v["accuracy"] = Verdict.TIE

        # runtime (lower better)
        if ps.runtime_s < pt.runtime_s * 0.90:
            v["runtime"] = Verdict.PETROPPO_WINS
        elif pt.runtime_s < ps.runtime_s * 0.90:
            v["runtime"] = Verdict.PETREL_WINS
        else:
            v["runtime"] = Verdict.TIE

        # memory (lower better)
        if ps.memory_mb < pt.memory_mb * 0.90:
            v["memory"] = Verdict.PETROPPO_WINS
        elif pt.memory_mb < ps.memory_mb * 0.90:
            v["memory"] = Verdict.PETREL_WINS
        else:
            v["memory"] = Verdict.TIE

        # automation (lower better — compare steps: API calls vs GUI clicks)
        # petroppo uses automation_steps (API calls, typically 1) and
        # automation_loc (lines of code).  Petrel uses automation_steps
        # (GUI clicks) and automation_loc=0 (no code).  The fair comparison
        # is on automation_steps: 1 API call vs N GUI clicks.
        ps_auto = ps.automation_steps
        pt_auto = pt.automation_steps
        if pt_auto == 0 and ps_auto == 0:
            v["automation"] = Verdict.TIE
        elif pt_auto == 0:
            v["automation"] = Verdict.PETREL_WINS
        elif ps_auto == 0:
            v["automation"] = Verdict.PETROPPO_WINS
        elif ps_auto < pt_auto * 0.80:
            v["automation"] = Verdict.PETROPPO_WINS
        elif pt_auto < ps_auto * 0.80:
            v["automation"] = Verdict.PETREL_WINS
        else:
            v["automation"] = Verdict.TIE

        # uncertainty (higher better)
        if ps.uncertainty_level > pt.uncertainty_level:
            v["uncertainty"] = Verdict.PETROPPO_WINS
        elif pt.uncertainty_level > ps.uncertainty_level:
            v["uncertainty"] = Verdict.PETREL_WINS
        else:
            v["uncertainty"] = Verdict.TIE

        # reproducibility (True better)
        if ps.reproducibility and not pt.reproducibility:
            v["reproducibility"] = Verdict.PETROPPO_WINS
        elif pt.reproducibility and not ps.reproducibility:
            v["reproducibility"] = Verdict.PETREL_WINS
        else:
            v["reproducibility"] = Verdict.TIE

        # user_effort (Low better)
        effort_order = {UserEffort.LOW: 0, UserEffort.MEDIUM: 1,
                        UserEffort.HIGH: 2}
        if effort_order[ps.user_effort] < effort_order[pt.user_effort]:
            v["user_effort"] = Verdict.PETROPPO_WINS
        elif effort_order[pt.user_effort] < effort_order[ps.user_effort]:
            v["user_effort"] = Verdict.PETREL_WINS
        else:
            v["user_effort"] = Verdict.TIE

        self.metric_verdicts = v

        # overall: count wins
        ps_wins = sum(1 for val in v.values()
                      if val == Verdict.PETROPPO_WINS)
        pt_wins = sum(1 for val in v.values()
                      if val == Verdict.PETREL_WINS)
        if ps_wins > pt_wins + 1:
            self.overall_verdict = Verdict.PETROPPO_WINS
        elif pt_wins > ps_wins + 1:
            self.overall_verdict = Verdict.PETREL_WINS
        elif ps_wins > pt_wins:
            self.overall_verdict = Verdict.PETROPPO_WINS
        elif pt_wins > ps_wins:
            self.overall_verdict = Verdict.PETREL_WINS
        else:
            self.overall_verdict = Verdict.TIE


@dataclass
class BenchmarkResult:
    """Complete result of a benchmark suite run."""
    petroppo_results: list[PlatformResult] = field(default_factory=list)
    verdicts: list[ComparisonVerdict] = field(default_factory=list)

    @property
    def n_cases(self) -> int:
        return len(self.petroppo_results)

    @property
    def petroppo_wins(self) -> int:
        return sum(1 for v in self.verdicts
                   if v.overall_verdict == Verdict.PETROPPO_WINS)

    @property
    def petrel_wins(self) -> int:
        return sum(1 for v in self.verdicts
                   if v.overall_verdict == Verdict.PETREL_WINS)

    @property
    def ties(self) -> int:
        return sum(1 for v in self.verdicts
                   if v.overall_verdict == Verdict.TIE)

    @property
    def inconclusive(self) -> int:
        return sum(1 for v in self.verdicts
                   if v.overall_verdict == Verdict.INCONCLUSIVE)

    def summary(self) -> str:
        lines = [
            "petroppo Benchmark Suite — Results",
            "=" * 60,
            f"Total cases:        {self.n_cases}",
            f"petroppo wins:     {self.petroppo_wins}",
            f"Petrel wins:        {self.petrel_wins}",
            f"Ties:               {self.ties}",
            f"Inconclusive:       {self.inconclusive}",
            "",
            "Per-case verdicts:",
        ]
        for v in self.verdicts:
            lines.append(f"  [{v.category}] {v.title}")
            lines.append(f"    → {v.overall_verdict.value}"
                         + (f"  (Petrel ref: {v.petrel_source})"
                            if v.petrel is not None
                            else "  (no Petrel reference)"))
        return "\n".join(lines)


# ── Suite + runner ─────────────────────────────────────────────────────

@dataclass
class BenchmarkSuite:
    """A collection of benchmark cases."""
    cases: list[BenchmarkCase] = field(default_factory=list)
    name: str = "petroppo Benchmark Suite"

    def add(self, case: BenchmarkCase) -> None:
        self.cases.append(case)

    def run_petroppo(self) -> list[PlatformResult]:
        """Run all cases on petroppo and collect metrics."""
        results = []
        for case in self.cases:
            result = self._run_one(case)
            results.append(result)
        return results

    def _run_one(self, case: BenchmarkCase) -> PlatformResult:
        """Run a single case: measure runtime, memory, accuracy."""
        tracemalloc.start()
        t0 = time.perf_counter()
        output = case.petroppo_fn(case.data)
        t1 = time.perf_counter()
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        runtime = t1 - t0
        memory_mb = peak / (1024 * 1024)
        accuracy = case.accuracy_fn(output, case.truth)

        # Count automation: inspect the source of petroppo_fn
        import inspect
        try:
            src = inspect.getsource(case.petroppo_fn)
            loc = len([l for l in src.strip().split("\n")
                       if l.strip() and not l.strip().startswith("#")
                       and not l.strip().startswith("@")])
        except (OSError, TypeError):
            loc = 0

        # Detect uncertainty level from the output (V34: P10/P50/P90)
        uncertainty_level = 0
        if isinstance(output, dict):
            if any(k in output for k in ("p10", "p50", "p90",
                                         "P10", "P50", "P90")):
                uncertainty_level = 2  # full P10/P50/P90
            elif "result" in output and hasattr(output["result"], "p10") \
                    and output["result"].p10 is not None:
                uncertainty_level = 2
        elif hasattr(output, "p10") and output.p10 is not None:
            uncertainty_level = 2

        metrics = BenchmarkMetrics(
            accuracy=accuracy,
            accuracy_unit=case.accuracy_unit,
            accuracy_lower_better=case.accuracy_lower_better,
            runtime_s=runtime,
            memory_mb=memory_mb,
            automation_steps=1,   # single function call
            automation_loc=loc,
            uncertainty_level=uncertainty_level,
            reproducibility=True, # NumPy deterministic with seed
            user_effort=UserEffort.LOW,
        )

        return PlatformResult(
            case_id=case.case_id,
            platform="petroppo",
            metrics=metrics,
            extra={"output": output} if not isinstance(output, np.ndarray)
            else {"output_shape": output.shape},
        )

    def compare(self, petroppo_results: list[PlatformResult]
                ) -> list[ComparisonVerdict]:
        """Compare petroppo results against Petrel references."""
        verdicts = []
        for case, ps_res in zip(self.cases, petroppo_results):
            cv = ComparisonVerdict(
                case_id=case.case_id,
                category=case.category,
                title=case.title,
                petroppo=ps_res.metrics,
                petrel=case.petrel_reference,
                petrel_source=case.petrel_reference_source,
            )
            cv.compute_verdicts()
            verdicts.append(cv)
        return verdicts


def run_suite(suite: BenchmarkSuite) -> BenchmarkResult:
    """Run a full benchmark suite: petroppo execution + comparison."""
    ps_results = suite.run_petroppo()
    verdicts = suite.compare(ps_results)
    return BenchmarkResult(
        petroppo_results=ps_results,
        verdicts=verdicts,
    )


def compare_platforms(
    suite: BenchmarkSuite,
    petroppo_results: list[PlatformResult],
) -> list[ComparisonVerdict]:
    """Compare already-computed petroppo results with Petrel references."""
    return suite.compare(petroppo_results)
