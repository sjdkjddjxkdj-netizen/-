"""
petroppo field case studies (V39).

Synthetic reservoir scenarios that replicate real-world depositional
environments, with known ground truth and full-workflow validation.

Modules
-------
* :mod:`field_studies` -- three benchmark field cases:
    - North Sea Clastic (deltaic, waterflood, 4-D time-lapse)
    - Carbonate Platform (layered, dual-porosity, gas injection)
    - Deepwater Turbidite (channelised, stratigraphic trap, uncertainty)
"""

from __future__ import annotations

__all__: list = []

try:
    from . import field_studies  # noqa: F401
    __all__.append("field_studies")
except Exception:  # pragma: no cover
    pass
