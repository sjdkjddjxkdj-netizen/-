"""Core layer — aggregation of fundamental units."""
from .config import get_settings, Settings
from .logging import get_logger, setup_logging
from .errors import (
    petroppoError, ConfigError, DatabaseError, HardwareError,
    DeviceNotFoundError, DeviceConnectionError, SimulationError,
    ForwardModelError, InversionError, DataQualityError, UIError,
)
from .units import UNITS, convert, format_value
from .coordinates import GeoPoint, LocalPoint, geo_to_local, local_to_geo, distance, bearing
from .models import (
    Project, Survey, DeviceInfo, Measurement, MeasurementMethod,
    ProjectStatus, SurveyStatus, DeviceStatus,
    Layer, ResistivityBody, EarthModel,
    InversionResult, QualityReport, new_id,
)

__all__ = [
    "get_settings", "Settings",
    "get_logger", "setup_logging",
    "petroppoError", "ConfigError", "DatabaseError", "HardwareError",
    "DeviceNotFoundError", "DeviceConnectionError", "SimulationError",
    "ForwardModelError", "InversionError", "DataQualityError", "UIError",
    "UNITS", "convert", "format_value",
    "GeoPoint", "LocalPoint", "geo_to_local", "local_to_geo", "distance", "bearing",
    "Project", "Survey", "DeviceInfo", "Measurement", "MeasurementMethod",
    "ProjectStatus", "SurveyStatus", "DeviceStatus",
    "Layer", "ResistivityBody", "EarthModel",
    "InversionResult", "QualityReport", "new_id",
]
