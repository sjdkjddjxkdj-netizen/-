"""Central settings unit — holds project paths and configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _default_data_dir() -> Path:
    """Default data directory.

    When the application is frozen (PyInstaller), the package directory
    is read-only, so writable data goes under the user profile:
      Windows  -> %APPDATA%/petroppo/data
      macOS    -> ~/Library/Application Support/petroppo/data
      Linux    -> ~/.local/share/petroppo/data
    From source it stays next to the package.
    """
    import sys
    if getattr(sys, "frozen", False):
        home = Path.home()
        if os.name == "nt":
            base = Path(os.environ.get("APPDATA", home)) / "petroppo"
        elif sys.platform == "darwin":
            base = home / "Library" / "Application Support" / "petroppo"
        else:
            base = Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share")) / "petroppo"
        return base / "data"
    here = Path(__file__).resolve().parent.parent
    return here / "data"


@dataclass
class Settings:
    """General application settings."""

    # paths
    data_dir: Path = field(default_factory=_default_data_dir)
    db_path: Path = field(default_factory=lambda: _default_data_dir() / "petroppo.db")

    # database
    db_echo: bool = False

    # GUI
    window_width: int = 1400
    window_height: int = 900
    theme: str = "comsol"  # comsol (light professional) or dark

    # simulation defaults
    default_grid_spacing: float = 5.0  # meters
    default_frequency: float = 1.0     # Hz
    default_noise_level: float = 0.02  # 2%

    # HAL
    default_device_poll_interval: float = 0.2  # seconds

    @classmethod
    def load(cls) -> "Settings":
        """Load settings from environment variables with defaults."""
        s = cls()
        env_data = os.environ.get("PETROPPO_DATA_DIR")
        if env_data:
            s.data_dir = Path(env_data)
            s.db_path = s.data_dir / "petroppo.db"
        s.data_dir.mkdir(parents=True, exist_ok=True)
        return s

    def ensure_dirs(self) -> None:
        """Ensure all required directories exist."""
        self.data_dir.mkdir(parents=True, exist_ok=True)


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings.load()
    return _settings
