"""Coordinate system — supports geographic and local (UTM-like) coordinates.

V20 shim: delegates to the strict :mod:`petroppo.physics.coordinates` CRS
framework (WGS84 ellipsoidal geodetic↔ECEF↔UTM↔local-ENU, all with <1 mm
accuracy).  The V19 API (``GeoPoint``, ``LocalPoint``, ``geo_to_local``,
``local_to_geo``, ``distance``, ``bearing``) is preserved for backward
compatibility, but now all transforms use the full CRS pipeline.

This closes V19 gap G2 (tangent-plane approximation that treats lat/lon as
flat offsets and ignores ellipsoidal geometry).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from petroppo.physics.coordinates import (  # noqa: F401
    CRS,
    Geographic,
    UTM,
    Local,
    CRSMismatch,
    transform,
    geodetic_to_ecef,
    ecef_to_geodetic,
    to_local_xy,
    local_to_latlon,
)


@dataclass(frozen=True)
class GeoPoint:
    """Geographic point by latitude and longitude (degrees)."""
    lat: float
    lon: float
    elev: float = 0.0  # elevation in meters


@dataclass(frozen=True)
class LocalPoint:
    """Local point with easting/northing/elevation (meters)."""
    easting: float
    northing: float
    elev: float = 0.0


def geo_to_local(origin: GeoPoint, point: GeoPoint) -> LocalPoint:
    """Convert geographic to local ENU at *origin* using the V20 CRS framework."""
    e, n, u = to_local_xy(point.lat, point.lon, origin.lat, origin.lon,
                          h0=origin.elev)
    return LocalPoint(easting=e, northing=n, elev=u)


def local_to_geo(origin: GeoPoint, point: LocalPoint) -> GeoPoint:
    """Inverse conversion from local ENU to geographic via V20 CRS framework."""
    lat, lon, h = local_to_latlon(point.easting, point.northing, point.elev,
                                  origin.lat, origin.lon, h0=origin.elev)
    return GeoPoint(lat=lat, lon=lon, elev=h)


def distance(a: LocalPoint, b: LocalPoint) -> float:
    """Horizontal distance between two local points (meters)."""
    return math.hypot(a.easting - b.easting, a.northing - b.northing)


def bearing(a: LocalPoint, b: LocalPoint) -> float:
    """Azimuth from a to b in degrees [0, 360)."""
    dx = b.easting - a.easting
    dy = b.northing - a.northing
    az = math.degrees(math.atan2(dx, dy))
    return az % 360.0
