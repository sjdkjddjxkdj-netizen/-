"""Custom exception hierarchy for petroppo."""
from __future__ import annotations


class petroppoError(Exception):
    """Base exception for all petroppo errors."""

    def __init__(self, message: str, detail: str = ""):
        self.message = message
        self.detail = detail
        super().__init__(message)


class ConfigError(petroppoError):
    """Configuration error."""


class DatabaseError(petroppoError):
    """Database operation error."""


class HardwareError(petroppoError):
    """Hardware/instrument error."""


class DeviceNotFoundError(HardwareError):
    """Device not found in registry or manager."""


class DeviceConnectionError(HardwareError):
    """Failed to connect to a device."""


class SimulationError(petroppoError):
    """Simulation error."""


class ForwardModelError(SimulationError):
    """Forward modeling error."""


class InversionError(petroppoError):
    """Inversion error."""


class DataQualityError(petroppoError):
    """Data quality issue."""


class UIError(petroppoError):
    """UI error."""


# ──────────────────────────────────────────────────────────────────────────────
# V20 Scientific error hierarchy
# ──────────────────────────────────────────────────────────────────────────────
# V19 scattered ad-hoc ValueError/RuntimeError raises with inconsistent messages.
# V20 introduces typed scientific errors so the benchmark harness and verification
# suite can catch specific failure modes (non-converged solve vs unit mismatch vs
# CRS error) and report them distinctly in the Gate report.

from petroppo.physics.units import DimensionError as _DimensionError
from petroppo.physics.coordinates import CRSMismatch as _CRSMismatch


class ScientificError(Exception):
    """Base class for all petroppo V20 scientific errors."""


class ConvergenceError(ScientificError):
    """Solver did not converge within the iteration budget or tolerance."""


class UnitError(_DimensionError, ScientificError):
    """Unit / dimension mismatch.  Alias for physics.units.DimensionError."""


class CoordinateError(_CRSMismatch, ScientificError):
    """CRS mismatch.  Alias for physics.coordinates.CRSMismatch."""


class JacobianError(ScientificError):
    """Jacobian computation or validation (G6 agreement) failed."""


class GateFailure(ScientificError):
    """A V20 Gate criterion (G-A … G-K) was not satisfied."""

    def __init__(self, gate_id: str, message: str):
        self.gate_id = gate_id
        super().__init__(f"[{gate_id}] {message}")


class ReproducibilityError(ScientificError):
    """A rerun under the same conditions produced materially different results."""
