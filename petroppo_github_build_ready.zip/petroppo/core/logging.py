"""Central logging unit — single logging system for the whole application."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .config import get_settings

_LOGGER_NAME = "petroppo"
_initialized = False


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    """Configure the logging system once."""
    global _initialized
    logger = logging.getLogger(_LOGGER_NAME)

    if _initialized:
        return logger

    logger.setLevel(level)
    logger.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # console output
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    # rotating file output
    settings = get_settings()
    settings.ensure_dirs()
    log_file: Path = settings.data_dir / "petroppo.log"
    try:
        fh = RotatingFileHandler(
            log_file, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
        )
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except Exception as exc:  # pragma: no cover
        logger.warning("Failed to open log file %s: %s", log_file, exc)

    _initialized = True
    logger.info("Logging system initialized — file: %s", log_file)
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """Get a child logger linked to the main logger."""
    if not _initialized:
        setup_logging()
    if name:
        return logging.getLogger(f"{_LOGGER_NAME}.{name}")
    return logging.getLogger(_LOGGER_NAME)
