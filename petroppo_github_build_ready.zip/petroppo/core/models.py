"""Shared data models used across the entire petroppo system."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np


def new_id() -> str:
    """Generate a short unique identifier."""
    return uuid.uuid4().hex[:12]


class ProjectStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class SurveyStatus(str, Enum):
    PLANNED = "planned"
    SIMULATED = "simulated"
    ACQUIRING = "acquiring"
    COMPLETED = "completed"


class DeviceStatus(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTED = "connected"
    ACQUIRING = "acquiring"
    ERROR = "error"


class MeasurementMethod(str, Enum):
    """Geophysical measurement methods supported by petroppo."""
    ERT = "ert"                # Electrical Resistivity Tomography
    SPECTRAL = "spectral"      # Spectral Induced Polarization (multi-frequency)
    MAGNETIC = "magnetic"      # Magnetic survey
    GRAVITY = "gravity"        # Gravity survey
    GPR = "gpr"                # Ground Penetrating Radar
    SEISMIC = "seismic"        # Seismic refraction


@dataclass
class Project:
    """An exploration project."""
    id: str = field(default_factory=new_id)
    name: str = "New Project"
    description: str = ""
    status: ProjectStatus = ProjectStatus.DRAFT
    origin_lat: float = 0.0
    origin_lon: float = 0.0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class Survey:
    """A geophysical survey within a project."""
    id: str = field(default_factory=new_id)
    project_id: str = ""
    name: str = "New Survey"
    method: MeasurementMethod = MeasurementMethod.ERT
    status: SurveyStatus = SurveyStatus.PLANNED
    grid_spacing: float = 5.0       # meters
    n_lines: int = 1
    n_electrodes: int = 32
    config: str = "wenner"          # electrode configuration
    frequency: float = 1.0          # Hz (for spectral methods)
    created_at: float = field(default_factory=time.time)
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeviceInfo:
    """Description of a measurement instrument."""
    id: str = field(default_factory=new_id)
    name: str = "Unnamed Instrument"
    kind: MeasurementMethod = MeasurementMethod.ERT
    driver: str = "virtual"         # driver name in HAL
    connection: str = "virtual"     # usb / serial / ethernet / virtual
    address: str = ""               # connection address
    status: DeviceStatus = DeviceStatus.DISCONNECTED
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class Measurement:
    """A single reading from an instrument."""
    id: str = field(default_factory=new_id)
    survey_id: str = ""
    device_id: str = ""
    method: MeasurementMethod = MeasurementMethod.ERT
    timestamp: float = field(default_factory=time.time)
    # position
    x: float = 0.0   # local easting
    y: float = 0.0   # local northing
    z: float = 0.0   # elevation/depth
    # raw physical values
    values: dict[str, float] = field(default_factory=dict)
    # reading quality (0..1) computed by QC
    quality: float = 1.0
    note: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def apparent_resistivity(self) -> float | None:
        return self.values.get("rho_a")

    @property
    def voltage(self) -> float | None:
        return self.values.get("v")

    @property
    def current(self) -> float | None:
        return self.values.get("i")


# --- Simulation & Earth Model ---
@dataclass
class Layer:
    """A subsurface layer in the earth model."""
    name: str
    top_depth: float     # meters
    bottom_depth: float  # meters
    resistivity: float   # ohm·m
    density: float = 2400.0      # kg/m³
    magnetic_susceptibility: float = 0.0  # SI
    vp: float = 2000.0           # P-wave velocity (m/s)
    vs: float = 1200.0           # S-wave velocity (m/s)
    dielectric: float = 6.0      # relative permittivity (for GPR)
    color: str = "#8B7355"


@dataclass
class ResistivityBody:
    """A physical anomaly body within the model (e.g., reservoir, brine, ore).

    Carries all physical properties needed for accurate multi-method forward
    modeling: resistivity (ERT/IP), density (gravity), magnetic
    susceptibility (magnetics), and dielectric permittivity (GPR).
    A value of ``None`` means "inherit from the host layer".
    """
    cx: float  # center x
    cy: float  # center y
    cz: float  # center z (positive downward)
    rx: float  # semi-axis x
    ry: float  # semi-axis y
    rz: float  # semi-axis z
    resistivity: float
    label: str = "body"
    density: float | None = None                 # kg/m^3 (None = inherit host)
    magnetic_susceptibility: float | None = None  # SI (None = inherit host)
    dielectric: float | None = None               # relative permittivity (GPR)
    vp: float | None = None                       # P-wave velocity (m/s)
    chargeability: float = 0.0                    # IP chargeability (0..1)

    def contains(self, x: float, y: float, z: float) -> bool:
        dx = (x - self.cx) / max(self.rx, 1e-9)
        dy = (y - self.cy) / max(self.ry, 1e-9)
        dz = (z - self.cz) / max(self.rz, 1e-9)
        return dx * dx + dy * dy + dz * dz <= 1.0


@dataclass
class EarthModel:
    """The virtual earth model used for forward simulation."""
    name: str = "Untitled"
    layers: list[Layer] = field(default_factory=list)
    bodies: list[ResistivityBody] = field(default_factory=list)
    extent_x: tuple[float, float] = (0.0, 100.0)
    extent_y: tuple[float, float] = (0.0, 0.0)
    max_depth: float = 50.0
    background_resistivity: float = 100.0

    def resistivity_at(self, x: float, y: float, z: float) -> float:
        """Return the true resistivity at point (x, y, z)."""
        for b in self.bodies:
            if b.contains(x, y, z):
                return b.resistivity
        for lay in self.layers:
            if lay.top_depth <= z <= lay.bottom_depth:
                return lay.resistivity
        return self.background_resistivity

    def layer_at(self, z: float) -> Layer | None:
        """Return the layer containing depth z, or None."""
        for lay in self.layers:
            if lay.top_depth <= z <= lay.bottom_depth:
                return lay
        return None

    def property_at(self, x: float, y: float, z: float, prop: str,
                    default: float = 0.0) -> float:
        """Return a physical property (density, vp, etc.) at a point."""
        for b in self.bodies:
            if b.contains(x, y, z):
                break
        lay = self.layer_at(z)
        if lay:
            return float(getattr(lay, prop, default))
        return default


# --- Results ---
@dataclass
class InversionResult:
    """Result of an inversion run."""
    survey_id: str
    model: np.ndarray = field(default_factory=lambda: np.empty(0))
    rmse: float = 0.0
    n_iter: int = 0
    cell_size: float = 5.0
    extent: tuple[float, float, float] = (0.0, 0.0, 0.0)
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class QualityReport:
    """Data quality report for survey measurements."""
    survey_id: str
    overall_quality: float = 1.0   # 0..1
    n_total: int = 0
    n_good: int = 0
    n_bad: int = 0
    issues: list[str] = field(default_factory=list)
    per_measurement: dict[str, float] = field(default_factory=dict)
