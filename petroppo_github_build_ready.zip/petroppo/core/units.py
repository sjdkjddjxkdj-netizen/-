"""Physical unit definitions and conversions.

V20 shim: delegates to the strict :mod:`petroppo.physics.units` module which
enforces dimensional consistency.  The V19 API (``convert``, ``format_value``,
``UNITS`` dict, ``Unit`` dataclass) is preserved for backward compatibility,
but now all conversions route through the dimension-aware physics layer.

This closes V19 gap G1 (permissive units: 14 units, trusts the caller, no
dimension checking).
"""
from __future__ import annotations

from petroppo.physics.units import (  # noqa: F401
    Unit,
    Quantity,
    DimensionError,
    UNITS,
    register_unit,
    convert,
    to_si,
    format_value,
)

__all__ = [
    "Unit",
    "Quantity",
    "DimensionError",
    "UNITS",
    "register_unit",
    "convert",
    "to_si",
    "format_value",
]
