"""Database access layer — SQLite with JSON-serialized flexible fields."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

from ..core import (
    DatabaseError, Project, Survey, DeviceInfo, Measurement, MeasurementMethod,
    ProjectStatus, SurveyStatus, DeviceStatus, get_logger, get_settings,
)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT DEFAULT 'draft',
    origin_lat REAL DEFAULT 0,
    origin_lon REAL DEFAULT 0,
    created_at REAL,
    updated_at REAL,
    meta TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS surveys (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    name TEXT,
    method TEXT,
    status TEXT DEFAULT 'planned',
    grid_spacing REAL,
    n_lines INTEGER,
    n_electrodes INTEGER,
    config TEXT,
    frequency REAL,
    created_at REAL,
    meta TEXT DEFAULT '{}',
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    name TEXT,
    kind TEXT,
    driver TEXT,
    connection TEXT,
    address TEXT,
    status TEXT DEFAULT 'disconnected',
    meta TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS measurements (
    id TEXT PRIMARY KEY,
    survey_id TEXT,
    device_id TEXT,
    method TEXT,
    timestamp REAL,
    x REAL, y REAL, z REAL,
    vals TEXT DEFAULT '{}',
    quality REAL DEFAULT 1.0,
    note TEXT DEFAULT '',
    meta TEXT DEFAULT '{}',
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_survey_project ON surveys(project_id);
CREATE INDEX IF NOT EXISTS idx_meas_survey ON measurements(survey_id);
"""


class Database:
    """Thread-safe SQLite database manager."""

    def __init__(self, path: Path | None = None):
        self.path = path or get_settings().db_path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._log = get_logger("db")
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    @contextmanager
    def conn(self) -> Generator[sqlite3.Connection, None, None]:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = self._connect()
        try:
            yield self._local.conn
            self._local.conn.commit()
        except Exception:
            self._local.conn.rollback()
            raise

    def _init_schema(self) -> None:
        try:
            with self.conn() as c:
                c.executescript(_SCHEMA)
            self._log.info("Database schema initialized: %s", self.path)
        except sqlite3.Error as exc:
            raise DatabaseError("Failed to initialize database", detail=str(exc)) from exc

    # --- Projects ---
    def save_project(self, p: Project) -> Project:
        p.updated_at = time.time()
        with self.conn() as c:
            c.execute(
                """INSERT INTO projects
                   (id,name,description,status,origin_lat,origin_lon,created_at,updated_at,meta)
                   VALUES (?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET
                     name=excluded.name, description=excluded.description,
                     status=excluded.status, origin_lat=excluded.origin_lat,
                     origin_lon=excluded.origin_lon, updated_at=excluded.updated_at,
                     meta=excluded.meta""",
                (p.id, p.name, p.description, p.status.value,
                 p.origin_lat, p.origin_lon, p.created_at, p.updated_at,
                 json.dumps(p.meta)),
            )
        return p

    def list_projects(self) -> list[Project]:
        with self.conn() as c:
            rows = c.execute("SELECT * FROM projects ORDER BY updated_at DESC").fetchall()
        return [self._row_to_project(r) for r in rows]

    def get_project(self, project_id: str) -> Project | None:
        with self.conn() as c:
            r = c.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        return self._row_to_project(r) if r else None

    def delete_project(self, project_id: str) -> None:
        with self.conn() as c:
            c.execute("DELETE FROM projects WHERE id=?", (project_id,))

    def _row_to_project(self, r: sqlite3.Row) -> Project:
        return Project(
            id=r["id"], name=r["name"], description=r["description"],
            status=ProjectStatus(r["status"]),
            origin_lat=r["origin_lat"], origin_lon=r["origin_lon"],
            created_at=r["created_at"], updated_at=r["updated_at"],
            meta=json.loads(r["meta"] or "{}"),
        )

    # --- Surveys ---
    def save_survey(self, s: Survey) -> Survey:
        with self.conn() as c:
            c.execute(
                """INSERT INTO surveys
                   (id,project_id,name,method,status,grid_spacing,n_lines,n_electrodes,
                    config,frequency,created_at,meta)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET
                     project_id=excluded.project_id, name=excluded.name,
                     method=excluded.method, status=excluded.status,
                     grid_spacing=excluded.grid_spacing, n_lines=excluded.n_lines,
                     n_electrodes=excluded.n_electrodes, config=excluded.config,
                     frequency=excluded.frequency, meta=excluded.meta""",
                (s.id, s.project_id, s.name, s.method.value, s.status.value,
                 s.grid_spacing, s.n_lines, s.n_electrodes, s.config, s.frequency,
                 s.created_at, json.dumps(s.meta)),
            )
        return s

    def list_surveys(self, project_id: str) -> list[Survey]:
        with self.conn() as c:
            rows = c.execute(
                "SELECT * FROM surveys WHERE project_id=? ORDER BY created_at DESC",
                (project_id,),
            ).fetchall()
        return [self._row_to_survey(r) for r in rows]

    def get_survey(self, survey_id: str) -> Survey | None:
        with self.conn() as c:
            r = c.execute("SELECT * FROM surveys WHERE id=?", (survey_id,)).fetchone()
        return self._row_to_survey(r) if r else None

    def delete_survey(self, survey_id: str) -> None:
        with self.conn() as c:
            c.execute("DELETE FROM surveys WHERE id=?", (survey_id,))

    def _row_to_survey(self, r: sqlite3.Row) -> Survey:
        return Survey(
            id=r["id"], project_id=r["project_id"], name=r["name"],
            method=MeasurementMethod(r["method"]),
            status=SurveyStatus(r["status"]),
            grid_spacing=r["grid_spacing"], n_lines=r["n_lines"],
            n_electrodes=r["n_electrodes"], config=r["config"],
            frequency=r["frequency"], created_at=r["created_at"],
            meta=json.loads(r["meta"] or "{}"),
        )

    # --- Devices ---
    def save_device(self, d: DeviceInfo) -> DeviceInfo:
        with self.conn() as c:
            c.execute(
                """INSERT OR REPLACE INTO devices
                   (id,name,kind,driver,connection,address,status,meta)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (d.id, d.name, d.kind.value, d.driver, d.connection, d.address,
                 d.status.value, json.dumps(d.meta)),
            )
        return d

    def list_devices(self) -> list[DeviceInfo]:
        with self.conn() as c:
            rows = c.execute("SELECT * FROM devices ORDER BY name").fetchall()
        return [self._row_to_device(r) for r in rows]

    def delete_device(self, device_id: str) -> None:
        with self.conn() as c:
            c.execute("DELETE FROM devices WHERE id=?", (device_id,))

    def _row_to_device(self, r: sqlite3.Row) -> DeviceInfo:
        return DeviceInfo(
            id=r["id"], name=r["name"], kind=MeasurementMethod(r["kind"]),
            driver=r["driver"], connection=r["connection"], address=r["address"],
            status=DeviceStatus(r["status"]),
            meta=json.loads(r["meta"] or "{}"),
        )

    # --- Measurements ---
    def save_measurement(self, m: Measurement) -> Measurement:
        with self.conn() as c:
            c.execute(
                """INSERT OR REPLACE INTO measurements
                   (id,survey_id,device_id,method,timestamp,x,y,z,vals,quality,note,meta)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (m.id, m.survey_id, m.device_id, m.method.value, m.timestamp,
                 m.x, m.y, m.z, json.dumps(m.values), m.quality, m.note,
                 json.dumps(m.meta)),
            )
        return m

    def save_measurements(self, ms: list[Measurement]) -> int:
        n = 0
        with self.conn() as c:
            for m in ms:
                c.execute(
                    """INSERT OR REPLACE INTO measurements
                       (id,survey_id,device_id,method,timestamp,x,y,z,vals,quality,note,meta)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (m.id, m.survey_id, m.device_id, m.method.value, m.timestamp,
                     m.x, m.y, m.z, json.dumps(m.values), m.quality, m.note,
                     json.dumps(m.meta)),
                )
                n += 1
        return n

    def list_measurements(self, survey_id: str) -> list[Measurement]:
        with self.conn() as c:
            rows = c.execute(
                "SELECT * FROM measurements WHERE survey_id=? ORDER BY timestamp",
                (survey_id,),
            ).fetchall()
        return [self._row_to_measurement(r) for r in rows]

    def count_measurements(self, survey_id: str) -> int:
        with self.conn() as c:
            r = c.execute(
                "SELECT COUNT(*) FROM measurements WHERE survey_id=?", (survey_id,)
            ).fetchone()
        return r[0]

    def _row_to_measurement(self, r: sqlite3.Row) -> Measurement:
        return Measurement(
            id=r["id"], survey_id=r["survey_id"], device_id=r["device_id"],
            method=MeasurementMethod(r["method"]), timestamp=r["timestamp"],
            x=r["x"], y=r["y"], z=r["z"],
            values=json.loads(r["vals"] or "{}"),
            quality=r["quality"], note=r["note"],
            meta=json.loads(r["meta"] or "{}"),
        )


_db: Database | None = None


def get_db() -> Database:
    global _db
    if _db is None:
        _db = Database()
    return _db
