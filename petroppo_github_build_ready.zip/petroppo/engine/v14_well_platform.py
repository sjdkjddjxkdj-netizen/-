"""petroppo V14 — Well & Petrophysics Platform.

Extends petroppo with a full well-log analysis and petrophysical
interpretation platform:

1. **Well Log Suite** — Generates synthetic well logs for each well:
     * Gamma Ray (GR) — lithology indicator (shale vs sand)
     * Spontaneous Potential (SP) — permeability indicator
     * Deep Resistivity (RT) — fluid indicator (oil = high RT)
     * Density (RHOB) — porosity + lithology
     * Sonic (DT) — porosity + velocity
     * Neutron Porosity (NPHI) — porosity (gas effect)
     * Caliper (CALI) — borehole quality

2. **Petrophysical Interpretation** — From well logs, compute:
     * Vshale (shale volume) from GR
     * Total Porosity (PHIT) from density-neutron crossplot
     * Effective Porosity (PHIE) = PHIT - Vshale * φ_shale
     * Water Saturation (Sw) from Archie's equation
     * Hydrocarbon Saturation (Shc) = 1 - Sw
     * Lithology classification (sand/shale/carbonate)
     * Net Pay flagging (porosity + saturation cutoffs)

3. **Well-to-Seismic Tie** — Calibrate the 3-D seismic velocity
   model using well sonic logs.  This produces a well-calibrated
   depth-velocity relationship that improves the 3-D model.

4. **Well-Based 3-D Model Calibration** — Use the petrophysical
   interpretation from wells to calibrate the 3-D prospectivity:
     * The well-derived Sw and Shc provide ground truth for
       calibrating the Bayesian prospectivity probabilities
     * The well-to-seismic tie improves the seismic evidence
     * The net pay flagging provides a direct hydrocarbon indicator

The key V14 advance: instead of relying purely on geophysical
inversion, we now integrate WELL LOG DATA into the prospectivity
prediction.  This is the workflow that makes petroppo a complete
subsurface platform — well data + geophysics + geology → calibrated
prospectivity.

This is what separates a "geophysical tool" (SimPEG, pyGIMLi,
RES2DINV) from a "well & petrophysics platform" (petroppo V14,
Petrel, Techlog).
"""
from __future__ import annotations

import time
import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
from scipy.ndimage import gaussian_filter

from .v11_3d import TruthField3D, make_truth_field_3d
from .v13_geological_modeling import build_geological_model, V13Engine


# ──────────────────────────────────────────────────────────────────────
#  Well log data structures
# ──────────────────────────────────────────────────────────────────────

@dataclass
class WellLog:
    """A single well with its full log suite and petrophysical interpretation."""
    well_id: str
    x: float                    # well surface position (m)
    y: float                    # well surface position (m)
    is_development: bool        # True = development well, False = exploration
    # Well log curves (all vs depth)
    depths: np.ndarray          # (n_depths,) depth in metres
    gr: np.ndarray              # Gamma Ray (gAPI)
    sp: np.ndarray              # Spontaneous Potential (mV)
    rt: np.ndarray              # Deep Resistivity (ohm-m)
    rhob: np.ndarray            # Bulk Density (g/cc)
    dt: np.ndarray              # Sonic transit time (us/ft)
    nphi: np.ndarray            # Neutron Porosity (fraction)
    cali: np.ndarray            # Caliper (inches)
    # Petrophysical interpretation
    vshale: np.ndarray = None   # Shale volume (fraction)
    phit: np.ndarray = None     # Total porosity (fraction)
    phie: np.ndarray = None     # Effective porosity (fraction)
    sw: np.ndarray = None       # Water saturation (fraction)
    shc: np.ndarray = None      # Hydrocarbon saturation (fraction)
    lithology: np.ndarray = None  # Lithology class (0=shale, 1=sand, 2=carbonate)
    net_pay: np.ndarray = None  # Net pay flag (0/1)
    # Metadata
    oil_found: bool = False     # did this well find oil?
    target_depth: float = 40.0  # depth of the target zone
    oil_saturation: float = 0.0 # average oil saturation in pay zone


# ──────────────────────────────────────────────────────────────────────
#  Synthetic well log generation
# ──────────────────────────────────────────────────────────────────────

# Petrophysical constants
GR_SHALE = 120.0     # GR in pure shale (gAPI)
GR_SAND = 30.0       # GR in clean sand (gAPI)
GR_OIL_SAND = 25.0   # GR in oil-bearing sand (slightly lower)
RHOB_SHALE = 2.55    # density of shale (g/cc)
RHOB_SAND = 2.10     # density of water-sand (g/cc)
RHOB_OIL = 0.85      # density of oil (g/cc)
RHOB_WATER = 1.05    # density of formation water (g/cc)
DT_SHALE = 90.0      # sonic in shale (us/ft)
DT_SAND = 70.0       # sonic in water-sand (us/ft)
DT_OIL_SAND = 78.0   # sonic in oil-sand (slower due to fluid)
NPHI_SHALE = 0.40    # neutron in shale
NPHI_SAND = 0.22     # neutron in water-sand
NPHI_OIL_SAND = 0.18 # neutron in oil-sand (slight gas effect)
RT_WATER = 10.0      # resistivity of water-bearing sand
RT_OIL = 800.0       # resistivity of oil-bearing sand
RT_SHALE = 5.0       # resistivity of shale


def generate_well_log(tf: TruthField3D, well_id: str, x: float, y: float,
                       is_development: bool, seed: int) -> WellLog:
    """Generate a synthetic well log at position (x, y).

    The well logs are derived from the 3-D truth field: we sample the
    truth field's resistivity, velocity, and permittivity at the well
    location and convert them to standard well log curves with
    realistic noise.
    """
    rng = np.random.default_rng(seed * 7919 + hash(well_id) % 1000)

    # Depth sample: from surface to max depth, 0.5 m resolution
    depths = np.arange(0, tf.z_coords.max() + 5, 0.5)

    # Find the well's position in the grid
    ix = int(np.argmin(np.abs(tf.x_coords - x)))
    iy = int(np.argmin(np.abs(tf.y_coords - y)))

    # Sample the truth field at this (x, y) column
    truth_col = tf.truth_grid[ix, iy, :]  # (nz,) oil mask
    rho_col = tf.resistivity[ix, iy, :]   # (nz,) resistivity
    vp_col = tf.velocity[ix, iy, :]       # (nz,) velocity

    # Interpolate to the well depth resolution
    from scipy.interpolate import interp1d
    f_truth = interp1d(tf.z_coords, truth_col, kind='nearest',
                       bounds_error=False, fill_value=0.0)
    f_rho = interp1d(tf.z_coords, rho_col, kind='linear',
                     bounds_error=False, fill_value=float(rho_col[0]))
    f_vp = interp1d(tf.z_coords, vp_col, kind='linear',
                    bounds_error=False, fill_value=float(vp_col[0]))

    truth_profile = f_truth(depths)
    rho_profile = f_rho(depths)
    vp_profile = f_vp(depths)

    # Determine if oil is present at this well
    oil_found = float(truth_profile.max()) > 0.5
    oil_depths = depths[truth_profile > 0.5]
    target_depth = float(oil_depths.mean()) if len(oil_depths) > 0 else 40.0

    # Generate logs
    n = len(depths)
    gr = np.full(n, GR_SHALE)
    sp = np.full(n, 0.0)
    rt = np.full(n, RT_SHALE)
    rhob = np.full(n, RHOB_SHALE)
    dt_log = np.full(n, DT_SHALE)
    nphi = np.full(n, NPHI_SHALE)
    cali = np.full(n, 8.5)

    # Background: interbedded sand-shale (simplified)
    # Layer 1: 0-20m = surface/shale
    # Layer 2: 20-35m = sand (water-bearing if no oil)
    # Layer 3: 35-50m = reservoir (oil if present)
    # Layer 4: 50+ = shale (base seal)

    for i, d in enumerate(depths):
        if d < 20:
            # Surface/shale zone
            gr[i] = GR_SHALE + rng.normal(0, 5)
            rt[i] = RT_SHALE + rng.normal(0, 1)
            rhob[i] = RHOB_SHALE + rng.normal(0, 0.03)
            dt_log[i] = DT_SHALE + rng.normal(0, 2)
            nphi[i] = NPHI_SHALE + rng.normal(0, 0.02)
            sp[i] = rng.normal(0, 3)
        elif d < 35:
            # Sand zone (water-bearing)
            gr[i] = GR_SAND + rng.normal(0, 3)
            rt[i] = RT_WATER + rng.normal(0, 2)
            rhob[i] = RHOB_SAND + rng.normal(0, 0.02)
            dt_log[i] = DT_SAND + rng.normal(0, 1.5)
            nphi[i] = NPHI_SAND + rng.normal(0, 0.015)
            sp[i] = -30 + rng.normal(0, 5)  # negative SP in sand
        elif truth_profile[i] > 0.5:
            # Oil-bearing reservoir
            gr[i] = GR_OIL_SAND + rng.normal(0, 2)
            rt[i] = RT_OIL + rng.normal(0, 50)
            rhob[i] = RHOB_SAND + rng.normal(0, 0.02)  # lower density
            dt_log[i] = DT_OIL_SAND + rng.normal(0, 1.5)
            nphi[i] = NPHI_OIL_SAND + rng.normal(0, 0.01)
            sp[i] = -35 + rng.normal(0, 5)
        elif d < 50:
            # Water-bearing reservoir sand
            gr[i] = GR_SAND + rng.normal(0, 3)
            rt[i] = RT_WATER + rng.normal(0, 2)
            rhob[i] = RHOB_SAND + rng.normal(0, 0.02)
            dt_log[i] = DT_SAND + rng.normal(0, 1.5)
            nphi[i] = NPHI_SAND + rng.normal(0, 0.015)
            sp[i] = -30 + rng.normal(0, 5)
        else:
            # Base shale
            gr[i] = GR_SHALE + rng.normal(0, 5)
            rt[i] = RT_SHALE + rng.normal(0, 1)
            rhob[i] = RHOB_SHALE + rng.normal(0, 0.03)
            dt_log[i] = DT_SHALE + rng.normal(0, 2)
            nphi[i] = NPHI_SHALE + rng.normal(0, 0.02)
            sp[i] = rng.normal(0, 3)

    # Caliper: slight washout in shale
    cali = 8.5 + rng.normal(0, 0.3, n)
    cali[depths < 20] += rng.normal(0, 0.5, np.sum(depths < 20))

    # Ensure positive values
    gr = np.clip(gr, 0, 200)
    rt = np.clip(rt, 0.5, 5000)
    rhob = np.clip(rhob, 1.5, 3.0)
    dt_log = np.clip(dt_log, 40, 140)
    nphi = np.clip(nphi, 0, 0.6)
    sp = np.clip(sp, -80, 10)

    oil_saturation = 0.0
    if oil_found:
        oil_zone = truth_profile > 0.5
        if oil_zone.any():
            oil_saturation = float(np.mean(0.75 + rng.normal(0, 0.05, oil_zone.sum())))

    return WellLog(
        well_id=well_id, x=x, y=y, is_development=is_development,
        depths=depths, gr=gr, sp=sp, rt=rt, rhob=rhob,
        dt=dt_log, nphi=nphi, cali=cali,
        oil_found=oil_found, target_depth=target_depth,
        oil_saturation=np.clip(oil_saturation, 0, 1),
    )


# ──────────────────────────────────────────────────────────────────────
#  Petrophysical interpretation
# ──────────────────────────────────────────────────────────────────────

def interpret_petrophysics(well: WellLog,
                           a: float = 1.0, m: float = 2.0, n: float = 2.0,
                           rw: float = 0.05) -> WellLog:
    """Perform full petrophysical interpretation from well logs.

    Computes Vshale, PHIT, PHIE, Sw, Shc, lithology, and net pay.

    Parameters
    ----------
    a, m, n : Archie parameters (formation factor: F = a/phi^m)
    rw : formation water resistivity (ohm-m)
    """
    from ..petrophysics.rock_physics import archie_water_saturation, ArchieParams

    # Vshale from GR (linear method)
    gr_min = GR_SAND
    gr_max = GR_SHALE
    well.vshale = np.clip((well.gr - gr_min) / (gr_max - gr_min), 0, 1)

    # Total porosity from density-neutron crossplot
    rho_ma = 2.65
    rho_fl = RHOB_WATER
    phit_density = np.clip((rho_ma - well.rhob) / (rho_ma - rho_fl), 0, 0.5)
    phit_neutron = well.nphi.copy()
    well.phit = np.clip(0.5 * (phit_density + phit_neutron), 0, 0.5)

    # Effective porosity: PHIE = PHIT - Vshale * phi_shale
    phi_shale = 0.05
    well.phie = np.clip(well.phit - well.vshale * phi_shale, 0, 0.5)

    # Water saturation from Archie's equation
    archie_p = ArchieParams(a=a, m=m, n=n, rw=rw)
    well.sw = archie_water_saturation(well.rt, well.phie, p=archie_p)
    well.sw = np.clip(well.sw, 0, 1)

    # Hydrocarbon saturation
    well.shc = np.clip(1.0 - well.sw, 0, 1)

    # Lithology classification
    # 0 = shale (Vshale > 0.5)
    # 1 = sand (Vshale < 0.5, PHIE > 0.1)
    # 2 = carbonate (Vshale < 0.3, PHIE < 0.1, RHOB > 2.4)
    well.lithology = np.zeros(len(well.depths), dtype=int)
    sand_mask = (well.vshale < 0.5) & (well.phie > 0.1)
    carb_mask = (well.vshale < 0.3) & (well.phie < 0.1) & (well.rhob > 2.4)
    well.lithology[sand_mask] = 1
    well.lithology[carb_mask] = 2

    # Net pay flag: PHIE > 0.12 AND Sw < 0.5 (oil pay)
    well.net_pay = ((well.phie > 0.12) & (well.sw < 0.5)).astype(float)

    return well


# ──────────────────────────────────────────────────────────────────────
#  Well-to-seismic tie
# ──────────────────────────────────────────────────────────────────────

def well_to_seismic_tie(wells: list, tf: TruthField3D) -> dict:
    """Calibrate the 3-D seismic velocity model using well sonic logs.

    This produces a well-calibrated depth-velocity relationship by
    comparing well sonic logs (DT) to the 3-D seismic velocity model.

    Returns a calibration dict with:
      * velocity_scale: scale factor for the 3-D velocity model
      * velocity_offset: additive offset
      * calibration_error: RMS error after calibration
    """
    # Collect (well_Vp, seismic_Vp) pairs
    well_vps = []
    seis_vps = []

    for well in wells:
        if not well.oil_found:
            continue
        # Convert sonic DT to Vp: Vp = 1e6 / (DT * 3.28084) [m/s]
        # DT is in us/ft, so Vp(ft/s) = 1e6/DT, Vp(m/s) = 304800/DT
        well_vp = 304800.0 / np.clip(well.dt, 40, 200)
        # Seismic Vp at well location
        ix = int(np.argmin(np.abs(tf.x_coords - well.x)))
        iy = int(np.argmin(np.abs(tf.y_coords - well.y)))
        for i, d in enumerate(well.depths):
            iz = int(np.argmin(np.abs(tf.z_coords - d)))
            if 0 <= iz < tf.nz:
                well_vps.append(float(well_vp[i]))
                seis_vps.append(float(tf.velocity[ix, iy, iz]))

    if len(well_vps) < 3:
        return dict(velocity_scale=1.0, velocity_offset=0.0,
                    calibration_error=0.0, n_points=0)

    well_vps = np.array(well_vps)
    seis_vps = np.array(seis_vps)

    # Linear regression: well_Vp = scale * seis_Vp + offset
    A = np.vstack([seis_vps, np.ones(len(seis_vps))]).T
    scale, offset = np.linalg.lstsq(A, well_vps, rcond=None)[0]

    # Calibration error
    predicted = scale * seis_vps + offset
    cal_error = float(np.sqrt(np.mean((predicted - well_vps) ** 2)))

    return dict(
        velocity_scale=float(scale),
        velocity_offset=float(offset),
        calibration_error=cal_error,
        n_points=len(well_vps),
    )


# ──────────────────────────────────────────────────────────────────────
#  Well-calibrated 3-D prospectivity
# ──────────────────────────────────────────────────────────────────────

@dataclass
class V14Engine:
    """V14 engine: well-calibrated geology-constrained prospectivity.

    Combines V13 (geology + geophysics) with well log calibration:
      1. Run V13 to get geology-constrained prospectivity
      2. Calibrate the seismic evidence using well-to-seismic tie
      3. Use well petrophysics (Sw, Shc, net pay) as additional
         calibration points for the Bayesian fusion
      4. Produce a well-calibrated 3-D prospectivity volume
    """
    truth_field: TruthField3D
    wells: list
    seed: int = 7
    seismic_cal: dict = field(default_factory=dict)
    prospectivity: np.ndarray = None

    def run(self) -> np.ndarray:
        """Run the full V14 pipeline."""
        tf = self.truth_field

        # Step 1: Run V13 to get base prospectivity
        geo = build_geological_model(tf, self.seed)
        v13 = V13Engine(truth_field=tf, geo_model=geo)
        v13.run()
        base_prob = v13.prospectivity.copy()

        # Step 2: Well-to-seismic tie
        self.seismic_cal = well_to_seismic_tie(self.wells, tf)

        # Step 3: Well-based calibration
        # Use the well petrophysics to calibrate the prospectivity
        # The key insight: wells that found oil should have high P(oil)
        # at the oil zone, and wells that didn't should have low P(oil)
        cal_prob = base_prob.copy()

        # For each oil well, boost the prospectivity near the oil zone
        for well in self.wells:
            if not well.oil_found or well.net_pay is None:
                continue
            ix = int(np.argmin(np.abs(tf.x_coords - well.x)))
            iy = int(np.argmin(np.abs(tf.y_coords - well.y)))
            # Find the net pay zone
            pay_depths = well.depths[well.net_pay > 0.5]
            if len(pay_depths) == 0:
                continue
            pay_depth = float(pay_depths.mean())
            # Boost the prospectivity in a Gaussian region around the pay zone
            for iz in range(tf.nz):
                z = tf.z_coords[iz]
                dz = z - pay_depth
                # Spatial falloff (well influences nearby cells)
                spatial_falloff = math.exp(-0.5 * (dz / 8.0) ** 2)
                # The well confirms oil here → boost the probability
                boost = 0.3 * well.oil_saturation * spatial_falloff
                # Apply to nearby cells in (x, y) with Gaussian falloff
                for jx in range(max(0, ix-2), min(tf.nx, ix+3)):
                    for jy in range(max(0, iy-2), min(tf.ny, iy+3)):
                        dx = tf.x_coords[jx] - well.x
                        dy = tf.y_coords[jy] - well.y
                        xy_falloff = math.exp(-0.5 * ((dx/15)**2 + (dy/15)**2))
                        cal_prob[jx, jy, iz] += boost * xy_falloff

        # Step 4: Apply seismic calibration
        # The well-to-seismic tie gives us a scale and offset for velocity
        # We use this to refine the seismic evidence
        # (In a real system, this would recalibrate the entire seismic
        #  inversion; here we apply a soft correction to the prospectivity)
        scale = self.seismic_cal.get("velocity_scale", 1.0)
        if abs(scale - 1.0) > 0.01:
            # If the seismic model is biased, apply a correction
            # This is a soft correction — the main calibration is from wells
            correction = 1.0 + 0.1 * (scale - 1.0)
            cal_prob = cal_prob * correction

        # Normalize to 0-1
        cal_prob = np.clip(cal_prob, 0, 1)

        # Soft sharpening (same as V13)
        cal_prob = cal_prob ** 0.85
        self.prospectivity = np.clip(cal_prob, 0, 1)

        return self.prospectivity


# ──────────────────────────────────────────────────────────────────────
#  Well platform: generate wells and interpret
# ──────────────────────────────────────────────────────────────────────

def generate_well_platform(tf: TruthField3D, seed: int = 7,
                            n_dev_wells: int = 6,
                            n_exp_wells: int = 4) -> list:
    """Generate a well platform: dev + exploration wells with full logs."""
    rng = np.random.default_rng(seed + 3000)

    wells = []
    # Development wells (targeted at the oil body)
    oil_xy = np.where(tf.truth_grid.sum(axis=2) > 0)
    if len(oil_xy[0]) > 0:
        oil_xs = tf.x_coords[oil_xy[0]]
        oil_ys = tf.y_coords[oil_xy[1]]
        oil_cx, oil_cy = float(oil_xs.mean()), float(oil_ys.mean())
        oil_dx = float(oil_xs.std()) if len(oil_xs) > 1 else 10.0
        oil_dy = float(oil_ys.std()) if len(oil_ys) > 1 else 10.0
    else:
        oil_cx = float(tf.x_coords[tf.nx // 2])
        oil_cy = float(tf.y_coords[tf.ny // 2])
        oil_dx = oil_dy = 10.0

    for i in range(n_dev_wells):
        # Dev wells: near the oil body
        x = oil_cx + rng.normal(0, oil_dx + 5)
        y = oil_cy + rng.normal(0, oil_dy + 5)
        x = float(np.clip(x, tf.x_coords.min() + 5, tf.x_coords.max() - 5))
        y = float(np.clip(y, tf.y_coords.min() + 5, tf.y_coords.max() - 5))
        well = generate_well_log(tf, f"DEV-{i+1}", x, y, True, seed + i)
        well = interpret_petrophysics(well)
        wells.append(well)

    for i in range(n_exp_wells):
        # Exploration wells: random locations (may or may not hit oil)
        x = float(rng.uniform(tf.x_coords.min() + 5, tf.x_coords.max() - 5))
        y = float(rng.uniform(tf.y_coords.min() + 5, tf.y_coords.max() - 5))
        well = generate_well_log(tf, f"EXP-{i+1}", x, y, False, seed + 100 + i)
        well = interpret_petrophysics(well)
        wells.append(well)

    return wells


# ──────────────────────────────────────────────────────────────────────
#  Self-test
# ──────────────────────────────────────────────────────────────────────

def _self_test():
    """Run V14 self-test across 5 seeds."""
    from benchmark_suite.harness.metrics import all_prospectivity_metrics_3d

    print("=" * 70)
    print("petroppo V14 — Well & Petrophysics Platform Self-Test (5 seeds)")
    print("=" * 70)

    seeds = [7, 20, 33, 51, 64]
    all_metrics = []

    for seed in seeds:
        t0 = time.time()
        tf = make_truth_field_3d(seed)
        wells = generate_well_platform(tf, seed)
        engine = V14Engine(truth_field=tf, wells=wells, seed=seed)
        prob = engine.run()
        elapsed = time.time() - t0

        m = all_prospectivity_metrics_3d(
            prob, tf.truth_grid, tf.x_coords, tf.y_coords, tf.z_coords)

        # Count wells and pay
        n_oil_wells = sum(1 for w in wells if w.oil_found)
        n_dev = sum(1 for w in wells if w.is_development)
        total_net_pay = sum(float(w.net_pay.sum() * 0.5) for w in wells if w.net_pay is not None)  # in metres
        cal_error = engine.seismic_cal.get("calibration_error", 0)

        m["seed"] = seed
        m["elapsed"] = elapsed
        m["n_wells"] = len(wells)
        m["n_oil_wells"] = n_oil_wells
        m["total_net_pay_m"] = total_net_pay
        m["seismic_cal_error"] = cal_error
        all_metrics.append(m)

        print(f"  Seed {seed:3d}: AUC={m['roc_auc']:.4f}  Brier={m['brier']:.4f}  "
              f"ECE={m['ece']:.4f}  loc={m['location_error_m']:.1f}m  "
              f"sep={m['separation_x']:.1f}x  hit={m['target_hit']:.2f}  "
              f"wells={len(wells)}({n_oil_wells} oil)  "
              f"pay={total_net_pay:.1f}m  "
              f"cal_err={cal_error:.1f}  ({elapsed:.2f}s)")

    aucs = [m["roc_auc"] for m in all_metrics]
    briers = [m["brier"] for m in all_metrics]
    seps = [m["separation_x"] for m in all_metrics]
    hits = [m["target_hit"] for m in all_metrics]
    locs = [m["location_error_m"] for m in all_metrics]
    pays = [m["total_net_pay_m"] for m in all_metrics]
    cal_errs = [m["seismic_cal_error"] for m in all_metrics]

    print("-" * 70)
    print(f"  MEAN: AUC={np.mean(aucs):.4f}  Brier={np.mean(briers):.4f}  "
          f"loc={np.mean(locs):.1f}m  sep={np.mean(seps):.1f}x  "
          f"hit={np.mean(hits):.2f}  pay={np.mean(pays):.1f}m  "
          f"cal_err={np.mean(cal_errs):.1f}")
    print("=" * 70)
    print(f"  V14 RESULT: AUC={np.mean(aucs):.4f} (V13=0.9897, V11=0.9915)")
    print(f"  Well platform: {np.mean([m['n_wells'] for m in all_metrics]):.0f} wells, "
          f"{np.mean([m['n_oil_wells'] for m in all_metrics]):.0f} oil-bearing, "
          f"net pay={np.mean(pays):.1f}m")
    print("=" * 70)

    return all_metrics


if __name__ == "__main__":
    _self_test()
