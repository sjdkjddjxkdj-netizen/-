"""GUI layer — COMSOL-style desktop interface + web console for petroppo V35."""
from .main_window import MainWindow
from .style import apply_theme, COMSOL_QSS
from .viz import ModelCanvas
from .model_tree import ModelTree
from .property_panel import PropertyPanel
from .viewer3d import VolumeViewer3D
from .prospectivity_view import ProspectivityView

__all__ = ["MainWindow", "apply_theme", "COMSOL_QSS",
           "ModelCanvas", "ModelTree", "PropertyPanel",
           "VolumeViewer3D", "ProspectivityView",
           "launch_web_console"]


def launch_web_console(host="127.0.0.1", port=8899, open_browser=True):
    """Launch the petroppo V35 web console UI (Microsoft Office-style ribbon).

    This is the HTML5 Canvas console interface with project explorer,
    properties panel, AI Copilot, and 3D/2D/1D seismic visualisations
    with six selectable color maps.

    Parameters
    ----------
    host : str
        Bind address (default 127.0.0.1).
    port : int
        Port number (default 8899).
    open_browser : bool
        Open the console in the default browser (default True).
    """
    from ..web_console import launch_console
    return launch_console(host=host, port=port, open_browser=open_browser)
