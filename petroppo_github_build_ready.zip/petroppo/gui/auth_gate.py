"""petroppo — Login gate + trial lock.

On startup the app shows a login dialog.  Based on who logs in:
  * **Owner** (moamen / alaa) → full access + owner dashboard button.
  * **Customer with active trial** → full pro features, shows days left.
  * **Customer with expired trial** → LOCKED screen demanding payment.

The trial lock screen shows:
  - "Your 30-day free trial has ended."
  - The price + a "Pay Now" button (opens the website payment page).
  - A "Contact Sales" button.
  - No access to the app until payment is recorded by the owner or via
    the website payment gateway.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QMessageBox, QWidget, QFrame, QSizePolicy,
)

from .pro_style import (
    PRO_QSS, ORANGE, ORANGE_DARK, ORANGE_HOVER, BG_DARKEST, BG_PANEL,
    BG_CARD, BORDER, TEXT, TEXT_MUTED, TEXT_INVERSE, GREEN, RED,
)
from .pro_icons import logo_icon
from ..platform.owner_accounts import (
    AccountStore, ROLE_OWNER, verify_password, get_machine_id,
)


# --------------------------------------------------------------------------- #
#  Login dialog                                                                #
# --------------------------------------------------------------------------- #
class LoginDialog(QDialog):
    """Login screen shown before the main window."""

    authenticated = Signal(str, str)  # username, role

    def __init__(self, store: AccountStore, parent=None):
        super().__init__(parent)
        self.store = store
        self.setWindowTitle("petroppo — Sign In")
        self.setMinimumSize(420, 520)
        self.setStyleSheet(PRO_QSS)
        self._user = None
        self._role = None
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(40, 40, 40, 30)
        root.setSpacing(0)

        # logo
        logo_lbl = QLabel()
        logo_lbl.setPixmap(logo_icon(64, 2.0).pixmap(64, 64))
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(logo_lbl)

        title = QLabel("petroppo")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            f"font-size:30px; font-weight:bold; color:{TEXT}; background:transparent;")
        root.addWidget(title)

        sub = QLabel("SUBSURFACE INTELLIGENCE PLATFORM")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet(
            f"font-size:11px; color:{TEXT_MUTED}; letter-spacing:2px; background:transparent;")
        root.addWidget(sub)

        root.addSpacing(30)

        # form card
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {BG_PANEL};
                border: 1px solid {BORDER};
                border-radius: 10px;
            }}
            QLabel {{ background: transparent; }}
            QLineEdit {{
                background-color: {BG_DARKEST};
                border: 1px solid {BORDER};
                border-radius: 6px;
                padding: 10px 12px;
                font-size: 14px;
            }}
            QLineEdit:focus {{ border: 1px solid {ORANGE}; }}
        """)
        form = QVBoxLayout(card)
        form.setContentsMargins(24, 24, 24, 24)
        form.setSpacing(12)

        lbl_user = QLabel("Username")
        lbl_user.setStyleSheet(f"color:{TEXT_MUTED}; font-size:12px; font-weight:bold;")
        form.addWidget(lbl_user)
        self.in_user = QLineEdit()
        self.in_user.setPlaceholderText("Enter your username")
        form.addWidget(self.in_user)

        lbl_pass = QLabel("Password")
        lbl_pass.setStyleSheet(f"color:{TEXT_MUTED}; font-size:12px; font-weight:bold;")
        form.addWidget(lbl_pass)
        self.in_pass = QLineEdit()
        self.in_pass.setPlaceholderText("Enter your password")
        self.in_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.in_pass.returnPressed.connect(self._on_login)
        form.addWidget(self.in_pass)

        form.addSpacing(6)
        self.btn_login = QPushButton("  Sign In  ")
        self.btn_login.setStyleSheet(f"""
            QPushButton {{
                background-color: {ORANGE};
                color: white;
                border: none;
                border-radius: 6px;
                padding: 12px;
                font-size: 15px;
                font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {ORANGE_HOVER}; }}
            QPushButton:pressed {{ background-color: {ORANGE_DARK}; }}
        """)
        self.btn_login.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_login.clicked.connect(self._on_login)
        form.addWidget(self.btn_login)

        root.addWidget(card)

        root.addSpacing(16)
        hint = QLabel("Don't have an account? Sign up at petroppo.io")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet(f"color:{TEXT_MUTED}; font-size:11px; background:transparent;")
        root.addWidget(hint)

        err_style = f"color:{RED}; font-size:12px; background:transparent;"
        root.addSpacing(8)
        self.err = QLabel("")
        self.err.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.err.setStyleSheet(err_style)
        root.addWidget(self.err)

        root.addStretch()

    def _on_login(self):
        u = self.in_user.text().strip()
        p = self.in_pass.text()
        if not u or not p:
            self.err.setText("Please enter username and password.")
            return
        acc = self.store.get_account(u)
        if not acc or not verify_password(p, acc["password_hash"]):
            self.store.log(u, "login_failed", "bad credentials")
            self.err.setText("Invalid username or password.")
            return
        # success
        self.store.update_last_login(u)
        self.store.log(u, "login", f"role={acc['role']} machine={get_machine_id()[:8]}")
        self.store.set_machine_id(u, get_machine_id())
        self._user = u
        self._role = acc["role"]
        self.authenticated.emit(u, acc["role"])
        self.accept()

    @property
    def username(self):
        return self._user

    @property
    def role(self):
        return self._role


# --------------------------------------------------------------------------- #
#  Trial-expired lock screen                                                   #
# --------------------------------------------------------------------------- #
class TrialLockDialog(QDialog):
    """Shown when a customer's trial expired and they haven't paid."""

    payNow = Signal(str)   # username

    def __init__(self, store: AccountStore, username: str, parent=None):
        super().__init__(parent)
        self.store = store
        self.username = username
        self.setWindowTitle("petroppo — Trial Expired")
        self.setMinimumSize(480, 380)
        self.setStyleSheet(PRO_QSS)
        self.setModal(True)
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(40, 36, 40, 30)
        root.setSpacing(0)

        lock = QLabel("🔒")
        lock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lock.setStyleSheet("font-size:54px; background:transparent;")
        root.addWidget(lock)
        root.addSpacing(10)

        title = QLabel("Your free trial has ended")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            f"font-size:22px; font-weight:bold; color:{TEXT}; background:transparent;")
        root.addWidget(title)

        sub = QLabel(
            f"Hello <b>{self.username}</b>, your 30-day petroppo trial is over.\n"
            f"Subscribe now to keep using the platform.")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet(
            f"font-size:14px; color:{TEXT_MUTED}; background:transparent;")
        root.addWidget(sub)

        root.addSpacing(24)

        # pricing
        price_card = QFrame()
        price_card.setStyleSheet(f"""
            QFrame {{
                background-color: {BG_PANEL};
                border: 1px solid {BORDER};
                border-radius: 10px;
            }}
            QLabel {{ background: transparent; }}
        """)
        pc = QVBoxLayout(price_card)
        pc.setContentsMargins(24, 20, 24, 20)
        pc.setSpacing(6)

        p1 = QLabel("Professional")
        p1.setStyleSheet(f"font-size:16px; font-weight:bold; color:{TEXT};")
        p1.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.addWidget(p1)
        p2 = QLabel("$199<span style='font-size:12px;color:{mut}'>/year</span>".format(mut=TEXT_MUTED))
        p2.setStyleSheet(f"font-size:30px; font-weight:bold; color:{ORANGE};")
        p2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.addWidget(p2)
        p3 = QLabel("All features • 1 user • Desktop + Updates")
        p3.setStyleSheet(f"font-size:12px; color:{TEXT_MUTED};")
        p3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pc.addWidget(p3)
        root.addWidget(price_card)

        root.addSpacing(22)

        btn_pay = QPushButton("  Pay Now & Activate  ")
        btn_pay.setStyleSheet(f"""
            QPushButton {{
                background-color: {ORANGE}; color: white; border: none;
                border-radius: 8px; padding: 14px; font-size: 16px; font-weight: bold;
            }}
            QPushButton:hover {{ background-color: {ORANGE_HOVER}; }}
        """)
        btn_pay.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_pay.clicked.connect(self._on_pay)
        root.addWidget(btn_pay)

        root.addSpacing(10)
        contact = QLabel("Need help? Contact sales@petroppo.io")
        contact.setAlignment(Qt.AlignmentFlag.AlignCenter)
        contact.setStyleSheet(f"color:{TEXT_MUTED}; font-size:11px; background:transparent;")
        root.addWidget(contact)

        root.addStretch()

    def _on_pay(self):
        self.payNow.emit(self.username)
        # In a real deployment this opens the website payment page.
        QMessageBox.information(
            self, "Payment",
            "Your browser will open the petroppo payment page.\n\n"
            "After payment is confirmed, your account will be activated\n"
            "automatically. Please restart petroppo.")
        self.reject()


# --------------------------------------------------------------------------- #
#  High-level gate helper                                                      #
# --------------------------------------------------------------------------- #
def run_login_gate(store: AccountStore) -> tuple[str | None, str | None, bool]:
    """Show the login dialog.  Returns (username, role, ok).
    If the customer's trial expired, shows the lock screen and returns
    ok=False so the caller can refuse to launch the main window."""
    dlg = LoginDialog(store)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return None, None, False
    user = dlg.username
    role = dlg.role
    # owners always pass
    if role == ROLE_OWNER:
        return user, role, True
    # customer — check trial
    if store.trial_expired(user):
        store.lock_account(user)
        lock = TrialLockDialog(store, user)
        lock.exec()
        return user, role, False  # don't launch
    return user, role, True
