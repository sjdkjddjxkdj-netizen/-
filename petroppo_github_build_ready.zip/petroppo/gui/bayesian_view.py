"""Bayesian prospectivity view — calibrated HC probability with uncertainty.

This is the V7 scientific core of the GUI.  It replaces the V6
"noisy-OR fuzzy fusion" panel with a **calibrated Bayesian posterior**
that:

  * produces a true probability ``P(oil | geophysics)`` calibrated
    against known wells (not a hand-tuned fuzzy score);
  * reports **uncertainty** (posterior standard deviation and 95 %
    credible intervals) so the user sees how confident the map is;
  * is **honest about calibration status** — a status badge shows
    whether the engine has seen real well data (calibrated) or is
    running on default priors (uncalibrated), and how many wells were
    used;
  * lets the user **import well logs** (LAS 2.0 or CSV) to calibrate
    the engine and run leave-one-well-out cross-validation;
  * never claims "actual oil detection" — the verdict text always
    states that only drilling confirms hydrocarbons.
"""
from __future__ import annotations

import numpy as np

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QMessageBox,
    QPushButton, QSpinBox, QTextEdit, QVBoxLayout, QWidget,
)

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from ..core import get_logger
from ..processing import (
    BayesianProspectivityEngine, BayesianProspectivityMap,
    extract_well_evidence, calibrate_from_wells, cross_validate_wells,
)
from ..io import import_wells_csv, import_well_las, import_wells_las
from ..validation import quick_validation
from .style import MPL_FACE, MPL_TEXT, MPL_MUTED, MPL_ACCENT
from .widgets import make_title, make_panel

_log = get_logger("gui.bayesian")


def _status_badge_html(calibrated: bool, n_wells: int) -> str:
    """HTML for the calibration status badge."""
    if calibrated and n_wells > 0:
        color = "#2ecc71"
        label = f"CALIBRATED — {n_wells} wells"
        detail = "Posterior is a calibrated probability validated against wells."
    else:
        color = "#f39c12"
        label = "UNCALIBRATED — default priors"
        detail = ("No well data yet.  Map uses sensible default LLRs; "
                  "import wells to calibrate.  Treat P as relative, not absolute.")
    return (f"<span style='color:{color}; font-weight:bold; font-size:12px;'>"
            f"● {label}</span><br>"
            f"<span style='color:#8893a5; font-size:11px;'>{detail}</span>")


class BayesianProspectivityView(QWidget):
    """Calibrated Bayesian hydrocarbon-probability panel with uncertainty."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self._engine: BayesianProspectivityEngine | None = None
        self._result: BayesianProspectivityMap | None = None
        self._wells: list = []
        self._build()

    # ------------------------------------------------------------------ #
    #  UI construction                                                    #
    # ------------------------------------------------------------------ #
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Bayesian Hydrocarbon Prospectivity",
            "Calibrated probability P(oil | geophysics) with uncertainty quantification"
        ))

        # --- Calibration status badge ---
        badge_panel, badge_body = make_panel("Calibration Status")
        root.addWidget(badge_panel)
        self.badge_label = QLabel(_status_badge_html(False, 0))
        self.badge_label.setTextFormat(Qt.TextFormat.RichText)
        self.badge_label.setWordWrap(True)
        self.badge_label.setStyleSheet("padding: 10px;")
        badge_body.addWidget(self.badge_label)

        # --- Well-log import panel ---
        well_panel, well_body = make_panel("Well-Log Calibration")
        root.addWidget(well_panel)

        well_row = QHBoxLayout()
        self.btn_import_csv = QPushButton("📁  Import Wells (CSV)")
        self.btn_import_csv.clicked.connect(self._import_csv)
        well_row.addWidget(self.btn_import_csv)

        self.btn_import_las = QPushButton("📄  Import Well (LAS 2.0)")
        self.btn_import_las.clicked.connect(self._import_las)
        well_row.addWidget(self.btn_import_las)

        self.btn_calibrate = QPushButton("🎯  Calibrate Engine")
        self.btn_calibrate.clicked.connect(self._calibrate)
        self.btn_calibrate.setEnabled(False)
        well_row.addWidget(self.btn_calibrate)

        self.btn_crossval = QPushButton("🔀  Cross-Validate")
        self.btn_crossval.clicked.connect(self._cross_validate)
        self.btn_crossval.setEnabled(False)
        well_row.addWidget(self.btn_crossval)
        well_body.addLayout(well_row)

        self.well_count_label = QLabel("No wells imported.")
        self.well_count_label.setProperty("role", "muted")
        well_body.addWidget(self.well_count_label)

        # --- Fusion mode selector ---
        mode_panel, mode_body = make_panel("Inference")
        root.addWidget(mode_panel)

        mode_form = QFormLayout()
        mode_form.setSpacing(8)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Bayesian (calibrated posterior)", "bayesian")
        self.mode_combo.addItem("Legacy noisy-OR (V6 fuzzy)", "legacy")
        mode_form.addRow("Fusion mode:", self.mode_combo)
        mode_body.addLayout(mode_form)

        run_row = QHBoxLayout()
        self.btn_run = QPushButton("⚡  Run Bayesian Inference")
        self.btn_run.clicked.connect(self._run_inference)
        run_row.addWidget(self.btn_run)

        self.btn_export = QPushButton("📊  Export Map (CSV)")
        self.btn_export.clicked.connect(self._export_map)
        run_row.addWidget(self.btn_export)

        self.btn_validate = QPushButton("✅  Run Self-Validation")
        self.btn_validate.clicked.connect(self._run_self_validation)
        run_row.addWidget(self.btn_validate)
        mode_body.addLayout(run_row)

        # --- Map canvas ---
        canvas_panel, canvas_body = make_panel("Posterior Probability Map")
        root.addWidget(canvas_panel)

        self.fig = Figure(figsize=(9, 5), facecolor=MPL_FACE)
        self.canvas = FigureCanvas(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(MPL_FACE)
        self._draw_placeholder()
        canvas_body.addWidget(self.canvas)

        # --- Verdict / report text ---
        report_panel, report_body = make_panel("Interpretation & Honest Verdict")
        root.addWidget(report_panel)
        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        self.report_text.setMaximumHeight(160)
        self.report_text.setPlainText(
            "Run Bayesian inference to generate the calibrated posterior map.\n\n"
            "IMPORTANT: This system produces a CALIBRATED PROBABILITY of "
            "hydrocarbon presence based on geophysical evidence.  It is NOT "
            "a direct oil detection.  Only drilling can confirm hydrocarbons.  "
            "The probability is only as good as the calibration data behind it."
        )
        report_body.addWidget(self.report_text)

        root.addStretch()

    # ------------------------------------------------------------------ #
    #  Well import                                                       #
    # ------------------------------------------------------------------ #
    def _import_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Wells from CSV", "",
            "CSV Files (*.csv);;All Files (*)")
        if not path:
            return
        try:
            wells = import_wells_csv(path)
            self._wells.extend(wells)
            self._update_well_count()
            self.main._log(f"Imported {len(wells)} wells from CSV ({path})", "SUCCESS")
            self.btn_calibrate.setEnabled(len(self._wells) > 0)
            self.btn_crossval.setEnabled(len(self._wells) >= 4)
        except Exception as exc:
            self.main._log(f"CSV import failed: {exc}", "ERROR")
            QMessageBox.warning(self, "Import Error", str(exc))

    def _import_las(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Import LAS 2.0 Well(s)", "",
            "LAS Files (*.las);;All Files (*)")
        if not paths:
            return
        try:
            wells = import_wells_las(paths)
            self._wells.extend(wells)
            self._update_well_count()
            self.main._log(f"Imported {len(wells)} wells from LAS ({len(paths)} files)", "SUCCESS")
            self.btn_calibrate.setEnabled(len(self._wells) > 0)
            self.btn_crossval.setEnabled(len(self._wells) >= 4)
        except Exception as exc:
            self.main._log(f"LAS import failed: {exc}", "ERROR")
            QMessageBox.warning(self, "Import Error", str(exc))

    def _update_well_count(self):
        n = len(self._wells)
        n_oil = sum(1 for w in self._wells if getattr(w, "label", 0) == 1)
        n_dry = n - n_oil
        self.well_count_label.setText(
            f"{n} wells imported ({n_oil} oil shows, {n_dry} dry).")

    # ------------------------------------------------------------------ #
    #  Calibration                                                       #
    # ------------------------------------------------------------------ #
    def _calibrate(self):
        """Fit the Bayesian engine's LLR mapping from imported wells."""
        if not self._wells:
            QMessageBox.warning(self, "No Wells", "Import wells first.")
            return
        inv = self.main.current_inversion
        if inv is None:
            QMessageBox.warning(
                self, "No Inversion",
                "Run an ERT inversion first so well evidence can be sampled "
                "on the inversion grid.")
            return
        try:
            self._engine = calibrate_from_wells(
                self._wells,
                ert=inv,
                ert_x=getattr(inv, "x_coords", None),
                ert_z=getattr(inv, "z_coords", None),
            )
            cal = self._engine.calibration
            self.badge_label.setText(_status_badge_html(
                cal.is_calibrated, cal.n_wells))
            self.main._log(
                f"Engine calibrated on {cal.n_wells} wells — "
                f"prior P={1/(1+np.exp(-cal.prior_logit)):.3f}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Calibration failed: {exc}", "ERROR")
            QMessageBox.warning(self, "Calibration Error", str(exc))

    def _cross_validate(self):
        """Leave-one-well-out cross-validation of the calibration."""
        if len(self._wells) < 4:
            QMessageBox.warning(
                self, "Too Few Wells",
                "Cross-validation needs at least 4 wells.")
            return
        inv = self.main.current_inversion
        if inv is None:
            QMessageBox.warning(
                self, "No Inversion",
                "Run an ERT inversion first.")
            return
        try:
            cv = cross_validate_wells(
                self._wells,
                ert=inv,
                ert_x=getattr(inv, "x_coords", None),
                ert_z=getattr(inv, "z_coords", None),
            )
            auc = cv.get("roc_auc", float("nan"))
            brier = cv.get("brier", float("nan"))
            acc = cv.get("accuracy", float("nan"))
            self.report_text.setPlainText(
                f"Leave-one-well-out cross-validation ({len(self._wells)} wells):\n"
                f"  ROC-AUC  = {auc:.3f}  (0.5=random, 1.0=perfect)\n"
                f"  Brier    = {brier:.3f}  (0=perfect, 0.25=random)\n"
                f"  Accuracy = {acc:.3f}\n\n"
                f"These metrics show how well the calibration GENERALIZES to "
                f"wells it has not seen.  A ROC-AUC > 0.5 means the engine "
                f"ranks oil wells above dry wells better than chance.")
            self.main._log(
                f"Cross-validation: AUC={auc:.3f}, Brier={brier:.3f}, "
                f"Acc={acc:.3f}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Cross-validation failed: {exc}", "ERROR")
            QMessageBox.warning(self, "CV Error", str(exc))

    # ------------------------------------------------------------------ #
    #  Inference                                                         #
    # ------------------------------------------------------------------ #
    def _run_inference(self):
        """Run the Bayesian (or legacy) prospectivity inference."""
        inv = self.main.current_inversion
        if inv is None:
            QMessageBox.warning(
                self, "No Data",
                "Run an ERT inversion first to generate evidence for inference.")
            return

        mode = self.mode_combo.currentData()
        try:
            if mode == "bayesian":
                result = self._run_bayesian(inv)
            else:
                from ..processing import fuse_prospectivity
                result = fuse_prospectivity(ert=inv)
            self._result = result
            self._draw_map(result)
            self._write_verdict(result, mode)
            pmax = float(result.probability.max())
            self.main._log(
                f"{'Bayesian' if mode=='bayesian' else 'Legacy'} inference "
                f"complete: max P={pmax:.3f}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Inference failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Inference Error", str(exc))

    def _run_bayesian(self, inv) -> BayesianProspectivityMap:
        """Build/run the Bayesian engine on the current inversion."""
        if self._engine is None:
            self._engine = BayesianProspectivityEngine()
        # try to pull auxiliary grids from the multiphysics view
        gravity = self._aux_grid("gravity_contrast")
        magnetic = self._aux_grid("magnetic_anomaly")
        chargeability = self._aux_grid("chargeability")
        seismic = self._aux_grid("seismic_velocity")
        return self._engine.infer_from_inversions(
            ert=inv,
            gravity_contrast=gravity,
            magnetic_anomaly=magnetic,
            chargeability=chargeability,
            seismic_velocity=seismic,
        )

    def _aux_grid(self, attr: str):
        """Fetch an auxiliary inversion grid from the multiphysics view."""
        mp = getattr(self.main, "view_multiphysics", None)
        if mp is None:
            return None
        return getattr(mp, attr, None)

    # ------------------------------------------------------------------ #
    #  Drawing                                                           #
    # ------------------------------------------------------------------ #
    def _draw_placeholder(self):
        self.ax.clear()
        self.ax.set_facecolor(MPL_FACE)
        self.ax.text(0.5, 0.5, "Run inference to generate posterior map",
                     ha="center", va="center", transform=self.ax.transAxes,
                     color=MPL_MUTED, fontsize=13)
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self.fig.tight_layout()
        self.canvas.draw_idle()

    def _draw_map(self, result):
        """Draw the posterior probability map + uncertainty."""
        self.ax.clear()
        self.ax.set_facecolor(MPL_FACE)

        prob = result.probability
        x = result.x_coords
        z = result.z_coords

        im = self.ax.imshow(prob.T, aspect="auto", origin="upper",
                            cmap="YlOrRd", interpolation="bilinear",
                            vmin=0, vmax=1,
                            extent=[x[0], x[-1], z[-1], z[0]])
        self.ax.set_xlabel("Distance (m)", color=MPL_TEXT, fontsize=11)
        self.ax.set_ylabel("Depth (m)", color=MPL_TEXT, fontsize=11)
        cal = getattr(self._engine, "calibration", None) if self._engine else None
        title = "Calibrated Posterior P(oil | geophysics)"
        if cal is not None and not cal.is_calibrated:
            title += "  [UNCALIBRATED]"
        self.ax.set_title(title, color=MPL_TEXT, fontsize=13, fontweight="bold")
        self.ax.tick_params(colors=MPL_MUTED)

        cbar = self.fig.colorbar(im, ax=self.ax, fraction=0.046, pad=0.04)
        cbar.set_label("P(oil)", color=MPL_TEXT)
        cbar.ax.tick_params(colors=MPL_MUTED)
        cbar.outline.set_edgecolor(MPL_MUTED)

        self.fig.tight_layout()
        self.canvas.draw_idle()

        # mark best targets with their 95% CI
        targets = result.best_targets(n=3)
        for t in targets:
            self.ax.plot(t["x"], t["z"], "o", ms=11, mfc="none",
                         mec="#00e0ff", mew=2)
            ci = t.get("probability_ci95", (0.0, 1.0))
            self.ax.annotate(
                f"P={t['probability']:.2f}\n[{ci[0]:.2f},{ci[1]:.2f}]",
                (t["x"], t["z"]),
                color="#00e0ff", fontsize=8, fontweight="bold",
                xytext=(7, 7), textcoords="offset points")
            self.main._log(
                f"  Target: P={t['probability']:.2f} "
                f"(95% CI {ci[0]:.2f}–{ci[1]:.2f}) at "
                f"({t['x']:.1f}m, {t['z']:.1f}m)", "INFO")
        if targets:
            self.canvas.draw_idle()

    # ------------------------------------------------------------------ #
    #  Verdict text (honest)                                             #
    # ------------------------------------------------------------------ #
    def _write_verdict(self, result, mode: str):
        pmax = float(result.probability.max())
        pmean = float(result.probability.mean())
        has_ci = result.posterior_std.size > 0
        max_std = float(result.posterior_std.max()) if has_ci else 0.0
        cal = getattr(self._engine, "calibration", None) if self._engine else None
        cal_status = "calibrated against wells" if (cal and cal.is_calibrated) \
            else "UNCALIBRATED (default priors — treat as relative)"
        n_wells = cal.n_wells if cal else 0

        lines = [
            f"Fusion mode: {'Bayesian (calibrated posterior)' if mode=='bayesian' else 'Legacy noisy-OR (V6 fuzzy)'}",
            f"Calibration: {cal_status}  ({n_wells} wells)",
            f"Max posterior P(oil) = {pmax:.3f}",
            f"Mean posterior P(oil) = {pmean:.3f}",
        ]
        if has_ci:
            lines.append(f"Max posterior std    = {max_std:.3f}  (uncertainty)")
        lines.append("")
        lines.append(
            "SCIENTIFIC VERDICT: This map is a calibrated PROBABILITY of "
            "hydrocarbon presence based on geophysical evidence.  It is NOT "
            "a direct measurement of oil.  Only drilling can confirm "
            "hydrocarbons.  The probability is only as reliable as the "
            "calibration data behind it — an uncalibrated map reflects "
            "relative prospectivity, not absolute risk.")
        self.report_text.setPlainText("\n".join(lines))

    # ------------------------------------------------------------------ #
    #  Self-validation                                                   #
    # ------------------------------------------------------------------ #
    def _run_self_validation(self):
        """Run the full synthetic-field self-validation and report metrics."""
        try:
            self.main._log("Running synthetic-field self-validation...", "INFO")
            rep = quick_validation()
            self.report_text.setPlainText(rep.to_text())
            self.main._log(
                f"Self-validation: ROC-AUC={np.mean(rep.roc_aucs):.3f}, "
                f"Brier={np.mean(rep.briers):.3f}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Self-validation failed: {exc}", "ERROR")
            QMessageBox.warning(self, "Validation Error", str(exc))

    # ------------------------------------------------------------------ #
    #  Export                                                            #
    # ------------------------------------------------------------------ #
    def _export_map(self):
        if self._result is None:
            QMessageBox.warning(self, "No Data", "Run inference first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Prospectivity Map", "bayesian_prospectivity.csv",
            "CSV Files (*.csv)")
        if not path:
            return
        try:
            from ..io import export_prospectivity_csv
            export_prospectivity_csv(
                self._result.probability,
                self._result.x_coords,
                self._result.z_coords,
                path)
            self.main._log(f"Bayesian map exported to {path}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Export failed: {exc}", "ERROR")

    # ------------------------------------------------------------------ #
    #  Refresh (called on tab switch)                                    #
    # ------------------------------------------------------------------ #
    def refresh(self):
        """Re-render the cached map and sync the calibration badge."""
        try:
            cal = getattr(self._engine, "calibration", None) if self._engine else None
            if cal is not None:
                self.badge_label.setText(_status_badge_html(
                    cal.is_calibrated, cal.n_wells))
            self._update_well_count()
            if self._result is not None:
                self._draw_map(self._result)
            else:
                self._draw_placeholder()
        except Exception:
            pass
