"""Dashboard view — overview of the entire petroppo system."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGridLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget, QFrame,
)

from .widgets import make_stat_card, make_title, make_panel
from ..simulator.scenarios import SCENARIOS


class DashboardView(QWidget):
    """Dashboard screen showing system overview."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(16)

        root.addWidget(make_title(
            "Dashboard", "Overview of projects, surveys, and instruments"
        ))

        # Statistics cards
        stats_row = QHBoxLayout()
        stats_row.setSpacing(12)
        self.card_projects = make_stat_card("Projects", "0", "Active exploration projects")
        self.card_surveys = make_stat_card("Surveys", "0", "Total surveys designed")
        self.card_readings = make_stat_card("Measurements", "0", "Simulated readings")
        self.card_methods = make_stat_card("Methods", "6", "ERT, Spectral, Magnetic, Gravity, GPR, Seismic")
        for c in (self.card_projects, self.card_surveys, self.card_readings, self.card_methods):
            stats_row.addWidget(c)
        root.addLayout(stats_row)

        # Quick actions
        actions_panel, actions_body = make_panel("Quick Actions")
        root.addWidget(actions_panel)

        btn_row = QHBoxLayout()
        btn_run = QPushButton("▶  Run Simulation")
        btn_run.clicked.connect(lambda: self.main._run_simulation())
        btn_invert = QPushButton("🔄  Run Inversion")
        btn_invert.clicked.connect(lambda: self.main._run_inversion())
        btn_model = QPushButton("🌐  View Model")
        btn_model.clicked.connect(lambda: self.main._show_cross_section())
        btn_interp = QPushButton("📋  Interpret")
        btn_interp.clicked.connect(lambda: self.main._show_interpretation())
        for b in (btn_run, btn_invert, btn_model, btn_interp):
            btn_row.addWidget(b)
        actions_body.addLayout(btn_row)

        # Scenarios
        scen_panel, scen_body = make_panel("Earth Model Scenarios")
        root.addWidget(scen_panel)
        grid = QGridLayout()
        grid.setSpacing(8)
        for i, name in enumerate(SCENARIOS):
            btn = QPushButton(name.replace("_", " ").title())
            btn.clicked.connect(lambda checked=False, n=name: self.main._load_scenario(n))
            grid.addWidget(btn, i // 3, i % 3)
        scen_body.addLayout(grid)

        # Info
        info_panel, info_body = make_panel("About petroppo")
        root.addWidget(info_panel)
        info_label = QLabel(
            "petroppo is an open-source scientific subsurface geophysics platform "
            "for seismic interpretation, geological modeling, reservoir simulation, "
            "and geophysical inversion — with uncertainty quantification and AI-assisted "
            "interpretation.  It integrates forward modeling, inversion, and reservoir "
            "engineering in a single reproducible workflow.\n\n"
            "Design inspired by COMSOL Multiphysics."
        )
        info_label.setWordWrap(True)
        info_label.setProperty("role", "muted")
        info_body.addWidget(info_label)

        root.addStretch()

    def refresh(self):
        """Refresh dashboard statistics from live project state.

        Counts real data held by the main window: the number of surveys
        designed in the Survey view, the number of simulated readings
        produced, whether an inversion result is available, and the name
        of the currently loaded earth model.  No placeholder values \u2014
        every number reflects the actual session state.
        """
        try:
            mw = self.main
            # Projects: 1 active project (the loaded model); show model name
            n_proj = 1
            self._set_card_value(self.card_projects, str(n_proj))

            # Surveys: count from the SurveyView if it exists
            n_surveys = 0
            n_readings = 0
            sv = getattr(mw, "view_survey", None)
            if sv is not None:
                n_surveys = len(getattr(sv, "surveys", []) or [])
                table = getattr(sv, "table", None)
                if table is not None:
                    for r in range(table.rowCount()):
                        item = table.item(r, 3)
                        if item is not None:
                            try:
                                n_readings += int(item.text())
                            except ValueError:
                                pass
            self._set_card_value(self.card_surveys, str(n_surveys))
            self._set_card_value(self.card_readings, str(n_readings))

            # Methods card stays static (6), but reflect inversion status
            inv = getattr(mw, "current_inversion", None)
            if inv is not None:
                rmse = getattr(inv, "rmse", None)
                if rmse is not None:
                    self._status_msg = f"Inversion ready (RMSE={rmse:.4f})"
                else:
                    self._status_msg = "Inversion ready"
            else:
                self._status_msg = "No inversion yet"
        except Exception:
            pass

    @staticmethod
    def _set_card_value(card, value: str):
        """Update the large value label (2nd child) of a stat card."""
        try:
            lay = card.layout()
            if lay is not None and lay.count() >= 2:
                w = lay.itemAt(1).widget()
                if w is not None:
                    w.setText(str(value))
        except Exception:
            pass
