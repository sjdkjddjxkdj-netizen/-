"""Devices view — manage instruments and run live acquisition.

This panel is the GUI front-end for petroppo's Hardware Abstraction Layer
(HAL).  It lets the user:

  * See every registered driver (simulator / serial / tcp / file).
  * Connect a real or virtual instrument by filling in its connection
    parameters (serial port + baud, host:port, or a CSV file path).
  * Watch the device status (disconnected / connected / acquiring / error)
    update in real time.
  * Build an ERT acquisition plan and run a live survey, watching each
    reading stream into a live table with its QC verdict.
  * See the acquisition progress bar, good/bad counts, and overall quality.

Because every driver implements the same :class:`BaseDevice` contract, the
same panel drives the virtual simulator, a serial resistivity meter, a
networked instrument, or a file replay — the processing pipeline downstream
is identical.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QProgressBar, QPushButton, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from ..core import (
    DeviceInfo, DeviceStatus, MeasurementMethod, new_id, get_logger,
)
from ..hal import (
    AcquisitionController, AcquisitionPlan, build_ert_plan,
    available_drivers, list_serial_ports,
)
from .widgets import make_title, make_panel

_log = get_logger("gui.devices")

_DRIVER_LABELS = {
    "simulator": "Virtual Instrument (self-contained)",
    "virtual": "Virtual Instrument (self-contained)",
    "serial": "Serial / USB-Serial Resistivity Meter",
    "tcp": "Networked (TCP/Ethernet) Instrument",
    "file": "File / CSV Data Replay",
}

_METHOD_LABELS = [
    ("ERT", MeasurementMethod.ERT),
    ("Spectral IP", MeasurementMethod.SPECTRAL),
    ("Magnetic", MeasurementMethod.MAGNETIC),
    ("Gravity", MeasurementMethod.GRAVITY),
    ("GPR", MeasurementMethod.GPR),
    ("Seismic", MeasurementMethod.SEISMIC),
]

_STATUS_COLORS = {
    DeviceStatus.DISCONNECTED: "#8893a5",
    DeviceStatus.CONNECTED: "#50d878",
    DeviceStatus.ACQUIRING: "#f0b040",
    DeviceStatus.ERROR: "#e85540",
}


class DevicesView(QWidget):
    """Device management + live acquisition screen."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self.device = None  # currently connected BaseDevice
        self._acq_ctrl: AcquisitionController | None = None
        self._build()

    # ------------------------------------------------------------------ #
    #  UI construction
    # ------------------------------------------------------------------ #
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Instruments & Acquisition",
            "Connect real or virtual instruments and run live surveys"
        ))

        # --- Connection panel ---
        conn_panel, conn_body = make_panel("Instrument Connection")
        root.addWidget(conn_panel)

        form = QFormLayout()
        form.setSpacing(8)

        self.driver_combo = QComboBox()
        for d in available_drivers():
            self.driver_combo.addItem(_DRIVER_LABELS.get(d, d), d)
        self.driver_combo.currentIndexChanged.connect(self._on_driver_changed)
        form.addRow("Driver:", self.driver_combo)

        self.method_combo = QComboBox()
        for label, method in _METHOD_LABELS:
            self.method_combo.addItem(label, method)
        form.addRow("Method:", self.method_combo)

        # address field + browse button (for serial ports / files)
        addr_row = QHBoxLayout()
        self.address_edit = QLineEdit("/dev/ttyUSB0")
        self.address_edit.setPlaceholderText("port / host:port / file path")
        addr_row.addWidget(self.address_edit)
        self.btn_browse = QPushButton("Browse…")
        self.btn_browse.clicked.connect(self._browse)
        addr_row.addWidget(self.btn_browse)
        form.addRow("Address:", addr_row)

        # protocol selector (serial / tcp only)
        self.proto_combo = QComboBox()
        self.proto_combo.addItems(["generic_ert", "syscal", "abem"])
        form.addRow("Protocol:", self.proto_combo)

        conn_body.addLayout(form)

        # status row
        status_row = QHBoxLayout()
        self.lbl_status = QLabel("● Disconnected")
        self.lbl_status.setStyleSheet("font-weight: bold; color: #8893a5;")
        status_row.addWidget(self.lbl_status)
        status_row.addStretch()
        self.btn_connect = QPushButton("🔌  Connect")
        self.btn_connect.clicked.connect(self._toggle_connect)
        status_row.addWidget(self.btn_connect)
        conn_body.addLayout(status_row)

        # --- Acquisition panel ---
        acq_panel, acq_body = make_panel("ERT Acquisition Plan")
        root.addWidget(acq_panel)

        acq_form = QFormLayout()
        acq_form.setSpacing(8)
        self.spin_electrodes = QSpinBox()
        self.spin_electrodes.setRange(4, 64)
        self.spin_electrodes.setValue(24)
        acq_form.addRow("Electrodes:", self.spin_electrodes)

        self.spin_spacing = QSpinBox()
        self.spin_spacing.setRange(1, 50)
        self.spin_spacing.setValue(5)
        self.spin_spacing.setSuffix(" m")
        acq_form.addRow("Spacing:", self.spin_spacing)

        self.config_combo = QComboBox()
        self.config_combo.addItems(["wenner", "dipole-dipole"])
        acq_form.addRow("Configuration:", self.config_combo)

        self.spin_current = QSpinBox()
        self.spin_current.setRange(1, 2000)
        self.spin_current.setValue(100)
        self.spin_current.setSuffix(" mA")
        acq_form.addRow("Injection current:", self.spin_current)
        acq_body.addLayout(acq_form)

        run_row = QHBoxLayout()
        self.btn_run = QPushButton("▶  Run Acquisition")
        self.btn_run.clicked.connect(self._run_acquisition)
        self.btn_abort = QPushButton("■  Abort")
        self.btn_abort.setEnabled(False)
        self.btn_abort.clicked.connect(self._abort_acquisition)
        run_row.addWidget(self.btn_run)
        run_row.addWidget(self.btn_abort)
        acq_body.addLayout(run_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        acq_body.addWidget(self.progress)

        self.lbl_quality = QLabel("Quality: —")
        self.lbl_quality.setStyleSheet("color: #a8c7e8;")
        acq_body.addWidget(self.lbl_quality)

        # --- Live readings table ---
        live_panel, live_body = make_panel("Live Readings")
        root.addWidget(live_panel)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["#", "x (m)", "z (m)", "rho_a (Ω·m)", "V (mV)", "I (mA)",
             "QC"])
        self.table.horizontalHeader().setStretchLastSection(True)
        live_body.addWidget(self.table)

        root.addStretch()

        # initial state
        self._on_driver_changed()
        self._refresh_status()

    # ------------------------------------------------------------------ #
    #  Driver / address handling
    # ------------------------------------------------------------------ #
    def _current_driver(self) -> str:
        return self.driver_combo.currentData()

    def _on_driver_changed(self):
        d = self._current_driver()
        is_file = (d == "file")
        is_serial = (d == "serial")
        is_tcp = (d == "tcp")
        self.btn_browse.setEnabled(is_file or is_serial)
        self.proto_combo.setEnabled(is_serial or is_tcp)
        if is_file:
            self.address_edit.setPlaceholderText("CSV / .dat file path")
        elif is_tcp:
            self.address_edit.setPlaceholderText("host:port (e.g. 192.168.1.5:10001)")
            self.proto_combo.clear()
            self.proto_combo.addItems(["generic_tcp", "iris_elix"])
        elif is_serial:
            self.address_edit.setPlaceholderText("serial port (e.g. /dev/ttyUSB0)")
            self.proto_combo.clear()
            self.proto_combo.addItems(["generic_ert", "syscal", "abem"])
            ports = list_serial_ports()
            if ports and self.address_edit.text() in ("", "/dev/ttyUSB0"):
                self.address_edit.setText(ports[0])
        else:
            self.address_edit.setPlaceholderText("virtual — no address needed")

    def _browse(self):
        d = self._current_driver()
        if d == "file":
            path, _ = QFileDialog.getOpenFileName(
                self, "Select data file", "",
                "Data files (*.csv *.dat *.txt);;All files (*)")
            if path:
                self.address_edit.setText(path)
        elif d == "serial":
            ports = list_serial_ports()
            if not ports:
                QMessageBox.information(
                    self, "No serial ports",
                    "No serial ports were detected.\n"
                    "Make sure pyserial is installed and the device is plugged in.")
                return
            from PySide6.QtWidgets import QInputDialog
            port, ok = QInputDialog.getItem(
                self, "Select serial port", "Available ports:", ports, 0, False)
            if ok and port:
                self.address_edit.setText(port)

    # ------------------------------------------------------------------ #
    #  Connect / disconnect
    # ------------------------------------------------------------------ #
    def _build_device(self):
        from ..hal.manager import make_device
        driver = self._current_driver()
        method = self.method_combo.currentData()
        info = DeviceInfo(
            id=new_id(), name=f"{driver} {method.value}",
            kind=method, driver=driver,
            connection=("virtual" if driver in ("simulator", "virtual")
                        else driver),
            address=self.address_edit.text().strip(),
        )
        kwargs = {}
        if driver in ("serial", "tcp"):
            kwargs["protocol"] = self.proto_combo.currentText()
        if driver == "simulator":
            # bind the virtual instrument to the current earth model so the
            # live acquisition produces physically realistic data
            kwargs["model"] = self.main.current_model
        return make_device(info, **kwargs)

    def _toggle_connect(self):
        if self.device is not None and self.device.is_connected():
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        try:
            self.device = self._build_device()
            self.device.connect()
        except Exception as exc:
            self._log(f"Connection failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Connection Error", str(exc))
            self.device = None
            self._refresh_status()
            return
        self._log(f"Connected to {self.device.info.name} "
                  f"({self.device.info.connection})", "SUCCESS")
        self._refresh_status()

    def _disconnect(self):
        if self.device is not None:
            try:
                self.device.disconnect()
            except Exception as exc:
                self._log(f"Disconnect error: {exc}", "WARNING")
            self._log(f"Disconnected from {self.device.info.name}", "INFO")
        self.device = None
        self._refresh_status()

    def _refresh_status(self):
        connected = self.device is not None and self.device.is_connected()
        status = (self.device.status if self.device is not None
                  else DeviceStatus.DISCONNECTED)
        color = _STATUS_COLORS.get(status, "#8893a5")
        self.lbl_status.setText(f"● {status.value.title()}")
        self.lbl_status.setStyleSheet(f"font-weight: bold; color: {color};")
        self.btn_connect.setText("🔌  Disconnect" if connected else "🔌  Connect")
        self.btn_run.setEnabled(connected)
        self._status_method = connected

    # ------------------------------------------------------------------ #
    #  Acquisition
    # ------------------------------------------------------------------ #
    def _run_acquisition(self):
        if self.device is None or not self.device.is_connected():
            QMessageBox.warning(self, "Not connected",
                                "Connect an instrument first.")
            return
        self.table.setRowCount(0)
        self.progress.setValue(0)
        self.lbl_quality.setText("Quality: —")

        plan = build_ert_plan(
            n_electrodes=self.spin_electrodes.value(),
            spacing=float(self.spin_spacing.value()),
            config=self.config_combo.currentText(),
            method=self.device.info.kind,
            current=self.spin_current.value() / 1000.0,
        )
        self._acq_ctrl = AcquisitionController(self.device, plan, delay=0.0)
        self.btn_run.setEnabled(False)
        self.btn_abort.setEnabled(True)

        n = len(plan.points)
        self._log(f"Starting acquisition: {n} readings via "
                  f"{self.device.info.name}", "INFO")

        def progress_cb(measurement, qc_summary):
            self._on_reading(measurement, qc_summary, n)

        # Run in a non-blocking way by processing one reading at a time on a
        # timer, so the UI stays responsive.
        self._acq_state = {
            "plan": plan, "ctrl": self._acq_ctrl, "idx": 0, "n": n,
            "good": 0, "bad": 0, "results": [],
        }
        self._acq_timer = QTimer(self)
        self._acq_timer.timeout.connect(self._acq_step)
        self._acq_timer.start(0)

    def _acq_step(self):
        st = self._acq_state
        if st["idx"] >= st["n"]:
            self._acq_finish()
            return
        params = st["plan"].points[st["idx"]]
        try:
            m = st["ctrl"].device.measure(**params)
        except Exception as exc:
            self._log(f"Reading {st['idx']} failed: {exc}", "ERROR")
            st["idx"] += 1
            st["bad"] += 1
            self._update_progress(st["idx"], st["n"], st["good"], st["bad"])
            return
        qc = st["ctrl"]._qc(m, st["results"])
        st["results"].append(m)
        if qc["pass"]:
            st["good"] += 1
        else:
            st["bad"] += 1
        self._on_reading(m, qc, st["n"])
        st["idx"] += 1
        self._update_progress(st["idx"], st["n"], st["good"], st["bad"])

    def _on_reading(self, m, qc_summary, n_total):
        row = self.table.rowCount()
        self.table.insertRow(row)
        vals = m.values
        items = [
            str(row + 1),
            f"{m.x:.1f}",
            f"{m.z:.1f}",
            f"{vals.get('rho_a', float('nan')):.2f}",
            f"{vals.get('v', float('nan')) * 1000:.3f}",
            f"{vals.get('i', float('nan')) * 1000:.1f}",
            "✓ pass" if qc_summary["pass"] else "✗ " + qc_summary["reason"],
        ]
        for col, txt in enumerate(items):
            it = QTableWidgetItem(txt)
            if col == 6:
                it.setForeground(Qt.GlobalColor.darkGreen if qc_summary["pass"]
                                 else Qt.GlobalColor.red)
            self.table.setItem(row, col, it)
        self.table.scrollToBottom()

    def _update_progress(self, idx, n, good, bad):
        self.progress.setValue(int(100 * idx / n) if n else 0)
        total = good + bad
        q = (good / total) if total else 0.0
        self.lbl_quality.setText(
            f"Readings: {idx}/{n}   Good: {good}   Bad: {bad}   "
            f"Quality: {q * 100:.1f}%")

    def _acq_finish(self):
        self._acq_timer.stop()
        st = self._acq_state
        self._log(
            f"Acquisition complete: {st['n']} readings "
            f"({st['good']} good, {st['bad']} bad)", "SUCCESS")
        # Store the live measurements on the main window for downstream use
        self.main.live_measurements = st["results"]
        self.btn_run.setEnabled(True)
        self.btn_abort.setEnabled(False)
        self._acq_ctrl = None

    def _abort_acquisition(self):
        if self._acq_ctrl is not None:
            self._acq_ctrl.abort()
        if hasattr(self, "_acq_timer"):
            self._acq_timer.stop()
        self._log("Acquisition aborted by user", "WARNING")
        self.btn_run.setEnabled(True)
        self.btn_abort.setEnabled(False)

    # ------------------------------------------------------------------ #
    #  Helpers
    # ------------------------------------------------------------------ #
    def _log(self, msg, level="INFO"):
        self.main._log(msg, level)

    def refresh(self):
        self._refresh_status()
