"""Lab view — measurement research lab for configuration optimization."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
    QPushButton, QSpinBox, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget, QMessageBox,
)

from ..lab import MeasurementLab, ElectrodeConfig
from ..simulator.scenarios import SCENARIOS
from .widgets import make_title, make_panel


class LabView(QWidget):
    """Measurement research lab screen."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self.lab = MeasurementLab()
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Measurement Research Lab",
            "Compare electrode configurations and optimize survey design"
        ))

        # --- Configuration panel ---
        config_panel, config_body = make_panel("Experiment Configuration")
        root.addWidget(config_panel)

        form = QFormLayout()
        form.setSpacing(8)

        self.target_combo = QComboBox()
        for name in SCENARIOS:
            self.target_combo.addItem(name.replace("_", " ").title(), name)
        form.addRow("Target model:", self.target_combo)

        self.background_combo = QComboBox()
        for name in SCENARIOS:
            self.background_combo.addItem(name.replace("_", " ").title(), name)
        self.background_combo.setCurrentIndex(0)
        form.addRow("Background model:", self.background_combo)

        self.electrodes_spin = QSpinBox()
        self.electrodes_spin.setRange(4, 64)
        self.electrodes_spin.setValue(24)
        form.addRow("Electrodes:", self.electrodes_spin)

        self.spacing_spin = QDoubleSpinBox()
        self.spacing_spin.setRange(1, 20)
        self.spacing_spin.setValue(5.0)
        self.spacing_spin.setSuffix(" m")
        form.addRow("Spacing:", self.spacing_spin)

        self.noise_spin = QDoubleSpinBox()
        self.noise_spin.setRange(0, 0.5)
        self.noise_spin.setValue(0.02)
        self.noise_spin.setSingleStep(0.005)
        form.addRow("Noise level:", self.noise_spin)

        config_body.addLayout(form)

        # --- Run buttons ---
        btn_row = QHBoxLayout()
        btn_rank = QPushButton("🏆  Rank Configurations")
        btn_rank.setDefault(True)
        btn_rank.clicked.connect(self._rank)
        btn_row.addWidget(btn_rank)

        btn_report = QPushButton("📄  Full Report")
        btn_report.clicked.connect(self._full_report)
        btn_row.addWidget(btn_report)

        btn_sens = QPushButton("📊  Sensitivity Analysis")
        btn_sens.clicked.connect(self._sensitivity)
        btn_row.addWidget(btn_sens)
        config_body.addLayout(btn_row)

        # --- Results table ---
        results_panel, results_body = make_panel("Configuration Ranking")
        root.addWidget(results_panel)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Rank", "Configuration", "IG", "SNR Max", "Detection %"])
        self.table.horizontalHeader().setStretchLastSection(True)
        results_body.addWidget(self.table)

        # --- Report text ---
        report_panel, report_body = make_panel("Report")
        root.addWidget(report_panel)
        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        self.report_text.setMaximumHeight(200)
        report_body.addWidget(self.report_text)

        root.addStretch()

    def _setup_lab(self):
        self.lab.set_target(self.target_combo.currentData())
        self.lab.set_background(self.background_combo.currentData())

    def _rank(self):
        self._setup_lab()
        ranked = self.lab.rank(
            noise_level=self.noise_spin.value(),
            n_electrodes=self.electrodes_spin.value(),
            spacing=self.spacing_spin.value(),
        )
        self.table.setRowCount(0)
        for i, r in enumerate(ranked):
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(i + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(r["label"]))
            self.table.setItem(row, 2, QTableWidgetItem(f"{r['ig']:.2f}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{r['snr_max']:.2f}"))
            det_pct = r['detection_rate'] * 100
            self.table.setItem(row, 4, QTableWidgetItem(f"{det_pct:.0f}%"))
        self.main._log(f"Ranked {len(ranked)} configurations — best: {ranked[0]['label']}", "SUCCESS")

    def _full_report(self):
        self._setup_lab()
        report = self.lab.to_report(noise_level=self.noise_spin.value())
        self.report_text.setPlainText(report)
        self.main._log("Full experiment report generated", "SUCCESS")

    def _sensitivity(self):
        self._setup_lab()
        sens = self.lab.compare_all(
            n_electrodes=self.electrodes_spin.value(),
            spacing=self.spacing_spin.value(),
        )
        lines = ["Sensitivity Comparison:\n"]
        for s in sens:
            lines.append(f"  {s['config']:20s}  peak_depth={s['peak_depth']:.1f}m  "
                         f"max_depth={s['max_depth']:.1f}m")
        self.report_text.setPlainText("\n".join(lines))
        self.main._log(f"Sensitivity analysis: {len(sens)} configurations", "INFO")

    def refresh(self):
        """Restore the lab view to a clean baseline state.

        Clears any previous ranking table rows and resets the report
        text area so that re-entering the Lab tab always presents a
        tidy starting point rather than stale results.
        """
        try:
            if self.table.rowCount() > 0:
                self.table.setRowCount(0)
            if self.report_text.toPlainText():
                self.report_text.clear()
        except Exception:
            pass
