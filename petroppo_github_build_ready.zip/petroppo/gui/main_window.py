"""Main window — COMSOL-style professional engineering interface.

Layout:
    +----------------------------------------------------------+
    |  Menu Bar (File, View, Tools, Help)                      |
    +----------------------------------------------------------+
    |  Ribbon Toolbar (Home, Modeling, Simulation, Analysis)   |
    +----------+---------------------------+-------------------+
    |          |                           |                   |
    | Model    |    Graphics Viewport      |   Property        |
    | Tree     |    (matplotlib canvas)    |   Panel           |
    |          |                           |                   |
    |          |                           |                   |
    +----------+---------------------------+-------------------+
    |  Log / Status Console                                    |
    +----------------------------------------------------------+
    |  Status Bar                                              |
    +----------------------------------------------------------+
"""
from __future__ import annotations

from PySide6.QtCore import Qt, QSize, Signal
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QDockWidget, QToolBar, QStatusBar, QMessageBox, QLabel,
    QPlainTextEdit, QTabWidget, QPushButton, QToolButton, QComboBox,
)

from ..core import (
    get_logger, get_settings, EarthModel, MeasurementMethod,
)
from ..simulator.scenarios import get_scenario, SCENARIOS, scenario_descriptions
from ..simulator.engine import get_engine
from ..simulator.hifwd import forward_ert_fd
from ..simulator.forward import wenner_geometry
from ..lab import MeasurementLab, ElectrodeConfig
from ..processing import invert_from_model, detect_anomalies, generate_report
from ..processing.hi_inversion import invert_from_model_hi

from .style import apply_theme, COMSOL_QSS, ACCENT, BG, BG_WHITE, BG_PANEL
from .widgets import make_ribbon_button, make_ribbon_group
from .model_tree import ModelTree
from .property_panel import PropertyPanel
from .viz import ModelCanvas
from .dashboard import DashboardView
from .survey_view import SurveyView
from .devices_view import DevicesView
from .lab_view import LabView
from .viewer3d import VolumeViewer3D
from .prospectivity_view import ProspectivityView
from .multiphysics_view import MultiPhysicsView
from .bayesian_view import BayesianProspectivityView

import numpy as np


class LogConsole(QPlainTextEdit):
    """A dark-themed log console at the bottom of the window."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setProperty("role", "console")
        self.setMaximumBlockCount(500)
        self.setStyleSheet(
            "background-color: #0f1116; color: #a8c7e8; "
            "font-family: 'Consolas', 'Courier New', monospace; "
            "font-size: 12px; border: none;"
        )

    def append_log(self, msg: str, level: str = "INFO"):
        color = "#a8c7e8"
        if level == "WARNING":
            color = "#f0b040"
        elif level == "ERROR":
            color = "#e85540"
        elif level == "SUCCESS":
            color = "#50d878"
        self.appendHtml(
            f'<span style="color:#5b9cf6;">[petroppo]</span> '
            f'<span style="color:{color};">{msg}</span>'
        )


class MainWindow(QMainWindow):
    """The COMSOL-style main window for petroppo."""

    def __init__(self):
        super().__init__()
        self.log = get_logger("gui.main")
        self.settings = get_settings()
        self.current_model: EarthModel = get_scenario("reservoir")
        self.current_inversion = None
        self.lab = MeasurementLab()

        self.setWindowTitle("petroppo — Integrated Subsurface Geophysics Platform")
        self.resize(self.settings.window_width, self.settings.window_height)

        self._build_ui()
        self._log("petroppo initialized — subsurface geophysics platform ready", "SUCCESS")
        self._log(f"Loaded scenario: {self.current_model.name}", "INFO")
        self._update_tree()
        self._show_cross_section()

    def _build_ui(self):
        self._build_menubar()
        self._build_ribbon()
        self._build_central()
        self._build_docks()
        self._build_statusbar()

    # ===== Menu Bar =====
    def _build_menubar(self):
        mb = self.menuBar()

        m_file = mb.addMenu("&File")
        a_new = QAction("New Project", self)
        a_new.triggered.connect(self._new_project)
        m_file.addAction(a_new)
        a_open = QAction("Open Project...", self)
        a_open.setShortcut("Ctrl+O")
        a_open.triggered.connect(self._open_project)
        m_file.addAction(a_open)
        a_save = QAction("Save Project...", self)
        a_save.setShortcut("Ctrl+S")
        a_save.triggered.connect(self._save_project)
        m_file.addAction(a_save)
        m_file.addSeparator()
        a_export_csv = QAction("Export Measurements (CSV)", self)
        a_export_csv.triggered.connect(self._export_csv)
        m_file.addAction(a_export_csv)
        a_export_vtk = QAction("Export 3D Volume (VTK)", self)
        a_export_vtk.triggered.connect(self._export_vtk)
        m_file.addAction(a_export_vtk)
        m_file.addSeparator()
        a_report = QAction("Generate PDF Report...", self)
        a_report.triggered.connect(self._generate_report)
        m_file.addAction(a_report)
        m_file.addSeparator()
        a_quit = QAction("E&xit", self)
        a_quit.setShortcut("Ctrl+Q")
        a_quit.triggered.connect(self.close)
        m_file.addAction(a_quit)

        m_model = mb.addMenu("&Model")
        for name in SCENARIOS:
            a = QAction(f"Load {name.replace('_', ' ').title()}", self)
            a.triggered.connect(lambda checked=False, n=name: self._load_scenario(n))
            m_model.addAction(a)

        m_view = mb.addMenu("&View")
        a_cs = QAction("Cross-Section", self)
        a_cs.triggered.connect(self._show_cross_section)
        m_view.addAction(a_cs)
        a_inv = QAction("Inversion Result", self)
        a_inv.triggered.connect(self._show_inversion)
        m_view.addAction(a_inv)
        a_3d = QAction("3D Volume Viewer", self)
        a_3d.triggered.connect(lambda: self._switch_tab("viewer3d"))
        m_view.addAction(a_3d)
        a_prosp = QAction("Prospectivity Map", self)
        a_prosp.triggered.connect(lambda: self._switch_tab("prospectivity"))
        m_view.addAction(a_prosp)

        m_help = mb.addMenu("&Help")
        a_about = QAction("About petroppo", self)
        a_about.triggered.connect(self._about)
        m_help.addAction(a_about)

    # ===== Ribbon Toolbar =====
    def _build_ribbon(self):
        ribbon = QToolBar("Ribbon")
        ribbon.setMovable(False)
        ribbon.setIconSize(QSize(32, 32))
        ribbon.setFixedHeight(80)
        self.addToolBar(ribbon)

        # --- Home group ---
        btn_home = make_ribbon_button("Dashboard", "Overview")
        btn_home.clicked.connect(lambda: self._switch_tab("dashboard"))
        btn_proj = make_ribbon_button("Project", "Project settings")
        btn_proj.clicked.connect(lambda: self._switch_tab("project"))
        ribbon.addWidget(make_ribbon_group("Home", [btn_home, btn_proj]))

        # --- Modeling group ---
        btn_model = make_ribbon_button("Model", "View earth model")
        btn_model.clicked.connect(self._show_cross_section)
        btn_edit = make_ribbon_button("Edit Model", "Edit layers and bodies")
        btn_edit.clicked.connect(self._show_cross_section)
        ribbon.addWidget(make_ribbon_group("Modeling", [btn_model, btn_edit]))

        # --- Simulation group ---
        btn_run = make_ribbon_button("Run Sim", "Run forward simulation")
        btn_run.clicked.connect(self._run_simulation)
        btn_invert = make_ribbon_button("Invert", "Run inversion")
        btn_invert.clicked.connect(self._run_inversion)
        # Accuracy selector — controls the FD solver mesh resolution
        self.accuracy_combo = QComboBox()
        self.accuracy_combo.setToolTip(
            "Physics accuracy level for the finite-difference solver")
        self.accuracy_combo.addItems(["Standard", "High", "Ultra"])
        self.accuracy_combo.setCurrentIndex(1)  # High = production default
        self.accuracy_combo.currentIndexChanged.connect(self._on_accuracy_changed)
        acc_label = QLabel("Accuracy")
        acc_label.setStyleSheet("color: #8893a5; font-size: 10px; font-weight: bold; letter-spacing: 0.5px;")
        acc_box = QWidget()
        acc_lay = QVBoxLayout(acc_box)
        acc_lay.setContentsMargins(4, 2, 4, 2)
        acc_lay.setSpacing(0)
        acc_lay.addWidget(acc_label)
        acc_lay.addWidget(self.accuracy_combo)
        ribbon.addWidget(make_ribbon_group(
            "Simulation", [btn_run, btn_invert]))
        ribbon.addWidget(acc_box)

        # --- Analysis group ---
        btn_lab = make_ribbon_button("Lab", "Measurement research lab")
        btn_lab.clicked.connect(lambda: self._switch_tab("lab"))
        btn_interp = make_ribbon_button("Interpret", "Interpretation report")
        btn_interp.clicked.connect(self._show_interpretation)
        btn_prosp = make_ribbon_button("Prospect", "HC prospectivity fusion")
        btn_prosp.clicked.connect(lambda: self._switch_tab("prospectivity"))
        btn_3d = make_ribbon_button("3D View", "3D volume viewer")
        btn_3d.clicked.connect(lambda: self._switch_tab("viewer3d"))
        ribbon.addWidget(make_ribbon_group("Analysis", [btn_lab, btn_interp, btn_prosp, btn_3d]))

        # --- Devices group ---
        btn_dev = make_ribbon_button("Devices", "Virtual instruments")
        btn_dev.clicked.connect(lambda: self._switch_tab("devices"))
        btn_survey = make_ribbon_button("Survey", "Survey design")
        btn_survey.clicked.connect(lambda: self._switch_tab("survey"))
        ribbon.addWidget(make_ribbon_group("Instruments", [btn_dev, btn_survey]))

    # ===== Central Area =====
    def _build_central(self):
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(False)

        # Tab 1: Graphics viewport (main COMSOL-style view)
        self.canvas = ModelCanvas()
        self.tab_widget.addTab(self.canvas, "📊  Graphics")

        # Tab 2: Dashboard
        self.view_dashboard = DashboardView(self)
        self.tab_widget.addTab(self.view_dashboard, "🏠  Dashboard")

        # Tab 3: Survey
        self.view_survey = SurveyView(self)
        self.tab_widget.addTab(self.view_survey, "📡  Survey")

        # Tab 4: Devices
        self.view_devices = DevicesView(self)
        self.tab_widget.addTab(self.view_devices, "🔧  Devices")

        # Tab 5: Lab
        self.view_lab = LabView(self)
        self.tab_widget.addTab(self.view_lab, "🧪  Lab")

        # Tab 6: 3D Volume Viewer
        self.view_3d = VolumeViewer3D(self)
        self.tab_widget.addTab(self.view_3d, "🧊  3D Viewer")

        # Tab 7: Prospectivity (legacy V6 fuzzy fusion)
        self.view_prospectivity = ProspectivityView(self)
        self.tab_widget.addTab(self.view_prospectivity, "🛢️  Prospectivity")

        # Tab 7b: Bayesian prospectivity (V7 calibrated posterior + uncertainty)
        self.view_bayesian = BayesianProspectivityView(self)
        self.tab_widget.addTab(self.view_bayesian, "🎯  Bayesian P(oil)")

        # Tab 8: Multi-Physics inversion (gravity / magnetic / GPR / seismic)
        self.view_multiphysics = MultiPhysicsView(self)
        self.tab_widget.addTab(self.view_multiphysics, "🧲  Multi-Physics")

        self.setCentralWidget(self.tab_widget)

    # ===== Dock Widgets =====
    def _build_docks(self):
        # Left: Model Tree
        self.model_tree = ModelTree()
        self.model_tree.itemActivated.connect(self._on_tree_select)
        dock_tree = QDockWidget("Model Tree", self)
        dock_tree.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea |
                                  Qt.DockWidgetArea.RightDockWidgetArea)
        dock_tree.setWidget(self.model_tree)
        dock_tree.setMinimumWidth(220)
        dock_tree.setMaximumWidth(350)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock_tree)

        # Right: Property Panel
        self.prop_panel = PropertyPanel()
        dock_prop = QDockWidget("Properties", self)
        dock_prop.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea |
                                  Qt.DockWidgetArea.RightDockWidgetArea)
        dock_prop.setWidget(self.prop_panel)
        dock_prop.setMinimumWidth(250)
        dock_prop.setMaximumWidth(400)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock_prop)

        # Bottom: Log Console
        self.console = LogConsole()
        dock_log = QDockWidget("Log Console", self)
        dock_log.setAllowedAreas(Qt.DockWidgetArea.BottomDockWidgetArea |
                                  Qt.DockWidgetArea.TopDockWidgetArea)
        dock_log.setWidget(self.console)
        dock_log.setMaximumHeight(180)
        dock_log.setMinimumHeight(80)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock_log)

    # ===== Status Bar =====
    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        self._status_label = QLabel("Ready")
        sb.addWidget(self._status_label)
        self._status_method = QLabel("Mode: Virtual (self-contained)")
        sb.addPermanentWidget(self._status_method)

    # ===== Actions =====
    def _new_project(self):
        self._log("New project created", "INFO")
        self._status("New project")

    def _save_project(self):
        """Save the current project to a .pscan file."""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Project", "petroppo_project.pscan",
            "petroppo Project (*.pscan);;JSON (*.json)")
        if not path:
            return
        try:
            from ..io import ProjectBundle, save_project
            bundle = ProjectBundle()
            bundle.project.name = self.current_model.name
            bundle.earth_model = self.current_model
            if self.current_inversion:
                bundle.inversions = [self.current_inversion]
            save_project(bundle, path)
            self._log(f"Project saved to {path}", "SUCCESS")
        except Exception as exc:
            self._log(f"Save failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Save Error", str(exc))

    def _open_project(self):
        """Load a project from a .pscan or .json file."""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Project", "",
            "petroppo Project (*.pscan);;JSON (*.json);;All Files (*)")
        if not path:
            return
        try:
            from ..io import load_project
            bundle = load_project(path)
            if bundle.earth_model:
                self.current_model = bundle.earth_model
                self._update_tree()
                self._show_cross_section()
            if bundle.inversions:
                self.current_inversion = bundle.inversions[0]
                self._show_inversion()
            self._log(f"Project loaded: {bundle.project.name} "
                      f"({len(bundle.measurements)} measurements)", "SUCCESS")
        except Exception as exc:
            self._log(f"Load failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Load Error", str(exc))

    def _export_csv(self):
        """Export measurements to CSV."""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Measurements", "measurements.csv",
            "CSV Files (*.csv)")
        if not path:
            return
        try:
            # Generate measurements if we have an inversion
            from ..simulator.hifwd import forward_ert_fd
            from ..simulator.forward import wenner_geometry
            geom = wenner_geometry(24, 5.0)
            readings = forward_ert_fd(self.current_model, geom, noise=0.02)
            from ..core import Measurement, MeasurementMethod
            measurements = []
            for r in readings:
                measurements.append(Measurement(
                    method=MeasurementMethod.ERT,
                    x=r.get("x_mid", 0), z=r.get("depth", 0),
                    values={"rho_a": r.get("rho_a", 0),
                            "v": r.get("v", 0), "i": r.get("i", 1)},
                    quality=0.95,
                ))
            from ..io import export_measurements_csv
            export_measurements_csv(measurements, path)
            self._log(f"Exported {len(measurements)} measurements to {path}",
                      "SUCCESS")
        except Exception as exc:
            self._log(f"CSV export failed: {exc}", "ERROR")

    def _export_vtk(self):
        """Export the current inversion model to VTK."""
        if self.current_inversion is None:
            self._log("Run inversion first to export 3D volume.", "WARNING")
            return
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Export VTK Volume", "inversion.vtk",
            "VTK Files (*.vtk)")
        if not path:
            return
        try:
            from ..io import export_inversion_vtk
            model = np.asarray(self.current_inversion.model)
            extent_x = self.current_model.extent_x
            max_depth = self.current_model.max_depth
            if model.ndim == 2:
                nx, nz = model.shape
                xc = np.linspace(extent_x[0], extent_x[1], nx)
                zc = np.linspace(0, max_depth, nz)
                export_inversion_vtk(model, xc, None, zc, path,
                                     "resistivity")
            elif model.ndim == 3:
                # 3D inversion result — use its own coordinates if present
                xc = getattr(self.current_inversion, "x_coords", None)
                yc = getattr(self.current_inversion, "y_coords", None)
                zc = getattr(self.current_inversion, "z_coords", None)
                nx, ny, nz = model.shape
                if xc is None or len(xc) != nx:
                    xc = np.linspace(extent_x[0], extent_x[1], nx)
                if yc is None or len(yc) != ny:
                    yc = np.linspace(self.current_model.extent_y[0],
                                     self.current_model.extent_y[1] or ny,
                                     ny)
                if zc is None or len(zc) != nz:
                    zc = np.linspace(0, max_depth, nz)
                export_inversion_vtk(model, xc, yc, zc, path,
                                     "resistivity")
            else:
                self._log(f"Cannot export {model.ndim}D model to VTK.",
                          "WARNING")
                return
            self._log(f"VTK volume exported to {path}", "SUCCESS")
        except Exception as exc:
            self._log(f"VTK export failed: {exc}", "ERROR")

    def _generate_report(self):
        """Generate a PDF report."""
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Generate PDF Report", "petroppo_report.pdf",
            "PDF Files (*.pdf)")
        if not path:
            return
        try:
            from ..io import generate_pdf_report
            from ..processing import detect_anomalies, generate_report

            interpretation = ""
            if self.current_inversion:
                bodies = detect_anomalies(self.current_inversion)
                interpretation = generate_report(self.current_inversion, bodies)

            result_path = generate_pdf_report(
                path,
                project_name=f"petroppo — {self.current_model.name}",
                earth_model=self.current_model,
                inversions=[self.current_inversion] if self.current_inversion else None,
                interpretation=interpretation,
            )
            self._log(f"PDF report generated: {result_path}", "SUCCESS")
            QMessageBox.information(self, "Report Generated",
                                    f"Report saved to:\n{result_path}")
        except Exception as exc:
            self._log(f"Report generation failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Report Error", str(exc))

    def _load_scenario(self, name: str):
        self.current_model = get_scenario(name)
        engine = get_engine()
        engine.set_model(self.current_model)
        self._log(f"Loaded scenario: {name}", "INFO")
        self._update_tree()
        self._show_cross_section()
        self._status(f"Model: {name}")

    def _switch_tab(self, tab: str):
        mapping = {
            "dashboard": 1, "survey": 2, "devices": 3, "lab": 4,
            "viewer3d": 5, "prospectivity": 6, "bayesian": 7,
            "multiphysics": 8,
        }
        idx = mapping.get(tab, 0)
        self.tab_widget.setCurrentIndex(idx)
        if idx == 1 and hasattr(self.view_dashboard, "refresh"):
            self.view_dashboard.refresh()
        if idx == 7 and hasattr(self, "view_bayesian") \
                and hasattr(self.view_bayesian, "refresh"):
            self.view_bayesian.refresh()

    def _accuracy_mesh(self):
        """Return (nx, nz) FD mesh for the current accuracy selection."""
        return {"standard": (60, 30),
                "high": (100, 50),
                "ultra": (160, 80)}[self._accuracy_key()]

    def _accuracy_key(self):
        return self.accuracy_combo.currentText().lower()

    def _on_accuracy_changed(self, _idx):
        """Sync the engine accuracy when the GUI selector changes."""
        try:
            get_engine().set_accuracy(self._accuracy_key())
            nx, nz = self._accuracy_mesh()
            self._log(f"Accuracy set to {self.accuracy_combo.currentText()} "
                      f"(FD mesh {nx}x{nz})", "INFO")
        except Exception as exc:
            self._log(f"Accuracy change failed: {exc}", "ERROR")

    def _run_simulation(self):
        """Run a HIGH-ACCURACY FD forward simulation and display the pseudosection."""
        nx, nz = self._accuracy_mesh()
        self._log("Running ERT FD forward simulation "
                  f"(accuracy={self.accuracy_combo.currentText()}, mesh {nx}x{nz})...",
                  "INFO")
        geometry = wenner_geometry(24, 5.0)
        readings = forward_ert_fd(self.current_model, geometry, noise=0.02,
                                  nx=nx, nz=nz)
        self._log(f"Simulation complete: {len(readings)} readings", "SUCCESS")
        self.canvas.draw_pseudosection(
            readings, title=f"Pseudosection — {self.current_model.name}")
        self.tab_widget.setCurrentIndex(0)
        self._status(f"Simulated {len(readings)} readings "
                     f"({self.accuracy_combo.currentText()})")

    def _run_inversion(self):
        """Run HIGH-ACCURACY ERT inversion and display the result."""
        self._log("Running high-accuracy inversion (FD forward, Gauss-Newton)...",
                  "INFO")
        try:
            nx, nz = self._accuracy_mesh()
            result = invert_from_model_hi(
                self.current_model, n_electrodes=24, spacing=5.0,
                config="wenner", noise=0.02, n_x=20, n_z=10,
                use_fd_operator=False, max_iter=10,
                fd_nx=nx, fd_nz=nz)
            self.current_inversion = result
            rel = result.meta.get("rel_rmse", float("nan"))
            self._log(
                f"Inversion complete: {result.n_iter} iters, "
                f"RMSE={result.rmse:.4f} (rel={rel:.4f})", "SUCCESS")
            self._show_inversion()
            self._update_3d_viewer()
            self._update_tree()
            self._status(f"Inversion: RMSE={result.rmse:.4f}")
        except Exception as exc:
            self._log(f"Inversion failed: {exc}", "ERROR")

    def _update_3d_viewer(self):
        """Push the current inversion (or earth model) into the 3D viewer."""
        try:
            inv = self.current_inversion
            if inv is not None:
                model = np.asarray(inv.model)
                if model.ndim == 3:
                    # 3D inversion result — show the resistivity volume
                    self.view_3d.set_earth_model_3d(inv)
                    self._log("3D viewer updated with inversion volume",
                              "INFO")
                    return
                # 2D inversion — extrude into a thin 3D slab for the viewer
                nx, nz = model.shape
                vol = model[:, np.newaxis, :]
                xc = np.linspace(self.current_model.extent_x[0],
                                 self.current_model.extent_x[1], nx)
                yc = np.array([0.0])
                zc = np.linspace(0, self.current_model.max_depth, nz)
                self.view_3d.set_volume(vol, xc, yc, zc, "resistivity")
                self._log("3D viewer updated with 2D inversion slab", "INFO")
        except Exception as exc:
            self._log(f"3D viewer update failed: {exc}", "WARNING")

    def _show_cross_section(self):
        self.canvas.draw_cross_section(self.current_model,
                                       title=f"Cross-Section — {self.current_model.name}")
        self.tab_widget.setCurrentIndex(0)

    def _show_inversion(self):
        if self.current_inversion is None:
            self._log("No inversion result available. Run inversion first.", "WARNING")
            return
        self.canvas.draw_inversion(self.current_inversion)
        self.tab_widget.setCurrentIndex(0)

    def _show_interpretation(self):
        if self.current_inversion is None:
            self._log("Run inversion first to generate interpretation.", "WARNING")
            return
        bodies = detect_anomalies(self.current_inversion)
        report = generate_report(self.current_inversion, bodies)
        self._log(f"Interpretation: {len(bodies)} bodies detected", "SUCCESS")
        QMessageBox.information(self, "Interpretation Report", report)

    def _on_tree_select(self, node_type: str, node_id: str):
        """Handle model tree selection."""
        self._log(f"Selected: {node_type} ({node_id})", "INFO")
        if node_type == "model":
            self.prop_panel.show_model_properties(self.current_model)
        elif node_type == "layer":
            self.prop_panel.show_layer_properties(self.current_model, int(node_id))
        elif node_type == "body":
            self.prop_panel.show_body_properties(self.current_model, int(node_id))
        elif node_type == "surveys":
            self.prop_panel.show_survey_properties()
        elif node_type == "inversion":
            self.prop_panel.show_inversion_properties()

    def _update_tree(self):
        inv_results = [self.current_inversion] if self.current_inversion else None
        self.model_tree.load_project(
            project_name=self.current_model.name,
            model=self.current_model,
            surveys=None,
            inversion_results=inv_results,
        )

    def _about(self):
        QMessageBox.about(
            self, "About petroppo",
            "<h2>petroppo</h2>"
            "<p><b>Open-Source Scientific Subsurface Geophysics Platform</b></p>"
            "<p>A complete subsurface geophysics platform featuring seismic "
            "interpretation (AI Seismic Copilot), geological modeling, reservoir "
            "simulation with history matching, joint geophysical inversion, "
            "uncertainty quantification, and calibrated Bayesian "
            "hydrocarbon-prospectivity — all with reproducible workflows and "
            "method-of-manufactured-solutions verification.</p>"
            "<p>The system is scientifically honest: it reports "
            "<i>probabilities with uncertainty</i>, not detections — "
            "only drilling confirms hydrocarbons.</p>"
            "<p><i>Open source. Reproducible. Physics-constrained.</i></p>"
        )

    def _log(self, msg: str, level: str = "INFO"):
        self.console.append_log(msg, level)
        self.log.info(msg)

    def _status(self, msg: str):
        self._status_label.setText(msg)

    def closeEvent(self, event):
        self._log("Shutting down petroppo...", "INFO")
        super().closeEvent(event)
