"""Model tree widget — COMSOL-style hierarchical project browser.

Displays the project structure as a tree:
    Project
    ├── Geometry (Earth Model)
    │   ├── Layers
    │   └── Bodies
    ├── Surveys
    │   ├── ERT Survey
    │   ├── Magnetic Survey
    │   └── ...
    ├── Materials / Properties
    ├── Inversion
    │   └── Results
    └── Interpretation
        └── Reports
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem

from ..core import get_logger

_log = get_logger("gui.modeltree")


class ModelTree(QTreeWidget):
    """Hierarchical model tree for the project."""

    itemActivated = Signal(str, str)  # (node_type, node_id)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderHidden(True)
        self.setAnimated(True)
        self.setUniformRowHeights(True)
        self.itemClicked.connect(self._on_click)
        self._build_empty()

    def _build_empty(self):
        self.clear()
        root = QTreeWidgetItem(self, ["📄 No Project Loaded"])
        root.setData(0, Qt.ItemDataRole.UserRole, ("empty", ""))
        self.addTopLevelItem(root)

    def load_project(self, project_name: str, model=None,
                     surveys=None, inversion_results=None):
        """Populate the tree from project data."""
        self.clear()

        # Root: project
        root = QTreeWidgetItem(self, [f"🗂  {project_name}"])
        root.setData(0, Qt.ItemDataRole.UserRole, ("project", ""))
        root.setExpanded(True)
        self.addTopLevelItem(root)

        # Earth Model / Geometry
        geo_node = QTreeWidgetItem(root, ["🌐  Earth Model"])
        geo_node.setData(0, Qt.ItemDataRole.UserRole, ("model", ""))
        geo_node.setExpanded(True)

        if model is not None:
            layers_node = QTreeWidgetItem(geo_node, [f"    📐  Layers ({len(model.layers)})"])
            layers_node.setData(0, Qt.ItemDataRole.UserRole, ("layers", ""))
            for i, lay in enumerate(model.layers):
                ln = QTreeWidgetItem(layers_node, [
                    f"    🟫  {lay.name} ({lay.resistivity:.0f} ohm.m)"])
                ln.setData(0, Qt.ItemDataRole.UserRole, ("layer", str(i)))

            bodies_node = QTreeWidgetItem(geo_node, [f"    🔷  Bodies ({len(model.bodies)})"])
            bodies_node.setData(0, Qt.ItemDataRole.UserRole, ("bodies", ""))
            for i, b in enumerate(model.bodies):
                bn = QTreeWidgetItem(bodies_node, [
                    f"    ⬭  {b.label} ({b.resistivity:.0f} ohm.m)"])
                bn.setData(0, Qt.ItemDataRole.UserRole, ("body", str(i)))
        else:
            QTreeWidgetItem(geo_node, ["    (no model loaded)"])

        # Surveys
        surveys_node = QTreeWidgetItem(root, ["📡  Surveys"])
        surveys_node.setData(0, Qt.ItemDataRole.UserRole, ("surveys", ""))
        if surveys:
            for s in surveys:
                sn = QTreeWidgetItem(surveys_node, [
                    f"    📊  {s.name} [{s.method.value}]"])
                sn.setData(0, Qt.ItemDataRole.UserRole, ("survey", s.id))
        else:
            QTreeWidgetItem(surveys_node, ["    (no surveys)"])

        # Inversion
        inv_node = QTreeWidgetItem(root, ["🔄  Inversion"])
        inv_node.setData(0, Qt.ItemDataRole.UserRole, ("inversion", ""))
        if inversion_results:
            for i, r in enumerate(inversion_results):
                rn = QTreeWidgetItem(inv_node, [
                    f"    📈  Result #{i+1} (RMSE={r.rmse:.3f})"])
                rn.setData(0, Qt.ItemDataRole.UserRole, ("inv_result", str(i)))
        else:
            QTreeWidgetItem(inv_node, ["    (no results)"])

        # Interpretation
        interp_node = QTreeWidgetItem(root, ["📋  Interpretation"])
        interp_node.setData(0, Qt.ItemDataRole.UserRole, ("interpretation", ""))

        # Properties
        props_node = QTreeWidgetItem(root, ["⚙️  Properties"])
        props_node.setData(0, Qt.ItemDataRole.UserRole, ("properties", ""))

    def _on_click(self, item, column):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if data:
            node_type, node_id = data
            self.itemActivated.emit(node_type, node_id)
