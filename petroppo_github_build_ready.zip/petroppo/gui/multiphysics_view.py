"""Multi-physics inversion view — gravity, magnetic, GPR, seismic.

This panel drives the ``petroppo.simulator.mpinv`` module from the GUI so
that every geophysical method supported by petroppo can be run, inverted
and visualised without leaving the application.  Synthetic data are
generated from the current 2-D earth model when real measurements are not
available, which keeps the workflow identical for virtual and live surveys.
"""
from __future__ import annotations

import numpy as np

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QGridLayout, QHBoxLayout,
    QLabel, QProgressBar, QPushButton, QSpinBox, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget, QMessageBox,
)

from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvas

from .style import MPL_FACE, MPL_GRID, MPL_TEXT
from .widgets import make_title, make_panel

# Multi-physics inversion engines
from ..simulator.mpinv import (
    PrismModel, invert_gravity, invert_magnetic,
    forward_gpr_fdt, forward_seismic_tomography,
    invert_seismic_tomography,
    _gravity_sensitivity, _magnetic_sensitivity,
)


_METHODS = [
    ("Gravity", "gravity"),
    ("Magnetic", "magnetic"),
    ("GPR (radargram)", "gpr"),
    ("Seismic tomography", "seismic"),
]


class MultiPhysicsView(QWidget):
    """Run and visualise non-ERT geophysical inversions."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self.result = None          # most-recent inversion result object
        self._build()

    # ------------------------------------------------------------------ build
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Multi-Physics Inversion",
            "Gravity · Magnetic · GPR · Seismic — forward modelling & inversion",
        ))

        # --- control row ---
        ctrl_panel, ctrl_body = make_panel("Method & Parameters")
        root.addWidget(ctrl_panel)

        form = QFormLayout()
        form.setSpacing(8)

        self.method_combo = QComboBox()
        for label, _key in _METHODS:
            self.method_combo.addItem(label)
        self.method_combo.currentIndexChanged.connect(self._on_method_changed)
        form.addRow("Method:", self.method_combo)

        self.stations_spin = QSpinBox()
        self.stations_spin.setRange(6, 200)
        self.stations_spin.setValue(30)
        form.addRow("Stations / shots:", self.stations_spin)

        self.nx_spin = QSpinBox()
        self.nx_spin.setRange(8, 80)
        self.nx_spin.setValue(24)
        form.addRow("Model cells (X):", self.nx_spin)

        self.nz_spin = QSpinBox()
        self.nz_spin.setRange(4, 60)
        self.nz_spin.setValue(12)
        form.addRow("Model cells (Z):", self.nz_spin)

        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(1, 50)
        self.iter_spin.setValue(12)
        form.addRow("Max iterations:", self.iter_spin)

        self.noise_spin = QDoubleSpinBox()
        self.noise_spin.setRange(0, 20)
        self.noise_spin.setDecimals(1)
        self.noise_spin.setValue(2.0)
        self.noise_spin.setSuffix(" %")
        form.addRow("Synthetic noise:", self.noise_spin)

        # method-specific extra parameter
        self.param_combo = QComboBox()
        form.addRow("Field / mode:", self.param_combo)

        run_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run Forward + Invert")
        self.run_btn.clicked.connect(self._run)
        run_row.addWidget(self.run_btn)
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(self._clear)
        run_row.addWidget(self.clear_btn)
        form.addRow(run_row)
        ctrl_body.addLayout(form)

        # --- main split: figure + side info ---
        split = QHBoxLayout()
        split.setSpacing(14)

        # figure
        self.fig = Figure(figsize=(8, 6), dpi=100, facecolor=MPL_FACE)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setMinimumHeight(360)
        split.addWidget(self.canvas, 3)

        # side: progress + stats + log
        side = QVBoxLayout()
        side.setSpacing(10)

        stat_panel, stat_body = make_panel("Quality Stats")
        side.addWidget(stat_panel)
        self.stat_table = QTableWidget(4, 2)
        self.stat_table.setHorizontalHeaderLabels(["Metric", "Value"])
        self.stat_table.verticalHeader().setVisible(False)
        self.stat_table.setEditTriggers(QTableWidget.NoEditTriggers)
        for i, label in enumerate(["RMSE", "Iterations", "Converged", "Cells"]):
            self.stat_table.setItem(i, 0, QTableWidgetItem(label))
            self.stat_table.setItem(i, 1, QTableWidgetItem("—"))
        self.stat_table.setColumnWidth(0, 90)
        self.stat_table.setColumnWidth(1, 120)
        stat_body.layout().addWidget(self.stat_table)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        side.addWidget(self.progress)

        log_panel, log_body = make_panel("Run Log")
        side.addWidget(log_panel)
        self.log_edit = QTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setMaximumHeight(140)
        log_body.layout().addWidget(self.log_edit)

        side.addStretch(1)
        split.addLayout(side, 1)
        root.addLayout(split, 1)

        self._on_method_changed(0)

    # ----------------------------------------------------------- method switch
    def _on_method_changed(self, _idx: int):
        self.param_combo.clear()
        key = _METHODS[self.method_combo.currentIndex()][1]
        if key == "gravity":
            self.param_combo.addItem("Density contrast (kg/m³)")
        elif key == "magnetic":
            self.param_combo.addItem("Total field F = 50 000 nT")
            self.param_combo.addItem("Reduced-to-pole (inc=90°)")
        elif key == "gpr":
            self.param_combo.addItem("Central freq 100 MHz")
            self.param_combo.addItem("Central freq 250 MHz")
            self.param_combo.addItem("Central freq 500 MHz")
        elif key == "seismic":
            self.param_combo.addItem("Initial v = 2000 m/s")
            self.param_combo.addItem("Initial v = 3000 m/s")
            self.param_combo.addItem("Initial v = 4000 m/s")

    # ------------------------------------------------------------------ helpers
    def _log(self, msg: str):
        self.log_edit.append(msg)

    def _current_model(self):
        m = getattr(self.main, "current_model", None)
        if m is None:
            raise RuntimeError("No earth model loaded — create or load a model first.")
        return m

    def _stations(self, model):
        n = self.stations_spin.value()
        x0, x1 = model.extent_x
        return np.linspace(x0, x1, n)

    def _sample_property(self, model, nx, nz, prop="resistivity"):
        """Sample a model property onto an (nx, nz) grid using the model's
        property_at / resistivity_at sampler (2-D profile, y=0)."""
        x0, x1 = model.extent_x
        md = model.max_depth
        xc = np.linspace(x0, x1, nx)
        zc = np.linspace(md / (2 * nz), md - md / (2 * nz), nz)
        grid = np.zeros((nx, nz))
        for ix, x in enumerate(xc):
            for iz, z in enumerate(zc):
                try:
                    if prop == "resistivity" and hasattr(model, "resistivity_at"):
                        grid[ix, iz] = model.resistivity_at(x, 0.0, z)
                    elif hasattr(model, "property_at"):
                        grid[ix, iz] = model.property_at(x, 0.0, z, prop)
                    else:
                        grid[ix, iz] = 0.0
                except TypeError:
                    # fallback for 2-arg signatures
                    grid[ix, iz] = model.resistivity_at(x, z) if prop == "resistivity" else 0.0
        return grid

    # ------------------------------------------------------------------ run
    def _run(self):
        try:
            model = self._current_model()
        except Exception as exc:
            QMessageBox.warning(self, "Multi-Physics", str(exc))
            return

        key = _METHODS[self.method_combo.currentIndex()][1]
        self.progress.setValue(5)
        self._log(f"▶ Running {key} forward + inversion …")

        try:
            if key == "gravity":
                self.result = self._run_gravity(model)
            elif key == "magnetic":
                self.result = self._run_magnetic(model)
            elif key == "gpr":
                self.result = self._run_gpr(model)
            elif key == "seismic":
                self.result = self._run_seismic(model)
        except Exception as exc:
            self._log(f"✗ Error: {exc}")
            QMessageBox.critical(self, "Multi-Physics", f"Inversion failed:\n{exc}")
            self.progress.setValue(0)
            return

        self.progress.setValue(90)
        self._plot_result(key)
        self._update_stats(key)
        self.progress.setValue(100)
        self._log("✔ Done.")
        if self.main is not None and hasattr(self.main, "_log"):
            self.main._log(f"Multi-physics [{key}] inversion complete", "INFO")

    # ----- gravity -----------------------------------------------------------
    def _run_gravity(self, model):
        stations = self._stations(model)
        nx, nz = self.nx_spin.value(), self.nz_spin.value()
        x0, x1 = model.extent_x
        md = model.max_depth
        # build a synthetic density-contrast model: dense where resistivity is
        # low (heuristic — a low-resistivity body is often mineralised/dense)
        rho_grid = self._sample_property(model, nx, nz, "resistivity")
        density = 0.4 * (rho_grid.max() - rho_grid) / max(np.ptp(rho_grid), 1e-9)
        # build prism model (same convention as invert_gravity)
        xs = np.linspace(x0, x1, nx + 1)
        zs = np.linspace(0, md, nz + 1)
        xc = 0.5 * (xs[:-1] + xs[1:])
        zc = 0.5 * (zs[:-1] + zs[1:])
        pm = PrismModel(x_centers=xc, z_centers=zc,
                        dx=float(xc[1] - xc[0]), dz=float(zc[1] - zc[0]),
                        y_extent=50.0)
        G = _gravity_sensitivity(pm, stations)
        obs = G @ density.ravel()
        noise = self.noise_spin.value() / 100.0
        if noise > 0:
            rng = np.random.default_rng(7)
            obs = obs + rng.normal(0, noise * max(np.abs(obs).mean(), 1e-6),
                                   obs.size)
        res = invert_gravity(
            stations, obs, x0, x1, md,
            nx=nx, nz=nz, n_iter=self.iter_spin.value(),
            target_rmse=0.05, survey_id="mp_gravity",
        )
        self._log(f"  stations={len(stations)}, cells={nx}x{nz}, "
                  f"rmse={res.rmse:.4f}, iter={res.n_iter}, "
                  f"converged={res.converged}")
        return res

    # ----- magnetic ----------------------------------------------------------
    def _run_magnetic(self, model):
        stations = self._stations(model)
        nx, nz = self.nx_spin.value(), self.nz_spin.value()
        x0, x1 = model.extent_x
        md = model.max_depth
        rho_grid = self._sample_property(model, nx, nz, "resistivity")
        susc = 0.02 * (rho_grid.max() - rho_grid) / max(np.ptp(rho_grid), 1e-9)
        xs = np.linspace(x0, x1, nx + 1)
        zs = np.linspace(0, md, nz + 1)
        xc = 0.5 * (xs[:-1] + xs[1:])
        zc = 0.5 * (zs[:-1] + zs[1:])
        pm = PrismModel(x_centers=xc, z_centers=zc,
                        dx=float(xc[1] - xc[0]), dz=float(zc[1] - zc[0]),
                        y_extent=50.0)
        G = _magnetic_sensitivity(pm, stations, F_mag=50000.0, inc_deg=60.0)
        obs = G @ susc.ravel()
        noise = self.noise_spin.value() / 100.0
        if noise > 0:
            rng = np.random.default_rng(11)
            obs = obs + rng.normal(0, noise * max(np.abs(obs).mean(), 1e-6),
                                   obs.size)
        res = invert_magnetic(
            stations, obs, x0, x1, md,
            nx=nx, nz=nz, n_iter=self.iter_spin.value(),
            target_rmse=0.5, survey_id="mp_magnetic",
        )
        self._log(f"  stations={len(stations)}, cells={nx}x{nz}, "
                  f"rmse={res.rmse:.4f}, iter={res.n_iter}, "
                  f"converged={res.converged}")
        return res

    # ----- gpr ---------------------------------------------------------------
    def _run_gpr(self, model):
        freqs = [100.0, 250.0, 500.0]
        freq = freqs[self.param_combo.currentIndex()]
        x0, x1 = model.extent_x
        n_traces = max(20, self.stations_spin.value() // 2)
        midpoints = np.linspace(x0, x1, n_traces)
        offset = min((x1 - x0) / n_traces, 5.0)
        radargram = None
        time_axis = None
        for i, mx in enumerate(midpoints):
            res = forward_gpr_fdt(
                model, x_tx=mx - offset / 2, x_rx=mx + offset / 2,
                twt_max=120.0, dt=0.5, nx=80, nz=60, freq_central=freq,
            )
            trace = np.asarray(res["trace"])
            if radargram is None:
                radargram = np.zeros((len(trace), n_traces))
                time_axis = np.asarray(res["time"])
            radargram[:, i] = trace
        n_refl = len(res.get("reflections", []))
        self._log(f"  freq={freq} MHz, traces={n_traces}, "
                  f"samples={len(time_axis)}, reflections={n_refl}")
        return {"radargram": radargram, "time": time_axis,
                "midpoints": midpoints, "freq": freq,
                "n_traces": n_traces, "twt_max": 120.0}

    # ----- seismic -----------------------------------------------------------
    def _run_seismic(self, model):
        stations = self._stations(model)
        n = len(stations)
        nx, nz = self.nx_spin.value(), self.nz_spin.value()
        x0, x1 = model.extent_x
        md = model.max_depth
        v0 = [2000.0, 3000.0, 4000.0][self.param_combo.currentIndex()]
        # synthetic: velocity increases with depth, modulated by resistivity
        rho_grid = self._sample_property(model, nx, nz, "resistivity")
        rho_cols = rho_grid.mean(axis=1)
        norm_rho = (rho_cols - rho_cols.min()) / max(np.ptp(rho_cols), 1e-9)
        x_centers = np.linspace(x0, x1, nx)
        z_centers = np.linspace(md / nz / 2, md, nz)
        vel_grid = np.zeros((nx, nz))
        for iz in range(nz):
            depth_frac = iz / max(nz - 1, 1)
            vel_grid[:, iz] = v0 + 800.0 * depth_frac + 1200.0 * norm_rho
        # shots: every few stations; receivers: all stations
        step = max(1, n // 8)
        shots = stations[::step]
        receivers = stations
        # observed travel times from forward (returns plain array)
        obs = forward_seismic_tomography(vel_grid, x_centers, z_centers,
                                         shots, receivers)
        noise = self.noise_spin.value() / 100.0
        if noise > 0 and obs.size:
            rng = np.random.default_rng(3)
            obs = obs * (1 + rng.normal(0, noise, obs.size))
        res = invert_seismic_tomography(
            shots, receivers, obs, x0, x1, md,
            nx=nx, nz=nz, initial_velocity=v0,
            n_iter=self.iter_spin.value(), target_rmse=0.005,
            survey_id="mp_seismic",
        )
        self._log(f"  shots={len(shots)}, receivers={len(receivers)}, "
                  f"cells={nx}x{nz}, rmse={res.rmse:.4f}, "
                  f"iter={res.n_iter}, converged={res.converged}")
        return res

    # ------------------------------------------------------------------ plot
    def _plot_result(self, key: str):
        self.fig.clear()
        if key in ("gravity", "magnetic"):
            data = (self.result.density_contrast if key == "gravity"
                    else self.result.susceptibility)
            pm = self.result.prism_model
            ax = self.fig.add_subplot(111)
            im = ax.imshow(
                np.asarray(data).T, origin="upper", aspect="auto",
                extent=[pm.x_min, pm.x_max, pm.max_depth, 0],
                cmap="RdBu_r",
            )
            ax.set_xlabel("X (m)", color=MPL_TEXT)
            ax.set_ylabel("Depth (m)", color=MPL_TEXT)
            title = "Density contrast (kg/m³)" if key == "gravity" \
                else "Susceptibility (SI)"
            ax.set_title(f"{key.capitalize()} inversion — {title}",
                         color=MPL_TEXT)
            self.fig.colorbar(im, ax=ax, shrink=0.82, pad=0.02)
        elif key == "gpr":
            ax = self.fig.add_subplot(111)
            rg = np.asarray(self.result["radargram"])
            mids = np.asarray(self.result["midpoints"])
            t = np.asarray(self.result["time"])
            if rg.size:
                extent = [mids[0], mids[-1], t[-1], t[0]]
                im = ax.imshow(rg, aspect="auto", cmap="Greys",
                               origin="upper", extent=extent)
                ax.set_xlabel("Distance (m)", color=MPL_TEXT)
                ax.set_ylabel("Two-way time (ns)", color=MPL_TEXT)
                ax.set_title(
                    f"GPR radargram — {self.result['freq']:.0f} MHz, "
                    f"{self.result['n_traces']} traces", color=MPL_TEXT)
                self.fig.colorbar(im, ax=ax, shrink=0.82, pad=0.02)
            else:
                ax.text(0.5, 0.5, "No radargram data", ha="center",
                        transform=ax.transAxes, color=MPL_TEXT)
        elif key == "seismic":
            vel = np.asarray(self.result.velocity)
            ax = self.fig.add_subplot(111)
            im = ax.imshow(
                vel.T, origin="upper", aspect="auto",
                extent=[self.result.x_centers[0], self.result.x_centers[-1],
                        self.result.z_centers[-1], self.result.z_centers[0]],
                cmap="viridis",
            )
            ax.set_xlabel("X (m)", color=MPL_TEXT)
            ax.set_ylabel("Depth (m)", color=MPL_TEXT)
            ax.set_title("Seismic velocity (m/s)", color=MPL_TEXT)
            self.fig.colorbar(im, ax=ax, shrink=0.82, pad=0.02)
        self.fig.tight_layout()
        self.canvas.draw_idle()

    # ------------------------------------------------------------------ stats
    def _update_stats(self, key: str):
        def set_row(i, val):
            self.stat_table.setItem(i, 1, QTableWidgetItem(str(val)))
        if key in ("gravity", "magnetic"):
            set_row(0, f"{self.result.rmse:.4f}")
            set_row(1, self.result.n_iter)
            set_row(2, "yes" if self.result.converged else "no")
            set_row(3, f"{self.result.density_contrast.shape if key=='gravity' else self.result.susceptibility.shape}")
        elif key == "seismic":
            set_row(0, f"{self.result.rmse:.4f}")
            set_row(1, self.result.n_iter)
            set_row(2, "yes" if self.result.converged else "no")
            set_row(3, f"{self.result.velocity.shape}")
        elif key == "gpr":
            rg = self.result["radargram"]
            set_row(0, "—")
            set_row(1, "—")
            set_row(2, "—")
            set_row(3, f"{rg.shape}")

    def _clear(self):
        self.fig.clear()
        self.canvas.draw_idle()
        self.log_edit.clear()
        self.progress.setValue(0)
        for i in range(4):
            self.stat_table.setItem(i, 1, QTableWidgetItem("—"))
        self.result = None
