"""petroppo — Owner Dashboard.

A window only owners can open.  Shows:
  * All accounts (customers + owners) with status, trial/paid days, last login
  * All payments (who paid, when, how much, plan)
  * Full audit log (logins, login failures, locks, license changes)
  * Actions: manually activate/extend a customer, lock a customer, refresh

This gives the owners full visibility & control as requested.
"""
from __future__ import annotations

import time

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QLineEdit, QComboBox, QFrame,
)

from .pro_style import (
    PRO_QSS, ORANGE, ORANGE_DARK, ORANGE_HOVER, BG_DARKEST, BG_PANEL,
    BG_CARD, BORDER, TEXT, TEXT_MUTED, GREEN, RED, YELLOW,
)
from .pro_icons import logo_icon
from ..platform.owner_accounts import AccountStore, ROLE_OWNER


def _epoch_to_str(ts) -> str:
    if not ts:
        return "—"
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(float(ts)))
    except Exception:
        return str(ts)


class OwnerDashboard(QMainWindow):
    """Owner control panel — full visibility of accounts & payments."""

    def __init__(self, store: AccountStore, owner_username: str):
        super().__init__()
        self.store = store
        self.owner = owner_username
        self.setWindowTitle("petroppo — Owner Dashboard")
        self.resize(1100, 720)
        self.setStyleSheet(PRO_QSS)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(20, 18, 20, 18)
        root.setSpacing(12)

        # header
        header = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(logo_icon(36, 2.0).pixmap(36, 36))
        header.addWidget(logo)
        h_title = QLabel("Owner Dashboard")
        h_title.setStyleSheet(
            f"font-size:20px; font-weight:bold; color:{TEXT}; background:transparent;")
        header.addWidget(h_title)
        header.addStretch()
        owner_lbl = QLabel(f"Signed in as:  {owner_username}  (Owner)")
        owner_lbl.setStyleSheet(
            f"color:{ORANGE}; font-weight:bold; background:transparent;")
        header.addWidget(owner_lbl)
        btn_refresh = QPushButton("  Refresh  ")
        btn_refresh.setStyleSheet(f"""
            QPushButton {{
                background-color: {BG_PANEL}; color: {TEXT};
                border: 1px solid {BORDER}; border-radius: 6px; padding: 8px 16px;
            }}
            QPushButton:hover {{ border: 1px solid {ORANGE}; color: {ORANGE}; }}
        """)
        btn_refresh.clicked.connect(self._refresh)
        header.addWidget(btn_refresh)
        root.addLayout(header)

        # summary cards
        self._build_summary(root)

        # tabs
        tabs = QTabWidget()
        tabs.setStyleSheet(PRO_QSS)

        self.tab_accounts = self._make_table([
            "User", "Name", "Role", "License", "Status", "Trial/Paid Days Left",
            "Machine", "Created", "Last Login"])
        self.tab_payments = self._make_table([
            "Time", "User", "Plan", "Amount USD", "Method", "Status"])
        self.tab_audit = self._make_table([
            "Time", "User", "Action", "Detail"])

        tabs.addTab(self.tab_accounts, "Accounts")
        tabs.addTab(self.tab_payments, "Payments")
        tabs.addTab(self.tab_audit, "Audit Log")
        root.addWidget(tabs, 1)

        # actions row
        actions = QHBoxLayout()
        lbl = QLabel("Customer actions:")
        lbl.setStyleSheet(f"color:{TEXT_MUTED}; background:transparent;")
        actions.addWidget(lbl)

        self.cb_user = QComboBox()
        actions.addWidget(self.cb_user, 1)

        btn_activate = QPushButton("  Activate / Extend (1 year)  ")
        btn_activate.setStyleSheet(f"""
            QPushButton {{
                background-color: {GREEN}; color: white; border: none;
                border-radius: 6px; padding: 9px 16px; font-weight: bold;
            }}
            QPushButton:hover {{ background-color: #12a34a; }}
        """)
        btn_activate.clicked.connect(self._activate)
        actions.addWidget(btn_activate)

        btn_lock = QPushButton("  Lock  ")
        btn_lock.setStyleSheet(f"""
            QPushButton {{
                background-color: {RED}; color: white; border: none;
                border-radius: 6px; padding: 9px 16px; font-weight: bold;
            }}
            QPushButton:hover {{ background-color: #b91c1c; }}
        """)
        btn_lock.clicked.connect(self._lock)
        actions.addWidget(btn_lock)

        root.addLayout(actions)

        self._refresh()

    # --------------------------------------------------------------- helpers
    def _make_table(self, headers) -> QTableWidget:
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        t.setAlternatingRowColors(True)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        return t

    def _build_summary(self, root):
        row = QHBoxLayout()
        row.setSpacing(12)
        self.lbl_total = self._stat_card(row, "Total Accounts", "0", ORANGE)
        self.lbl_paid = self._stat_card(row, "Paid Customers", "0", GREEN)
        self.lbl_trial = self._stat_card(row, "Active Trials", "0", YELLOW)
        self.lbl_revenue = self._stat_card(row, "Total Revenue", "$0", ORANGE)
        root.addLayout(row)

    def _stat_card(self, layout, title, value, color):
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {BG_PANEL};
                border: 1px solid {BORDER};
                border-radius: 10px;
            }}
            QLabel {{ background: transparent; }}
        """)
        v = QVBoxLayout(card)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(4)
        t = QLabel(title)
        t.setStyleSheet(f"color:{TEXT_MUTED}; font-size:11px; font-weight:bold; letter-spacing:1px;")
        val = QLabel(value)
        val.setStyleSheet(f"color:{color}; font-size:26px; font-weight:bold;")
        v.addWidget(t)
        v.addWidget(val)
        layout.addWidget(card)
        return val

    # --------------------------------------------------------------- refresh
    def _refresh(self):
        accounts = self.store.list_accounts()
        payments = self.store.list_payments()
        audit = self.store.list_audit(limit=300)

        # accounts table
        self.tab_accounts.setRowCount(0)
        customers = []
        for a in accounts:
            r = self.tab_accounts.rowCount()
            self.tab_accounts.insertRow(r)
            days = self.store.days_left_trial(a["username"])
            if a["role"] == ROLE_OWNER:
                days_lbl = "∞"
            elif a["status"] == "active" and a["paid_until"]:
                days_lbl = f"{days} d (paid)"
            elif a["status"] == "locked":
                days_lbl = "LOCKED"
            else:
                days_lbl = f"{days} d (trial)"
            vals = [
                a["username"], a["full_name"] or "", a["role"],
                a["license_type"], a["status"], days_lbl,
                (a["machine_id"] or "")[:12], _epoch_to_str(a["created_at"]),
                _epoch_to_str(a["last_login"]),
            ]
            for c, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                if a["status"] == "locked":
                    item.setForeground(QColor(RED))
                elif a["status"] == "active" and a["role"] != ROLE_OWNER:
                    item.setForeground(QColor(GREEN))
                self.tab_accounts.setItem(r, c, item)
            if a["role"] != ROLE_OWNER:
                customers.append(a["username"])

        # payments table
        self.tab_payments.setRowCount(0)
        revenue = 0.0
        for p in payments:
            r = self.tab_payments.rowCount()
            self.tab_payments.insertRow(r)
            vals = [_epoch_to_str(p["ts"]), p["username"], p["plan"],
                    f"${p['amount_usd']:.2f}", p["method"], p["status"]]
            for c, val in enumerate(vals):
                self.tab_payments.setItem(r, c, QTableWidgetItem(str(val)))
            if p["status"] == "success":
                revenue += float(p["amount_usd"] or 0)

        # audit table
        self.tab_audit.setRowCount(0)
        for a in audit:
            r = self.tab_audit.rowCount()
            self.tab_audit.insertRow(r)
            vals = [_epoch_to_str(a["ts"]), a["username"] or "", a["action"], a["detail"] or ""]
            for c, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                if a["action"] == "login_failed":
                    item.setForeground(QColor(RED))
                elif a["action"] == "payment":
                    item.setForeground(QColor(GREEN))
                elif a["action"] == "lock":
                    item.setForeground(QColor(RED))
                self.tab_audit.setItem(r, c, item)

        # summary
        total = len(accounts)
        paid = sum(1 for a in accounts if a["role"] != ROLE_OWNER
                   and a["status"] == "active" and a["paid_until"])
        trial = sum(1 for a in accounts if a["role"] != ROLE_OWNER
                    and a["status"] != "locked" and not (a["paid_until"] and a["paid_until"] > time.time()))
        self.lbl_total.setText(str(total))
        self.lbl_paid.setText(str(paid))
        self.lbl_trial.setText(str(trial))
        self.lbl_revenue.setText(f"${revenue:,.0f}")

        # customer dropdown
        self.cb_user.clear()
        for c in customers:
            self.cb_user.addItem(c)

    # --------------------------------------------------------------- actions
    def _activate(self):
        u = self.cb_user.currentText()
        if not u:
            return
        self.store.mark_paid(u, "professional", 199.0, method="manual_by_owner")
        self.store.log(u, "license_change", f"activated by owner {self.owner}")
        QMessageBox.information(self, "Activated",
                                f"Account '{u}' activated for 1 year (Professional).")
        self._refresh()

    def _lock(self):
        u = self.cb_user.currentText()
        if not u:
            return
        self.store.lock_account(u)
        QMessageBox.information(self, "Locked", f"Account '{u}' has been locked.")
        self._refresh()
