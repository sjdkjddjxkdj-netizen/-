"""petroppo Pro — crisp 4K-ready SVG vector icons (scale to any DPI).

Every icon is drawn from an SVG string and rasterised on demand at the
requested pixel ratio, so the UI stays razor-sharp on 4K / 8K displays.
"""
from __future__ import annotations

from PySide6.QtCore import QByteArray, QSize, Qt, QRectF
from PySide6.QtGui import QPixmap, QPainter, QIcon
from PySide6.QtSvg import QSvgRenderer

import os

# ---------------------------------------------------------------------------
# SVG templates.  Colors are injected via str.format.  All use
# vector paths so they scale perfectly to 4K / retina.
# ---------------------------------------------------------------------------

_SVG_WRAP = (
    '<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
    'viewBox="0 0 24 24" fill="none">'
    '{body}</svg>'
)

# Folder (open/closed) — used for project groups
SVG_FOLDER = (
    '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h8a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7z" '
    'fill="{c}" opacity="0.95"/>'
    '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h8a1 1 0 0 1 1 1" stroke="{cd}" '
    'stroke-width="0.8" fill="none"/>'
)

# Seismic volume — layered wiggle traces
SVG_SEISMIC = (
    '<rect x="3.5" y="3" width="17" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M6 17 C7 13 7 11 8 8 C8.5 6.5 9 6.5 9.5 8 C10 11 10 13 11 16 '
    'C11.5 18 12 18 12.5 16 C13 13 13 11 14 8 C14.5 6.5 15 6.5 15.5 8 '
    'C16 11 16 13 17 16 C17.5 17.5 18 17.5 18.5 16" '
    'stroke="{c}" stroke-width="1.3" fill="none" stroke-linecap="round"/>'
)

# Well log — vertical line with tick marks (gamma ray style)
SVG_WELL = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M10 5 L10 19" stroke="{c}" stroke-width="1.6" stroke-linecap="round"/>'
    '<path d="M7 7 L13 7 M7 10 L13 10 M7 13 L13 13 M7 16 L13 16" '
    'stroke="{c}" stroke-width="1" opacity="0.8"/>'
    '<circle cx="10" cy="5" r="1.4" fill="{c}"/>'
)

# Horizon / surface — wavy line
SVG_HORIZON = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M6 11 C8 7 10 15 12 11 C14 7 16 15 18 11" '
    'stroke="{c}" stroke-width="1.6" fill="none" stroke-linecap="round"/>'
    '<path d="M6 15 C8 12 10 18 12 15 C14 12 16 18 18 15" '
    'stroke="{c}" stroke-width="1.2" fill="none" opacity="0.5"/>'
)

# Fault — zigzag line
SVG_FAULT = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M11 4 L8 8 L14 11 L9 15 L13 20" '
    'stroke="{c}" stroke-width="1.8" fill="none" stroke-linecap="round" '
    'stroke-linejoin="round"/>'
)

# AI brain / copilot
SVG_AI = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<circle cx="9" cy="10" r="2" fill="none" stroke="{c}" stroke-width="1.3"/>'
    '<circle cx="15" cy="10" r="2" fill="none" stroke="{c}" stroke-width="1.3"/>'
    '<path d="M11 10 L13 10" stroke="{c}" stroke-width="1.3"/>'
    '<path d="M9 12.5 L9 16 M15 12.5 L15 16" stroke="{c}" stroke-width="1.2"/>'
    '<path d="M7 16 L17 16" stroke="{c}" stroke-width="1.2" stroke-linecap="round"/>'
    '<circle cx="12" cy="18" r="0.9" fill="{c}"/>'
)

# Model / grid — 3D cube
SVG_MODEL = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M8 7 L16 7 L16 16 L8 16 Z" fill="none" stroke="{c}" stroke-width="1.3"/>'
    '<path d="M8 7 L11 5 L19 5 L16 7 M16 7 L19 5 L19 14 L16 16" '
    'fill="none" stroke="{c}" stroke-width="1.3" stroke-linejoin="round"/>'
    '<path d="M8 11 L16 11 M8 13.5 L16 13.5" stroke="{c}" stroke-width="0.8" opacity="0.6"/>'
)

# Reservoir / simulation — tank with arrows
SVG_RESERVOIR = (
    '<rect x="4" y="3" width="16" height="18" rx="3" fill="{bg}" stroke="{bd}" stroke-width="1"/>'
    '<path d="M7 8 L17 8 L17 17 L7 17 Z" fill="none" stroke="{c}" stroke-width="1.3"/>'
    '<path d="M7 12 L17 12" stroke="{c}" stroke-width="0.9" opacity="0.6"/>'
    '<path d="M10 6 L10 5 L14 5 L14 6" stroke="{c}" stroke-width="1.2" fill="none"/>'
    '<path d="M12 5 L12 8" stroke="{c}" stroke-width="1.2"/>'
)

# Export / file
SVG_FILE = (
    '<path d="M6 3 L14 3 L18 7 L18 21 L6 21 Z" fill="{bg}" stroke="{bd}" stroke-width="1.1" '
    'stroke-linejoin="round"/>'
    '<path d="M14 3 L14 7 L18 7" fill="none" stroke="{bd}" stroke-width="1.1"/>'
    '<path d="M9 12 L15 12 M9 15 L15 15 M9 18 L13 18" stroke="{c}" stroke-width="1" '
    'stroke-linecap="round"/>'
)

# ---- Toolbar icons (line style, orange) ----

SVG_NEW = (
    '<path d="M12 4 L12 20 M4 12 L20 12" stroke="{c}" stroke-width="2" '
    'stroke-linecap="round"/>'
)
SVG_OPEN = (
    '<path d="M4 7 L9 7 L11 9 L20 9 L20 18 L4 18 Z" fill="none" stroke="{c}" '
    'stroke-width="1.8" stroke-linejoin="round"/>'
)
SVG_SAVE = (
    '<path d="M5 4 L17 4 L19 6 L19 20 L5 20 Z" fill="none" stroke="{c}" stroke-width="1.8" '
    'stroke-linejoin="round"/>'
    '<path d="M8 4 L8 9 L15 9 L15 4" fill="none" stroke="{c}" stroke-width="1.8"/>'
    '<rect x="8" y="13" width="8" height="6" fill="{c}" opacity="0.25" stroke="{c}" '
    'stroke-width="1.2"/>'
)
SVG_IMPORT = (
    '<path d="M12 4 L12 15 M8 11 L12 15 L16 11" stroke="{c}" stroke-width="1.9" '
    'stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
    '<path d="M5 18 L19 18" stroke="{c}" stroke-width="1.9" stroke-linecap="round"/>'
)
SVG_EXPORT = (
    '<path d="M12 15 L12 4 M8 8 L12 4 L16 8" stroke="{c}" stroke-width="1.9" '
    'stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
    '<path d="M5 18 L19 18" stroke="{c}" stroke-width="1.9" stroke-linecap="round"/>'
)
SVG_PRINT = (
    '<rect x="7" y="5" width="10" height="5" rx="1" fill="none" stroke="{c}" stroke-width="1.7"/>'
    '<rect x="6" y="10" width="12" height="8" rx="1" fill="none" stroke="{c}" stroke-width="1.7"/>'
    '<path d="M9 14 L15 14 M9 16 L13 16" stroke="{c}" stroke-width="1.4" stroke-linecap="round"/>'
)
SVG_UNDO = (
    '<path d="M9 8 L5 12 L9 16" fill="none" stroke="{c}" stroke-width="1.9" '
    'stroke-linecap="round" stroke-linejoin="round"/>'
    '<path d="M5 12 L15 12 C18 12 19 14 19 16 C19 18 18 20 15 20 L11 20" '
    'fill="none" stroke="{c}" stroke-width="1.9" stroke-linecap="round"/>'
)
SVG_REDO = (
    '<path d="M15 8 L19 12 L15 16" fill="none" stroke="{c}" stroke-width="1.9" '
    'stroke-linecap="round" stroke-linejoin="round"/>'
    '<path d="M19 12 L9 12 C6 12 5 14 5 16 C5 18 6 20 9 20 L13 20" '
    'fill="none" stroke="{c}" stroke-width="1.9" stroke-linecap="round"/>'
)
SVG_SETTINGS = (
    '<circle cx="12" cy="12" r="3" fill="none" stroke="{c}" stroke-width="1.7"/>'
    '<path d="M12 3 L12 6 M12 18 L12 21 M3 12 L6 12 M18 12 L21 12 '
    'M5.6 5.6 L7.7 7.7 M16.3 16.3 L18.4 18.4 M5.6 18.4 L7.7 16.3 '
    'M16.3 7.7 L18.4 5.6" stroke="{c}" stroke-width="1.7" stroke-linecap="round"/>'
)
SVG_HISTORY = (
    '<path d="M4 12 a8 8 0 1 0 2.3-5.6" fill="none" stroke="{c}" stroke-width="1.8" '
    'stroke-linecap="round"/>'
    '<path d="M4 4 L4 8 L8 8" fill="none" stroke="{c}" stroke-width="1.8" '
    'stroke-linecap="round" stroke-linejoin="round"/>'
    '<path d="M12 8 L12 12 L15 14" fill="none" stroke="{c}" stroke-width="1.7" '
    'stroke-linecap="round"/>'
)

# ---- Brand logo (hexagon + waveform) ----
SVG_LOGO = (
    # --- OUTER HEXAGON (pointy-top, orange outline + faint fill) ---
    '<polygon points="12,1.8 21.3,7.2 21.3,18 12,23.4 2.7,18 2.7,7.2" '
    'fill="{c}" fill-opacity="0.10" stroke="{c}" stroke-width="1.5" '
    'stroke-linejoin="round"/>'
    # --- INNER HEXAGON (smaller, semi-transparent orange fill + outline) ---
    '<polygon points="12,4.2 18.2,7.8 18.2,15.4 12,19 5.8,15.4 5.8,7.8" '
    'fill="{c}" fill-opacity="0.22" stroke="{c}" stroke-width="1.0" '
    'stroke-linejoin="round"/>'
    # --- BLACK SUBSURFACE STRATA (bottom bands, inside inner hex) ---
    '<path d="M5 17 C8 15.5 10 16.2 12 16 C14 15.8 16 16.5 19 16.2 '
    'L19 20 L5 20 Z" fill="{cd}"/>'
    '<path d="M5.4 15.5 C8.2 14.2 10.2 14.9 12 14.7 C14 14.5 15.8 15.2 18.6 14.9 '
    'L18.6 17 C16 16.4 14 16.8 12 16 C10 15.8 8 16.5 5.4 17 Z" '
    'fill="{cd}" opacity="0.65"/>'
    '<path d="M6 14.8 C8.5 13.7 10.3 14.4 12 14.2 C14 14 15.5 14.7 18 14.4 '
    'L18 15.5 C15.5 15 14 15.3 12 14.7 C10.2 14.5 8.5 15.2 6 15.5 Z" '
    'fill="#ffffff" opacity="0.75"/>'
    # --- ORANGE HEARTBEAT / SEISMIC PULSE (center) ---
    '<path d="M6.8 11.6 L9.2 11.6 L9.9 9.6 L10.8 14 L11.5 8.8 L12.2 13.2 '
    'L12.8 11.6 L17.2 11.6" stroke="{c}" stroke-width="1.2" fill="none" '
    'stroke-linecap="round" stroke-linejoin="miter"/>'
)


def _render_svg(svg_body: str, color: str, dark: str = "#3a4150",
                bg: str = "#eef1f5", bd: str = "#c4cbd6",
                size: int = 24, scale: float = 2.0) -> QIcon:
    """Render an SVG body to a QIcon at the given scale (for 4K sharpness)."""
    full = _SVG_WRAP.format(
        w=size, h=size,
        body=svg_body.format(c=color, cd=dark, bg=bg, bd=bd),
    )
    renderer = QSvgRenderer(QByteArray(full.encode("utf-8")))
    if not renderer.isValid():
        # fallback empty
        pix = QPixmap(size, size)
        pix.fill(Qt.GlobalColor.transparent)
        return QIcon(pix)
    pix = QPixmap(int(size * scale), int(size * scale))
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    renderer.render(p, QRectF(0, 0, pix.width(), pix.height()))
    p.end()
    return QIcon(pix)


# ---------------------------------------------------------------------------
# Palette constants (rich, saturated for 4K screens)
# ---------------------------------------------------------------------------
ORANGE = "#FF6600"
ORANGE_HI = "#FF8533"
ORANGE_DK = "#E65C00"
GOLD = "#D97706"
GREEN = "#16A34A"
RED = "#DC2626"
BLUE = "#2563EB"
CYAN = "#0891B2"
VIOLET = "#7C3AED"
GREY = "#5B6470"

FILE_BG = "#eef1f5"
FILE_BD = "#c4cbd6"


# ---------------------------------------------------------------------------
# Icon factory — cached at module level
# ---------------------------------------------------------------------------
class _IconCache:
    def __init__(self):
        self._cache: dict[str, QIcon] = {}

    def get(self, key: str, factory) -> QIcon:
        if key not in self._cache:
            self._cache[key] = factory()
        return self._cache[key]


_cache = _IconCache()


def folder_icon(color: str = ORANGE, size: int = 22, scale: float = 2.0) -> QIcon:
    return _cache.get(f"folder_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_FOLDER, color, size=size, scale=scale))


def seismic_icon(color: str = BLUE, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"seis_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_SEISMIC, color, size=size, scale=scale))


def well_icon(color: str = ORANGE, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"well_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_WELL, color, size=size, scale=scale))


def horizon_icon(color: str = GREEN, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"hor_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_HORIZON, color, size=size, scale=scale))


def fault_icon(color: str = RED, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"flt_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_FAULT, color, size=size, scale=scale))


def ai_icon(color: str = BLUE, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"ai_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_AI, color, size=size, scale=scale))


def model_icon(color: str = GREEN, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"mdl_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_MODEL, color, size=size, scale=scale))


def reservoir_icon(color: str = GOLD, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"res_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_RESERVOIR, color, size=size, scale=scale))


def file_icon(color: str = GREY, size: int = 20, scale: float = 2.0) -> QIcon:
    return _cache.get(f"file_{color}_{size}_{scale}",
                      lambda: _render_svg(SVG_FILE, color, size=size, scale=scale))


def toolbar_icon(svg: str, color: str = ORANGE, size: int = 22, scale: float = 2.0) -> QIcon:
    key = f"tb_{id(svg)}_{color}_{size}_{scale}"
    return _cache.get(key, lambda: _render_svg(svg, color, size=size, scale=scale))


def _load_logo_png(size: int, scale: float) -> QIcon:
    """Load the official petroppo logo (hexagon icon) from the 4K PNG asset
    that was upscaled from the original company logo image. This guarantees
    the desktop app shows the EXACT same logo as the website — pixel-perfect
    brand consistency across every surface."""
    import os
    # Search candidate locations (works in dev + after PyInstaller packaging)
    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "data", "assets", "logo-icon_4k.png"),
        os.path.join(os.path.dirname(__file__), "..", "data", "assets", "logo-icon.png"),
        os.path.join(os.path.dirname(__file__), "..", "..", "website", "assets", "logo-icon_4k.png"),
        os.path.join(os.path.dirname(__file__), "..", "..", "website", "assets", "logo-icon.png"),
    ]
    for c in candidates:
        c = os.path.normpath(c)
        if os.path.isfile(c):
            pix = QPixmap(c)
            if not pix.isNull():
                target = int(size * scale)
                pix = pix.scaled(target, target, Qt.AspectRatioMode.KeepAspectRatio,
                                 Qt.TransformationMode.SmoothTransformation)
                return QIcon(pix)
    # Fallback to SVG rendering if PNG not found
    return _render_svg(SVG_LOGO, ORANGE, size=size, scale=scale)


def logo_icon(size: int = 32, scale: float = 2.0, color: str = ORANGE) -> QIcon:
    key = f"logo_{size}_{scale}_{color}"
    if key not in _cache._cache:
        _cache._cache[key] = _load_logo_png(size, scale)
    return _cache._cache[key]


# Convenience: pick a file icon by extension
def icon_for_name(name: str, size: int = 20, scale: float = 2.0) -> QIcon:
    low = name.lower()
    if low.endswith((".sgy", ".segy", ".ogy")):
        return seismic_icon(BLUE if low.endswith(".sgy") else GOLD, size, scale)
    if low.endswith(".las"):
        return well_icon(ORANGE, size, scale)
    if low.endswith((".dev", ".deviation")):
        return file_icon(GOLD, size, scale)
    if any(k in low for k in ("top ", "base ", "seal", "horizon")):
        return horizon_icon(GREEN, size, scale)
    if "fault" in low:
        return fault_icon(RED, size, scale)
    if low.startswith("ai") or "facies" in low and "map" in low:
        return ai_icon(BLUE, size, scale)
    if any(k in low for k in ("grid", "model", "facies model", "property")):
        return model_icon(GREEN, size, scale)
    if any(k in low for k in ("pvt", "scal", "simulation", "history")):
        return reservoir_icon(GOLD, size, scale)
    return file_icon(GREY, size, scale)
