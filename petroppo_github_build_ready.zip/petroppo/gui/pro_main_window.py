"""petroppo Pro — Main Window (COMSOL/Petrel-style professional desktop).

Layout (matching reference screenshots):
    +---------------------------------------------------------------+
    | Menu Bar: File Seismic Inversion Reservoir Modeling Platform  |
    |           View Help                       [user] [_][□][×]    |
    +---------------------------------------------------------------+
    | Toolbar: New Open Save | Import Export Print | Undo Redo |    |
    |          Settings History                                     |
    +---------+--------------------------------------+-------------+
    | Project |                                      | Properties  |
    | Explorer|        3D Seismic Volume View        |   Panel     |
    |         |                                      |             |
    +---------+--------------------------------------+-------------+
    | Status: IL:258  XL:288  TWT:3388 ms  objects  UTM 31N  23%   |
    +---------------------------------------------------------------+
"""
from __future__ import annotations

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QAction, QFont, QIcon
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QToolBar, QStatusBar, QLabel, QDockWidget, QSizePolicy,
    QPushButton, QToolButton, QMessageBox,
)

from .pro_style import PRO_QSS, ORANGE, BG_DARKEST, BG_DARK, TEXT, TEXT_MUTED, BG_VIEWPORT
from .pro_icons import (
    toolbar_icon, logo_icon,
    SVG_NEW, SVG_OPEN, SVG_SAVE, SVG_IMPORT, SVG_EXPORT,
    SVG_PRINT, SVG_UNDO, SVG_REDO, SVG_SETTINGS, SVG_HISTORY,
)
from .project_explorer import ProjectExplorer
from .seismic3d_view import Seismic3DView
from .properties_panel import PropertiesPanel
from ..platform.owner_accounts import AccountStore, ROLE_OWNER

import os
import sys

# path to licensing (added later)
_HERE = os.path.dirname(os.path.abspath(__file__))


class ProMainWindow(QMainWindow):
    """The commercial-grade petroppo desktop shell."""

    def __init__(self, username: str = "demo", license_type: str = "Trial",
                 store: AccountStore | None = None):
        super().__init__()
        self.username = username
        self.license_type = license_type
        self.store = store  # AccountStore (may be None for legacy/demo)

        self.setWindowTitle("petroppo — Subsurface Intelligence Platform")
        self.resize(1600, 980)
        self.setMinimumSize(1280, 760)
        self.setStyleSheet(PRO_QSS)
        self.setDockNestingEnabled(True)
        # Official petroppo logo as the window/taskbar icon (brand consistency)
        self.setWindowIcon(logo_icon(64, 2.0))

        self._build_menu_bar()
        self._build_toolbar()
        self._build_central()
        self._build_status_bar()

        self.log("petroppo initialized — subsurface geophysics platform ready")
        self.log(f"User: {username}  |  License: {license_type}  |  Mode: Desktop")

    # ----------------------------------------------------------- menu bar
    def _build_menu_bar(self):
        mb = self.menuBar()

        file_menu = mb.addMenu("File")
        for name, slot in [
            ("New Project…", self._noop),
            ("Open Project…", self._noop),
            ("Open Recent", None),
            ("Save", self._noop),
            ("Save As…", self._noop),
            ("Import…", self._noop),
            ("Export…", self._noop),
            ("Print…", self._noop),
            ("Exit", self.close),
        ]:
            if slot is None:
                file_menu.addSeparator()
                sub = file_menu.addMenu("Open Recent")
                for p in ("North Sea Project V25", "Carbonate Platform", "Turbidite Field"):
                    sub.addAction(p, self._noop)
                file_menu.addSeparator()
                continue
            a = QAction(name, self)
            a.triggered.connect(slot)
            file_menu.addAction(a)

        for name in ["Seismic", "Inversion", "Reservoir", "Modeling", "Platform", "View", "Help"]:
            menu = mb.addMenu(name)
            if name == "Seismic":
                for it in ["Load SEG-Y…", "Preprocessing…", "Attributes…",
                           "AI Horizon Tracking…", "AI Fault Detection…",
                           "Facies Classification…", "AVO/AVA Analysis…"]:
                    menu.addAction(it, self._noop)
            elif name == "Inversion":
                for it in ["Acoustic Inversion…", "Elastic Inversion…",
                           "Joint Inversion…", "Bayesian Inversion…",
                           "AVO Inversion…", "Rock Physics Modeling…"]:
                    menu.addAction(it, self._noop)
            elif name == "Reservoir":
                for it in ["PVT Modeling…", "SCAL…", "Simulation Run…",
                           "History Matching (AI)…", "Forecast…",
                           "EOR Scenarios…", "Uncertainty P10/P50/P90…"]:
                    menu.addAction(it, self._noop)
            elif name == "Modeling":
                for it in ["Structural Framework…", "Fault Modeling…",
                           "Horizon Modeling…", "Grid Generation…",
                           "Facies Modeling…", "Property Modeling…",
                           "Upscaling…"]:
                    menu.addAction(it, self._noop)
            elif name == "Platform":
                for it, slot in [("Licensing…", self._noop),
                                 ("Check for Updates…", self._noop),
                                 ("Settings…", self._noop),
                                 ("HPC Configuration…", self._noop),
                                 ("Cloud Deployment…", self._noop),
                                 ("Owner Dashboard…", self._open_owner_dashboard),
                                 ("Logout", self._logout)]:
                    a = QAction(it, self)
                    a.triggered.connect(slot)
                    menu.addAction(a)
            elif name == "View":
                for it in ["Project Explorer", "Properties Panel",
                           "3D View", "Log Console", "Status Bar"]:
                    menu.addAction(it, self._noop)
            elif name == "Help":
                for it in ["User Manual…", "Tutorials…", "API Documentation…",
                           "Scientific Methodology…", "Benchmark Report…",
                           "About petroppo…"]:
                    menu.addAction(it, self._noop)

        # spacer + user badge on the right
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        mb.setCornerWidget(spacer)
        # user label
        self.user_label = QLabel(f"  👤  {self.username}  ·  {self.license_type}  ")
        self.user_label.setStyleSheet(
            f"color:{ORANGE}; font-weight:bold; padding:0 10px;"
        )
        mb.setCornerWidget(self.user_label, Qt.Corner.TopRightCorner)

    # ----------------------------------------------------------- toolbar
    def _build_toolbar(self):
        tb = QToolBar("Main")
        tb.setMovable(False)
        tb.setIconSize(QSize(22, 22))
        self.addToolBar(tb)

        def add_btn(svg, tip, slot=None):
            b = QToolButton()
            b.setIcon(toolbar_icon(svg, ORANGE, 22, 2.0))
            b.setToolTip(tip)
            b.setAutoRaise(True)
            if slot:
                b.clicked.connect(slot)
            tb.addWidget(b)
            return b

        add_btn(SVG_NEW, "New Project", self._noop)
        add_btn(SVG_OPEN, "Open Project", self._noop)
        add_btn(SVG_SAVE, "Save", self._noop)
        tb.addSeparator()
        add_btn(SVG_IMPORT, "Import", self._noop)
        add_btn(SVG_EXPORT, "Export", self._noop)
        add_btn(SVG_PRINT, "Print", self._noop)
        tb.addSeparator()
        add_btn(SVG_UNDO, "Undo", self._noop)
        add_btn(SVG_REDO, "Redo", self._noop)
        tb.addSeparator()
        add_btn(SVG_SETTINGS, "Settings", self._noop)
        add_btn(SVG_HISTORY, "History", self._noop)

        tb.addSeparator()
        # logo on the far right of toolbar
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        logo = QLabel()
        logo.setPixmap(logo_icon(28, 2.0).pixmap(QSize(28, 28)))
        logo.setStyleSheet("padding: 0 8px;")
        tb.addWidget(logo)
        name = QLabel("petroppo")
        name.setStyleSheet(
            f"color:{ORANGE}; font-weight:bold; font-size:15px; padding-right:8px;"
        )
        tb.addWidget(name)

    # ----------------------------------------------------------- central
    def _build_central(self):
        # left: project explorer
        self.explorer = ProjectExplorer()
        dock_left = QDockWidget("Project Explorer", self)
        dock_left.setWidget(self.explorer)
        dock_left.setFeatures(QDockWidget.DockWidgetFeature.NoDockWidgetFeatures)
        dock_left.setMinimumWidth(260)
        dock_left.setMaximumWidth(340)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock_left)

        # right: properties panel
        self.props = PropertiesPanel()

        # center: 3D seismic view
        self.view3d = Seismic3DView()
        self.props.connect_to(self.view3d)

        # splitter for center + right
        center_right = QSplitter(Qt.Orientation.Horizontal)
        center_right.addWidget(self.view3d)
        center_right.addWidget(self.props)
        center_right.setStretchFactor(0, 4)
        center_right.setStretchFactor(1, 1)
        center_right.setSizes([1100, 300])

        # main splitter left + (center+right)
        main = QSplitter(Qt.Orientation.Horizontal)
        main.addWidget(dock_left)
        main.addWidget(center_right)
        main.setStretchFactor(0, 0)
        main.setStretchFactor(1, 1)
        main.setSizes([280, 1320])

        self.setCentralWidget(main)

    # ----------------------------------------------------------- status bar
    def _build_status_bar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)

        self.il_label = QLabel("IL: 258")
        self.xl_label = QLabel("XL: 288")
        self.twt_label = QLabel("TWT: 3388 ms")
        self.obj_label = QLabel("1,247 objects")
        self.utm_label = QLabel("UTM 31N")
        self.zoom_label = QLabel("23%")
        self.ready_label = QLabel("Ready")

        for lbl in (self.il_label, self.xl_label, self.twt_label,
                    self.obj_label, self.utm_label, self.zoom_label):
            lbl.setStyleSheet(f"color:{TEXT_MUTED}; padding:0 6px;")
            sb.addWidget(lbl)
        sb.addPermanentWidget(self.ready_label)

        # wire view signals to status bar
        self.view3d.sliceChanged.connect(self._on_slice_changed)

    def _on_slice_changed(self, il, xl, ts):
        self.il_label.setText(f"IL: {il}")
        self.xl_label.setText(f"XL: {xl}")
        self.twt_label.setText(f"TWT: {ts*10+1000} ms")
        self.obj_label.setText(f"{self.view3d._object_count:,} objects")

    # ----------------------------------------------------------- helpers
    def log(self, msg: str):
        # status bar transient
        self.ready_label.setText(msg[:60])

    def _noop(self):
        pass

    def _open_owner_dashboard(self):
        """Open the owner dashboard (owners only)."""
        if self.store is None:
            QMessageBox.warning(self, "Owner Dashboard",
                                "Account store not available in this build.")
            return
        acc = self.store.get_account(self.username)
        if not acc or acc.get("role") != ROLE_OWNER:
            QMessageBox.warning(self, "Access Denied",
                                "Only owners can open the dashboard.")
            return
        from .owner_dashboard import OwnerDashboard
        self._dash = OwnerDashboard(self.store, self.username)
        self._dash.show()

    def _logout(self):
        """Close the app back to the login gate."""
        if self.store is not None:
            self.store.log(self.username, "logout", "")
        self.close()


def run_app(username: str = "demo", license_type: str = "Trial",
                 skip_login: bool = False) -> int:
    """Entry point used by the packaged launcher.

    If skip_login is False (default for the real product), shows the
    login gate first.  Owners get full access + dashboard.  Customers
    get pro features during the 30-day trial, then a lock screen.
    """
    from PySide6.QtWidgets import QApplication
    import sys
    import os
    # High-DPI handling
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setStyleSheet(PRO_QSS)

    store = None
    final_user = username
    final_role = license_type

    if not skip_login:
        from ..platform.owner_accounts import AccountStore, bootstrap_owners, DB_PATH
        import sys
        if getattr(sys, "frozen", False):
            data_dir = os.path.dirname(DB_PATH)
            db = DB_PATH
        else:
            data_dir = os.path.join(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))), "data")
            db = os.path.join(data_dir, "petroppo_accounts.db")
        os.makedirs(data_dir, exist_ok=True)
        store = AccountStore(db)
        creds_file = os.path.join(data_dir, "owner_credentials.txt")
        bootstrap_owners(store, creds_file)

        from .auth_gate import run_login_gate
        user, role, ok = run_login_gate(store)
        if not ok or not user:
            # login cancelled or trial locked without payment
            store.close()
            return 0
        final_user = user
        final_role = "Owner" if role == ROLE_OWNER else (
            "Professional" if (store.get_account(user) or {}).get("paid_until") else "Trial")

    w = ProMainWindow(username=final_user, license_type=final_role, store=store)
    w.showMaximized()
    ret = app.exec()
    if store is not None:
        store.close()
    return ret


if __name__ == "__main__":
    sys.exit(run_app())
