"""petroppo Pro — professional desktop LIGHT theme (white).

Color palette: clean WHITE/ light-gray UI panels with orange (#FF6600)
accents, matching the client reference website (white background).
The 3D viewport stays dark (near-black) like COMSOL so the colored
seismic data pops against it.
"""
from __future__ import annotations

# --- Brand colors ---
ORANGE = "#FF6600"
ORANGE_HOVER = "#FF8533"
ORANGE_DARK = "#E65C00"

# --- LIGHT UI palette (white theme) ---
BG_DARKEST = "#ffffff"        # main window / menu bar background (white)
BG_DARK = "#ffffff"           # side panels (white)
BG_PANEL = "#ffffff"          # inner panels / group boxes (white)
BG_CARD = "#f4f6f9"           # cards / hover (very light gray)
BG_INPUT = "#ffffff"          # input fields (white)
BG_WHITE = "#ffffff"
BG_VIEWPORT = "#ffffff"       # 3D viewport background (white — light theme)

BORDER = "#e4e8ee"            # light borders (clearly visible on white)
BORDER_LIGHT = "#c8cfdb"
BORDER_FOCUS = ORANGE

TEXT = "#1b1d22"              # main text — dark on white
TEXT_MUTED = "#5b6470"        # muted dark gray
TEXT_DIM = "#8b94a3"
TEXT_INVERSE = "#ffffff"      # text on orange/dark backgrounds

# --- Accent helpers ---
GREEN = "#16a34a"
RED = "#dc2626"
YELLOW = "#eab308"
BLUE = "#2563eb"

# --- QSS stylesheet (applied to the whole app) ---
PRO_QSS = f"""
QWidget {{
    background-color: {BG_DARKEST};
    color: {TEXT};
    font-family: 'Segoe UI', 'DejaVu Sans', Arial, sans-serif;
    font-size: 13px;
}}

/* ---- Menu bar ---- */
QMenuBar {{
    background-color: {BG_DARKEST};
    color: {TEXT};
    padding: 2px 4px;
    border-bottom: 1px solid {BORDER};
    font-size: 13px;
}}
QMenuBar::item {{
    background: transparent;
    padding: 6px 12px;
    border-radius: 3px;
    color: {TEXT_MUTED};
}}
QMenuBar::item:selected {{
    background-color: {BG_DARK};
    color: {ORANGE};
}}
QMenuBar::item:pressed {{
    background-color: {ORANGE};
    color: white;
}}
QMenu {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
    padding: 4px;
    color: {TEXT};
}}
QMenu::item {{
    padding: 6px 24px 6px 18px;
    border-radius: 3px;
    color: {TEXT};
}}
QMenu::item:selected {{
    background-color: {BG_DARK};
    color: {ORANGE};
}}
QMenu::separator {{
    height: 1px;
    background: {BORDER};
    margin: 4px 8px;
}}

/* ---- Toolbars ---- */
QToolBar {{
    background-color: {BG_DARKEST};
    border: none;
    border-bottom: 1px solid {BORDER};
    spacing: 2px;
    padding: 3px 4px;
}}
QToolBar::separator {{
    width: 1px;
    background: {BORDER};
    margin: 4px 6px;
}}
QToolButton {{
    background: transparent;
    border: none;
    border-radius: 4px;
    padding: 6px 8px;
    color: {TEXT_MUTED};
}}
QToolButton:hover {{
    background-color: {BG_DARK};
    color: {ORANGE};
}}
QToolButton:pressed, QToolButton:checked {{
    background-color: {ORANGE};
    color: white;
}}

/* ---- Dock widgets (side panels) ---- */
QDockWidget {{
    titlebar-close-icon: none;
    titlebar-normal-icon: none;
    color: {TEXT};
}}
QDockWidget::title {{
    background-color: {BG_DARK};
    padding: 6px 10px;
    border-bottom: 1px solid {BORDER};
    color: {ORANGE};
    font-weight: bold;
    font-size: 12px;
    letter-spacing: 0.5px;
}}

/* ---- Tree (Project Explorer) ---- */
QTreeWidget, QTreeView {{
    background-color: {BG_DARK};
    alternate-background-color: {BG_PANEL};
    border: none;
    outline: 0;
    padding: 2px;
    color: {TEXT};
}}
QTreeWidget::item, QTreeView::item {{
    padding: 5px 4px;
    border: none;
    color: {TEXT};
}}
QTreeWidget::item:selected, QTreeView::item:selected {{
    background-color: {BORDER};
    color: {ORANGE_DARK};
}}
QTreeWidget::item:hover, QTreeView::item:hover {{
    background-color: {BG_CARD};
}}
QTreeView::branch {{
    background: transparent;
}}
QHeaderView::section {{
    background-color: {BG_DARK};
    color: {TEXT_MUTED};
    padding: 5px 8px;
    border: none;
    border-bottom: 1px solid {BORDER};
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}

/* ---- Group boxes (Properties sections) ---- */
QGroupBox {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
    border-radius: 6px;
    margin-top: 14px;
    padding: 14px 10px 10px 10px;
    font-size: 11px;
    font-weight: bold;
    color: {ORANGE};
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 6px;
    background-color: {BG_PANEL};
    color: {ORANGE};
}}
QGroupBox::indicator {{
    width: 0; height: 0;
}}

/* ---- Labels ---- */
QLabel {{
    background: transparent;
    color: {TEXT};
}}
QLabel[role="section"] {{
    color: {ORANGE};
    font-weight: bold;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 2px 0;
}}
QLabel[role="muted"] {{
    color: {TEXT_MUTED};
    font-size: 12px;
}}
QLabel[role="title"] {{
    color: {TEXT};
    font-size: 20px;
    font-weight: bold;
}}
QLabel[role="subtitle"] {{
    color: {TEXT_MUTED};
    font-size: 13px;
}}
QLabel[role="value"] {{
    color: {ORANGE};
    font-size: 22px;
    font-weight: bold;
}}

/* ---- Inputs ---- */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background-color: {BG_INPUT};
    border: 1px solid {BORDER_LIGHT};
    border-radius: 4px;
    padding: 5px 8px;
    color: {TEXT};
    selection-background-color: {ORANGE};
    selection-color: white;
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1px solid {ORANGE};
}}
QSpinBox::up-button, QDoubleSpinBox::up-button,
QSpinBox::down-button, QDoubleSpinBox::down-button {{
    background-color: {BG_DARK};
    border: none;
    width: 18px;
}}
QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover,
QSpinBox::down-button:hover, QDoubleSpinBox::down-button:hover {{
    background-color: {ORANGE};
}}
QComboBox::drop-down {{
    border: none;
    width: 22px;
}}
QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {TEXT_MUTED};
    margin-right: 6px;
}}
QComboBox QAbstractItemView {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER_LIGHT};
    selection-background-color: {BG_DARK};
    selection-color: {ORANGE};
    outline: 0;
    padding: 4px;
    color: {TEXT};
}}

/* ---- Sliders ---- */
QSlider::groove:horizontal {{
    height: 4px;
    background: {BORDER_LIGHT};
    border-radius: 2px;
}}
QSlider::handle:horizontal {{
    background: {ORANGE};
    width: 14px;
    height: 14px;
    margin: -6px 0;
    border-radius: 7px;
}}
QSlider::handle:horizontal:hover {{
    background: {ORANGE_HOVER};
}}
QSlider::sub-page:horizontal {{
    background: {ORANGE_DARK};
    border-radius: 2px;
}}

/* ---- Checkboxes ---- */
QCheckBox {{
    spacing: 8px;
    color: {TEXT};
    padding: 3px 0;
}}
QCheckBox::indicator {{
    width: 16px;
    height: 16px;
    border-radius: 3px;
    border: 1px solid {BORDER_LIGHT};
    background-color: {BG_INPUT};
}}
QCheckBox::indicator:hover {{
    border: 1px solid {ORANGE};
}}
QCheckBox::indicator:checked {{
    background-color: {ORANGE};
    border: 1px solid {ORANGE};
    image: none;
}}

/* ---- Buttons ---- */
QPushButton {{
    background-color: {BG_INPUT};
    border: 1px solid {BORDER_LIGHT};
    border-radius: 4px;
    padding: 6px 14px;
    color: {TEXT};
}}
QPushButton:hover {{
    background-color: {BG_DARK};
    border: 1px solid {ORANGE};
    color: {ORANGE};
}}
QPushButton:pressed {{
    background-color: {ORANGE_DARK};
    color: white;
}}
QPushButton[role="primary"] {{
    background-color: {ORANGE};
    border: 1px solid {ORANGE};
    color: white;
    font-weight: bold;
}}
QPushButton[role="primary"]:hover {{
    background-color: {ORANGE_HOVER};
    border: 1px solid {ORANGE_HOVER};
    color: white;
}}

/* ---- Status bar ---- */
QStatusBar {{
    background-color: {BG_DARK};
    color: {TEXT_MUTED};
    border-top: 1px solid {BORDER};
    font-size: 12px;
    padding: 2px 8px;
}}
QStatusBar::item {{ border: none; }}
QStatusBar QLabel {{ color: {TEXT_MUTED}; padding: 0 10px 0 0; }}

/* ---- Scroll bars ---- */
QScrollBar:vertical {{
    background: {BG_DARK};
    width: 10px;
    border: none;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {BORDER_LIGHT};
    min-height: 28px;
    border-radius: 5px;
    margin: 1px;
}}
QScrollBar::handle:vertical:hover {{
    background: {ORANGE};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{
    background: {BG_DARK};
    height: 10px;
    border: none;
    margin: 0;
}}
QScrollBar::handle:horizontal {{
    background: {BORDER_LIGHT};
    min-width: 28px;
    border-radius: 5px;
    margin: 1px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {ORANGE};
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

/* ---- Tab widget ---- */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    background: {BG_DARK};
}}
QTabBar::tab {{
    background: {BG_DARKEST};
    color: {TEXT_MUTED};
    padding: 7px 16px;
    border: none;
    border-right: 1px solid {BORDER};
}}
QTabBar::tab:selected {{
    background: {BG_DARK};
    color: {ORANGE};
    border-bottom: 2px solid {ORANGE};
}}

/* ---- Splitter handles ---- */
QSplitter::handle {{
    background: {BORDER};
}}
QSplitter::handle:hover {{
    background: {ORANGE};
}}
QSplitter::handle:horizontal {{ width: 2px; }}
QSplitter::handle:vertical {{ height: 2px; }}

/* ---- Table ---- */
QTableWidget {{
    background-color: {BG_DARK};
    gridline-color: {BORDER};
    border: none;
    color: {TEXT};
}}
QTableWidget::item {{
    padding: 4px;
    color: {TEXT};
}}
QTableWidget::item:selected {{
    background-color: {BORDER};
    color: {ORANGE_DARK};
}}
QHeaderView::section {{
    background-color: {BG_DARK};
    color: {TEXT_MUTED};
    padding: 5px;
    border: none;
    border-right: 1px solid {BORDER};
    border-bottom: 1px solid {BORDER};
}}

/* ---- Text edit / console ---- */
QPlainTextEdit, QTextEdit {{
    background-color: {BG_DARK};
    color: #1b4d7a;
    border: 1px solid {BORDER};
    border-radius: 4px;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
    padding: 4px;
}}
"""
