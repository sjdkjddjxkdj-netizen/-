"""petroppo Pro — Project Explorer tree (left panel).

Matches the reference screenshot hierarchy:
    North Sea Project V25
    ├── Seismic Volumes
    │   ├── NorthSea_30.sgy
    │   ├── Shallow_Gas.sgy
    │   └── Deep_Carbonates.sgy
    ├── Well Data
    │   ├── Well-A1.las
    │   ├── Well-B2.las
    │   ├── Well-C3.las
    │   └── Well-D4.las
    ├── Horizons
    │   ├── Top Reservoir
    │   ├── Base Reservoir
    │   └── Top Seal
    ├── Faults
    ├── Interpretation
    ├── Models
    ├── Reservoir
    └── Exports
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QTreeWidget, QTreeWidgetItem, QMenu, QAbstractItemView,
)

from .pro_icons import (
    folder_icon, icon_for_name, ORANGE,
)


class ProjectExplorer(QTreeWidget):
    """Hierarchical project tree on the left side of the window."""

    itemActivated2 = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderHidden(True)
        self.setRootIsDecorated(True)
        self.setUniformRowHeights(True)
        self.setAlternatingRowColors(False)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setAnimated(True)
        self.setExpandsOnDoubleClick(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)
        self._build_demo_tree()

    # ----------------------------------------------------------- tree build
    def _build_demo_tree(self):
        self.clear()

        # Root project
        root = QTreeWidgetItem(self, ["North Sea Project V25"])
        root.setIcon(0, folder_icon(ORANGE, 22, 2.0))
        f = root.font(0)
        f.setBold(True)
        f.setPointSize(11)
        root.setFont(0, f)
        root.setForeground(0, QColor(ORANGE))

        # Seismic Volumes
        seis = self._add_folder(root, "Seismic Volumes")
        for name in ["NorthSea_30.sgy", "Shallow_Gas.sgy", "Deep_Carbonates.sgy",
                     "NorthSea_30.ogy", "Shallow_Gas.ogy"]:
            self._add_file(seis, name)

        # Well Data
        wells = self._add_folder(root, "Well Data")
        for name in ["Well-A1.las", "Well-B2.las", "Well-C3.las", "Well-D4.las",
                     "Well-A1.dev", "deviation.txt", "checkshot.txt"]:
            self._add_file(wells, name)

        # Horizons
        hor = self._add_folder(root, "Horizons")
        for name in ["Top Reservoir", "Base Reservoir", "Top Seal"]:
            self._add_file(hor, name)

        # Faults
        faults = self._add_folder(root, "Faults")
        for name in ["Fault_1", "Fault_2", "Fault_3"]:
            self._add_file(faults, name)

        # Interpretation
        interp = self._add_folder(root, "Interpretation")
        for name in ["AI Horizons", "AI Faults", "Facies Map", "Confidence Map"]:
            self._add_file(interp, name)

        # Models
        models = self._add_folder(root, "Models")
        for name in ["Structural Grid", "Facies Model", "Property Model",
                     "Petrophysical Model"]:
            self._add_file(models, name)

        # Reservoir
        res = self._add_folder(root, "Reservoir")
        for name in ["PVT", "SCAL", "Simulation Case", "History Match",
                     "Forecast", "Uncertainty P10/P50/P90"]:
            self._add_file(res, name)

        # Exports
        exp = self._add_folder(root, "Exports")
        for name in ["Report.pdf", "Volume.vtr", "Grid.grdecl", "Well_tops.txt"]:
            self._add_file(exp, name)

        self.expandItem(root)
        for i in range(root.childCount()):
            self.expandItem(root.child(i))

    def _add_folder(self, parent, name: str) -> QTreeWidgetItem:
        it = QTreeWidgetItem(parent, [name])
        it.setIcon(0, folder_icon(ORANGE, 22, 2.0))
        f = it.font(0)
        f.setBold(True)
        it.setFont(0, f)
        return it

    def _add_file(self, parent, name: str) -> QTreeWidgetItem:
        it = QTreeWidgetItem(parent, [name])
        it.setIcon(0, icon_for_name(name, 20, 2.0))
        return it

    # ----------------------------------------------------------- context menu
    def _on_context_menu(self, pos):
        it = self.itemAt(pos)
        menu = QMenu(self)
        if it is None:
            menu.addAction("New Project…", self._noop)
            menu.addAction("Open Project…", self._noop)
        else:
            menu.addAction("Import…", self._noop)
            menu.addAction("Export…", self._noop)
            menu.addSeparator()
            menu.addAction("Rename", self._noop)
            menu.addAction("Delete", self._noop)
            menu.addSeparator()
            menu.addAction("Properties", lambda: self.itemActivated2.emit(it.text(0)))
        menu.exec(self.viewport().mapToGlobal(pos))

    def _noop(self):
        pass
