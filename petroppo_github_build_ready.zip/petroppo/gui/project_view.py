"""Project view — project management and settings."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QVBoxLayout, QWidget, QDoubleSpinBox,
)

from .widgets import make_title, make_panel


class ProjectView(QWidget):
    """Project management screen."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Project Settings", "Configure exploration project parameters"
        ))

        # Project info
        panel, body = make_panel("Project Information")
        root.addWidget(panel)

        form = QFormLayout()
        form.setSpacing(8)
        self.name_edit = QLineEdit("New Exploration Project")
        form.addRow("Project name:", self.name_edit)
        self.desc_edit = QLineEdit()
        self.desc_edit.setPlaceholderText("Project description...")
        form.addRow("Description:", self.desc_edit)

        self.lat_spin = QDoubleSpinBox()
        self.lat_spin.setRange(-90, 90)
        self.lat_spin.setDecimals(6)
        self.lat_spin.setValue(0.0)
        form.addRow("Origin latitude:", self.lat_spin)

        self.lon_spin = QDoubleSpinBox()
        self.lon_spin.setRange(-180, 180)
        self.lon_spin.setDecimals(6)
        self.lon_spin.setValue(0.0)
        form.addRow("Origin longitude:", self.lon_spin)
        body.addLayout(form)

        # Save button
        btn_row = QHBoxLayout()
        btn_save = QPushButton("💾  Save Project")
        btn_save.setDefault(True)
        btn_save.clicked.connect(self._save)
        btn_row.addWidget(btn_save)
        body.addLayout(btn_row)

        root.addStretch()

    def _save(self):
        name = self.name_edit.text()
        self.main._log(f"Project '{name}' saved", "SUCCESS")

    def refresh(self):
        """Sync the form with the currently loaded earth model.

        When the user loads a different scenario in the main window, the
        project name field is updated to reflect it so the Project view
        never shows stale information.
        """
        try:
            model = getattr(self.main, "current_model", None)
            if model is not None and hasattr(model, "name"):
                current = self.name_edit.text()
                # Only overwrite if the field still holds a default/previous
                # model name \u2014 avoid clobbering a user's custom project name.
                if not current or current.startswith("New Exploration") \
                        or current == getattr(self, "_last_model_name", ""):
                    self.name_edit.setText(model.name)
                    self._last_model_name = model.name
        except Exception:
            pass
