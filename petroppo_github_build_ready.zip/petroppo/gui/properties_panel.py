"""petroppo Pro — Properties Panel (right side).

Sections (matching reference screenshots):
  * Display   — Volume, Color Map, Opacity, Clip
  * Slicing   — Inline, Crossline, Time Slice (ms)
  * Layers    — checkboxes for visible layers
  * Analysis  — Attribute dropdown, Window (ms), Compute Attribute button
  * AI Copilot — NEW badge
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QGroupBox, QComboBox, QSlider,
    QLabel, QCheckBox, QPushButton, QSpinBox, QDoubleSpinBox, QFrame,
    QHBoxLayout, QSizePolicy, QScrollArea,
)

from .pro_style import ORANGE, TEXT_MUTED, TEXT, BORDER
from .pro_icons import ai_icon


class _Section(QGroupBox):
    """A titled section with a form layout inside."""

    def __init__(self, title: str, parent=None):
        super().__init__(title, parent)
        self.form = QFormLayout()
        self.form.setSpacing(8)
        self.form.setContentsMargins(10, 14, 10, 10)
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        inner = QWidget()
        inner.setLayout(self.form)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(inner)

    def addRow(self, label, widget):
        if isinstance(label, str):
            lbl = QLabel(label)
            lbl.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 12px;")
            self.form.addRow(lbl, widget)
        else:
            self.form.addRow(label, widget)


class PropertiesPanel(QWidget):
    """Right-side properties panel."""

    computeAttribute = Signal()
    aiCopilot = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(280)
        self.setMaximumWidth(360)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        host = QWidget()
        host.setLayout(self._build())
        scroll.setWidget(host)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(scroll)

    # ----------------------------------------------------------- build
    def _build(self) -> QVBoxLayout:
        root = QVBoxLayout()
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(12)

        # ===== Display =====
        disp = _Section("Display")

        self.volume_combo = QComboBox()
        self.volume_combo.addItems(["NorthSea_30.sgy", "Shallow_Gas.sgy",
                                    "Deep_Carbonates.sgy"])
        disp.addRow("Volume:", self.volume_combo)

        self.cmap_combo = QComboBox()
        self.cmap_combo.addItems([
            "Seismic: Blue-White-Red", "Rainbow", "Turbo",
            "Grayscale", "Inferno", "Viridis", "Jet", "Plasma",
        ])
        disp.addRow("Color Map:", self.cmap_combo)

        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(0, 100)
        self.opacity_slider.setValue(85)
        self.opacity_value = QLabel("85%")
        self.opacity_value.setMinimumWidth(34)
        self.opacity_value.setStyleSheet(f"color: {ORANGE}; font-weight: bold;")
        op_row = QHBoxLayout()
        op_row.setSpacing(6)
        op_row.addWidget(self.opacity_slider, 1)
        op_row.addWidget(self.opacity_value)
        op_w = QWidget()
        op_w.setLayout(op_row)
        disp.addRow("Opacity:", op_w)

        self.clip_spin = QDoubleSpinBox()
        self.clip_spin.setRange(0.1, 50.0)
        self.clip_spin.setSingleStep(0.5)
        self.clip_spin.setValue(3.0)
        self.clip_spin.setSuffix(" %")
        disp.addRow("Clip:", self.clip_spin)

        root.addWidget(disp)

        # ===== Slicing =====
        slicing = _Section("Slicing")

        self.inline_spin = QSpinBox()
        self.inline_spin.setRange(1, 500)
        self.inline_spin.setValue(258)
        slicing.addRow("Inline:", self.inline_spin)

        self.crossline_spin = QSpinBox()
        self.crossline_spin.setRange(1, 400)
        self.crossline_spin.setValue(288)
        slicing.addRow("Crossline:", self.crossline_spin)

        self.timeslice_spin = QSpinBox()
        self.timeslice_spin.setRange(100, 3000)
        self.timeslice_spin.setSingleStep(4)
        self.timeslice_spin.setValue(1388)
        self.timeslice_spin.setSuffix(" ms")
        slicing.addRow("Time Slice (ms):", self.timeslice_spin)

        root.addWidget(slicing)

        # ===== Layers =====
        layers = _Section("Layers")
        layers.form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.chk_volume = QCheckBox("Seismic Volume")
        self.chk_volume.setChecked(True)
        self.chk_horizon = QCheckBox("Top Reservoir Horizon")
        self.chk_horizon.setChecked(True)
        self.chk_faults = QCheckBox("Fault Polygons")
        self.chk_faults.setChecked(False)
        self.chk_wells = QCheckBox("Well Trajectories")
        self.chk_wells.setChecked(True)
        self.chk_coherence = QCheckBox("Coherence Cube")
        self.chk_coherence.setChecked(False)
        self.chk_ai = QCheckBox("AI Impedance")
        self.chk_ai.setChecked(False)

        for chk in (self.chk_volume, self.chk_horizon, self.chk_faults,
                    self.chk_wells, self.chk_coherence, self.chk_ai):
            layers.form.addRow(chk)

        root.addWidget(layers)

        # ===== Analysis =====
        analysis = _Section("Analysis")

        self.attr_combo = QComboBox()
        self.attr_combo.addItems([
            "RMS Amplitude", "Instantaneous Amplitude", "Instantaneous Phase",
            "Instantaneous Frequency", "Coherence", "Sweetness",
            "Spectral Decomposition", "GLCM Texture", "Chaos",
        ])
        analysis.addRow("Attribute:", self.attr_combo)

        self.window_spin = QSpinBox()
        self.window_spin.setRange(1, 500)
        self.window_spin.setValue(50)
        self.window_spin.setSuffix(" ms")
        analysis.addRow("Window (ms):", self.window_spin)

        self.compute_btn = QPushButton("▶  Compute Attribute")
        self.compute_btn.setProperty("role", "primary")
        self.compute_btn.clicked.connect(self.computeAttribute)
        analysis.addRow("", self.compute_btn)

        root.addWidget(analysis)

        # ===== AI Copilot =====
        ai_box = QGroupBox("AI Copilot")
        ai_box.setStyleSheet(
            f"QGroupBox{{ border:1px solid {ORANGE}; }}"
        )
        ai_lay = QVBoxLayout()
        ai_lay.setContentsMargins(10, 16, 10, 10)
        ai_lay.setSpacing(8)

        badge_row = QHBoxLayout()
        badge = QLabel("NEW")
        badge.setStyleSheet(
            f"background-color:{ORANGE}; color:white; padding:2px 8px; "
            f"border-radius:8px; font-size:10px; font-weight:bold;"
        )
        badge_row.addWidget(badge)
        badge_row.addStretch()
        ai_lay.addLayout(badge_row)

        ai_desc = QLabel("AI-assisted horizon tracking, fault detection,\n"
                         "and facies classification with confidence maps.")
        ai_desc.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 12px;")
        ai_desc.setWordWrap(True)
        ai_lay.addWidget(ai_desc)

        self.ai_btn = QPushButton("Launch AI Copilot")
        self.ai_btn.setProperty("role", "primary")
        self.ai_btn.clicked.connect(self.aiCopilot)
        ai_lay.addWidget(self.ai_btn)

        ai_box.setLayout(ai_lay)
        root.addWidget(ai_box)

        root.addStretch(1)
        return root

    # ----------------------------------------------------------- wiring
    def connect_to(self, view):
        """Wire panel controls to the 3D seismic view."""
        self.cmap_combo.currentTextChanged.connect(
            lambda t: view.set_cmap(self._cmap_name(t)))
        self.opacity_slider.valueChanged.connect(
            lambda v: (self.opacity_value.setText(f"{v}%"), view.set_opacity(v)))
        self.clip_spin.valueChanged.connect(view.set_clip)
        self.inline_spin.valueChanged.connect(view.set_inline)
        self.crossline_spin.valueChanged.connect(view.set_crossline)
        self.timeslice_spin.valueChanged.connect(view.set_timeslice)
        self.chk_volume.toggled.connect(view.toggle_volume)
        self.chk_horizon.toggled.connect(view.toggle_horizon)
        self.chk_faults.toggled.connect(view.toggle_faults)
        self.chk_wells.toggled.connect(view.toggle_wells)
        self.chk_coherence.toggled.connect(view.toggle_coherence)
        self.chk_ai.toggled.connect(view.toggle_ai)

    @staticmethod
    def _cmap_name(label: str) -> str:
        m = {
            "Seismic: Blue-White-Red": "seismic",
            "Rainbow": "rainbow",
            "Turbo": "turbo",
            "Grayscale": "gray",
            "Inferno": "inferno",
            "Viridis": "viridis",
            "Jet": "jet",
            "Plasma": "plasma",
        }
        for k, v in m.items():
            if k in label:
                return v
        return "seismic"
