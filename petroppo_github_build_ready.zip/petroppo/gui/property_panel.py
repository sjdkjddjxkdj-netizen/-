"""Property panel — COMSOL-style context-sensitive settings panel.

Displays properties of the currently selected model tree node, allowing
the user to edit layer parameters, body geometry, survey settings, etc.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFormLayout, QGroupBox, QLabel, QLineEdit, QDoubleSpinBox, QSpinBox,
    QPushButton, QVBoxLayout, QWidget, QScrollArea, QComboBox,
)

from ..core import EarthModel, Layer, ResistivityBody, get_logger

_log = get_logger("gui.properties")


class PropertyPanel(QWidget):
    """Context-sensitive property panel."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_model: EarthModel | None = None
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        self.title = QLabel("Properties")
        self.title.setProperty("role", "section")
        layout.addWidget(self.title)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(10)
        self.scroll.setWidget(self.content)
        layout.addWidget(self.scroll, 1)

        self._show_empty()

    def _clear_content(self):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def _show_empty(self):
        self._clear_content()
        lbl = QLabel("Select an item from the model tree\nto view and edit its properties.")
        lbl.setProperty("role", "muted")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(lbl)
        self.content_layout.addStretch()

    def show_model_properties(self, model: EarthModel):
        """Show earth model global properties."""
        self._current_model = model
        self._clear_content()
        self.title.setText("Earth Model Properties")

        group = QGroupBox("General")
        form = QFormLayout(group)
        name_edit = QLineEdit(model.name)
        form.addRow("Name:", name_edit)

        bg_spin = QDoubleSpinBox()
        bg_spin.setRange(0.1, 100000)
        bg_spin.setValue(model.background_resistivity)
        bg_spin.setSuffix(" ohm.m")
        form.addRow("Background ρ:", bg_spin)

        depth_spin = QDoubleSpinBox()
        depth_spin.setRange(1, 500)
        depth_spin.setValue(model.max_depth)
        depth_spin.setSuffix(" m")
        form.addRow("Max depth:", depth_spin)

        self.content_layout.addWidget(group)

        info = QLabel(
            f"Layers: {len(model.layers)}\n"
            f"Bodies: {len(model.bodies)}\n"
            f"Extent X: {model.extent_x[0]} - {model.extent_x[1]} m"
        )
        info.setProperty("role", "muted")
        self.content_layout.addWidget(info)
        self.content_layout.addStretch()

    def show_layer_properties(self, model: EarthModel, layer_index: int):
        """Show properties of a specific layer."""
        self._current_model = model
        self._clear_content()
        if layer_index >= len(model.layers):
            self._show_empty()
            return
        layer = model.layers[layer_index]
        self.title.setText(f"Layer: {layer.name}")

        group = QGroupBox("Layer Properties")
        form = QFormLayout(group)

        name_edit = QLineEdit(layer.name)
        form.addRow("Name:", name_edit)

        rho_spin = QDoubleSpinBox()
        rho_spin.setRange(0.1, 100000)
        rho_spin.setValue(layer.resistivity)
        rho_spin.setSuffix(" ohm.m")
        form.addRow("Resistivity:", rho_spin)

        top_spin = QDoubleSpinBox()
        top_spin.setRange(0, 500)
        top_spin.setValue(layer.top_depth)
        top_spin.setSuffix(" m")
        form.addRow("Top depth:", top_spin)

        bot_spin = QDoubleSpinBox()
        bot_spin.setRange(0, 500)
        bot_spin.setValue(layer.bottom_depth)
        bot_spin.setSuffix(" m")
        form.addRow("Bottom depth:", bot_spin)

        density_spin = QDoubleSpinBox()
        density_spin.setRange(1000, 5000)
        density_spin.setValue(layer.density)
        density_spin.setSuffix(" kg/m³")
        form.addRow("Density:", density_spin)

        vp_spin = QDoubleSpinBox()
        vp_spin.setRange(100, 10000)
        vp_spin.setValue(layer.vp)
        vp_spin.setSuffix(" m/s")
        form.addRow("P-wave vel:", vp_spin)

        dielectric_spin = QDoubleSpinBox()
        dielectric_spin.setRange(1, 81)
        dielectric_spin.setValue(layer.dielectric)
        form.addRow("Dielectric:", dielectric_spin)

        self.content_layout.addWidget(group)
        self.content_layout.addStretch()

    def show_body_properties(self, model: EarthModel, body_index: int):
        """Show properties of a resistivity body."""
        self._current_model = model
        self._clear_content()
        if body_index >= len(model.bodies):
            self._show_empty()
            return
        body = model.bodies[body_index]
        self.title.setText(f"Body: {body.label}")

        group = QGroupBox("Body Geometry")
        form = QFormLayout(group)

        label_edit = QLineEdit(body.label)
        form.addRow("Label:", label_edit)

        cx_spin = QDoubleSpinBox()
        cx_spin.setRange(-1000, 1000)
        cx_spin.setValue(body.cx)
        form.addRow("Center X:", cx_spin)

        cz_spin = QDoubleSpinBox()
        cz_spin.setRange(0, 500)
        cz_spin.setValue(body.cz)
        form.addRow("Center Z:", cz_spin)

        rx_spin = QDoubleSpinBox()
        rx_spin.setRange(0.1, 500)
        rx_spin.setValue(body.rx)
        form.addRow("Radius X:", rx_spin)

        rz_spin = QDoubleSpinBox()
        rz_spin.setRange(0.1, 500)
        rz_spin.setValue(body.rz)
        form.addRow("Radius Z:", rz_spin)

        rho_spin = QDoubleSpinBox()
        rho_spin.setRange(0.1, 100000)
        rho_spin.setValue(body.resistivity)
        rho_spin.setSuffix(" ohm.m")
        form.addRow("Resistivity:", rho_spin)

        self.content_layout.addWidget(group)
        self.content_layout.addStretch()

    def show_survey_properties(self):
        """Show survey design properties."""
        self._clear_content()
        self.title.setText("Survey Properties")

        group = QGroupBox("Survey Design")
        form = QFormLayout(group)

        method_combo = QComboBox()
        method_combo.addItems(["ERT", "Spectral IP", "Magnetic", "Gravity", "GPR", "Seismic"])
        form.addRow("Method:", method_combo)

        config_combo = QComboBox()
        config_combo.addItems(["Wenner", "Dipole-Dipole", "Schlumberger", "Pole-Dipole", "Pole-Pole"])
        form.addRow("Configuration:", config_combo)

        n_spin = QSpinBox()
        n_spin.setRange(4, 128)
        n_spin.setValue(32)
        form.addRow("Electrodes:", n_spin)

        spacing_spin = QDoubleSpinBox()
        spacing_spin.setRange(0.5, 50)
        spacing_spin.setValue(5.0)
        spacing_spin.setSuffix(" m")
        form.addRow("Spacing:", spacing_spin)

        lines_spin = QSpinBox()
        lines_spin.setRange(1, 20)
        lines_spin.setValue(1)
        form.addRow("Lines:", lines_spin)

        noise_spin = QDoubleSpinBox()
        noise_spin.setRange(0, 0.5)
        noise_spin.setValue(0.02)
        noise_spin.setSingleStep(0.005)
        noise_spin.setSuffix(" (fraction)")
        form.addRow("Noise level:", noise_spin)

        self.content_layout.addWidget(group)

        run_btn = QPushButton("▶  Run Simulation")
        run_btn.setDefault(True)
        self.content_layout.addWidget(run_btn)
        self.content_layout.addStretch()
        return run_btn

    def show_inversion_properties(self):
        """Show inversion settings."""
        self._clear_content()
        self.title.setText("Inversion Settings")

        group = QGroupBox("Gauss-Newton Parameters")
        form = QFormLayout(group)

        iter_spin = QSpinBox()
        iter_spin.setRange(1, 50)
        iter_spin.setValue(10)
        form.addRow("Max iterations:", iter_spin)

        lam_spin = QDoubleSpinBox()
        lam_spin.setRange(0.1, 1000)
        lam_spin.setValue(10.0)
        form.addRow("Lambda (regularization):", lam_spin)

        decay_spin = QDoubleSpinBox()
        decay_spin.setRange(0.1, 1.0)
        decay_spin.setValue(0.8)
        decay_spin.setSingleStep(0.05)
        form.addRow("Lambda decay:", decay_spin)

        nx_spin = QSpinBox()
        nx_spin.setRange(5, 100)
        nx_spin.setValue(20)
        form.addRow("Grid cells X:", nx_spin)

        nz_spin = QSpinBox()
        nz_spin.setRange(5, 100)
        nz_spin.setValue(10)
        form.addRow("Grid cells Z:", nz_spin)

        self.content_layout.addWidget(group)

        run_btn = QPushButton("🔄  Run Inversion")
        run_btn.setDefault(True)
        self.content_layout.addWidget(run_btn)
        self.content_layout.addStretch()
        return run_btn
