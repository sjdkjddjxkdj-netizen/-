"""Prospectivity view — multi-physics HC prospectivity visualization.

Provides a GUI panel for:
  - Running multi-physics fusion from available inversion results
  - Displaying the prospectivity map
  - Adjusting fusion weights
  - Exporting the prospectivity map
"""
from __future__ import annotations

import numpy as np

from PySide6.QtWidgets import (
    QFormLayout, QGroupBox, QHBoxLayout, QLabel, QPushButton,
    QDoubleSpinBox, QVBoxLayout, QWidget, QMessageBox, QComboBox,
)

import matplotlib
matplotlib.use("QtAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from ..core import get_logger
from ..processing import fuse_prospectivity, hydrocarbon_prospectivity
from .style import MPL_FACE, MPL_TEXT, MPL_MUTED, MPL_ACCENT
from .widgets import make_title, make_panel

_log = get_logger("gui.prospectivity")


class ProspectivityView(QWidget):
    """Multi-physics hydrocarbon prospectivity panel."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Hydrocarbon Prospectivity",
            "Multi-physics fusion for oil & gas detection"
        ))

        # Info
        info = QLabel(
            "Combine ERT, gravity, magnetic, and IP data into a unified "
            "hydrocarbon prospectivity map using Noisy-OR Bayesian fusion. "
            "The map highlights areas with high probability of hydrocarbon "
            "accumulation based on multiple geophysical indicators."
        )
        info.setWordWrap(True)
        info.setStyleSheet("padding: 12px; background: #1f232b; border-radius: 8px; "
                           "border: 1px solid #2a2e38; color: #e4e7ed;")
        root.addWidget(info)

        # Controls panel
        ctrl_panel, ctrl_body = make_panel("Fusion Parameters")
        root.addWidget(ctrl_panel)

        form = QFormLayout()
        form.setSpacing(8)

        # Weight controls
        self.w_ert = QDoubleSpinBox()
        self.w_ert.setRange(0, 2)
        self.w_ert.setDecimals(2)
        self.w_ert.setSingleStep(0.1)
        self.w_ert.setValue(1.0)
        form.addRow("ERT weight:", self.w_ert)

        self.w_grav = QDoubleSpinBox()
        self.w_grav.setRange(0, 2)
        self.w_grav.setDecimals(2)
        self.w_grav.setSingleStep(0.1)
        self.w_grav.setValue(0.8)
        form.addRow("Gravity weight:", self.w_grav)

        self.w_mag = QDoubleSpinBox()
        self.w_mag.setRange(0, 2)
        self.w_mag.setDecimals(2)
        self.w_mag.setSingleStep(0.1)
        self.w_mag.setValue(0.6)
        form.addRow("Magnetic weight:", self.w_mag)

        self.w_ip = QDoubleSpinBox()
        self.w_ip.setRange(0, 2)
        self.w_ip.setDecimals(2)
        self.w_ip.setSingleStep(0.1)
        self.w_ip.setValue(0.7)
        form.addRow("Chargeability (IP) weight:", self.w_ip)

        ctrl_body.addLayout(form)

        # Run button
        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("⚡  Run Fusion")
        self.btn_run.clicked.connect(self._run_fusion)
        btn_row.addWidget(self.btn_run)

        self.btn_export = QPushButton("📊  Export Map (CSV)")
        self.btn_export.clicked.connect(self._export_map)
        btn_row.addWidget(self.btn_export)
        ctrl_body.addLayout(btn_row)

        # Canvas
        canvas_panel, canvas_body = make_panel("Prospectivity Map")
        root.addWidget(canvas_panel)

        self.fig = Figure(figsize=(8, 4), facecolor=MPL_FACE)
        self.canvas = FigureCanvas(self.fig)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(MPL_FACE)
        self.ax.text(0.5, 0.5, "Run fusion to generate prospectivity map",
                     ha="center", va="center", transform=self.ax.transAxes,
                     color=MPL_MUTED, fontsize=13)
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        canvas_body.addWidget(self.canvas)

        self._result = None

        root.addStretch()

    def _run_fusion(self):
        """Run multi-physics fusion from the current inversion result."""
        inv = self.main.current_inversion
        if inv is None:
            QMessageBox.warning(self, "No Data",
                                "Run ERT inversion first to generate data for fusion.")
            return

        weights = {
            "ert": self.w_ert.value(),
            "gravity": self.w_grav.value(),
            "magnetic": self.w_mag.value(),
            "chargeability": self.w_ip.value(),
        }

        try:
            result = fuse_prospectivity(ert=inv, weights=weights)
            self._result = result
            self._draw_map(result)
            self.main._log(
                f"Prospectivity fusion complete: max P={result.probability.max():.3f}",
                "SUCCESS")
        except Exception as exc:
            self.main._log(f"Prospectivity fusion failed: {exc}", "ERROR")
            QMessageBox.critical(self, "Fusion Error", str(exc))

    def _draw_map(self, result):
        """Draw the prospectivity map on the canvas."""
        self.ax.clear()
        self.ax.set_facecolor(MPL_FACE)

        prob = result.probability
        x = result.x_coords
        z = result.z_coords

        im = self.ax.imshow(prob.T, aspect="auto", origin="upper",
                            cmap="YlOrRd", interpolation="bilinear",
                            vmin=0, vmax=1,
                            extent=[x[0], x[-1], z[-1], z[0]])
        self.ax.set_xlabel("Distance (m)", color=MPL_TEXT, fontsize=11)
        self.ax.set_ylabel("Depth (m)", color=MPL_TEXT, fontsize=11)
        self.ax.set_title("Hydrocarbon Prospectivity Map",
                          color=MPL_TEXT, fontsize=13, fontweight="bold")
        self.ax.tick_params(colors=MPL_MUTED)

        cbar = self.fig.colorbar(im, ax=self.ax, fraction=0.046, pad=0.04)
        cbar.set_label("HC Probability", color=MPL_TEXT)
        cbar.ax.tick_params(colors=MPL_MUTED)
        cbar.outline.set_edgecolor(MPL_MUTED)

        self.fig.tight_layout()
        self.canvas.draw_idle()

        # Mark best targets on the map and log them
        targets = result.best_targets(n=3)
        for t in targets:
            self.ax.plot(t["x"], t["z"], "o", ms=10, mfc="none",
                         mec="#00e0ff", mew=2)
            self.ax.annotate(f"P={t['probability']:.2f}",
                             (t["x"], t["z"]),
                             color="#00e0ff", fontsize=9, fontweight="bold",
                             xytext=(6, 6), textcoords="offset points")
            self.main._log(
                f"  Target: P={t['probability']:.2f} at "
                f"({t['x']:.1f}m, {t['z']:.1f}m)", "INFO")
        if targets:
            self.canvas.draw_idle()

    def _export_map(self):
        """Export the prospectivity map to CSV."""
        if self._result is None:
            QMessageBox.warning(self, "No Data", "Run fusion first.")
            return

        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Prospectivity Map", "prospectivity.csv",
            "CSV Files (*.csv)")
        if not path:
            return

        try:
            from ..io import export_prospectivity_csv
            export_prospectivity_csv(
                self._result.probability,
                self._result.x_coords,
                self._result.z_coords,
                path)
            self.main._log(f"Prospectivity map exported to {path}", "SUCCESS")
        except Exception as exc:
            self.main._log(f"Export failed: {exc}", "ERROR")

    def refresh(self):
        """Re-render the prospectivity map if a result is cached.

        If a fusion has already been run (``self._result`` is set), the
        map is redrawn so it remains visible after tab switches.  If no
        result exists yet, the placeholder prompt is restored.
        """
        try:
            if self._result is not None:
                self._draw_map(self._result)
            else:
                self.ax.clear()
                self.ax.set_facecolor(MPL_FACE)
                self.ax.text(0.5, 0.5, "Run fusion to generate prospectivity map",
                             ha="center", va="center", transform=self.ax.transAxes,
                             color=MPL_MUTED, fontsize=13)
                self.ax.set_xticks([])
                self.ax.set_yticks([])
                self.fig.tight_layout()
                self.canvas.draw_idle()
        except Exception:
            pass
