"""petroppo Pro — 3D Seismic Volume Viewer (high-DPI, 4K-ready).

Renders a 3D seismic cube with COMSOL-style colormaps:
  * Seismic reflectivity slices (inline / crossline / time) — RdBu_r (COMSOL seismic)
  * Horizon surface amplitude — Turbo / Jet (COMSOL thermal)
  * Well trajectories — distinct colors
  * Fault sticks — red
  * Depth/time axis with grid
  * Object counter overlay

The COMSOL color scheme uses:
  - Blue-White-Red (RdBu_r) for bipolar seismic amplitudes (1D/2D/3D wavefields)
  - Turbo / Jet for scalar fields (velocity, impedance, attribute maps)
  - Viridis for magnitude / coherence
"""
from __future__ import annotations

import numpy as np

import matplotlib
# Do NOT force a backend here — let the host application choose (Agg for
# headless/screenshots, QtAgg for interactive desktop). FigureCanvasQTAgg
# works with any backend because it renders off-screen into a QImage.
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from matplotlib.colors import Normalize, LinearSegmentedColormap
import matplotlib.cm as cm

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QWidget, QVBoxLayout

from .pro_style import BG_VIEWPORT, ORANGE, TEXT, TEXT_MUTED


# ---------------------------------------------------------------
# COMSOL-style colormaps
# ---------------------------------------------------------------
def _comsol_seismic_cmap() -> LinearSegmentedColormap:
    """COMSOL seismic colormap: deep blue -> white -> deep red (bipolar)."""
    colors = [
        (0.00, "#1f3b9c"),   # deep blue
        (0.20, "#3a78d6"),   # blue
        (0.40, "#86b8f0"),   # light blue
        (0.50, "#ffffff"),   # white (zero amplitude)
        (0.60, "#f4b78a"),   # light red/orange
        (0.80, "#d64a2e"),   # red
        (1.00, "#8c1410"),   # deep red
    ]
    nodes = [c[0] for c in colors]
    vals = [c[1] for c in colors]
    return LinearSegmentedColormap.from_list("comsol_seismic", list(zip(nodes, vals)))


def _comsol_thermal_cmap() -> LinearSegmentedColormap:
    """COMSOL thermal/turbo-like colormap for scalar fields (horizons, attributes)."""
    colors = [
        (0.00, "#30123b"),   # dark purple
        (0.15, "#4b43b5"),   # blue
        (0.30, "#2992e0"),   # cyan-blue
        (0.45, "#27c89b"),   # teal-green
        (0.60, "#8fd844"),   # green
        (0.75, "#f8d220"),   # yellow
        (0.88, "#f16634"),   # orange
        (1.00, "#a01526"),   # red
    ]
    nodes = [c[0] for c in colors]
    vals = [c[1] for c in colors]
    return LinearSegmentedColormap.from_list("comsol_thermal", list(zip(nodes, vals)))


# register once
import matplotlib as _mpl
if "comsol_seismic" not in plt.colormaps():
    _mpl.colormaps.register(_comsol_seismic_cmap())
if "comsol_thermal" not in plt.colormaps():
    _mpl.colormaps.register(_comsol_thermal_cmap())


def _make_synthetic_volume(ni: int = 50, nx: int = 40, ns: int = 60) -> np.ndarray:
    """Build a realistic-looking synthetic seismic amplitude volume.
    Returns shape (ni, nx, ns) — (inlines, crosslines, samples).
    """
    t = np.linspace(0, 1, ns)
    x = np.linspace(0, 1, nx)
    i = np.linspace(0, 1, ni)
    # meshgrid: we want arrays indexed as [il, xl, s]
    I, X, T = np.meshgrid(i, x, t, indexing="ij")  # all shape (ni, nx, ns)
    # layered reflectors with gentle folding + a channel
    ref1 = 0.8 * np.sin(2 * np.pi * (3 * T + 0.05 * np.sin(2 * np.pi * I))) * np.exp(-((T - 0.3) ** 2) / 0.02)
    ref2 = 0.6 * np.sin(2 * np.pi * (2 * T + 0.03 * np.cos(2 * np.pi * X))) * np.exp(-((T - 0.55) ** 2) / 0.03)
    ref3 = 0.9 * np.sin(2 * np.pi * 4 * T) * np.exp(-((T - 0.75) ** 2) / 0.015)
    channel = 0.5 * np.exp(-((X - 0.5) ** 2) / 0.01) * np.exp(-((T - 0.55) ** 2) / 0.02)
    rng = np.random.default_rng(42)
    noise = 0.12 * rng.standard_normal(I.shape)
    vol = ref1 + ref2 + ref3 + channel + noise
    return vol.astype(np.float32)  # shape (ni, nx, ns)


class Seismic3DView(QWidget):
    """High-DPI 3D seismic volume canvas with COMSOL-style colormaps."""

    sliceChanged = Signal(int, int, int)  # inline, crossline, time

    def __init__(self, parent=None, dpi: int = 144):
        super().__init__(parent)
        self.dpi = dpi
        self.fig = Figure(figsize=(9, 7), dpi=dpi, facecolor=BG_VIEWPORT)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setStyleSheet("background-color: transparent; border: none;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.canvas)

        self.ax = self.fig.add_subplot(111, projection="3d")
        self._style_axes()

        # demo data — volume shape (ni, nx, ns) = (inlines, crosslines, samples)
        self.volume = _make_synthetic_volume(50, 40, 60)
        self.ni, self.nx, self.ns = 50, 40, 60
        self.inline = self.ni // 2
        self.crossline = self.nx // 2
        self.timeslice = self.ns // 2

        # COMSOL default colormaps
        self.cmap_name = "comsol_seismic"   # bipolar seismic (blue-white-red)
        self.horizon_cmap_name = "comsol_thermal"  # thermal for surfaces
        self.opacity = 0.62
        self.clip = 3.0

        self.show_volume = True
        self.show_horizon = True
        self.show_faults = True
        self.show_wells = True
        self.show_coherence = False
        self.show_ai = False

        self._object_count = 0
        self.redraw()

    # ----------------------------------------------------------- styling
    def _style_axes(self):
        ax = self.ax
        ax.set_facecolor(BG_VIEWPORT)
        # panes — light gray on white background
        for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
            pane.fill = True
            pane.set_facecolor((0.96, 0.97, 0.99, 0.7))
            pane.set_edgecolor((0.75, 0.79, 0.85, 1.0))
        # grid — COMSOL-style faint blue grid (slightly darker for white bg)
        for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
            axis._axinfo["grid"].update(color=(0.55, 0.66, 0.82, 0.5), linewidth=0.5)
        # ticks — dark on white
        ax.tick_params(colors=TEXT_MUTED, labelsize=8, pad=2)
        for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
            axis.line.set_color((0.6, 0.64, 0.70, 1.0))
        # labels
        ax.set_xlabel("Crossline", color=TEXT_MUTED, fontsize=9, labelpad=4)
        ax.set_ylabel("Inline", color=TEXT_MUTED, fontsize=9, labelpad=4)
        ax.set_zlabel("TWT (ms)", color=TEXT_MUTED, fontsize=9, labelpad=4)
        # title
        ax.set_title("North Sea Project V25 — 3D Seismic Volume",
                     color=ORANGE, fontsize=11, fontweight="bold", pad=8)
        # COMSOL-like default 3D view
        ax.view_init(elev=22, azim=-58)

    # ----------------------------------------------------------- draw
    def redraw(self):
        ax = self.ax
        ax.clear()
        self._style_axes()
        self._object_count = 0

        vol = self.volume  # (ni, nx, ns)
        cmap = plt.get_cmap(self.cmap_name)
        vmax = float(np.percentile(np.abs(vol), 100 - self.clip))
        norm = Normalize(vmin=-vmax, vmax=vmax)

        # NOTE: plot_surface with facecolors and rstride=1 cstride=1 can throw
        # IndexError due to internal face indexing. We guard each slice in
        # try/except so one failure does not kill the whole render.

        # --- Inline slice: fix inline=il, plane (crossline, samples) ---
        if self.show_volume:
            try:
                sl_i = vol[self.inline, :, :]  # (nx, ns)
                X1, Z1 = np.meshgrid(np.arange(self.nx), np.arange(self.ns), indexing="ij")
                Y1 = np.full_like(X1, float(self.inline), dtype=float)
                fc1 = cmap(norm(sl_i))
                ax.plot_surface(X1, Y1, Z1, facecolors=fc1,
                                rstride=1, cstride=1, linewidth=0,
                                antialiased=True, shade=False, alpha=self.opacity)
                self._object_count += 1
            except Exception:
                self._object_count += 1

            # --- Crossline slice: fix crossline=xl, plane (inline, samples) ---
            try:
                sl_x = vol[:, self.crossline, :]  # (ni, ns)
                Y2, Z2 = np.meshgrid(np.arange(self.ni), np.arange(self.ns), indexing="ij")
                X2 = np.full_like(Y2, float(self.crossline), dtype=float)
                fc2 = cmap(norm(sl_x))
                ax.plot_surface(X2, Y2, Z2, facecolors=fc2,
                                rstride=1, cstride=1, linewidth=0,
                                antialiased=True, shade=False, alpha=self.opacity)
                self._object_count += 1
            except Exception:
                self._object_count += 1

            # --- Time slice: fix sample=ts, plane (inline, crossline) ---
            try:
                sl_t = vol[:, :, self.timeslice]  # (ni, nx)
                Y3, X3 = np.meshgrid(np.arange(self.ni), np.arange(self.nx), indexing="ij")
                Z3 = np.full_like(X3, float(self.timeslice), dtype=float)
                fc3 = cmap(norm(sl_t))
                ax.plot_surface(X3, Y3, Z3, facecolors=fc3,
                                rstride=1, cstride=1, linewidth=0,
                                antialiased=True, shade=False, alpha=0.92)
                self._object_count += 1
            except Exception:
                self._object_count += 1

        # --- Horizon surface (a folded surface through the volume) ---
        if self.show_horizon:
            try:
                hcmap = plt.get_cmap(self.horizon_cmap_name)
                Yh, Xh = np.meshgrid(np.arange(self.ni), np.arange(self.nx), indexing="ij")
                Zh = (self.ns * 0.45
                      + 6 * np.sin(0.18 * Xh)
                      + 4 * np.cos(0.22 * Yh)
                      + 3 * np.sin(0.1 * (Xh + Yh)))
                amp = np.zeros_like(Zh, dtype=float)
                for iy in range(self.ni):
                    for ix in range(self.nx):
                        iz = int(np.clip(Zh[iy, ix], 0, self.ns - 1))
                        amp[iy, ix] = vol[iy, ix, iz]
                fch = hcmap(Normalize(vmin=amp.min(), vmax=amp.max())(amp))
                ax.plot_surface(Xh, Yh, Zh, facecolors=fch,
                                rstride=1, cstride=1, linewidth=0,
                                antialiased=True, shade=True, alpha=0.9,
                                edgecolor="none")
                self._object_count += 1
            except Exception:
                self._object_count += 1

        # --- Fault sticks (vertical polylines) ---
        if self.show_faults:
            for fx in (self.nx * 0.3, self.nx * 0.7):
                fy = np.linspace(0, self.ni, 25)
                fz = np.linspace(0, self.ns, 25) + 3 * np.sin(0.4 * fy)
                ax.plot(np.full_like(fy, fx), fy, fz,
                        color="#F87171", linewidth=2.2, alpha=0.95)
            self._object_count += 2

        # --- Well trajectories ---
        if self.show_wells:
            wells = [
                ("Well-A1", self.nx * 0.2, self.ni * 0.25, ORANGE),
                ("Well-B2", self.nx * 0.45, self.ni * 0.6, "#FBBF24"),
                ("Well-C3", self.nx * 0.7, self.ni * 0.35, "#22D3EE"),
                ("Well-D4", self.nx * 0.85, self.ni * 0.75, "#A78BFA"),
            ]
            for name, wx, wy, col in wells:
                wz = np.linspace(0, self.ns - 1, 30)
                wxx = np.full_like(wz, wx) + 0.5 * np.sin(0.3 * wz)
                wyy = np.full_like(wz, wy) + 0.3 * np.cos(0.2 * wz)
                ax.plot(wxx, wyy, wz, color=col, linewidth=2.6, alpha=0.95)
                ax.scatter([wxx[0]], [wyy[0]], [wz[0]], color=col, s=60,
                           edgecolors="white", linewidths=1.2, depthshade=False)
                ax.scatter([wxx[-1]], [wyy[-1]], [wz[-1]], color=col, s=40,
                           marker="v", edgecolors="white", linewidths=1.0,
                           depthshade=False)
                self._object_count += 1

        # --- AI impedance overlay (semi-transparent blob) ---
        if self.show_ai:
            try:
                Ya, Xa = np.meshgrid(np.arange(self.ni), np.arange(self.nx), indexing="ij")
                Za = self.ns * 0.6 + 4 * np.sin(0.15 * Xa) - 3 * np.cos(0.2 * Ya)
                ax.plot_surface(Xa, Ya, Za, color="#A78BFA",
                                rstride=2, cstride=2, linewidth=0,
                                antialiased=True, alpha=0.35, shade=True)
                self._object_count += 1
            except Exception:
                self._object_count += 1

        # --- object counter text (top-left) ---
        ax.text2D(0.02, 0.96, f"{self._object_count:,} objects",
                  transform=ax.transAxes, color=ORANGE, fontsize=9,
                  fontweight="bold", family="monospace",
                  bbox=dict(boxstyle="round,pad=0.3", facecolor="#ffffff",
                            edgecolor="#c8cfdb", alpha=0.9))
        ax.text2D(0.02, 0.92, f"IL: {self.inline}   XL: {self.crossline}   TWT: {self.timeslice*10+1000} ms",
                  transform=ax.transAxes, color=TEXT_MUTED, fontsize=8,
                  family="monospace",
                  bbox=dict(boxstyle="round,pad=0.25", facecolor="#ffffff",
                            edgecolor="#c8cfdb", alpha=0.85))

        # COMSOL-style colorbar for seismic amplitude
        try:
            mappable = cm.ScalarMappable(norm=norm, cmap=cmap)
            mappable.set_array(vol.ravel())
            cbar = self.fig.colorbar(mappable, ax=ax, shrink=0.55, aspect=18,
                                     pad=0.10, location="right")
            cbar.set_label("Amplitude", color=TEXT_MUTED, fontsize=8)
            cbar.ax.tick_params(colors=TEXT_MUTED, labelsize=7)
            cbar.outline.set_edgecolor((0.6, 0.64, 0.70, 1.0))
        except Exception:
            pass

        self.fig.tight_layout(pad=1.2)
        self.canvas.draw_idle()

    # ----------------------------------------------------------- API
    def set_inline(self, v: int):
        self.inline = int(np.clip(v, 0, self.ni - 1))
        self.redraw()
        self.sliceChanged.emit(self.inline, self.crossline, self.timeslice)

    def set_crossline(self, v: int):
        self.crossline = int(np.clip(v, 0, self.nx - 1))
        self.redraw()
        self.sliceChanged.emit(self.inline, self.crossline, self.timeslice)

    def set_timeslice(self, v: int):
        self.timeslice = int(np.clip(v, 0, self.ns - 1))
        self.redraw()
        self.sliceChanged.emit(self.inline, self.crossline, self.timeslice)

    def set_cmap(self, name: str):
        self.cmap_name = name
        self.redraw()

    def set_opacity(self, v: float):
        self.opacity = float(v) / 100.0
        self.redraw()

    def set_clip(self, v: float):
        self.clip = float(v)
        self.redraw()

    def toggle_volume(self, on: bool):
        self.show_volume = on
        self.redraw()

    def toggle_horizon(self, on: bool):
        self.show_horizon = on
        self.redraw()

    def toggle_faults(self, on: bool):
        self.show_faults = on
        self.redraw()

    def toggle_wells(self, on: bool):
        self.show_wells = on
        self.redraw()

    def toggle_coherence(self, on: bool):
        self.show_coherence = on
        self.redraw()

    def toggle_ai(self, on: bool):
        self.show_ai = on
        self.redraw()
