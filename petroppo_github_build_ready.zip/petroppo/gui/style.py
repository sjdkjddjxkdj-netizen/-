"""COMSOL-grade professional dark theme for petroppo V4.

A deep, rich, technical interface inspired by professional engineering
simulation software (COMSOL Multiphysics, ANSYS Workbench, Schlumberger
Petrel). Features a dark slate canvas with vibrant accent colors, polished
ribbon toolbar, card-style panels, refined typography, and subtle depth cues
that give the application a premium, company-presentable aesthetic.
"""

# ============================================================================
# COMSOL-QSS — comprehensive dark stylesheet
# ============================================================================
COMSOL_QSS = """
/* ===== Global ===== */
QWidget {
    background-color: #1c1f26;
    color: #e4e7ed;
    font-family: 'Segoe UI', 'Helvetica Neue', 'Arial', sans-serif;
    font-size: 13px;
}
QMainWindow { background-color: #15171c; }

/* ===== Menu Bar ===== */
QMenuBar {
    background-color: #1c1f26;
    border-bottom: 1px solid #2a2e38;
    padding: 2px;
    color: #c8ced9;
    font-weight: 500;
}
QMenuBar::item {
    padding: 7px 16px;
    background: transparent;
    border-radius: 4px;
    color: #c8ced9;
}
QMenuBar::item:selected {
    background-color: #2a3445;
    color: #5b9cf6;
}
QMenuBar::item:pressed {
    background-color: #34405a;
    color: #ffffff;
}
QMenu {
    background-color: #232831;
    border: 1px solid #3a4150;
    border-radius: 6px;
    padding: 6px;
}
QMenu::item {
    padding: 8px 32px 8px 22px;
    border-radius: 4px;
    color: #d4dae4;
}
QMenu::item:selected {
    background-color: #2f4d7a;
    color: #ffffff;
}
QMenu::separator {
    height: 1px;
    background: #2e343f;
    margin: 6px 10px;
}

/* ===== Ribbon / Toolbar ===== */
QToolBar {
    background-color: #20242d;
    border-bottom: 1px solid #2a2e38;
    border-top: 1px solid #1a1d24;
    spacing: 3px;
    padding: 6px 8px;
}
QToolBar::separator {
    width: 1px;
    background: #2a2e38;
    margin: 6px 10px;
}
QToolBar QToolButton {
    padding: 8px 14px;
    border: 1px solid transparent;
    border-radius: 6px;
    background: transparent;
    color: #c8ced9;
    text-align: center;
    font-weight: 500;
}
QToolBar QToolButton:hover {
    background-color: #2a3445;
    border: 1px solid #3a4658;
    color: #e4e7ed;
}
QToolBar QToolButton:checked, QToolBar QToolButton:pressed {
    background-color: #2f4d7a;
    border: 1px solid #3d6ba8;
    color: #ffffff;
}

/* ===== Status Bar ===== */
QStatusBar {
    background-color: #20242d;
    border-top: 1px solid #2a2e38;
    color: #8893a5;
    font-size: 12px;
}
QStatusBar::item { border: none; }
QStatusBar QLabel { color: #8893a5; background: transparent; }

/* ===== Dock Widgets (model tree, property panel, console) ===== */
QDockWidget {
    border: 1px solid #2a2e38;
    border-radius: 0px;
    color: #e4e7ed;
}
QDockWidget::title {
    background-color: #232831;
    padding: 8px 14px;
    border-bottom: 2px solid #2f4d7a;
    font-weight: bold;
    color: #5b9cf6;
    font-size: 12px;
    letter-spacing: 0.5px;
}
QDockWidget::close-button, QDockWidget::float-button {
    border: none;
    padding: 3px;
    border-radius: 3px;
}
QDockWidget::close-button:hover, QDockWidget::float-button:hover {
    background: #2a3445;
    border-radius: 3px;
}

/* ===== Tree Widget (Model Tree) ===== */
QTreeWidget {
    background-color: #1c1f26;
    border: none;
    border-right: 1px solid #2a2e38;
    alternate-background-color: #20242d;
    outline: 0;
    color: #c8ced9;
}
QTreeWidget::item {
    padding: 6px 5px;
    border-bottom: 0px;
}
QTreeWidget::item:selected {
    background-color: #2f4d7a;
    color: #ffffff;
}
QTreeWidget::item:hover {
    background-color: #2a3445;
}
QHeaderView::section {
    background-color: #232831;
    padding: 7px 10px;
    border: none;
    border-bottom: 1px solid #2a2e38;
    border-right: 1px solid #2e343f;
    color: #8893a5;
    font-weight: bold;
    font-size: 11px;
    letter-spacing: 0.5px;
}

/* ===== List Widget ===== */
QListWidget {
    background-color: #232831;
    border: 1px solid #2a2e38;
    border-radius: 6px;
    outline: 0;
    color: #c8ced9;
}
QListWidget::item {
    padding: 9px 12px;
    border-bottom: 1px solid #2a2e38;
}
QListWidget::item:selected {
    background-color: #2f4d7a;
    color: #ffffff;
}
QListWidget::item:hover {
    background-color: #2a3445;
}

/* ===== Buttons ===== */
QPushButton {
    background-color: #2a3445;
    border: 1px solid #3a4150;
    border-radius: 6px;
    padding: 8px 20px;
    color: #d4dae4;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #34405a;
    border-color: #4a5468;
    color: #ffffff;
}
QPushButton:pressed {
    background-color: #2f4d7a;
    border-color: #3d6ba8;
}
QPushButton:default {
    background-color: #2f6fd6;
    border-color: #2f6fd6;
    color: white;
    font-weight: bold;
}
QPushButton:default:hover {
    background-color: #4085ec;
    border-color: #4085ec;
}
QPushButton:disabled {
    color: #555c68;
    background-color: #23262d;
    border-color: #2a2e38;
}

/* ===== Input Fields ===== */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QTextEdit, QPlainTextEdit {
    background-color: #232831;
    border: 1px solid #3a4150;
    border-radius: 5px;
    padding: 6px 10px;
    color: #d4dae4;
    selection-background-color: #2f4d7a;
    selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QComboBox:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border: 2px solid #2f6fd6;
    padding: 5px 9px;
    background-color: #262c37;
}
QComboBox::drop-down {
    border: none;
    width: 24px;
}
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #8893a5;
    margin-right: 8px;
}
QComboBox QAbstractItemView {
    background-color: #232831;
    border: 1px solid #3a4150;
    selection-background-color: #2f4d7a;
    selection-color: #ffffff;
    outline: 0;
    color: #d4dae4;
}

/* ===== Group Box ===== */
QGroupBox {
    border: 1px solid #2a2e38;
    border-radius: 8px;
    margin-top: 16px;
    padding: 18px 12px 12px 12px;
    background-color: #1f232b;
    font-weight: bold;
    color: #8893a5;
    font-size: 12px;
    letter-spacing: 0.5px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 16px;
    padding: 0 8px;
    background-color: #1c1f26;
    color: #5b9cf6;
}

/* ===== Tab Widget ===== */
QTabWidget::pane {
    border: 1px solid #2a2e38;
    border-radius: 0px;
    background: #15171c;
    top: -1px;
}
QTabBar::tab {
    background-color: #1c1f26;
    padding: 9px 22px;
    border: 1px solid transparent;
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    color: #8893a5;
    margin-right: 2px;
    font-weight: 500;
}
QTabBar::tab:selected {
    background-color: #232831;
    color: #5b9cf6;
    border: 1px solid #2a2e38;
    border-bottom: 3px solid #2f6fd6;
    font-weight: bold;
}
QTabBar::tab:hover:!selected {
    background-color: #20242d;
    color: #c8ced9;
}

/* ===== Table Widget ===== */
QTableWidget {
    background-color: #1c1f26;
    gridline-color: #2a2e38;
    border: 1px solid #2a2e38;
    alternate-background-color: #20242d;
    color: #c8ced9;
}
QTableWidget::item:selected {
    background-color: #2f4d7a;
    color: #ffffff;
}
QTableWidget::item:hover {
    background-color: #2a3445;
}
QTableWidget QHeaderView::section {
    background-color: #232831;
    padding: 8px 12px;
    border: none;
    border-bottom: 1px solid #2a2e38;
    border-right: 1px solid #2e343f;
    color: #8893a5;
    font-weight: bold;
    font-size: 12px;
}

/* ===== Progress Bar ===== */
QProgressBar {
    background-color: #232831;
    border: 1px solid #2a2e38;
    border-radius: 5px;
    text-align: center;
    color: #d4dae4;
    font-weight: 500;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #2f6fd6, stop:1 #5b9cf6);
    border-radius: 4px;
}

/* ===== Scroll Bar ===== */
QScrollBar:vertical {
    background: #1c1f26;
    width: 12px;
    margin: 0;
    border: none;
}
QScrollBar::handle:vertical {
    background: #3a4150;
    min-height: 30px;
    border-radius: 5px;
    margin: 2px;
}
QScrollBar::handle:vertical:hover {
    background: #4a5468;
}
QScrollBar::horizontal {
    background: #1c1f26;
    height: 12px;
    margin: 0;
    border: none;
}
QScrollBar::handle:horizontal {
    background: #3a4150;
    min-width: 30px;
    border-radius: 5px;
    margin: 2px;
}
QScrollBar::handle:horizontal:hover {
    background: #4a5468;
}
QScrollBar::add-line, QScrollBar::sub-line {
    border: none;
    background: none;
    width: 0;
    height: 0;
}
QScrollBar::add-page, QScrollBar::sub-page {
    background: #1c1f26;
}

/* ===== Labels ===== */
QLabel { color: #e4e7ed; background: transparent; }
QLabel[role="title"] {
    font-size: 19px;
    font-weight: bold;
    color: #ffffff;
}
QLabel[role="subtitle"] {
    font-size: 12px;
    color: #8893a5;
}
QLabel[role="value"] {
    font-size: 26px;
    font-weight: bold;
    color: #5b9cf6;
}
QLabel[role="muted"] { color: #8893a5; }
QLabel[role="section"] {
    font-size: 13px;
    font-weight: bold;
    color: #5b9cf6;
    padding: 4px 0;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}

/* ===== Scroll Area ===== */
QScrollArea { border: none; background: transparent; }
QScrollArea > QWidget > QWidget { background: transparent; }

/* ===== Special Roles ===== */
QFrame[role="card"] {
    background-color: #232831;
    border: 1px solid #2a2e38;
    border-radius: 10px;
}
QFrame[role="panel"] {
    background-color: #1f232b;
    border: 1px solid #2a2e38;
    border-radius: 8px;
}
QFrame[role="ribbon-group"] {
    background-color: #1f232b;
    border: 1px solid #2a2e38;
    border-radius: 8px;
}
QFrame[role="console"] {
    background-color: #0f1116;
    border: 1px solid #2a2e38;
    border-radius: 0px;
}
QTextEdit[role="console"], QPlainTextEdit[role="console"] {
    background-color: #0f1116;
    color: #a8c7e8;
    border: none;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
}

/* ===== Splitter ===== */
QSplitter::handle {
    background-color: #2a2e38;
}
QSplitter::handle:horizontal { width: 2px; }
QSplitter::handle:vertical { height: 2px; }
QSplitter::handle:hover {
    background-color: #2f6fd6;
}

/* ===== ToolTip ===== */
QToolTip {
    background-color: #0f1116;
    color: #e4e7ed;
    border: 1px solid #2f6fd6;
    border-radius: 5px;
    padding: 7px 11px;
    font-size: 12px;
}
"""

# ============================================================================
# Color palette — deep slate with vibrant COMSOL-grade accents
# ============================================================================
ACCENT = "#2f6fd6"        # primary vivid blue
ACCENT_LIGHT = "#5b9cf6"  # lighter highlight blue
ACCENT_DIM = "#2f4d7a"    # deep selection blue
BG = "#1c1f26"            # main canvas (dark slate)
BG_DARK = "#15171c"       # deepest background (main window)
BG_WHITE = "#232831"      # panels, cards, inputs
BG_PANEL = "#1f232b"      # secondary panels / group boxes
BORDER = "#2a2e38"        # border lines
BORDER_LIGHT = "#3a4150"  # lighter borders / input borders
TEXT = "#e4e7ed"          # primary text (soft white)
TEXT_SECONDARY = "#c8ced9"  # secondary text
MUTED = "#8893a5"         # muted/gray text
CONSOLE_BG = "#0f1116"    # console background (near-black)
CONSOLE_FG = "#a8c7e8"    # console text (soft blue-white)

# Geological color palette — vibrant, distinguishable earth tones
GEO_COLORS = {
    "topsoil": "#6b5b3e",
    "sand": "#d4a84b",
    "clay": "#a07050",
    "limestone": "#c8c4b0",
    "sandstone": "#c4925a",
    "shale": "#5a5a62",
    "granite": "#8a6a5a",
    "basalt": "#3a3a42",
    "salt": "#e8dcb8",
    "water": "#3a7ec8",
    "oil": "#2b2b2b",
    "ore": "#a83820",
    "reservoir": "#e85d2b",
    "aquifer": "#3a9ec8",
}

# Matplotlib dark-theme colors (used by viz.py)
MPL_FACE = "#15171c"       # figure/axes background
MPL_PANEL = "#1c1f26"      # secondary axes
MPL_GRID = "#2a2e38"       # grid line color
MPL_TEXT = "#e4e7ed"       # primary text
MPL_MUTED = "#8893a5"      # muted/axis labels
MPL_SPINE = "#3a4150"      # axis spines
MPL_ACCENT = "#5b9cf6"     # line plot accent
MPL_ACCENT2 = "#e85d2b"    # secondary accent (orange)

# Professional colormaps for geophysical results
RESISTIVITY_CMAP = "turbo_r"   # perceptually uniform, great for resistivity
DEFAULT_CMAP = "turbo"
RADARGRAM_CMAP = "seismic"     # standard GPR display


def apply_theme(app) -> None:
    """Apply the COMSOL-grade dark professional theme to a Qt application."""
    app.setStyleSheet(COMSOL_QSS)
