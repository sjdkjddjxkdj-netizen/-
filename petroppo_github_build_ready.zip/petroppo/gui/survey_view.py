"""Survey view — design and run geophysical surveys."""
from __future__ import annotations

import time

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QPushButton, QSpinBox, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget, QProgressBar, QMessageBox,
)

from ..core import Survey, MeasurementMethod, SurveyStatus, new_id, get_logger
from ..simulator.engine import get_engine
from ..simulator.scenarios import SCENARIOS
from .widgets import make_title, make_panel


_log = get_logger("gui.survey")


class SurveyView(QWidget):
    """Survey design and execution screen."""

    def __init__(self, main_window):
        super().__init__()
        self.main = main_window
        self.surveys: list[Survey] = []
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        root.addWidget(make_title(
            "Survey Design & Simulation",
            "Configure survey parameters and run forward simulations"
        ))

        # --- Configuration panel ---
        config_panel, config_body = make_panel("Survey Configuration")
        root.addWidget(config_panel)

        form = QFormLayout()
        form.setSpacing(8)

        self.method_combo = QComboBox()
        methods = [
            ("ERT — Electrical Resistivity Tomography", MeasurementMethod.ERT),
            ("Spectral IP — Induced Polarization", MeasurementMethod.SPECTRAL),
            ("Magnetic Survey", MeasurementMethod.MAGNETIC),
            ("Gravity Survey", MeasurementMethod.GRAVITY),
            ("GPR — Ground Penetrating Radar", MeasurementMethod.GPR),
            ("Seismic Refraction", MeasurementMethod.SEISMIC),
        ]
        for label, method in methods:
            self.method_combo.addItem(label, method)
        form.addRow("Method:", self.method_combo)

        self.config_combo = QComboBox()
        self.config_combo.addItems(["Wenner", "Dipole-Dipole", "Schlumberger", "Pole-Dipole", "Pole-Pole"])
        form.addRow("Configuration:", self.config_combo)

        self.electrodes_spin = QSpinBox()
        self.electrodes_spin.setRange(4, 128)
        self.electrodes_spin.setValue(32)
        form.addRow("Electrodes:", self.electrodes_spin)

        self.spacing_spin = QDoubleSpinBox()
        self.spacing_spin.setRange(0.5, 50)
        self.spacing_spin.setValue(5.0)
        self.spacing_spin.setSuffix(" m")
        form.addRow("Spacing:", self.spacing_spin)

        self.lines_spin = QSpinBox()
        self.lines_spin.setRange(1, 20)
        self.lines_spin.setValue(1)
        form.addRow("Lines:", self.lines_spin)

        self.noise_spin = QDoubleSpinBox()
        self.noise_spin.setRange(0, 0.5)
        self.noise_spin.setValue(0.02)
        self.noise_spin.setSingleStep(0.005)
        self.noise_spin.setSuffix(" (frac)")
        form.addRow("Noise level:", self.noise_spin)

        self.scenario_combo = QComboBox()
        for name in SCENARIOS:
            self.scenario_combo.addItem(name.replace("_", " ").title(), name)
        form.addRow("Earth model:", self.scenario_combo)

        config_body.addLayout(form)

        # --- Run button + progress ---
        run_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run Simulation")
        self.run_btn.setDefault(True)
        self.run_btn.clicked.connect(self._run)
        run_row.addWidget(self.run_btn)

        self.progress = QProgressBar()
        self.progress.setValue(0)
        run_row.addWidget(self.progress)
        config_body.addLayout(run_row)

        # --- Results table ---
        results_panel, results_body = make_panel("Results")
        root.addWidget(results_panel)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["#", "Method", "Electrodes", "Readings", "Status"])
        self.table.horizontalHeader().setStretchLastSection(True)
        results_body.addWidget(self.table)

        root.addStretch()

    def _run(self):
        """Create a survey and run the simulation."""
        method = self.method_combo.currentData()
        config_map = {
            "Wenner": "wenner", "Dipole-Dipole": "dipole-dipole",
            "Schlumberger": "schlumberger", "Pole-Dipole": "pole-dipole",
            "Pole-Pole": "pole-pole",
        }
        scenario_name = self.scenario_combo.currentData()

        survey = Survey(
            id=new_id(),
            name=f"{method.value.upper()} Survey",
            method=method,
            status=SurveyStatus.PLANNED,
            grid_spacing=self.spacing_spin.value(),
            n_lines=self.lines_spin.value(),
            n_electrodes=self.electrodes_spin.value(),
            config=config_map.get(self.config_combo.currentText(), "wenner"),
        )

        # Load scenario into engine
        from ..simulator.scenarios import get_scenario
        engine = get_engine()
        engine.load_scenario(scenario_name)

        self.progress.setValue(10)
        self.run_btn.setEnabled(False)

        try:
            measurements = engine.run(survey, noise=self.noise_spin.value())
            self.progress.setValue(100)
            self.main._log(
                f"Survey '{survey.name}' complete: {len(measurements)} readings",
                "SUCCESS"
            )

            # Add to table
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(survey.method.value))
            self.table.setItem(row, 2, QTableWidgetItem(str(survey.n_electrodes)))
            self.table.setItem(row, 3, QTableWidgetItem(str(len(measurements))))
            self.table.setItem(row, 4, QTableWidgetItem("Completed"))

            self.surveys.append(survey)

        except Exception as exc:
            self.main._log(f"Simulation failed: {exc}", "ERROR")
            QMessageBox.warning(self, "Simulation Error", str(exc))
        finally:
            self.run_btn.setEnabled(True)

    def refresh(self):
        """Rebuild the results table from the stored surveys list.

        Ensures the table always reflects the real set of completed
        surveys held in ``self.surveys``, even if rows were added
        out-of-order or the view was navigated away and back.
        """
        try:
            self.table.setRowCount(0)
            for i, srv in enumerate(self.surveys):
                row = self.table.rowCount()
                self.table.insertRow(row)
                self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
                self.table.setItem(row, 1, QTableWidgetItem(srv.method.value))
                self.table.setItem(row, 2, QTableWidgetItem(str(srv.n_electrodes)))
                # readings count is not stored on the Survey object; show
                # electrodes*lines as a representative survey size
                est = srv.n_electrodes * max(srv.n_lines, 1)
                self.table.setItem(row, 3, QTableWidgetItem(f"~{est}"))
                status = srv.status.value if hasattr(srv.status, "value") else str(srv.status)
                self.table.setItem(row, 4, QTableWidgetItem(status.title()))
        except Exception:
            pass
