"""3D volume viewer — interactive 3D visualization of inversion models.

Uses matplotlib's 3D plotting capabilities to render:
  - 3D voxel volumes with isosurfaces
  - 2D inversion slices in 3D perspective
  - Earth model bodies in 3D
  - Prospectivity volumes

The viewer supports:
  - Threshold-based isosurface rendering
  - Multiple slice planes
  - Color-mapped volumetric display
  - Export to VTK for external 3D viewers
"""
from __future__ import annotations

import numpy as np

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QVBoxLayout, QHBoxLayout, QWidget, QLabel, QSlider, QPushButton,
    QDoubleSpinBox, QComboBox, QGroupBox, QFormLayout, QCheckBox,
)

import matplotlib
matplotlib.use("QtAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize

from ..core import EarthModel, get_logger
from .style import (
    MPL_FACE, MPL_GRID, MPL_TEXT, MPL_MUTED, MPL_SPINE,
    MPL_ACCENT, RESISTIVITY_CMAP,
)

_log = get_logger("gui.viewer3d")

_3D_RC = {
    "figure.facecolor": MPL_FACE,
    "axes.facecolor": MPL_FACE,
    "axes.edgecolor": MPL_SPINE,
    "axes.labelcolor": MPL_TEXT,
    "axes.titlecolor": MPL_TEXT,
    "axes.titleweight": "bold",
    "xtick.color": MPL_MUTED,
    "ytick.color": MPL_MUTED,
    "text.color": MPL_TEXT,
    "font.family": "sans-serif",
    "font.size": 10,
}


class VolumeViewer3D(QWidget):
    """Interactive 3D volume viewer widget."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._volume: np.ndarray | None = None
        self._x_coords: np.ndarray | None = None
        self._y_coords: np.ndarray | None = None
        self._z_coords: np.ndarray | None = None
        self._data_name: str = "resistivity"
        self._threshold: float = 0.0
        self._show_isosurface: bool = True
        self._show_slices: bool = True
        self._slice_idx: int = 0
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)

        # Canvas
        with plt.rc_context(_3D_RC):
            self.fig = Figure(figsize=(8, 6), facecolor=MPL_FACE)
        self.canvas = FigureCanvas(self.fig)
        self.ax = self.fig.add_subplot(111, projection="3d")
        self._style_3d_axes()
        layout.addWidget(self.canvas)

        # Controls
        ctrl = QGroupBox("3D View Controls")
        ctrl_form = QFormLayout(ctrl)
        ctrl_form.setSpacing(6)

        self.cmap_combo = QComboBox()
        self.cmap_combo.addItems(["turbo", "inferno", "viridis", "plasma",
                                   "magma", "jet"])
        self.cmap_combo.currentTextChanged.connect(self._redraw)
        ctrl_form.addRow("Colormap:", self.cmap_combo)

        self.threshold_spin = QDoubleSpinBox()
        self.threshold_spin.setRange(-999999, 999999)
        self.threshold_spin.setDecimals(1)
        self.threshold_spin.setSingleStep(10.0)
        self.threshold_spin.valueChanged.connect(self._on_threshold)
        ctrl_form.addRow("Isosurface threshold:", self.threshold_spin)

        self.slice_slider = QSlider()
        self.slice_slider.setOrientation(Qt.Orientation.Horizontal)  # Horizontal
        self.slice_slider.setMinimum(0)
        self.slice_slider.setMaximum(10)
        self.slice_slider.valueChanged.connect(self._on_slice)
        ctrl_form.addRow("Y-slice:", self.slice_slider)

        self.chk_iso = QCheckBox("Show isosurface")
        self.chk_iso.setChecked(True)
        self.chk_iso.toggled.connect(self._redraw)
        ctrl_form.addRow(self.chk_iso)

        self.chk_slices = QCheckBox("Show slices")
        self.chk_slices.setChecked(True)
        self.chk_slices.toggled.connect(self._redraw)
        ctrl_form.addRow(self.chk_slices)

        self.btn_reset = QPushButton("Reset View")
        self.btn_reset.clicked.connect(self._reset_view)
        ctrl_form.addRow(self.btn_reset)

        layout.addWidget(ctrl)

    def _style_3d_axes(self):
        self.ax.set_facecolor(MPL_FACE)
        for pane in [self.ax.xaxis, self.ax.yaxis, self.ax.zaxis]:
            pane.pane.set_facecolor((0.1, 0.11, 0.14, 0.8))
            pane.pane.set_edgecolor(MPL_SPINE)
        self.ax.tick_params(colors=MPL_MUTED, labelsize=8)

    def set_volume(self, volume: np.ndarray,
                   x_coords: np.ndarray | None = None,
                   y_coords: np.ndarray | None = None,
                   z_coords: np.ndarray | None = None,
                   data_name: str = "resistivity"):
        """Set the 3D volume to display.

        Parameters
        ----------
        volume : (nx, ny, nz) 3D array.
        x_coords, y_coords, z_coords : cell-centre coordinates.
        data_name : label for the scalar field.
        """
        self._volume = np.asarray(volume, dtype=float)
        nx, ny, nz = self._volume.shape
        self._x_coords = x_coords if x_coords is not None else np.arange(nx)
        self._y_coords = y_coords if y_coords is not None else np.arange(ny)
        self._z_coords = z_coords if z_coords is not None else np.arange(nz)
        self._data_name = data_name

        # Update threshold range
        vmin, vmax = float(self._volume.min()), float(self._volume.max())
        self.threshold_spin.setMinimum(vmin)
        self.threshold_spin.setMaximum(vmax)
        self.threshold_spin.setValue(vmin + 0.5 * (vmax - vmin))

        # Update slice slider
        self.slice_slider.setMaximum(max(ny - 1, 0))
        self.slice_slider.setValue(ny // 2)

        self._redraw()

    def set_earth_model_3d(self, model3d):
        """Set volume from an EarthModel3D (voxel model or 3D inversion result).

        Accepts either an :class:`~petroppo.simulator.EarthModel3D` (which
        exposes ``resistivity`` + ``x_coords/y_coords/z_coords``) or a 3-D
        inversion result that carries the same coordinate attributes plus a
        ``model`` array.
        """
        vol = getattr(model3d, "resistivity", None)
        if vol is None:
            vol = getattr(model3d, "model", None)
        if vol is None:
            raise ValueError("model3d must expose resistivity or model")
        self.set_volume(
            np.asarray(vol),
            x_coords=getattr(model3d, "x_coords", None),
            y_coords=getattr(model3d, "y_coords", None),
            z_coords=getattr(model3d, "z_coords", None),
            data_name="resistivity",
        )

    def _on_threshold(self, val):
        self._threshold = val
        self._redraw()

    def _on_slice(self, val):
        self._slice_idx = val
        self._redraw()

    def _redraw(self):
        if self._volume is None:
            return

        self.ax.clear()
        self._style_3d_axes()
        cmap = self.cmap_combo.currentText()
        vol = self._volume
        nx, ny, nz = vol.shape

        vmin = float(vol.min())
        vmax = float(vol.max())
        if vmax - vmin < 1e-9:
            vmax = vmin + 1.0
        norm = Normalize(vmin=vmin, vmax=vmax)

        X, Z = np.meshgrid(self._x_coords, self._z_coords, indexing="ij")

        # Draw slices
        if self.chk_slices.isChecked() and ny > 0:
            # Show a few y-slices
            n_show = min(3, ny)
            indices = np.linspace(0, ny - 1, n_show, dtype=int) if ny > 1 else [0]
            for iy in indices:
                y_val = self._y_coords[iy]
                slice_data = vol[:, iy, :]
                # Plot as a surface at fixed y
                surf = self.ax.plot_surface(
                    X, np.full_like(X, y_val), Z,
                    facecolors=plt.get_cmap(cmap)(norm(slice_data)),
                    shade=False, alpha=0.7, linewidth=0,
                    antialiased=True, rstride=1, cstride=1)

        # Draw isosurface (scatter of voxels above threshold)
        if self.chk_iso.isChecked():
            mask = vol > self._threshold
            if mask.any():
                ix, iy, iz = np.where(mask)
                xs = self._x_coords[ix]
                ys = self._y_coords[iy]
                zs = self._z_coords[iz]
                vals = vol[ix, iy, iz]
                # Subsample if too many points
                n_pts = len(xs)
                if n_pts > 3000:
                    idx = np.random.choice(n_pts, 3000, replace=False)
                    xs, ys, zs, vals = xs[idx], ys[idx], zs[idx], vals[idx]
                self.ax.scatter(xs, ys, zs, c=vals, cmap=cmap, norm=norm,
                                s=8, alpha=0.6, edgecolors="none")

        self.ax.set_xlabel("X (m)", color=MPL_TEXT, fontsize=9)
        self.ax.set_ylabel("Y (m)", color=MPL_TEXT, fontsize=9)
        self.ax.set_zlabel("Depth (m)", color=MPL_TEXT, fontsize=9)
        self.ax.set_title(f"3D {self._data_name.capitalize()} Volume "
                          f"({nx}x{ny}x{nz})",
                          color=MPL_TEXT, fontsize=12, fontweight="bold")

        # Invert z-axis so depth goes downward
        self.ax.invert_zaxis()

        self.fig.tight_layout()
        self.canvas.draw_idle()

    def _reset_view(self):
        self.ax.view_init(elev=30, azim=-60)
        self.canvas.draw_idle()

    def clear(self):
        self.ax.clear()
        self._style_3d_axes()
        self.canvas.draw_idle()
