"""Earth model visualization — publication-quality matplotlib rendering.

Provides a matplotlib canvas that renders:
- 2D cross-section of the earth model (layers + bodies)
- Inversion result images (resistivity tomography)
- Pseudosections of raw ERT data (smooth filled contours, not scatter dots)
- Profile plots for magnetic / gravity / seismic
- GPR radargram display
- Spectral IP response

All visualizations use a dark, professional theme consistent with the
petroppo COMSOL-grade interface. Colormaps are perceptually uniform (turbo /
inferno) for publication-quality results.
"""
from __future__ import annotations

import numpy as np
from scipy.interpolate import griddata

from PySide6.QtWidgets import QVBoxLayout, QWidget

import matplotlib
matplotlib.use("QtAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.colors import LogNorm, Normalize
from matplotlib.ticker import MaxNLocator

from ..core import EarthModel, InversionResult, get_logger
from .style import (
    GEO_COLORS, MPL_FACE, MPL_GRID, MPL_TEXT, MPL_MUTED, MPL_SPINE,
    MPL_ACCENT, MPL_ACCENT2, RESISTIVITY_CMAP, DEFAULT_CMAP,
)

_log = get_logger("gui.viz")

# ============================================================================
# Global matplotlib dark styling — applied once per canvas
# ============================================================================
_MPL_RC = {
    "figure.facecolor": MPL_FACE,
    "axes.facecolor": MPL_FACE,
    "axes.edgecolor": MPL_SPINE,
    "axes.labelcolor": MPL_TEXT,
    "axes.titlecolor": MPL_TEXT,
    "axes.titleweight": "bold",
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "axes.grid": True,
    "grid.color": MPL_GRID,
    "grid.alpha": 0.5,
    "grid.linestyle": "--",
    "grid.linewidth": 0.6,
    "xtick.color": MPL_MUTED,
    "ytick.color": MPL_MUTED,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "text.color": MPL_TEXT,
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 10,
    "axes.linewidth": 0.8,
}


class ModelCanvas(QWidget):
    """A matplotlib-based canvas for rendering earth models and results."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.fig = Figure(figsize=(9, 6.5), dpi=100, facecolor=MPL_FACE)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setStyleSheet(
            f"background: {MPL_FACE}; border: none;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.canvas)
        self._show_empty()

    # ---- internal helpers ------------------------------------------------
    def _clear(self):
        self.fig.clear()

    def _style_axes(self, ax):
        """Apply dark-theme styling to an axes object."""
        ax.set_facecolor(MPL_FACE)
        for spine in ax.spines.values():
            spine.set_color(MPL_SPINE)
            spine.set_linewidth(0.8)
        ax.tick_params(colors=MPL_MUTED, which="both", length=4, width=0.6)
        ax.grid(True, color=MPL_GRID, alpha=0.5, linestyle="--", linewidth=0.6)
        return ax

    def _style_colorbar(self, cbar, label: str):
        """Apply dark-theme styling to a colorbar."""
        cbar.set_label(label, color=MPL_TEXT, fontsize=10, fontweight="bold")
        cbar.ax.tick_params(colors=MPL_MUTED, length=3)
        cbar.outline.set_edgecolor(MPL_SPINE)
        cbar.outline.set_linewidth(0.6)
        return cbar

    def _finish(self, fig=None):
        """Tight layout + draw."""
        f = fig or self.fig
        try:
            f.tight_layout(pad=1.2)
        except Exception:
            pass
        self.canvas.draw()

    # ---- placeholder -----------------------------------------------------
    def _show_empty(self):
        """Show a placeholder message on the dark canvas."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)
            ax.grid(False)
            ax.text(0.5, 0.55, "petroppo", ha="center", va="center",
                    fontsize=28, color=MPL_ACCENT, fontweight="bold",
                    alpha=0.9, transform=ax.transAxes)
            ax.text(0.5, 0.42, "Earth Model Viewer", ha="center", va="center",
                    fontsize=13, color=MPL_MUTED, fontweight="normal",
                    transform=ax.transAxes)
            ax.text(0.5, 0.33, "Select a model or run a simulation\nto display results",
                    ha="center", va="center", fontsize=10, color=MPL_MUTED,
                    alpha=0.7, transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
        self.canvas.draw()

    # ---- cross-section ---------------------------------------------------
    def draw_cross_section(self, model: EarthModel, y: float = 0.0,
                           title: str = ""):
        """Draw a 2D vertical cross-section with smooth filled layers and bodies."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)
            ax.grid(False)

            x0, x1 = model.extent_x
            z_max = model.max_depth

            # filled layers (smooth horizontal bands)
            for lay in model.layers:
                z_top = lay.top_depth
                z_bot = lay.bottom_depth
                color = lay.color
                ax.axhspan(z_top, z_bot, xmin=0, xmax=1,
                           color=color, alpha=0.55, zorder=1)
                # subtle layer boundary line
                ax.axhline(z_top, color="#0f1116", linewidth=0.8,
                           alpha=0.4, zorder=2)
                # label at center
                z_mid = (z_top + z_bot) / 2
                ax.text(x1 * 0.5, z_mid,
                        f"{lay.name}\n{lay.resistivity:.0f} \u03a9\u00b7m",
                        ha="center", va="center", fontsize=9,
                        color="#ffffff", fontweight="bold",
                        bbox=dict(boxstyle="round,pad=0.3",
                                  facecolor="#0f1116", alpha=0.6,
                                  edgecolor="none"),
                        zorder=5)

            # bodies as smooth filled ellipses
            for b in model.bodies:
                ellipse = plt.matplotlib.patches.Ellipse(
                    (b.cx, b.cz), width=2 * b.rx, height=2 * b.rz,
                    facecolor=self._body_color(b.resistivity),
                    edgecolor="#ffffff", linewidth=2, alpha=0.85,
                    zorder=4,
                )
                ax.add_patch(ellipse)
                ax.text(b.cx, b.cz, f"{b.label}\n{b.resistivity:.0f} \u03a9\u00b7m",
                        ha="center", va="center", fontsize=8,
                        color="#ffffff", fontweight="bold",
                        bbox=dict(boxstyle="round,pad=0.25",
                                  facecolor="#0f1116", alpha=0.75,
                                  edgecolor="none"),
                        zorder=6)

            # surface line + annotation
            ax.axhline(0, color=MPL_ACCENT, linewidth=2.5, zorder=3)
            ax.annotate("SURFACE", xy=(x0 + 2, 0), fontsize=9,
                        color=MPL_ACCENT, va="bottom", fontweight="bold")

            ax.set_xlim(x0, x1)
            ax.set_ylim(z_max, 0)  # depth increases downward
            ax.set_xlabel("Distance (m)", color=MPL_TEXT)
            ax.set_ylabel("Depth (m)", color=MPL_TEXT)
            ax.set_title(title or f"Cross-Section: {model.name}",
                         fontsize=14, fontweight="bold", color=MPL_TEXT,
                         pad=12)
        self._finish()

    # ---- inversion result ------------------------------------------------
    def draw_inversion(self, result: InversionResult, title: str = ""):
        """Draw the inverted 2D resistivity model as a smooth filled contour."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)
            ax.grid(False)

            model = np.asarray(result.model, dtype=float)
            nz, nx = model.shape  # (rows=depth, cols=x)

            extent = getattr(result, "extent", None)
            cell_size = getattr(result, "cell_size", 1.0)
            if extent and len(extent) >= 4:
                x_extent = extent[1] - extent[0]
                z_extent = extent[3] - extent[2]
                x0 = extent[0]
                z0 = extent[2]
            else:
                x_extent = nx * cell_size
                z_extent = nz * cell_size
                x0 = 0.0
                z0 = 0.0

            # log-scale resistivity colormap
            vmin = max(model.min(), 1.0)
            vmax = max(model.max(), vmin * 5)
            norm = LogNorm(vmin=vmin, vmax=vmax)

            im = ax.imshow(model, aspect="auto", origin="upper",
                           extent=[x0, x0 + x_extent, z0 + z_extent, z0],
                           cmap=RESISTIVITY_CMAP, norm=norm,
                           interpolation="bilinear")

            cbar = self.fig.colorbar(im, ax=ax, shrink=0.82, pad=0.02)
            self._style_colorbar(cbar, "Resistivity (\u03a9\u00b7m)")

            # electrode positions at surface
            ax.axhline(z0, color=MPL_ACCENT, linewidth=2, alpha=0.8)

            ax.set_xlim(x0, x0 + x_extent)
            ax.set_ylim(z0 + z_extent, z0)
            ax.set_xlabel("Distance (m)", color=MPL_TEXT)
            ax.set_ylabel("Depth (m)", color=MPL_TEXT)
            rmse = getattr(result, "rmse", 0.0)
            n_iter = getattr(result, "n_iter", 0)
            ax.set_title(
                title or f"Inverted Resistivity Model  (RMSE={rmse:.4f}, {n_iter} iters)",
                fontsize=13, fontweight="bold", color=MPL_TEXT, pad=12)
        self._finish()

    # ---- pseudosection ---------------------------------------------------
    def draw_pseudosection(self, readings: list[dict],
                           title: str = "Pseudosection"):
        """Draw an ERT pseudosection as a smooth filled interpolated contour.

        Instead of scattered dots, the apparent-resistivity readings are
        interpolated onto a regular grid and displayed as a filled contour
        (tricontourf), producing the smooth, publication-quality appearance
        expected in professional geophysical software.
        """
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)
            ax.grid(False)

            if not readings:
                ax.text(0.5, 0.5, "No data available", ha="center",
                        va="center", transform=ax.transAxes,
                        fontsize=14, color=MPL_MUTED)
                self.canvas.draw()
                return

            xs = np.array([r["x_mid"] for r in readings], dtype=float)
            zs = np.array([r["depth"] for r in readings], dtype=float)
            rhos = np.array([r["rho_a"] for r in readings], dtype=float)

            # log-scale color mapping
            vmin = max(rhos.min(), 1.0)
            vmax = max(rhos.max(), vmin * 2)
            norm = LogNorm(vmin=vmin, vmax=vmax)

            # Build a smooth filled contour via tricontourf (handles the
            # irregular scatter of pseudo-positions naturally).
            n_levels = 24
            levels = np.logspace(np.log10(vmin), np.log10(vmax), n_levels)

            try:
                tcf = ax.tricontourf(xs, zs, rhos, levels=levels,
                                     cmap=RESISTIVITY_CMAP, norm=norm,
                                     extend="both")
                # thin contour lines for crisp boundaries
                ax.tricontour(xs, zs, rhos, levels=levels,
                              colors="none", linewidths=0)
            except Exception:
                # Fallback: regular-grid interpolation if tricontourf fails
                xi = np.linspace(xs.min(), xs.max(), 120)
                zi = np.linspace(zs.min(), zs.max(), 80)
                XI, ZI = np.meshgrid(xi, zi)
                RI = griddata((xs, zs), rhos, (XI, ZI), method="cubic")
                tcf = ax.contourf(XI, ZI, RI, levels=n_levels,
                                  cmap=RESISTIVITY_CMAP, norm=norm,
                                  extend="both")

            cbar = self.fig.colorbar(tcf, ax=ax, shrink=0.82, pad=0.02)
            self._style_colorbar(cbar, "Apparent Resistivity (\u03a9\u00b7m)")

            ax.set_xlim(xs.min() * 0.9, xs.max() * 1.05)
            # depth increases downward (inverted y-axis)
            ax.set_ylim(zs.max() * 1.1, zs.min() * 0.9)
            ax.set_xlabel("Midpoint (m)", color=MPL_TEXT)
            ax.set_ylabel("Investigation Depth (m)", color=MPL_TEXT)
            ax.set_title(title, fontsize=13, fontweight="bold",
                         color=MPL_TEXT, pad=12)
        self._finish()

    # ---- 1D profile (gravity, magnetic, seismic) -------------------------
    def draw_profile(self, x: np.ndarray, y: np.ndarray,
                     xlabel: str = "Distance (m)", ylabel: str = "Value",
                     title: str = "Profile", color: str = None):
        """Draw a polished 1D profile plot."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)

            line_color = color or MPL_ACCENT
            ax.plot(x, y, color=line_color, linewidth=2.2, marker="o",
                    markersize=4.5, markerfacecolor=MPL_FACE,
                    markeredgewidth=1.5, markeredgecolor=line_color, zorder=3)
            ax.fill_between(x, y, np.nanmean(y), alpha=0.18,
                            color=line_color, zorder=1)
            ax.axhline(np.nanmean(y), color=MPL_MUTED, linestyle="--",
                       linewidth=1, alpha=0.6, zorder=2)

            ax.set_xlabel(xlabel, color=MPL_TEXT)
            ax.set_ylabel(ylabel, color=MPL_TEXT)
            ax.set_title(title, fontsize=13, fontweight="bold",
                         color=MPL_TEXT, pad=12)
        self._finish()

    # ---- GPR radargram ---------------------------------------------------
    def draw_radargram(self, traces: list[list],
                       title: str = "GPR Radargram", dt: float = None):
        """Draw a GPR radargram as a filled color image."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax = self.fig.add_subplot(111)
            self._style_axes(ax)
            ax.grid(False)

            if not traces:
                ax.text(0.5, 0.5, "No GPR data", ha="center", va="center",
                        transform=ax.transAxes, fontsize=14, color=MPL_MUTED)
                self.canvas.draw()
                return

            data = np.array(traces).T  # time x position
            nt, ntr = data.shape

            if dt is not None:
                t_end = nt * dt
                extent = [0, ntr, t_end, 0]
                ylabel = "Two-way Time (s)"
            else:
                extent = [0, ntr, nt, 0]
                ylabel = "Time sample"

            im = ax.imshow(data, aspect="auto", cmap="seismic",
                           extent=extent, interpolation="bilinear",
                           vmin=-np.nanmax(np.abs(data)) * 0.8,
                           vmax=np.nanmax(np.abs(data)) * 0.8)
            cbar = self.fig.colorbar(im, ax=ax, shrink=0.82, pad=0.02)
            self._style_colorbar(cbar, "Amplitude")

            ax.set_xlabel("Trace position", color=MPL_TEXT)
            ax.set_ylabel(ylabel, color=MPL_TEXT)
            ax.set_title(title, fontsize=13, fontweight="bold",
                         color=MPL_TEXT, pad=12)
        self._finish()

    # ---- spectral IP -----------------------------------------------------
    def draw_spectral(self, frequencies: list, rho_a: list, phase: list,
                      title: str = "Spectral IP Response"):
        """Draw spectral IP data: resistivity magnitude and phase vs frequency."""
        self._clear()
        with plt.rc_context(_MPL_RC):
            ax1 = self.fig.add_subplot(211)
            self._style_axes(ax1)
            ax2 = self.fig.add_subplot(212)
            self._style_axes(ax2)

            freqs = np.array(frequencies, dtype=float)
            ax1.semilogx(freqs, rho_a, color=MPL_ACCENT, linewidth=2.2,
                         marker="s", markersize=5,
                         markerfacecolor=MPL_FACE, markeredgecolor=MPL_ACCENT)
            ax1.set_ylabel("Magnitude (\u03a9\u00b7m)", color=MPL_TEXT)
            ax1.set_title(title, fontsize=13, fontweight="bold",
                          color=MPL_TEXT, pad=12)

            ax2.semilogx(freqs, phase, color=MPL_ACCENT2, linewidth=2.2,
                         marker="s", markersize=5,
                         markerfacecolor=MPL_FACE, markeredgecolor=MPL_ACCENT2)
            ax2.set_xlabel("Frequency (Hz)", color=MPL_TEXT)
            ax2.set_ylabel("Phase (degrees)", color=MPL_TEXT)
        self._finish()

    # ---- body color helper ----------------------------------------------
    def _body_color(self, resistivity: float) -> str:
        """Choose a color for a body based on its resistivity."""
        if resistivity < 10:
            return GEO_COLORS["water"]
        elif resistivity < 50:
            return GEO_COLORS["clay"]
        elif resistivity < 200:
            return GEO_COLORS["sand"]
        elif resistivity < 500:
            return GEO_COLORS["limestone"]
        else:
            return GEO_COLORS["reservoir"]
