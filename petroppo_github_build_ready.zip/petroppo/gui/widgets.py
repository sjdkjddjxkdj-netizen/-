"""Shared UI widgets — cards, titles, panels, and COMSOL-style ribbon helpers."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget,
    QToolButton, QToolBar,
)

from .style import BG, BG_WHITE, BG_PANEL, BORDER, BORDER_LIGHT, TEXT, MUTED, ACCENT


def make_title(text: str, subtitle: str = "") -> QWidget:
    """Section title with an optional subtitle."""
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 4)
    lay.setSpacing(2)
    t = QLabel(text)
    t.setProperty("role", "title")
    lay.addWidget(t)
    if subtitle:
        s = QLabel(subtitle)
        s.setProperty("role", "subtitle")
        lay.addWidget(s)
    return w


def make_stat_card(title: str, value: str, subtitle: str = "") -> QFrame:
    """Statistics card: title + large value + subtitle line."""
    card = QFrame()
    card.setProperty("role", "card")
    card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
    lay = QVBoxLayout(card)
    lay.setContentsMargins(18, 16, 18, 16)
    lay.setSpacing(4)
    t = QLabel(title)
    t.setProperty("role", "subtitle")
    v = QLabel(value)
    v.setProperty("role", "value")
    lay.addWidget(t)
    lay.addWidget(v)
    if subtitle:
        s = QLabel(subtitle)
        s.setProperty("role", "muted")
        lay.addWidget(s)
    return card


def make_panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    """Titled panel — returns (panel, inner layout)."""
    panel = QFrame()
    panel.setProperty("role", "panel")
    outer = QVBoxLayout(panel)
    outer.setContentsMargins(14, 12, 14, 12)
    outer.setSpacing(8)
    t = QLabel(title)
    t.setProperty("role", "section")
    outer.addWidget(t)
    body = QVBoxLayout()
    body.setSpacing(6)
    outer.addLayout(body)
    return panel, body


def hline() -> QFrame:
    """Horizontal separator line."""
    ln = QFrame()
    ln.setFrameShape(QFrame.Shape.HLine)
    ln.setStyleSheet(f"color: {BORDER}; background-color: {BORDER}; max-height: 1px;")
    return ln


def section_label(text: str) -> QLabel:
    """A bold section label."""
    lbl = QLabel(text)
    lbl.setProperty("role", "section")
    return lbl


def make_ribbon_button(text: str, tooltip: str = "") -> QToolButton:
    """Create a COMSOL-style ribbon button (icon above text)."""
    btn = QToolButton()
    btn.setText(text)
    btn.setToolTip(tooltip or text)
    btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
    btn.setMinimumWidth(70)
    btn.setMinimumHeight(56)
    return btn


def make_ribbon_group(title: str, buttons: list[QToolButton]) -> QFrame:
    """Create a ribbon group with a title label at the bottom and buttons above."""
    group = QFrame()
    group.setProperty("role", "ribbon-group")
    lay = QVBoxLayout(group)
    lay.setContentsMargins(8, 6, 8, 2)
    lay.setSpacing(4)
    btn_row = QHBoxLayout()
    btn_row.setSpacing(4)
    for btn in buttons:
        btn_row.addWidget(btn)
    lay.addLayout(btn_row)
    lbl = QLabel(title)
    lbl.setProperty("role", "muted")
    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    lbl.setStyleSheet("font-size: 10px; color: #8893a5; padding: 2px; font-weight: bold; letter-spacing: 0.5px;")
    lay.addWidget(lbl)
    return group
