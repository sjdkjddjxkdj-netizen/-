"""HAL layer — hardware abstraction for geophysical instruments.

petroppo is fully self-contained via the virtual instrument
(:class:`SimulatorDevice`), but the same :class:`BaseDevice` interface is
implemented by real-hardware drivers so the processing pipeline is identical
whether data comes from a simulation or a real field instrument:

* :class:`SimulatorDevice` — virtual instrument (no hardware required)
* :class:`SerialDevice` — RS-232 / USB-serial resistivity meters
* :class:`TCPDevice` — networked (Ethernet/Wi-Fi) instruments
* :class:`FileDevice` — CSV / RES2DINV .dat file replay / import

The :class:`AcquisitionController` orchestrates a complete survey loop over
any of these devices with real-time QC.
"""
from .base import BaseDevice, DeviceCapabilities
from .simulator import SimulatorDevice
from .serial_device import SerialDevice, SerialProtocol, PROTOCOLS, list_serial_ports
from .tcp_device import TCPDevice, TCPProtocol, TCP_PROTOCOLS
from .file_device import FileDevice
from .acquisition import (
    AcquisitionController, AcquisitionPlan, AcquisitionResult,
    build_ert_plan, build_profile_plan,
)
from .manager import (
    DeviceManager, register_driver, make_device, available_drivers,
)

__all__ = [
    # base
    "BaseDevice", "DeviceCapabilities",
    # drivers
    "SimulatorDevice", "SerialDevice", "TCPDevice", "FileDevice",
    "SerialProtocol", "PROTOCOLS", "list_serial_ports",
    "TCPProtocol", "TCP_PROTOCOLS",
    # acquisition
    "AcquisitionController", "AcquisitionPlan", "AcquisitionResult",
    "build_ert_plan", "build_profile_plan",
    # manager
    "DeviceManager", "register_driver", "make_device", "available_drivers",
]
