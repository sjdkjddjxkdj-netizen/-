"""Acquisition controller — orchestrates a live geophysical survey.

The :class:`AcquisitionController` ties together a :class:`BaseDevice` (real or
virtual), a survey geometry (electrode configurations / station list), the
real-time QC pipeline, and an optional callback for live GUI updates.  It runs
a complete acquisition loop:

    for each measurement point in the survey plan:
        reading = device.measure(**params)
        qc.update(reading)
        store(reading)
        progress_callback(reading, qc_stats)

This is the layer that turns "a driver that can take one reading" into "a
complete field survey" — the same controller works with the virtual
:class:`SimulatorDevice`, a serial resistivity meter, a networked instrument,
or a file replay source, because they all share the :class:`BaseDevice`
contract.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

import numpy as np

from ..core import (
    Measurement, MeasurementMethod, Survey, get_logger,
)
from .base import BaseDevice

_log = get_logger("hal.acquisition")


ProgressCallback = Callable[[Measurement, dict], None]
"""Signature: callback(reading, qc_summary) -> None"""


@dataclass
class AcquisitionPlan:
    """Describes the full set of measurement points for a survey.

    Attributes
    ----------
    points : list[dict]
        Each dict is a kwargs bundle passed to ``device.measure()``.
        Typical keys: ``x, y, z, a, current, frequency, method``.
    method : MeasurementMethod
    label : str
        Human-readable survey label.
    """
    points: list[dict] = field(default_factory=list)
    method: MeasurementMethod = MeasurementMethod.ERT
    label: str = "survey"


@dataclass
class AcquisitionResult:
    """Result of a completed acquisition run."""
    measurements: list[Measurement] = field(default_factory=list)
    n_total: int = 0
    n_good: int = 0
    n_bad: int = 0
    duration: float = 0.0
    qc_history: list[dict] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)
    aborted: bool = False

    @property
    def overall_quality(self) -> float:
        return self.n_good / self.n_total if self.n_total else 0.0


class AcquisitionController:
    """Drive a device through a complete survey acquisition plan.

    Parameters
    ----------
    device : BaseDevice
        Connected (or connectable) instrument.
    plan : AcquisitionPlan
        Survey plan — list of measurement points.
    noise_floor : float
        Relative noise floor used by the QC pass/fail threshold.
    delay : float
        Artificial delay between readings (seconds).  Useful for replay
        pacing and for letting real instruments settle.
    """

    def __init__(self, device: BaseDevice, plan: AcquisitionPlan,
                 noise_floor: float = 0.02, delay: float = 0.0):
        self.device = device
        self.plan = plan
        self.noise_floor = noise_floor
        self.delay = delay
        self._abort = False
        self._log = get_logger(f"hal.acq.{device.info.name}")

    # --- public API ------------------------------------------------------ #
    def abort(self) -> None:
        """Request the acquisition to stop after the current reading."""
        self._abort = True
        self._log.info("Acquisition abort requested")

    def run(self, progress: ProgressCallback | None = None,
            auto_connect: bool = True) -> AcquisitionResult:
        """Execute the full acquisition loop.

        Parameters
        ----------
        progress : callable, optional
            Called after every reading with ``(measurement, qc_summary)``.
        auto_connect : bool
            If True, connect the device if it is not already connected.
        """
        if auto_connect and not self.device.is_connected():
            self.device.connect()

        result = AcquisitionResult()
        t0 = time.time()
        self._abort = False

        # rolling QC statistics
        from ..processing.qc import quality_score
        rolling: list[Measurement] = []

        for i, params in enumerate(self.plan.points):
            if self._abort:
                result.aborted = True
                self._log.warning("Acquisition aborted at reading %d/%d",
                                  i, len(self.plan.points))
                break
            try:
                m = self.device.measure(**params)
            except Exception as exc:
                self._log.error("Reading %d failed: %s", i, exc)
                result.issues.append(f"Reading {i}: {exc}")
                result.n_total += 1
                result.n_bad += 1
                continue

            result.measurements.append(m)
            result.n_total += 1
            rolling.append(m)
            # Real-time QC: score the latest reading against the rolling set
            qc_summary = self._qc(m, rolling)
            result.qc_history.append(qc_summary)
            if qc_summary["pass"]:
                result.n_good += 1
            else:
                result.n_bad += 1
                result.issues.append(
                    f"Reading {i} at x={m.x:.1f}: {qc_summary['reason']}")

            if progress is not None:
                progress(m, qc_summary)

            if self.delay > 0:
                time.sleep(self.delay)

        result.duration = time.time() - t0
        self._log.info("Acquisition complete: %d readings (%d good, %d bad) "
                       "in %.2fs", result.n_total, result.n_good,
                       result.n_bad, result.duration)
        return result

    # --- helpers --------------------------------------------------------- #
    def _qc(self, m: Measurement, rolling: list[Measurement]) -> dict:
        """Lightweight per-reading QC for real-time feedback."""
        rho = m.values.get("rho_a")
        if rho is None:
            return {"pass": True, "reason": "no rho_a field", "quality": m.quality}
        # Check for non-finite / non-positive
        if not np.isfinite(rho) or rho <= 0:
            return {"pass": False, "reason": f"invalid rho_a={rho}",
                    "quality": 0.0}
        # Check against rolling median (if we have enough data)
        rhos = np.array([r.values.get("rho_a", np.nan) for r in rolling])
        rhos = rhos[np.isfinite(rhos) & (rhos > 0)]
        if len(rhos) >= 4:
            med = np.median(rhos)
            if med <= 0:
                return {"pass": True, "reason": "ok", "quality": m.quality}
            rel_dev = abs(rho - med) / med
            # A reading is "bad" if it deviates by > 5x the noise floor
            # from the local median (likely a spike / bad contact)
            if rel_dev > 5.0 * self.noise_floor and rel_dev > 0.3:
                return {"pass": False,
                        "reason": f"outlier (rel_dev={rel_dev:.2f})",
                        "quality": max(0.0, 1.0 - rel_dev)}
        return {"pass": True, "reason": "ok", "quality": m.quality}


# --------------------------------------------------------------------- #
#  Plan builders                                                        #
# --------------------------------------------------------------------- #
def build_ert_plan(n_electrodes: int = 24, spacing: float = 5.0,
                   config: str = "wenner",
                   method: MeasurementMethod = MeasurementMethod.ERT,
                   current: float = 1.0) -> AcquisitionPlan:
    """Build an ERT acquisition plan from electrode geometry."""
    from ..simulator.forward import wenner_geometry, dipole_dipole_geometry
    geom_fn = (dipole_dipole_geometry if config == "dipole-dipole"
               else wenner_geometry)
    geometry = geom_fn(n_electrodes, spacing)
    points: list[dict] = []
    for (c1, p1, p2, c2, a, a_eff) in geometry:
        x_mid = 0.25 * (c1 + p1 + p2 + c2)
        points.append({
            "method": method, "x": x_mid, "y": 0.0,
            "z": a_eff * 0.5, "a": a_eff,
            "current": current,
            "c1": c1, "p1": p1, "p2": p2, "c2": c2,
        })
    return AcquisitionPlan(points=points, method=method,
                           label=f"ERT {config} {n_electrodes}el")


def build_profile_plan(x_start: float, x_end: float, n: int,
                       method: MeasurementMethod,
                       spacing: float | None = None) -> AcquisitionPlan:
    """Build a simple 1-D profile acquisition plan (gravity/magnetic/seismic)."""
    xs = np.linspace(x_start, x_end, n)
    points = [{"method": method, "x": float(x), "y": 0.0, "z": 0.0,
               "a": spacing or 5.0} for x in xs]
    return AcquisitionPlan(points=points, method=method,
                           label=f"{method.value} profile {n}pts")
