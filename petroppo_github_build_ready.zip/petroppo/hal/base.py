"""Abstract device interface — all drivers implement this."""
from __future__ import annotations

import abc
import time
from dataclasses import dataclass
from typing import Any

from ..core import Measurement, MeasurementMethod, DeviceInfo, DeviceStatus, get_logger


@dataclass
class DeviceCapabilities:
    """Declared capabilities of an instrument."""
    methods: list[MeasurementMethod]
    max_frequency: float = 1e4       # Hz
    min_frequency: float = 1e-3      # Hz
    max_current: float = 2.5         # A
    max_voltage: float = 400.0       # V
    channels: int = 64
    noise_floor: float = 1e-6        # V


class BaseDevice(abc.ABC):
    """Abstract interface implemented by every instrument/driver."""

    #: Driver name — used for registry lookup
    driver_name: str = "base"

    def __init__(self, info: DeviceInfo):
        self.info = info
        self._status = DeviceStatus.DISCONNECTED
        self._log = get_logger(f"hal.{info.driver}")
        self._capabilities: DeviceCapabilities | None = None

    # --- lifecycle ---
    @abc.abstractmethod
    def connect(self) -> None:
        """Connect to the instrument."""

    @abc.abstractmethod
    def disconnect(self) -> None:
        """Disconnect from the instrument."""

    @abc.abstractmethod
    def is_connected(self) -> bool:
        """Is the instrument connected?"""

    # --- measurement ---
    @abc.abstractmethod
    def measure(self, **params: Any) -> Measurement:
        """Execute a single reading and return it."""

    def measure_sequence(self, n: int, **params: Any) -> list[Measurement]:
        """Execute a sequence of readings. Default impl calls measure n times."""
        out: list[Measurement] = []
        for _ in range(n):
            out.append(self.measure(**params))
            time.sleep(0.0)
        return out

    # --- capabilities & status ---
    def capabilities(self) -> DeviceCapabilities:
        if self._capabilities is None:
            self._capabilities = self._describe_capabilities()
        return self._capabilities

    @abc.abstractmethod
    def _describe_capabilities(self) -> DeviceCapabilities:
        """Describe the instrument's capabilities."""

    @property
    def status(self) -> DeviceStatus:
        return self._status

    def _set_status(self, s: DeviceStatus) -> None:
        self._status = s
        self.info.status = s
        self._log.debug("Status <- %s (%s)", s.value, self.info.name)

    def __repr__(self) -> str:
        return f"<{self.driver_name} {self.info.name} [{self._status.value}]>"
