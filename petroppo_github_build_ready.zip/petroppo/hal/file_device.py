"""File / CSV import device driver — replay recorded data from files.

This driver implements the :class:`BaseDevice` interface for **file-based data
sources**: CSV exports from data loggers, RES2DINV ``.dat`` files, legacy
survey archives, or any tabular text file containing geophysical readings.

It is a "virtual replay" device — it reads a file on disk and yields the
recorded measurements one at a time (or in sequence) through the standard
:meth:`measure` / :meth:`measure_sequence` API.  This lets the rest of the
processing pipeline (QC, inversion, interpretation) operate on real recorded
data **exactly as it would on live instrument data**, without any special-case
code paths.

Supported file formats
----------------------
* **CSV** — comma/space/semicolon/tab separated; the column mapping is
  auto-detected from the header (looks for ``rho_a``, ``resistivity``,
  ``v``, ``voltage``, ``i``, ``current``, ``x``, ``y``, ``a``, ``spacing``,
  ``phase``, ``g``, ``gravity``, ``b_total``, ``mag``, ``t_first``, ``freq``).
* **RES2DINV .dat** — the widely used Wenner/Schlumberger format
  (profile distance, electrode spacing, apparent resistivity).
* **Generic text** — whitespace-separated numeric columns with a user-provided
  column-name list.
"""
from __future__ import annotations

import csv
import os
import time
from typing import Any

import numpy as np

from ..core import (
    Measurement, MeasurementMethod, DeviceInfo, DeviceStatus,
    DeviceConnectionError, HardwareError, new_id, get_logger,
)
from .base import BaseDevice, DeviceCapabilities

_log = get_logger("hal.file")


# Column-name aliases recognised in CSV headers
_COLUMN_ALIASES: dict[str, list[str]] = {
    "x": ["x", "x_mid", "midpoint", "position", "dist", "distance", "station"],
    "y": ["y", "northing", "north"],
    "z": ["z", "depth", "elevation", "elev"],
    "a": ["a", "spacing", "electrode_spacing", "level", "n"],
    "rho_a": ["rho_a", "rhoa", "resistivity", "apparent_resistivity",
              "rho_app", "ra"],
    "v": ["v", "voltage", "potential", "vp"],
    "i": ["i", "current", "curr", "injection"],
    "phase": ["phase", "ip", "chargeability", "m"],
    "g": ["g", "gravity", "bouguer", "mgal"],
    "b_total": ["b_total", "btotal", "mag", "magnetic", "nt", "b"],
    "t_first": ["t_first", "tfirst", "first_arrival", "traveltime", "t"],
    "freq": ["freq", "frequency", "f"],
    "quality": ["quality", "q", "std", "stddev"],
}


def _normalise_header(name: str) -> str:
    n = name.strip().lower().replace(" ", "_").replace("-", "_")
    for canon, aliases in _COLUMN_ALIASES.items():
        if n in aliases:
            return canon
    return n


def _guess_delimiter(sample: str) -> str:
    """Auto-detect the delimiter from a sample line.

    Returns the delimiter character, or ``None`` if the file appears to be
    whitespace-separated (in which case the caller should use
    :meth:`_load_whitespace`).
    """
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        return dialect.delimiter
    except csv.Error:
        # fall back to whitespace
        return None  # type: ignore[return-value]


def _parse_dat(path: str) -> list[dict[str, float]]:
    """Parse a RES2DINV-style .dat file.

    Format (simplified Wenner):
        n_electrodes spacing
        x_mid  a  rho_a
        ...
    Lines starting with ``#`` or ``!`` are comments.
    """
    rows: list[dict[str, float]] = []
    header_read = False
    with open(path, "r", errors="replace") as fh:
        for line in fh:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("!"):
                continue
            parts = s.replace(",", " ").split()
            if not header_read:
                # first non-comment line: electrode count + spacing
                header_read = True
                continue
            if len(parts) >= 3:
                try:
                    x = float(parts[0])
                    a = float(parts[1])
                    rho = float(parts[2])
                    rows.append({"x": x, "a": a, "rho_a": rho})
                except ValueError:
                    continue
    return rows


class FileDevice(BaseDevice):
    """Driver that replays recorded measurements from a data file.

    Parameters
    ----------
    info : DeviceInfo
        ``info.address`` is the path to the data file.
    method : MeasurementMethod, optional
        Override the measurement method (defaults to ``info.kind``).
    """

    driver_name = "file"

    def __init__(self, info: DeviceInfo, method: MeasurementMethod | None = None,
                 **kwargs: Any):
        super().__init__(info)
        self._method = method or info.kind
        self._rows: list[dict[str, float]] = []
        self._cursor = 0
        self._columns: list[str] = []

    # --- lifecycle ------------------------------------------------------- #
    def connect(self) -> None:
        if self.is_connected():
            return
        path = self.info.address
        if not path or not os.path.isfile(path):
            self._set_status(DeviceStatus.ERROR)
            raise DeviceConnectionError(
                f"Data file not found: '{path}'",
            )
        self._log.info("Loading data file: %s", path)
        try:
            self._rows = self._load(path)
        except Exception as exc:
            self._set_status(DeviceStatus.ERROR)
            raise DeviceConnectionError(
                f"Failed to parse data file '{path}'", detail=str(exc),
            ) from exc
        if not self._rows:
            raise DeviceConnectionError(
                f"No valid data rows found in '{path}'",
            )
        self._cursor = 0
        self._set_status(DeviceStatus.CONNECTED)
        self._log.info("Loaded %d readings from %s", len(self._rows), path)

    def disconnect(self) -> None:
        self._rows = []
        self._cursor = 0
        self._set_status(DeviceStatus.DISCONNECTED)
        self._log.info("Disconnected file source")

    def is_connected(self) -> bool:
        return self._status in (DeviceStatus.CONNECTED, DeviceStatus.ACQUIRING)

    # --- capabilities ---------------------------------------------------- #
    def _describe_capabilities(self) -> DeviceCapabilities:
        return DeviceCapabilities(
            methods=[self._method],
            max_frequency=1e4, min_frequency=1e-3,
            max_current=2.5, max_voltage=800.0,
            channels=1, noise_floor=1e-4,
        )

    # --- measurement ----------------------------------------------------- #
    def measure(self, **params: Any) -> Measurement:
        if not self.is_connected():
            raise DeviceConnectionError("File device not connected",
                                        detail=self.info.address)
        if self._cursor >= len(self._rows):
            # loop back to start (replay mode)
            self._cursor = 0
        row = self._rows[self._cursor]
        self._cursor += 1
        self._set_status(DeviceStatus.ACQUIRING)
        x = row.get("x", float(params.get("x", 0.0)))
        y = row.get("y", float(params.get("y", 0.0)))
        z = row.get("z", float(params.get("z", row.get("a", 5.0) * 0.5)))
        a = row.get("a", float(params.get("a", 5.0)))
        # build the values dict from the row
        values: dict[str, float] = {}
        for key in ("rho_a", "v", "i", "phase", "g", "b_total", "t_first", "freq"):
            if key in row:
                values[key] = row[key]
        values.setdefault("a", a)
        values.setdefault("i", 1.0)
        values.setdefault("freq", 1.0)
        quality = row.get("quality", 1.0)
        self._set_status(DeviceStatus.CONNECTED)
        return Measurement(
            id=new_id(),
            device_id=self.info.id,
            method=self._method,
            timestamp=time.time(),
            x=x, y=y, z=z,
            values=values,
            quality=float(quality),
            meta={"source": self.info.address, "row_index": self._cursor - 1},
        )

    def measure_sequence(self, n: int, **params: Any) -> list[Measurement]:
        """Return up to ``n`` remaining readings (or all if n <= 0)."""
        if n <= 0:
            n = len(self._rows) - self._cursor
        n = min(n, len(self._rows) - self._cursor)
        out: list[Measurement] = []
        for _ in range(n):
            out.append(self.measure(**params))
        return out

    @property
    def n_records(self) -> int:
        return len(self._rows)

    @property
    def remaining(self) -> int:
        return max(0, len(self._rows) - self._cursor)

    # --- file loading ---------------------------------------------------- #
    def _load(self, path: str) -> list[dict[str, float]]:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".dat":
            # Try RES2DINV format first; fall back to whitespace/CSV
            try:
                rows = _parse_dat(path)
                if rows:
                    return rows
            except Exception:
                pass
            return self._load_csv(path)
        # CSV / text — auto-detect
        return self._load_csv(path)

    def _load_csv(self, path: str) -> list[dict[str, float]]:
        rows: list[dict[str, float]] = []
        with open(path, "r", newline="", errors="replace") as fh:
            sample = fh.read(4096)
            fh.seek(0)
            delim = _guess_delimiter(sample)
            if delim is None:
                # whitespace-separated
                return self._load_whitespace(path)
            reader = csv.reader(fh, delimiter=delim)
            raw_header = next(reader, None)
            if raw_header is None:
                return []
            header = [_normalise_header(h) for h in raw_header]
            self._columns = header
            for raw_row in reader:
                if not raw_row or all(c.strip() == "" for c in raw_row):
                    continue
                if len(raw_row) < len(header):
                    continue
                record: dict[str, float] = {}
                for col, val in zip(header, raw_row):
                    try:
                        record[col] = float(val)
                    except ValueError:
                        continue
                if record:
                    rows.append(record)
        return rows

    def _load_whitespace(self, path: str) -> list[dict[str, float]]:
        rows: list[dict[str, float]] = []
        with open(path, "r", errors="replace") as fh:
            lines = [ln.strip() for ln in fh
                     if ln.strip() and not ln.lstrip().startswith("#")]
        if not lines:
            return []
        # try to interpret the first line as a header
        first = lines[0].split()
        is_header = any(c.lower() in
                        {alias for aliases in _COLUMN_ALIASES.values()
                         for alias in aliases}
                        for c in first)
        if is_header:
            header = [_normalise_header(c) for c in first]
            self._columns = header
            data_lines = lines[1:]
        else:
            # no header — assume positional x, a, rho_a
            header = ["x", "a", "rho_a"]
            self._columns = header
            data_lines = lines
        for ln in data_lines:
            parts = ln.replace(",", " ").split()
            if len(parts) < len(header):
                continue
            record: dict[str, float] = {}
            for col, val in zip(header, parts):
                try:
                    record[col] = float(val)
                except ValueError:
                    continue
            if record:
                rows.append(record)
        return rows
