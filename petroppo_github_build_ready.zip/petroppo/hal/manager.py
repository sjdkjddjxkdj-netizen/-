"""Device manager — driver registry and instrument lifecycle management."""
from __future__ import annotations

from typing import Callable

from ..core import DeviceInfo, DeviceNotFoundError, get_logger
from .base import BaseDevice
from .simulator import SimulatorDevice
from .serial_device import SerialDevice
from .tcp_device import TCPDevice
from .file_device import FileDevice


# Driver registry: name -> factory(info) -> BaseDevice
DriverFactory = Callable[[DeviceInfo], BaseDevice]

_REGISTRY: dict[str, DriverFactory] = {}


def register_driver(name: str, factory: DriverFactory) -> None:
    """Register a new driver."""
    _REGISTRY[name] = factory


def available_drivers() -> list[str]:
    return list(_REGISTRY.keys())


def make_device(info: DeviceInfo, **kwargs) -> BaseDevice:
    """Create a device based on its info. kwargs are passed to the driver if needed."""
    factory = _REGISTRY.get(info.driver)
    if factory is None:
        raise DeviceNotFoundError(
            f"Driver '{info.driver}' is not registered",
            detail=f"Available: {available_drivers()}",
        )
    try:
        return factory(info, **kwargs)
    except TypeError:
        return factory(info)


_log = get_logger("hal.manager")


def _simulator_factory(info: DeviceInfo, **kwargs):
    return SimulatorDevice(info, **kwargs)


def _serial_factory(info: DeviceInfo, **kwargs):
    return SerialDevice(info, **kwargs)


def _tcp_factory(info: DeviceInfo, **kwargs):
    return TCPDevice(info, **kwargs)


def _file_factory(info: DeviceInfo, **kwargs):
    return FileDevice(info, **kwargs)


# Register built-in drivers
register_driver("simulator", _simulator_factory)
register_driver("virtual", _simulator_factory)  # alias for self-contained mode
register_driver("serial", _serial_factory)
register_driver("tcp", _tcp_factory)
register_driver("file", _file_factory)


class DeviceManager:
    """Manages the lifecycle of instruments in the current session."""

    def __init__(self):
        self._devices: dict[str, BaseDevice] = {}
        self._log = _log

    def add(self, device: BaseDevice) -> None:
        self._devices[device.info.id] = device
        self._log.info("Added device: %s", device)

    def get(self, device_id: str) -> BaseDevice:
        if device_id not in self._devices:
            raise DeviceNotFoundError(device_id)
        return self._devices[device_id]

    def all(self) -> list[BaseDevice]:
        return list(self._devices.values())

    def remove(self, device_id: str) -> None:
        dev = self._devices.pop(device_id, None)
        if dev and dev.is_connected():
            dev.disconnect()

    def connect_all(self) -> None:
        for d in self._devices.values():
            try:
                if not d.is_connected():
                    d.connect()
            except Exception as exc:
                self._log.error("Failed to connect to %s: %s", d, exc)

    def disconnect_all(self) -> None:
        for d in self._devices.values():
            try:
                if d.is_connected():
                    d.disconnect()
            except Exception as exc:
                self._log.error("Failed to disconnect from %s: %s", d, exc)
