"""Serial device driver — read from real geophysical instruments over RS-232.

This driver implements the :class:`BaseDevice` interface for instruments that
communicate over a serial port (USB-to-serial adapters, RS-232 resistivity
meters, induced-polarisation receivers, magnetometers with serial output, etc.).

It supports a configurable ASCII protocol with a line-oriented request/response
pattern — the most common interface for field geophysical instruments.  The
protocol is fully described by a :class:`SerialProtocol` dataclass so that the
same driver can be adapted to many different instruments (ABEM Terrameter,
Syscal Pro, Geometrics, Iris Instruments, custom data loggers, …) by changing
the command strings and the response parser.

If ``pyserial`` is not installed, the driver still imports and can be
constructed, but :meth:`connect` raises a clear ``DeviceConnectionError`` so the
GUI can report the missing dependency gracefully.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from ..core import (
    Measurement, MeasurementMethod, DeviceInfo, DeviceStatus,
    DeviceConnectionError, HardwareError, new_id, get_logger,
)
from .base import BaseDevice, DeviceCapabilities

_log = get_logger("hal.serial")


# --------------------------------------------------------------------- #
#  Protocol description                                                 #
# --------------------------------------------------------------------- #
@dataclass
class SerialProtocol:
    """Declarative description of an instrument's serial protocol.

    Attributes
    ----------
    measure_command : str
        Command sent to request a reading (e.g. ``"MEAS\\r\\n"``).
        ``{x}``, ``{y}``, ``{a}``, ``{current}``, ``{freq}`` are substituted
        from the measure() kwargs.
    read_terminator : str
        Character(s) that mark the end of a response line.
    response_regex : str
        Regular expression with **named groups** used to parse the response.
        Recognised group names: ``rho``, ``v``, ``i``, ``phase``, ``g``,
        ``b_total``, ``t_first``, ``freq``, ``quality``.
    timeout : float
        Read timeout in seconds.
    baudrate : int
        Serial baud rate.
    bytesize, parity, stopbits
        Standard serial-line parameters.
    init_commands : list[str]
        Optional commands sent once after connect (e.g. ``"*RST\\r"``).
    """
    measure_command: str = "MEAS\r\n"
    read_terminator: str = "\r\n"
    response_regex: str = (
        r"R=(?P<rho>[-+0-9.]+E[+-]?[0-9]+|[-+0-9.]+)"
        r",V=(?P<v>[-+0-9.]+)"
        r",I=(?P<i>[-+0-9.]+)"
    )
    timeout: float = 5.0
    baudrate: int = 9600
    bytesize: int = 8
    parity: str = "N"
    stopbits: float = 1.0
    init_commands: list[str] = field(default_factory=list)


# A few well-known instrument protocols
PROTOCOLS: dict[str, SerialProtocol] = {
    "generic_ert": SerialProtocol(
        measure_command="MEAS\r\n",
        response_regex=(
            r"R=(?P<rho>[-+0-9.]+E[+-]?[0-9]+|[-+0-9.]+)"
            r",V=(?P<v>[-+0-9.]+)"
            r",I=(?P<i>[-+0-9.]+)"
        ),
        baudrate=9600,
    ),
    "syscal": SerialProtocol(
        measure_command="M\r",
        read_terminator="\r",
        response_regex=(
            r"(?P<rho>[-+0-9.]+)\s+(?P<v>[-+0-9.]+)\s+(?P<i>[-+0-9.]+)"
            r"(?:\s+(?P<phase>[-+0-9.]+))?"
        ),
        baudrate=115200,
    ),
    "abem": SerialProtocol(
        measure_command="MEAS\r\n",
        response_regex=(
            r"Rho=(?P<rho>[-+0-9.]+)\s+V=(?P<v>[-+0-9.]+)\s+I=(?P<i>[-+0-9.]+)"
        ),
        baudrate=9600,
    ),
}


def _serial_kwargs(proto: SerialProtocol) -> dict:
    """Build pyserial Serial() kwargs from a protocol description."""
    try:
        import serial  # noqa: F401
        from serial import PARITIES  # type: ignore
    except ImportError:
        return {}
    parity_map = {"N": PARITIES["N"], "E": PARITIES["E"],
                  "O": PARITIES["O"], "M": PARITIES["M"], "S": PARITIES["S"]}
    from serial import STOPBITS_ONE, STOPBITS_ONE_POINT_FIVE, STOPBITS_TWO
    sb_map = {1.0: STOPBITS_ONE, 1.5: STOPBITS_ONE_POINT_FIVE, 2.0: STOPBITS_TWO}
    from serial import EIGHTBITS, SEVENBITS, SIXBITS, FIVEBITS
    bs_map = {8: EIGHTBITS, 7: SEVENBITS, 6: SIXBITS, 5: FIVEBITS}
    return {
        "baudrate": proto.baudrate,
        "bytesize": bs_map.get(proto.bytesize, EIGHTBITS),
        "parity": parity_map.get(proto.parity, PARITIES["N"]),
        "stopbits": sb_map.get(proto.stopbits, STOPBITS_ONE),
        "timeout": proto.timeout,
    }


class SerialDevice(BaseDevice):
    """Driver for serial-port geophysical instruments.

    Parameters
    ----------
    info : DeviceInfo
        Must have ``address`` set to the serial port name
        (e.g. ``"/dev/ttyUSB0"`` or ``"COM3"``).
    protocol : SerialProtocol or str
        Either a :class:`SerialProtocol` instance or a key into the
        :data:`PROTOCOLS` registry (``"generic_ert"``, ``"syscal"``,
        ``"abem"``).
    """

    driver_name = "serial"

    def __init__(self, info: DeviceInfo, protocol: SerialProtocol | str = "generic_ert",
                 **kwargs: Any):
        super().__init__(info)
        if isinstance(protocol, str):
            if protocol not in PROTOCOLS:
                raise DeviceConnectionError(
                    f"Unknown serial protocol '{protocol}'",
                    detail=f"Available: {list(PROTOCOLS)}",
                )
            protocol = PROTOCOLS[protocol]
        self._proto = protocol
        self._serial = None  # type: ignore[assignment]
        self._parser = re.compile(protocol.response_regex)
        self._counter = 0

    # --- lifecycle ------------------------------------------------------- #
    def connect(self) -> None:
        if self.is_connected():
            return
        try:
            import serial
        except ImportError as exc:
            raise DeviceConnectionError(
                "pyserial is not installed — run `pip install pyserial`",
                detail=str(exc),
            ) from exc
        port = self.info.address or "/dev/ttyUSB0"
        self._log.info("Opening serial port %s @ %d baud...",
                       port, self._proto.baudrate)
        try:
            self._serial = serial.Serial(port=port, **_serial_kwargs(self._proto))
        except Exception as exc:
            self._set_status(DeviceStatus.ERROR)
            raise DeviceConnectionError(
                f"Cannot open serial port '{port}'", detail=str(exc),
            ) from exc
        # send init commands
        for cmd in self._proto.init_commands:
            self._serial.write(cmd.encode("ascii", errors="replace"))
            time.sleep(0.1)
        self._set_status(DeviceStatus.CONNECTED)
        self._log.info("Connected to %s on %s", self.info.name, port)

    def disconnect(self) -> None:
        if self._serial is not None:
            try:
                self._serial.close()
            except Exception:
                pass
            self._serial = None
        self._set_status(DeviceStatus.DISCONNECTED)
        self._log.info("Disconnected from %s", self.info.name)

    def is_connected(self) -> bool:
        if self._serial is None:
            return False
        try:
            return bool(getattr(self._serial, "is_open", False))
        except Exception:
            return False

    # --- capabilities ---------------------------------------------------- #
    def _describe_capabilities(self) -> DeviceCapabilities:
        method = self.info.kind
        return DeviceCapabilities(
            methods=[method],
            max_frequency=1e4 if method == MeasurementMethod.SPECTRAL else 1e4,
            min_frequency=1e-3,
            max_current=2.5,
            max_voltage=800.0,
            channels=64,
            noise_floor=1e-5,
        )

    # --- measurement ----------------------------------------------------- #
    def measure(self, **params: Any) -> Measurement:
        if not self.is_connected():
            raise DeviceConnectionError("Serial device not connected",
                                        detail=self.info.name)
        method: MeasurementMethod = params.get("method", self.info.kind)
        x = float(params.get("x", 0.0))
        y = float(params.get("y", 0.0))
        z = float(params.get("z", 0.0))
        a = float(params.get("a", 5.0))
        current = float(params.get("current", 1.0))
        freq = float(params.get("frequency", 1.0))

        self._counter += 1
        self._set_status(DeviceStatus.ACQUIRING)

        # Build & send command
        cmd = self._proto.measure_command.format(
            x=x, y=y, a=a, current=current, freq=freq)
        try:
            self._serial.reset_input_buffer()
            self._serial.write(cmd.encode("ascii", errors="replace"))
        except Exception as exc:
            self._set_status(DeviceStatus.ERROR)
            raise HardwareError(f"Serial write failed: {exc}") from exc

        # Read response (line-oriented)
        raw = self._read_line()
        self._set_status(DeviceStatus.CONNECTED)

        values = self._parse_response(raw, a=a, current=current, freq=freq)

        m = Measurement(
            id=new_id(),
            device_id=self.info.id,
            method=method,
            timestamp=time.time(),
            x=x, y=y, z=z,
            values=values,
            quality=float(values.pop("_quality", 1.0)),
            meta={"raw": raw, "port": self.info.address,
                  "protocol": getattr(self._proto, "__class__", SerialProtocol).__name__,
                  "baudrate": self._proto.baudrate},
        )
        return m

    def _read_line(self) -> str:
        """Read until the terminator, with timeout."""
        term = self._proto.read_terminator.encode("ascii", errors="replace")
        chunks: list[bytes] = []
        deadline = time.time() + self._proto.timeout
        while time.time() < deadline:
            ch = self._serial.read(1)
            if not ch:
                continue
            chunks.append(ch)
            if b"".join(chunks).endswith(term):
                break
        raw = b"".join(chunks).decode("ascii", errors="replace").strip()
        if not raw:
            raise HardwareError(
                "No response from instrument (timeout)",
                detail=f"port={self.info.address}, timeout={self._proto.timeout}s",
            )
        return raw

    def _parse_response(self, raw: str, *, a: float, current: float,
                        freq: float) -> dict[str, float]:
        """Parse the raw response line into a values dict."""
        match = self._parser.search(raw)
        values: dict[str, float] = {}
        if match:
            gd = match.groupdict()
            for key in ("rho", "v", "i", "phase", "g", "b_total",
                        "t_first", "freq", "quality"):
                val = gd.get(key)
                if val is not None:
                    try:
                        values[key] = float(val)
                    except ValueError:
                        pass
        # Normalise keys to petroppo convention
        if "rho" in values:
            values["rho_a"] = values.pop("rho")
        if "g" in values:
            values["g"] = values["g"]
        if "b_total" in values:
            values["b_total"] = values["b_total"]
        if "t_first" in values:
            values["t_first"] = values["t_first"]
        # Ensure we always report something
        if not values:
            self._log.warning("Could not parse response: %r", raw)
            values["raw"] = 0.0
        # carry bookkeeping
        values.setdefault("a", a)
        values.setdefault("i", current)
        values.setdefault("freq", freq)
        return values


def list_serial_ports() -> list[str]:
    """Return a list of available serial port device names.

    Uses ``pyserial.tools.list_ports`` when available; returns an empty
    list if pyserial is not installed.
    """
    try:
        from serial.tools import list_ports
    except ImportError:
        return []
    return [p.device for p in list_ports.comports()]
