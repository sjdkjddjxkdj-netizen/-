"""Virtual instrument driver — generates measurements from an earth model.

This is the self-contained core: petroppo measures without ANY external hardware.
The virtual instrument reads physical properties from the virtual earth model and
produces realistic readings with configurable noise — for ALL supported methods
(ERT, Spectral IP, Magnetic, Gravity, GPR, Seismic).
"""
from __future__ import annotations

import random
import time
from typing import Any

import numpy as np

from ..core import (
    Measurement, MeasurementMethod, DeviceInfo, DeviceStatus,
    EarthModel, DeviceConnectionError, new_id,
)
from .base import BaseDevice, DeviceCapabilities


class SimulatorDevice(BaseDevice):
    """Virtual instrument that extracts measurements from an earth model.

    No external hardware required. This is what makes petroppo fully self-contained:
    the virtual instrument reads true physical values from the virtual subsurface
    and adds realistic measurement noise.
    """

    driver_name = "simulator"

    def __init__(self, info: DeviceInfo, model: EarthModel | None = None,
                 noise_level: float = 0.02, seed: int | None = None):
        super().__init__(info)
        self._model = model or EarthModel()
        self._noise_level = noise_level
        self._rng = random.Random(seed)
        self._counter = 0

    def connect(self) -> None:
        if self.is_connected():
            return
        self._log.info("Connecting to virtual instrument '%s'...", self.info.name)
        time.sleep(0.05)
        self._set_status(DeviceStatus.CONNECTED)

    def disconnect(self) -> None:
        self._set_status(DeviceStatus.DISCONNECTED)
        self._log.info("Disconnected from virtual instrument '%s'", self.info.name)

    def is_connected(self) -> bool:
        return self._status in (DeviceStatus.CONNECTED, DeviceStatus.ACQUIRING)

    def _describe_capabilities(self) -> DeviceCapabilities:
        return DeviceCapabilities(
            methods=list(MeasurementMethod),
            max_frequency=1e4, min_frequency=1e-3,
            max_current=2.5, max_voltage=400.0,
            channels=64, noise_floor=1e-6,
        )

    def set_model(self, model: EarthModel) -> None:
        """Update the earth model the virtual instrument reads from."""
        self._model = model

    def measure(self, **params: Any) -> Measurement:
        if not self.is_connected():
            raise DeviceConnectionError("Virtual instrument not connected",
                                        detail=self.info.name)

        method: MeasurementMethod = params.get("method", self.info.kind)
        x = float(params.get("x", 0.0))
        y = float(params.get("y", 0.0))
        z = float(params.get("z", 0.0))
        a = float(params.get("a", 5.0))        # electrode spacing
        current = float(params.get("current", 1.0))  # amperes
        freq = float(params.get("frequency", 1.0))   # hertz

        self._counter += 1
        self._set_status(DeviceStatus.ACQUIRING)

        values: dict[str, float] = {}

        if method == MeasurementMethod.ERT:
            rho = self._sample_resistivity_volume(x, y, z, radius=a)
            rho_a = self._add_noise(rho)
            v = rho_a * current / (2.0 * np.pi * a) if a > 0 else 0.0
            v = self._add_noise(v, relative=False,
                                absolute=self.capabilities().noise_floor)
            values = {"rho_a": rho_a, "v": v, "i": current, "a": a}

        elif method == MeasurementMethod.SPECTRAL:
            rho_dc = self._sample_resistivity_volume(x, y, z, radius=a)
            # Cole-Cole style frequency dependence
            k = 0.05 * self._rng.uniform(-1, 1)
            mag = rho_dc * (1.0 + k * np.log10(freq + 1.0))
            phase = 0.02 * np.log10(freq + 1.0) + 0.01 * self._rng.gauss(0, 1)
            values = {
                "rho_a": self._add_noise(mag),
                "phase": self._add_noise(phase, relative=False, absolute=0.005),
                "freq": freq, "i": current, "a": a,
            }

        elif method == MeasurementMethod.MAGNETIC:
            susc = self._sample_property(x, y, z, "magnetic_susceptibility", 0.0)
            field = 5e4 * susc + 47000.0  # ~47000 nT background
            values = {"b_total": self._add_noise(field, relative=False, absolute=1.0)}

        elif method == MeasurementMethod.GRAVITY:
            dens = self._sample_property(x, y, z, "density", 2400.0)
            g = 0.04 * (dens - 2400.0)  # mGal
            values = {"g": self._add_noise(g, relative=False, absolute=0.05)}

        elif method == MeasurementMethod.GPR:
            eps = self._sample_property(x, y, z, "dielectric", 6.0)
            # GPR two-way travel time for depth z
            v_gpr = 0.3 / np.sqrt(max(eps, 1.0))  # m/ns approximation
            twt = 2.0 * z / (v_gpr * 1e9) if v_gpr > 0 else 0.0
            amp = self._sample_resistivity_volume(x, y, z, radius=a / 2)
            values = {"twt": self._add_noise(twt, relative=False, absolute=0.5),
                      "amplitude": self._add_noise(amp),
                      "dielectric": eps, "freq": freq}

        elif method == MeasurementMethod.SEISMIC:
            vp = self._sample_property(x, y, z, "vp", 2000.0)
            vs = self._sample_property(x, y, z, "vs", 1200.0)
            # first arrival time for distance a
            t_arr = a / max(vp, 1.0)
            values = {"t_first": self._add_noise(t_arr, relative=False, absolute=0.001),
                      "vp": vp, "vs": vs}

        else:
            values = {"raw": 0.0}

        self._set_status(DeviceStatus.CONNECTED)

        m = Measurement(
            id=new_id(),
            device_id=self.info.id,
            method=method,
            timestamp=time.time(),
            x=x, y=y, z=z,
            values=values,
            quality=1.0 - self._noise_level * (0.5 + 0.5 * self._rng.random()),
        )
        return m

    # --- internal utilities ---
    def _sample_resistivity_volume(self, x: float, y: float, z: float,
                                   radius: float, n: int = 8) -> float:
        """Average resistivity in a sampling volume (approximation)."""
        if not self._model.layers and not self._model.bodies:
            return self._model.background_resistivity
        rs: list[float] = []
        for _ in range(n):
            dx = self._rng.uniform(-radius, radius)
            dy = self._rng.uniform(-radius, radius)
            dz = self._rng.uniform(-radius, radius)
            rs.append(self._model.resistivity_at(x + dx, y + dy, z + dz))
        arr = np.array(rs)
        return float(np.mean(arr)) if arr.size else self._model.background_resistivity

    def _sample_property(self, x: float, y: float, z: float,
                         prop: str, default: float) -> float:
        """Sample a physical property from the layer at a point."""
        return self._model.property_at(x, y, z, prop, default)

    def _add_noise(self, value: float, relative: bool = True,
                   absolute: float = 0.0) -> float:
        """Add Gaussian noise. relative=True: proportional, else: absolute."""
        if relative:
            sigma = abs(value) * self._noise_level
        else:
            sigma = max(absolute, abs(value) * self._noise_level)
        return float(value + self._rng.gauss(0, sigma))
