"""TCP/Socket device driver — networked geophysical instruments.

Many modern geophysical instruments (wireless data loggers, networked
resistivity systems, cloud-connected magnetometers) expose a TCP socket
interface.  This driver implements the :class:`BaseDevice` contract over a
plain TCP connection using a line-oriented request/response protocol, very
similar to :mod:`petroppo.hal.serial_device` but transported over Ethernet
or Wi-Fi.

The instrument is identified by ``info.address`` as ``"host:port"`` (e.g.
``"192.168.1.50:10001"``).
"""
from __future__ import annotations

import re
import socket
import time
from dataclasses import dataclass
from typing import Any

from ..core import (
    Measurement, MeasurementMethod, DeviceInfo, DeviceStatus,
    DeviceConnectionError, HardwareError, new_id, get_logger,
)
from .base import BaseDevice, DeviceCapabilities
from .serial_device import SerialProtocol

_log = get_logger("hal.tcp")


@dataclass
class TCPProtocol:
    """TCP socket protocol description (mirrors SerialProtocol)."""
    measure_command: str = "MEAS\n"
    read_terminator: str = "\n"
    response_regex: str = (
        r"R=(?P<rho>[-+0-9.]+E[+-]?[0-9]+|[-+0-9.]+)"
        r",V=(?P<v>[-+0-9.]+)"
        r",I=(?P<i>[-+0-9.]+)"
    )
    timeout: float = 5.0
    init_commands: list[str] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.init_commands is None:
            self.init_commands = []


TCP_PROTOCOLS: dict[str, TCPProtocol] = {
    "generic_tcp": TCPProtocol(),
    "iris_elix": TCPProtocol(
        measure_command="*MEAS\n",
        response_regex=(
            r"(?P<rho>[-+0-9.]+)\s+(?P<v>[-+0-9.]+)\s+(?P<i>[-+0-9.]+)"
            r"(?:\s+(?P<phase>[-+0-9.]+))?"
        ),
        timeout=10.0,
    ),
}


class TCPDevice(BaseDevice):
    """Driver for TCP-socket geophysical instruments.

    Parameters
    ----------
    info : DeviceInfo
        ``info.address`` must be ``"host:port"``.
    protocol : TCPProtocol or str
        Protocol description or key into :data:`TCP_PROTOCOLS`.
    """

    driver_name = "tcp"

    def __init__(self, info: DeviceInfo, protocol: TCPProtocol | str = "generic_tcp",
                 **kwargs: Any):
        super().__init__(info)
        if isinstance(protocol, str):
            if protocol not in TCP_PROTOCOLS:
                raise DeviceConnectionError(
                    f"Unknown TCP protocol '{protocol}'",
                    detail=f"Available: {list(TCP_PROTOCOLS)}",
                )
            protocol = TCP_PROTOCOLS[protocol]
        self._proto = protocol
        self._sock: socket.socket | None = None
        self._parser = re.compile(protocol.response_regex)
        self._counter = 0

    # --- lifecycle ------------------------------------------------------- #
    def connect(self) -> None:
        if self.is_connected():
            return
        addr = self.info.address or "127.0.0.1:10001"
        try:
            host, port_s = addr.rsplit(":", 1)
            port = int(port_s)
        except ValueError:
            raise DeviceConnectionError(
                f"Invalid TCP address '{addr}' (expected host:port)",
            )
        self._log.info("Connecting to TCP instrument %s:%d...", host, port)
        try:
            self._sock = socket.create_connection(
                (host, port), timeout=self._proto.timeout)
            self._sock.settimeout(self._proto.timeout)
        except OSError as exc:
            self._set_status(DeviceStatus.ERROR)
            raise DeviceConnectionError(
                f"Cannot connect to {host}:{port}", detail=str(exc),
            ) from exc
        for cmd in self._proto.init_commands:
            try:
                self._sock.sendall(cmd.encode("ascii", errors="replace"))
                time.sleep(0.05)
            except OSError:
                pass
        self._set_status(DeviceStatus.CONNECTED)
        self._log.info("Connected to %s on %s:%d", self.info.name, host, port)

    def disconnect(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None
        self._set_status(DeviceStatus.DISCONNECTED)
        self._log.info("Disconnected from %s", self.info.name)

    def is_connected(self) -> bool:
        if self._sock is None:
            return False
        # peek to check the socket is alive
        try:
            self._sock.setblocking(False)
            data = self._sock.recv(1, socket.MSG_PEEK)
            if data == b"":
                # connection closed by peer
                return False
        except BlockingIOError:
            pass  # no data ready but socket is open
        except OSError:
            return False
        finally:
            try:
                self._sock.setblocking(True)
                self._sock.settimeout(self._proto.timeout)
            except OSError:
                pass
        return True

    # --- capabilities ---------------------------------------------------- #
    def _describe_capabilities(self) -> DeviceCapabilities:
        return DeviceCapabilities(
            methods=[self.info.kind],
            max_frequency=1e4, min_frequency=1e-3,
            max_current=2.5, max_voltage=800.0,
            channels=128, noise_floor=1e-5,
        )

    # --- measurement ----------------------------------------------------- #
    def measure(self, **params: Any) -> Measurement:
        if not self.is_connected():
            raise DeviceConnectionError("TCP device not connected",
                                        detail=self.info.name)
        method: MeasurementMethod = params.get("method", self.info.kind)
        x = float(params.get("x", 0.0))
        y = float(params.get("y", 0.0))
        z = float(params.get("z", 0.0))
        a = float(params.get("a", 5.0))
        current = float(params.get("current", 1.0))
        freq = float(params.get("frequency", 1.0))

        self._counter += 1
        self._set_status(DeviceStatus.ACQUIRING)

        cmd = self._proto.measure_command.format(
            x=x, y=y, a=a, current=current, freq=freq)
        try:
            self._sock.sendall(cmd.encode("ascii", errors="replace"))
        except OSError as exc:
            self._set_status(DeviceStatus.ERROR)
            raise HardwareError(f"TCP send failed: {exc}") from exc

        raw = self._read_line()
        self._set_status(DeviceStatus.CONNECTED)

        values = self._parse(raw, a=a, current=current, freq=freq)

        return Measurement(
            id=new_id(),
            device_id=self.info.id,
            method=method,
            timestamp=time.time(),
            x=x, y=y, z=z,
            values=values,
            quality=float(values.pop("_quality", 1.0)),
            meta={"raw": raw, "address": self.info.address},
        )

    def _read_line(self) -> str:
        term = self._proto.read_terminator.encode("ascii", errors="replace")
        buf = b""
        deadline = time.time() + self._proto.timeout
        while time.time() < deadline:
            try:
                ch = self._sock.recv(1)
            except socket.timeout as exc:
                raise HardwareError("TCP read timeout", detail=str(exc)) from exc
            if not ch:
                break
            buf += ch
            if buf.endswith(term):
                break
        raw = buf.decode("ascii", errors="replace").strip()
        if not raw:
            raise HardwareError("Empty TCP response (timeout/connection closed)")
        return raw

    def _parse(self, raw: str, *, a: float, current: float,
               freq: float) -> dict[str, float]:
        match = self._parser.search(raw)
        values: dict[str, float] = {}
        if match:
            gd = match.groupdict()
            for key in ("rho", "v", "i", "phase", "g", "b_total",
                        "t_first", "freq", "quality"):
                val = gd.get(key)
                if val is not None:
                    try:
                        values[key] = float(val)
                    except ValueError:
                        pass
        if "rho" in values:
            values["rho_a"] = values.pop("rho")
        if not values:
            self._log.warning("Unparseable TCP response: %r", raw)
            values["raw"] = 0.0
        values.setdefault("a", a)
        values.setdefault("i", current)
        values.setdefault("freq", freq)
        return values
