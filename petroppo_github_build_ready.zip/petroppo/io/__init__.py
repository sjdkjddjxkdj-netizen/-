"""I/O layer — project serialization, data export, and report generation.

Provides:
  * Project save/load (JSON) with full earth model, surveys, measurements,
    and inversion results.
  * CSV/JSON export of measurement data and inversion results.
  * PDF report generation (HTML → PDF via wkhtmltopdf).
  * 3D volume export (VTK legacy format for ParaView/3D viewers).
"""
from .project_io import (
    ProjectBundle,
    save_project,
    load_project,
    earthmodel_to_dict,
    earthmodel_from_dict,
    inversion_to_dict,
    inversion_from_dict,
    measurement_to_dict,
    measurement_from_dict,
)
from .export import (
    export_measurements_csv,
    export_measurements_json,
    export_inversion_csv,
    export_inversion_json,
    export_prospectivity_csv,
)
from .report import (
    generate_pdf_report,
    generate_html_report,
    ReportSection,
)
from .vtk_export import (
    export_volume_vtk,
    export_inversion_vtk,
)
from .well_io import (
    WellLog as IOWellLog,
    import_wells_csv, import_wells_csv_text,
    import_well_las, import_wells_las, parse_las_text,
    export_wells_csv,
)

__all__ = [
    # Project I/O
    "ProjectBundle", "save_project", "load_project",
    "earthmodel_to_dict", "earthmodel_from_dict",
    "inversion_to_dict", "inversion_from_dict",
    "measurement_to_dict", "measurement_from_dict",
    # Data export
    "export_measurements_csv", "export_measurements_json",
    "export_inversion_csv", "export_inversion_json",
    "export_prospectivity_csv",
    # Reports
    "generate_pdf_report", "generate_html_report", "ReportSection",
    # VTK
    "export_volume_vtk", "export_inversion_vtk",
    # Well-log I/O (V7)
    "import_wells_csv", "import_wells_csv_text",
    "import_well_las", "import_wells_las", "parse_las_text",
    "export_wells_csv",
]
