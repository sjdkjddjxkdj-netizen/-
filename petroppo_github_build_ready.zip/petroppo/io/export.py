"""Data export — CSV and JSON export of measurements, inversions, and maps."""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import numpy as np

from ..core import Measurement, InversionResult
from ..core.logging import get_logger

_log = get_logger("io.export")


def export_measurements_csv(measurements: list[Measurement],
                            path: str | Path) -> str:
    """Export measurements to a CSV file."""
    path = Path(path)
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "id", "survey_id", "method", "timestamp",
            "x", "y", "z",
            "rho_a", "v", "i", "quality", "note",
        ])
        for m in measurements:
            writer.writerow([
                m.id, m.survey_id, str(m.method), m.timestamp,
                m.x, m.y, m.z,
                m.values.get("rho_a", ""),
                m.values.get("v", ""),
                m.values.get("i", ""),
                m.quality, m.note,
            ])
    _log.info("Exported %d measurements to %s", len(measurements), path)
    return str(path.resolve())


def export_measurements_json(measurements: list[Measurement],
                             path: str | Path) -> str:
    """Export measurements to a JSON file."""
    from .project_io import measurement_to_dict
    path = Path(path)
    data = [measurement_to_dict(m) for m in measurements]
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    _log.info("Exported %d measurements to %s", len(measurements), path)
    return str(path.resolve())


def export_inversion_csv(result: InversionResult, path: str | Path) -> str:
    """Export an inversion result model to a CSV grid file."""
    path = Path(path)
    model = np.asarray(result.model)
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        if model.ndim == 2:
            writer.writerow(["x_index", "z_index", "value"])
            for i in range(model.shape[0]):
                for j in range(model.shape[1]):
                    writer.writerow([i, j, model[i, j]])
        elif model.ndim == 3:
            writer.writerow(["x_index", "y_index", "z_index", "value"])
            for i in range(model.shape[0]):
                for j in range(model.shape[1]):
                    for k in range(model.shape[2]):
                        writer.writerow([i, j, k, model[i, j, k]])
        elif model.ndim == 1:
            writer.writerow(["index", "value"])
            for i, v in enumerate(model):
                writer.writerow([i, v])
    _log.info("Exported inversion model (%s) to %s", model.shape, path)
    return str(path.resolve())


def export_inversion_json(result: InversionResult, path: str | Path) -> str:
    """Export an inversion result to a JSON file."""
    from .project_io import inversion_to_dict
    path = Path(path)
    with open(path, "w") as f:
        json.dump(inversion_to_dict(result), f, indent=2)
    _log.info("Exported inversion to %s", path)
    return str(path.resolve())


def export_prospectivity_csv(prob_map: np.ndarray,
                             x_coords: np.ndarray,
                             z_coords: np.ndarray,
                             path: str | Path) -> str:
    """Export a prospectivity map to a CSV grid file.

    Parameters
    ----------
    prob_map : (nx, nz) prospectivity probability array.
    x_coords : (nx,) x coordinates of cell centres.
    z_coords : (nz,) z coordinates (depth) of cell centres.
    """
    path = Path(path)
    nx, nz = prob_map.shape
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["x", "depth", "probability"])
        for i in range(nx):
            for j in range(nz):
                writer.writerow([x_coords[i], z_coords[j], prob_map[i, j]])
    _log.info("Exported prospectivity map (%dx%d) to %s", nx, nz, path)
    return str(path.resolve())
