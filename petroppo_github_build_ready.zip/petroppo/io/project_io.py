"""Project serialization — save/load complete project state as JSON.

A project bundle contains:
  - Project metadata (name, description, coordinates, timestamps)
  - Earth model (layers, bodies, extent)
  - Surveys
  - Measurements
  - Inversion results
  - Calibrations
  - Prospectivity maps

The format is a single JSON file (``.pscan``) or a zip archive containing
the JSON plus exported CSVs.
"""
from __future__ import annotations

import json
import time
import zipfile
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

import numpy as np

from ..core import (
    Project, Survey, DeviceInfo, Measurement, MeasurementMethod,
    ProjectStatus, SurveyStatus, DeviceStatus,
    Layer, ResistivityBody, EarthModel,
    InversionResult, new_id,
)
from ..core.logging import get_logger

_log = get_logger("io.project")


# ------------------------------------------------------------------ #
#  Enum / dataclass helpers                                          #
# ------------------------------------------------------------------ #

def _enum_to_str(val: Any) -> Any:
    """Convert enum values to strings for JSON."""
    if isinstance(val, (ProjectStatus, SurveyStatus, DeviceStatus,
                        MeasurementMethod)):
        return str(val)
    return val


def _str_to_enum(cls, val: str):
    """Convert string back to enum."""
    if val is None:
        return None
    try:
        return cls(val)
    except (ValueError, TypeError):
        return val


# ------------------------------------------------------------------ #
#  Earth model serialization                                        #
# ------------------------------------------------------------------ #

def earthmodel_to_dict(model: EarthModel) -> dict:
    """Serialize an EarthModel to a JSON-compatible dict."""
    return {
        "name": model.name,
        "extent_x": list(model.extent_x),
        "extent_y": list(model.extent_y),
        "max_depth": model.max_depth,
        "background_resistivity": model.background_resistivity,
        "layers": [asdict(l) for l in model.layers],
        "bodies": [asdict(b) for b in model.bodies],
    }


def earthmodel_from_dict(d: dict) -> EarthModel:
    """Deserialize an EarthModel from a dict."""
    layers = [Layer(**l) for l in d.get("layers", [])]
    bodies_data = d.get("bodies", [])
    bodies = []
    for b in bodies_data:
        # Filter to known fields
        known = {"cx", "cy", "cz", "rx", "ry", "rz", "resistivity",
                 "label", "density", "magnetic_susceptibility",
                 "dielectric", "vp", "chargeability"}
        filtered = {k: v for k, v in b.items() if k in known}
        bodies.append(ResistivityBody(**filtered))
    return EarthModel(
        name=d.get("name", "Untitled"),
        layers=layers,
        bodies=bodies,
        extent_x=tuple(d.get("extent_x", [0.0, 100.0])),
        extent_y=tuple(d.get("extent_y", [0.0, 0.0])),
        max_depth=d.get("max_depth", 50.0),
        background_resistivity=d.get("background_resistivity", 100.0),
    )


# ------------------------------------------------------------------ #
#  Inversion result serialization                                    #
# ------------------------------------------------------------------ #

def inversion_to_dict(result: InversionResult) -> dict:
    """Serialize an InversionResult to a JSON-compatible dict."""
    model_arr = np.asarray(result.model, dtype=float)
    return {
        "survey_id": result.survey_id,
        "model": model_arr.tolist(),
        "model_shape": list(model_arr.shape),
        "rmse": result.rmse,
        "n_iter": result.n_iter,
        "cell_size": result.cell_size,
        "extent": list(result.extent),
        "meta": _json_safe(result.meta),
    }


def inversion_from_dict(d: dict) -> InversionResult:
    """Deserialize an InversionResult from a dict."""
    model = np.array(d.get("model", []), dtype=float)
    shape = d.get("model_shape")
    if shape and model.size > 0:
        model = model.reshape(shape)
    return InversionResult(
        survey_id=d.get("survey_id", ""),
        model=model,
        rmse=d.get("rmse", 0.0),
        n_iter=d.get("n_iter", 0),
        cell_size=d.get("cell_size", 5.0),
        extent=tuple(d.get("extent", [0.0, 0.0, 0.0])),
        meta=d.get("meta", {}),
    )


# ------------------------------------------------------------------ #
#  Measurement serialization                                        #
# ------------------------------------------------------------------ #

def measurement_to_dict(m: Measurement) -> dict:
    """Serialize a Measurement to a JSON-compatible dict."""
    return {
        "id": m.id,
        "survey_id": m.survey_id,
        "device_id": m.device_id,
        "method": str(m.method),
        "timestamp": m.timestamp,
        "x": m.x,
        "y": m.y,
        "z": m.z,
        "values": dict(m.values),
        "quality": m.quality,
        "note": m.note,
        "meta": _json_safe(m.meta),
    }


def measurement_from_dict(d: dict) -> Measurement:
    """Deserialize a Measurement from a dict."""
    return Measurement(
        id=d.get("id", new_id()),
        survey_id=d.get("survey_id", ""),
        device_id=d.get("device_id", ""),
        method=_str_to_enum(MeasurementMethod, d.get("method", "ert")),
        timestamp=d.get("timestamp", time.time()),
        x=d.get("x", 0.0),
        y=d.get("y", 0.0),
        z=d.get("z", 0.0),
        values=dict(d.get("values", {})),
        quality=d.get("quality", 1.0),
        note=d.get("note", ""),
        meta=d.get("meta", {}),
    )


# ------------------------------------------------------------------ #
#  Survey & Project serialization                                    #
# ------------------------------------------------------------------ #

def survey_to_dict(s: Survey) -> dict:
    return {
        "id": s.id,
        "project_id": s.project_id,
        "name": s.name,
        "method": str(s.method),
        "status": str(s.status),
        "grid_spacing": s.grid_spacing,
        "n_lines": s.n_lines,
        "n_electrodes": s.n_electrodes,
        "config": s.config,
        "frequency": s.frequency,
        "created_at": s.created_at,
        "meta": _json_safe(s.meta),
    }


def survey_from_dict(d: dict) -> Survey:
    return Survey(
        id=d.get("id", new_id()),
        project_id=d.get("project_id", ""),
        name=d.get("name", "New Survey"),
        method=_str_to_enum(MeasurementMethod, d.get("method", "ert")),
        status=_str_to_enum(SurveyStatus, d.get("status", "planned")),
        grid_spacing=d.get("grid_spacing", 5.0),
        n_lines=d.get("n_lines", 1),
        n_electrodes=d.get("n_electrodes", 32),
        config=d.get("config", "wenner"),
        frequency=d.get("frequency", 1.0),
        created_at=d.get("created_at", time.time()),
        meta=d.get("meta", {}),
    )


def _json_safe(obj: Any) -> Any:
    """Make an object JSON-serializable (convert numpy types, etc.)."""
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (ProjectStatus, SurveyStatus, DeviceStatus,
                        MeasurementMethod)):
        return str(obj)
    return obj


# ------------------------------------------------------------------ #
#  Project bundle                                                    #
# ------------------------------------------------------------------ #

class ProjectBundle:
    """A complete project state container for serialization."""

    def __init__(self):
        self.project: Project = Project()
        self.earth_model: EarthModel | None = None
        self.surveys: list[Survey] = []
        self.measurements: list[Measurement] = []
        self.inversions: list[InversionResult] = []
        self.prospectivity: dict[str, Any] = {}
        self.created_at: float = time.time()

    def to_dict(self) -> dict:
        """Serialize the entire bundle to a JSON-compatible dict."""
        return {
            "format": "petroppo-project",
            "version": "2.0",
            "created_at": self.created_at,
            "project": {
                "id": self.project.id,
                "name": self.project.name,
                "description": self.project.description,
                "status": str(self.project.status),
                "origin_lat": self.project.origin_lat,
                "origin_lon": self.project.origin_lon,
                "created_at": self.project.created_at,
                "updated_at": self.project.updated_at,
                "meta": _json_safe(self.project.meta),
            },
            "earth_model": (earthmodel_to_dict(self.earth_model)
                            if self.earth_model else None),
            "surveys": [survey_to_dict(s) for s in self.surveys],
            "measurements": [measurement_to_dict(m) for m in self.measurements],
            "inversions": [inversion_to_dict(r) for r in self.inversions],
            "prospectivity": _json_safe(self.prospectivity),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ProjectBundle":
        """Deserialize a bundle from a dict."""
        bundle = cls()
        bundle.created_at = d.get("created_at", time.time())

        proj_d = d.get("project", {})
        bundle.project = Project(
            id=proj_d.get("id", new_id()),
            name=proj_d.get("name", "New Project"),
            description=proj_d.get("description", ""),
            status=_str_to_enum(ProjectStatus, proj_d.get("status", "draft")),
            origin_lat=proj_d.get("origin_lat", 0.0),
            origin_lon=proj_d.get("origin_lon", 0.0),
            created_at=proj_d.get("created_at", time.time()),
            updated_at=proj_d.get("updated_at", time.time()),
            meta=proj_d.get("meta", {}),
        )

        em_d = d.get("earth_model")
        if em_d:
            bundle.earth_model = earthmodel_from_dict(em_d)

        bundle.surveys = [survey_from_dict(s) for s in d.get("surveys", [])]
        bundle.measurements = [measurement_from_dict(m)
                               for m in d.get("measurements", [])]
        bundle.inversions = [inversion_from_dict(r)
                             for r in d.get("inversions", [])]
        bundle.prospectivity = d.get("prospectivity", {})
        return bundle


# ------------------------------------------------------------------ #
#  File-level save / load                                            #
# ------------------------------------------------------------------ #

def save_project(bundle: ProjectBundle, path: str | Path,
                 include_csv: bool = True) -> str:
    """Save a project bundle to a ``.pscan`` (zip) or ``.json`` file.

    If the path ends in ``.pscan``, a zip archive is created containing
    the JSON plus optional CSV exports.  If it ends in ``.json``, a plain
    JSON file is written.

    Returns the absolute path of the saved file.
    """
    path = Path(path)
    data = bundle.to_dict()

    if path.suffix == ".pscan":
        # Zip archive with JSON + CSVs
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("project.json", json.dumps(data, indent=2))
            if include_csv and bundle.measurements:
                import io as _io
                import csv
                buf = _io.StringIO()
                writer = csv.writer(buf)
                writer.writerow(["id", "method", "x", "y", "z",
                                 "rho_a", "v", "i", "quality", "timestamp"])
                for m in bundle.measurements:
                    writer.writerow([
                        m.id, str(m.method), m.x, m.y, m.z,
                        m.values.get("rho_a", ""),
                        m.values.get("v", ""),
                        m.values.get("i", ""),
                        m.quality, m.timestamp,
                    ])
                zf.writestr("measurements.csv", buf.getvalue())
            if include_csv and bundle.inversions:
                import io as _io
                import csv
                for idx, inv in enumerate(bundle.inversions):
                    buf = _io.StringIO()
                    writer = csv.writer(buf)
                    model = np.asarray(inv.model)
                    if model.ndim == 2:
                        writer.writerow(["x_idx", "z_idx", "resistivity"])
                        for i in range(model.shape[0]):
                            for j in range(model.shape[1]):
                                writer.writerow([i, j, model[i, j]])
                    elif model.ndim == 1:
                        writer.writerow(["idx", "resistivity"])
                        for i, v in enumerate(model):
                            writer.writerow([i, v])
                    zf.writestr(f"inversion_{idx}.csv", buf.getvalue())
    else:
        # Plain JSON
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    _log.info("Project saved to %s (%d measurements, %d inversions)",
              path, len(bundle.measurements), len(bundle.inversions))
    return str(path.resolve())


def load_project(path: str | Path) -> ProjectBundle:
    """Load a project bundle from a ``.pscan`` or ``.json`` file."""
    path = Path(path)

    if path.suffix == ".pscan":
        with zipfile.ZipFile(path, "r") as zf:
            with zf.open("project.json") as f:
                data = json.loads(f.read().decode("utf-8"))
    else:
        with open(path, "r") as f:
            data = json.load(f)

    bundle = ProjectBundle.from_dict(data)
    _log.info("Project loaded from %s: '%s' (%d measurements)",
              path, bundle.project.name, len(bundle.measurements))
    return bundle
