"""VTK export — write 3D volumes and inversion models in legacy VTK format.

These files can be opened in ParaView, VisIt, or any VTK-compatible
3D viewer for volume rendering and isosurface visualization.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from ..core.logging import get_logger

_log = get_logger("io.vtk")


def export_volume_vtk(volume: np.ndarray,
                      x_coords: np.ndarray,
                      y_coords: np.ndarray,
                      z_coords: np.ndarray,
                      path: str | Path,
                      data_name: str = "resistivity") -> str:
    """Export a 3D volume to a legacy VTK structured-points file.

    Parameters
    ----------
    volume : (nx, ny, nz) 3D array of scalar values.
    x_coords, y_coords, z_coords : cell-centre coordinates.
    path : output file path (``.vtk``).
    data_name : name of the scalar field.
    """
    path = Path(path)
    volume = np.asarray(volume, dtype=float)
    nx, ny, nz = volume.shape

    dx = float(x_coords[1] - x_coords[0]) if nx > 1 else 1.0
    dy = float(y_coords[1] - y_coords[0]) if ny > 1 else 1.0
    dz = float(z_coords[1] - z_coords[0]) if nz > 1 else 1.0

    # Origin at first cell corner
    x0 = float(x_coords[0]) - dx / 2
    y0 = float(y_coords[0]) - dy / 2
    z0 = float(z_coords[0]) - dz / 2

    with open(path, "w") as f:
        f.write("# vtk DataFile Version 3.0\n")
        f.write(f"petroppo 3D volume: {data_name}\n")
        f.write("ASCII\n")
        f.write("DATASET STRUCTURED_POINTS\n")
        f.write(f"DIMENSIONS {nx} {ny} {nz}\n")
        f.write(f"ORIGIN {x0} {y0} {z0}\n")
        f.write(f"SPACING {dx} {dy} {dz}\n")
        f.write(f"POINT_DATA {nx * ny * nz}\n")
        f.write(f"SCALARS {data_name} float 1\n")
        f.write("LOOKUP_TABLE default\n")

        # VTK expects data in Fortran order (x varies fastest)
        flat = volume.flatten(order="F")
        # Write in rows of 6 values
        for i in range(0, len(flat), 6):
            chunk = flat[i:i + 6]
            f.write(" ".join(f"{v:.6g}" for v in chunk) + "\n")

    _log.info("VTK volume exported: %s (%dx%dx%d)", path, nx, ny, nz)
    return str(path.resolve())


def export_inversion_vtk(model: np.ndarray,
                         x_coords: np.ndarray,
                         y_coords: np.ndarray | None,
                         z_coords: np.ndarray,
                         path: str | Path,
                         data_name: str = "resistivity") -> str:
    """Export a 2D or 3D inversion model to VTK.

    For 2D models (nx, nz), y_coords is ignored and a single-slice
    3D volume is written.
    """
    model = np.asarray(model, dtype=float)

    if model.ndim == 2:
        nx, nz = model.shape
        # Promote to 3D with a single y-slice
        vol = model[:, np.newaxis, :]
        y_c = np.array([0.0])
    elif model.ndim == 3:
        vol = model
        nx, ny, nz = model.shape
        y_c = y_coords if y_coords is not None else np.linspace(0, ny - 1, ny)
    else:
        raise ValueError(f"Model must be 2D or 3D, got {model.ndim}D")

    return export_volume_vtk(vol, x_coords, y_c, z_coords, path, data_name)
