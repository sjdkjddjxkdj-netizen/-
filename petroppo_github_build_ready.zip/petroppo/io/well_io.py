"""Well-log I/O — import LAS and CSV well data into petroppo.

Supports two formats:

* **CSV** — a simple, portable format.  Required columns: ``name, x, y,
  target_depth, label`` plus optional log columns (``resistivity,
  density, gamma, neutron``) sampled at ``depth``.  Two shapes are
  accepted:

    1. *One-row-per-well* (summary): a single row per well with scalar
       log values at the target depth and a ``label`` (1=oil, 0=dry).
    2. *Multi-row-per-well* (full log): many rows per well, each a depth
       sample.  ``label`` is repeated; the value at ``target_depth`` is
       used for calibration.

* **LAS** — the industry-standard well-log format (LAS 2.0).  Parsed
  with a lightweight reader (no external dependency) that extracts the
  well header (x, y, target depth from parameters) and the curve data.

The output is a list of :class:`WellLog` objects ready for
:func:`petroppo.processing.wellcal.calibrate_from_wells`.
"""
from __future__ import annotations

import csv
import io
import os
from typing import Any

import numpy as np

from ..core import get_logger
from ..processing.wellcal import WellLog

_log = get_logger("io.well_io")


# --------------------------------------------------------------------- #
#  CSV import                                                           #
# --------------------------------------------------------------------- #
def import_wells_csv(path: str) -> list[WellLog]:
    """Import wells from a CSV file → list of :class:`WellLog`.

    See module docstring for the accepted layouts.
    """
    with open(path, "r", newline="") as fh:
        reader = csv.DictReader(fh)
        rows = list(reader)
    return _wells_from_rows(rows)


def import_wells_csv_text(text: str) -> list[WellLog]:
    """Import wells from CSV text (string) — handy for tests/embedding."""
    reader = csv.DictReader(io.StringIO(text))
    return _wells_from_rows(list(reader))


def _wells_from_rows(rows: list[dict]) -> list[WellLog]:
    if not rows:
        return []
    # detect full-log (has 'depth' column) vs summary
    has_depth = "depth" in {k.lower() for k in rows[0].keys()}
    log_keys = {"resistivity", "density", "gamma", "gamma_ray", "gr",
                "neutron", "oil_show", "velocity", "vp"}
    wells: dict[str, WellLog] = {}
    for r in rows:
        lk = {k.lower(): v for k, v in r.items()}
        name = str(lk.get("name", lk.get("well", "well"))).strip() or "well"
        try:
            x = float(lk.get("x", 0.0) or 0.0)
            y = float(lk.get("y", 0.0) or 0.0)
            td = float(lk.get("target_depth", lk.get("td", 0.0)) or 0.0)
            label = int(float(lk.get("label", 0) or 0))
        except (TypeError, ValueError):
            continue
        if has_depth:
            d = float(lk.get("depth", 0.0) or 0.0)
            w = wells.setdefault(name, WellLog(
                name=name, x=x, y=y, target_depth=td, label=label,
                logs={}, log_depths=np.empty(0)))
            for prop, col in (("resistivity", "resistivity"),
                              ("density", "density"),
                              ("gamma", "gamma"),
                              ("neutron", "neutron"),
                              ("oil_show", "oil_show"),
                              ("velocity", "velocity")):
                if col in lk and lk[col] not in (None, ""):
                    try:
                        w.logs.setdefault(prop, []).append(float(lk[col]))
                    except ValueError:
                        w.logs.setdefault(prop, []).append(np.nan)
            w.log_depths = np.append(w.log_depths, d) if w.log_depths.size else np.array([d])
        else:
            # summary: scalar log values at target depth
            logs: dict[str, np.ndarray] = {}
            ld = np.array([td])
            for prop, col in (("resistivity", "resistivity"),
                              ("density", "density"),
                              ("gamma", "gamma"),
                              ("neutron", "neutron"),
                              ("velocity", "velocity")):
                if col in lk and lk[col] not in (None, ""):
                    try:
                        logs[prop] = np.array([float(lk[col])])
                    except ValueError:
                        pass
            wells[name] = WellLog(name=name, x=x, y=y, target_depth=td,
                                  label=label, logs=logs, log_depths=ld)

    # convert list-logs to arrays
    out = list(wells.values())
    for w in out:
        for k in list(w.logs.keys()):
            w.logs[k] = np.asarray(w.logs[k], dtype=float)
    return out


# --------------------------------------------------------------------- #
#  LAS 2.0 import (lightweight, dependency-free)                        #
# --------------------------------------------------------------------- #
def import_well_las(path: str) -> WellLog:
    """Import a single LAS 2.0 file → :class:`WellLog`.

    Reads the ``~W`` (well info), ``~P`` (parameters, for x/y/target),
    and ``~A`` (ASCII curve data) sections.  The ``label`` is read from
    a parameter named ``LABEL`` or ``OIL_SHOW`` if present, else 0.
    """
    with open(path, "r") as fh:
        text = fh.read()
    return parse_las_text(text, filename=os.path.basename(path))


def parse_las_text(text: str, filename: str = "well") -> WellLog:
    """Parse LAS 2.0 text → :class:`WellLog`.

    Supports both ``WRAP=NO`` (one line per depth step) and ``WRAP=YES``
    (curve values for a single depth step may span multiple lines, as is
    common in real wireline LAS exports with many curves).
    """
    lines = text.splitlines()
    section = None
    header: dict[str, str] = {}
    params: dict[str, str] = {}
    curve_names: list[str] = []
    data_rows: list[list[float]] = []
    wrap = False  # default
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("~V"):
            section = "V"; continue
        if s.startswith("~W"):
            section = "W"; continue
        if s.startswith("~P"):
            section = "P"; continue
        if s.startswith("~C"):
            section = "C"; continue
        if s.startswith("~A"):
            section = "A"; continue
        if s.startswith("~O"):
            section = "O"; continue
        if section in ("V", "W", "P"):
            # LAS 2.0 line format: MNEM.UNIT VALUE : DESCRIPTION
            # The dot separates MNEM from the rest; the rest is "UNIT VALUE"
            # followed by an optional ": DESCRIPTION".
            # UNIT may be empty (e.g. "WRAP.YES : ..."), in which case the
            # single token after the dot IS the value.
            # Heuristic: if the first token after the dot is a pure unit string
            # (alphabetic, like M, G/C3, DEG, OHMM) and there is a second token,
            # the second token is the value. Otherwise the first token is the value.
            parts = s.split(".", 1)
            mnem = parts[0].strip().upper() if parts else s.strip().upper()
            rest = parts[1] if len(parts) > 1 else ""
            val_desc = rest.split(":", 1)
            val_unit_part = val_desc[0].strip()
            tokens = val_unit_part.split()
            if len(tokens) >= 2:
                # Could be "UNIT VALUE" or "VALUE SOMETHING"
                # Units are typically short alphabetic strings; values are numeric
                first_is_unit = tokens[0].replace("/", "").replace("-", "").isalpha()
                val = tokens[1] if first_is_unit else tokens[0]
            elif len(tokens) == 1:
                val = tokens[0]
            else:
                val = ""
            (params if section == "P" else header)[mnem] = val
            # Detect wrap mode from the WRAP mnemonic (usually in ~V)
            if mnem == "WRAP":
                wrap = val.upper().startswith("Y")
        elif section == "C":
            parts = s.split(".", 1)
            nm = parts[0].strip().upper() if parts else s.strip().upper()
            if nm:
                curve_names.append(nm)
        elif section == "A":
            try:
                vals = [float(tok) for tok in s.split()]
                if vals:
                    data_rows.append(vals)
            except ValueError:
                continue

    # --- Handle WRAP=YES: reassemble multi-line rows ------------------ #
    if wrap and curve_names:
        n_curves = len(curve_names)
        flat: list[float] = []
        for row in data_rows:
            flat.extend(row)
        data_rows = [flat[i:i + n_curves]
                     for i in range(0, len(flat) - n_curves + 1, n_curves)]

    # header → x, y, target
    def _f(d, *keys):
        for k in keys:
            if k in d and d[k] not in ("", None):
                try:
                    return float(d[k])
                except ValueError:
                    pass
        return None

    def _dms(val_str):
        """Parse DMS coordinate like '-12/41/05.28' → decimal degrees."""
        if not val_str or "/" not in val_str:
            return None
        try:
            parts = val_str.split("/")
            deg = float(parts[0])
            minutes = float(parts[1]) if len(parts) > 1 else 0
            secs = float(parts[2]) if len(parts) > 2 else 0
            sign = -1 if deg < 0 else 1
            return sign * (abs(deg) + minutes / 60.0 + secs / 3600.0)
        except (ValueError, IndexError):
            return None

    # Try plain float first, then DMS format
    x = _f(header, "X", "XCOORD", "LONG", "XLOC")
    if x is None:
        x = _dms(header.get("LONG")) or _dms(header.get("LATI")) or 0.0
    y = _f(header, "Y", "YCOORD", "LAT", "YLOC")
    if y is None:
        y = _dms(header.get("LATI")) or 0.0
    td = _f(params, "TARG", "TARGET", "TDEPTH", "TD") or _f(header, "STOP") or 0.0
    label = int(_f(params, "LABEL", "OIL_SHOW", "HC") or 0)

    # find depth curve
    depth_idx = None
    for i, nm in enumerate(curve_names):
        if nm in ("DEPT", "DEPTH", "DEPTHL", "D"):
            depth_idx = i
            break
    depths = np.array([r[depth_idx] for r in data_rows], dtype=float) \
        if depth_idx is not None else np.arange(len(data_rows), dtype=float)

    # map curves → logs
    prop_map = {"RT": "resistivity", "RES": "resistivity",
                "LLD": "resistivity", "LLS": "resistivity",
                "MSFL": "resistivity", "AT90": "resistivity",
                "RHO": "density", "RHOB": "density", "DEN": "density",
                "GR": "gamma", "GAMMA": "gamma",
                "NPHI": "neutron", "NEUT": "neutron",
                "VP": "velocity", "VEL": "velocity",
                "DT": "velocity"}
    logs: dict[str, np.ndarray] = {}
    for i, nm in enumerate(curve_names):
        prop = prop_map.get(nm)
        if prop:
            logs[prop] = np.array([r[i] for r in data_rows], dtype=float)
    # replace -999.25 (LAS null) with nan
    for k in logs:
        logs[k] = np.where(np.abs(logs[k] + 999.25) < 1e-6, np.nan, logs[k])
    # Convert sonic transit time (μs/ft) → velocity (m/s) if DT was mapped
    if "velocity" in logs:
        v = logs["velocity"]
        # DT in μs/ft: v = 304800 / DT  (only for reasonable DT range 40–200)
        mask = (v > 30) & (v < 250) & ~np.isnan(v)
        v[mask] = 304800.0 / v[mask]
        logs["velocity"] = v

    name = filename.replace(".las", "")
    return WellLog(name=name, x=float(x), y=float(y),
                   target_depth=float(td), label=int(label),
                   logs=logs, log_depths=depths)


def import_wells_las(paths: list[str]) -> list[WellLog]:
    """Import multiple LAS files."""
    return [import_well_las(p) for p in paths]


# --------------------------------------------------------------------- #
#  Export                                                               #
# --------------------------------------------------------------------- #
def export_wells_csv(wells: list[WellLog], path: str) -> None:
    """Write wells to a summary CSV (one row per well, value at target)."""
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        cols = ["name", "x", "y", "target_depth", "label",
                "resistivity", "density", "gamma", "neutron", "velocity"]
        w.writerow(cols)
        for wl in wells:
            row = [wl.name, wl.x, wl.y, wl.target_depth, wl.label]
            for prop in ("resistivity", "density", "gamma", "neutron", "velocity"):
                v = wl.log_at_target(prop)
                row.append("" if v is None else f"{v:.4f}")
            w.writerow(row)
