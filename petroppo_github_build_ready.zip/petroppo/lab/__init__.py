"""Measurement Research Lab — electrode configuration analysis and optimization."""
from .configs import ElectrodeConfig, ConfigSpec, CONFIG_SPECS, get_spec, list_configs
from .sensitivity import sensitivity_map, compare_configs
from .infogain import information_gain, rank_configs, recommend_config
from .lab import MeasurementLab

__all__ = [
    "ElectrodeConfig", "ConfigSpec", "CONFIG_SPECS", "get_spec", "list_configs",
    "sensitivity_map", "compare_configs",
    "information_gain", "rank_configs", "recommend_config",
    "MeasurementLab",
]
