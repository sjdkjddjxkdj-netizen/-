"""Electrode configurations — definitions and engineering data for common arrays."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ElectrodeConfig(str, Enum):
    """Supported electrode arrays for electrical resistivity surveys."""
    WENNER = "wenner"              # alpha: C1-P1-P2-C2 equal spacing
    WENNER_BETA = "wenner-beta"    # C1-C2-P1-P2
    WENNER_GAMMA = "wenner-gamma"  # C1-P1-C2-P2
    DIPOLE_DIPOLE = "dipole-dipole"  # C1-C2 P1-P2
    SCHLUMBERGER = "schlumberger"  # C1-P1-P2-C2 with unequal spacing
    POLE_DIPOLE = "pole-dipole"
    POLE_POLE = "pole-pole"


@dataclass(frozen=True)
class ConfigSpec:
    """Specification of an electrode configuration."""
    name: ElectrodeConfig
    label: str
    geometry_factor: float   # geometric factor K (relative)
    depth_factor: float      # ratio of investigation depth to spacing
    signal_strength: float   # relative signal strength (1=strongest)
    horizontal_resolution: float  # relative horizontal resolution
    noise_sensitivity: float  # noise sensitivity (higher=worse)


CONFIG_SPECS: dict[ElectrodeConfig, ConfigSpec] = {
    ElectrodeConfig.WENNER: ConfigSpec(
        ElectrodeConfig.WENNER, "Wenner alpha", 2 * 3.14159, 0.5, 1.0, 1.0, 0.5),
    ElectrodeConfig.WENNER_BETA: ConfigSpec(
        ElectrodeConfig.WENNER_BETA, "Wenner beta", 6 * 3.14159, 0.4, 0.4, 1.0, 1.0),
    ElectrodeConfig.WENNER_GAMMA: ConfigSpec(
        ElectrodeConfig.WENNER_GAMMA, "Wenner gamma", 3 * 3.14159, 0.3, 0.6, 1.0, 0.8),
    ElectrodeConfig.DIPOLE_DIPOLE: ConfigSpec(
        ElectrodeConfig.DIPOLE_DIPOLE, "Dipole-Dipole", 3.14159, 0.3, 0.3, 1.5, 1.5),
    ElectrodeConfig.SCHLUMBERGER: ConfigSpec(
        ElectrodeConfig.SCHLUMBERGER, "Schlumberger", 3.14159, 0.5, 0.8, 1.2, 0.7),
    ElectrodeConfig.POLE_DIPOLE: ConfigSpec(
        ElectrodeConfig.POLE_DIPOLE, "Pole-Dipole", 2 * 3.14159, 0.45, 0.7, 1.3, 0.6),
    ElectrodeConfig.POLE_POLE: ConfigSpec(
        ElectrodeConfig.POLE_POLE, "Pole-Pole", 2 * 3.14159, 0.6, 0.9, 0.8, 0.4),
}


def get_spec(cfg: ElectrodeConfig) -> ConfigSpec:
    return CONFIG_SPECS[cfg]


def list_configs() -> list[ConfigSpec]:
    return list(CONFIG_SPECS.values())
