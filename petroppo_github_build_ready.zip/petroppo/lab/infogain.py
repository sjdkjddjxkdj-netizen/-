"""Information Gain (IG) evaluation for electrode configurations.

The idea: the best configuration is the one that reduces uncertainty about the
earth model. We estimate the information gain via the discriminating power between
two different models (a background model vs. a model with a target).

IG approximated via KL divergence between the reading distributions of the two
states:
    IG = mean |rho_a(target) - rho_a(background)| / sigma_noise
"""
from __future__ import annotations

import numpy as np

from ..core import EarthModel, get_logger
from ..simulator.forward import forward_ert, wenner_geometry, dipole_dipole_geometry
from ..simulator.scenarios import get_scenario
from .configs import ElectrodeConfig, get_spec

_log = get_logger("lab.infogain")


def information_gain(target_model: EarthModel,
                     background_model: EarthModel | None = None,
                     cfg: ElectrodeConfig = ElectrodeConfig.WENNER,
                     n_electrodes: int = 24, spacing: float = 5.0,
                     noise_level: float = 0.02) -> dict:
    """Compute the information gain of a configuration for target detection.

    Returns a dict:
      'ig': information gain (higher = better for detection)
      'contrast': mean difference in readings between the two models
      'snr': signal-to-noise ratio
      'detection_rate': fraction of readings exceeding the detection threshold
    """
    if background_model is None:
        background_model = get_scenario("layered")

    if cfg in (ElectrodeConfig.DIPOLE_DIPOLE,):
        geom_fn = dipole_dipole_geometry
    else:
        geom_fn = wenner_geometry

    geometry = geom_fn(n_electrodes, spacing)
    d_target = forward_ert(target_model, geometry, noise=0.0)
    d_back = forward_ert(background_model, geometry, noise=0.0)

    rho_t = np.array([r["rho_a"] for r in d_target])
    rho_b = np.array([r["rho_a"] for r in d_back])

    contrast = np.abs(rho_t - rho_b)
    sigma = noise_level * np.abs(rho_b) + 1e-9
    snr = contrast / sigma

    # Detection threshold: 2 sigma
    detection = contrast > (2 * sigma)
    detection_rate = float(np.mean(detection))

    # Information gain: sum of log(1 + SNR^2) — approximation of collective sensitivity
    ig = float(np.sum(np.log1p(snr ** 2)))

    spec = get_spec(cfg)
    # Adjust with configuration capabilities (signal strength and noise sensitivity)
    ig_adjusted = ig * spec.signal_strength / spec.noise_sensitivity

    return {
        "config": cfg.value,
        "label": spec.label,
        "ig": ig_adjusted,
        "contrast_mean": float(np.mean(contrast)),
        "contrast_max": float(np.max(contrast)),
        "snr_mean": float(np.mean(snr)),
        "snr_max": float(np.max(snr)),
        "detection_rate": detection_rate,
        "n_readings": len(d_target),
        "depth_factor": spec.depth_factor,
        "signal_strength": spec.signal_strength,
    }


def rank_configs(target_model: EarthModel,
                 background_model: EarthModel | None = None,
                 configs: list[ElectrodeConfig] | None = None,
                 **kwargs) -> list[dict]:
    """Rank configurations by information gain (highest = best)."""
    if configs is None:
        configs = list(ElectrodeConfig)
    results = []
    for cfg in configs:
        try:
            results.append(information_gain(target_model, background_model,
                                            cfg, **kwargs))
        except Exception as exc:
            _log.warning("IG computation failed for %s: %s", cfg.value, exc)
    results.sort(key=lambda r: r["ig"], reverse=True)
    return results


def recommend_config(target_model: EarthModel,
                     background_model: EarthModel | None = None,
                     noise_level: float = 0.02,
                     n_electrodes: int = 24, spacing: float = 5.0) -> dict:
    """Recommend the best configuration with a full explanation."""
    ranked = rank_configs(target_model, background_model,
                          noise_level=noise_level,
                          n_electrodes=n_electrodes, spacing=spacing)
    best = ranked[0] if ranked else None
    if best is None:
        return {"recommended": None, "reason": "No results available"}
    reason = (
        f"Configuration '{best['label']}' achieves the highest information gain "
        f"(IG={best['ig']:.2f}), peak signal-to-noise ratio "
        f"(SNR_max={best['snr_max']:.2f}), and detects {best['detection_rate']*100:.0f}% "
        f"of the readings above threshold."
    )
    return {
        "recommended": best,
        "ranking": ranked,
        "reason": reason,
    }
