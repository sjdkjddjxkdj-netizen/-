"""Measurement Research Lab — experiment, test, and optimize survey configurations.

This module is the heart of the innovation: we compare configurations, analyze their
sensitivity, and recommend the best one for detecting a specific target in a virtual model.
"""
from __future__ import annotations

from ..core import EarthModel, get_logger
from ..simulator.scenarios import get_scenario
from .configs import ElectrodeConfig, list_configs
from .sensitivity import sensitivity_map, compare_configs
from .infogain import information_gain, rank_configs, recommend_config

_log = get_logger("lab")


class MeasurementLab:
    """Measurement Research Lab — high-level interface for experiments."""

    def __init__(self):
        self.target: EarthModel = get_scenario("reservoir")
        self.background: EarthModel = get_scenario("layered")

    def set_target(self, model: EarthModel | str) -> None:
        if isinstance(model, str):
            model = get_scenario(model)
        self.target = model

    def set_background(self, model: EarthModel | str) -> None:
        if isinstance(model, str):
            model = get_scenario(model)
        self.background = model

    def list_configurations(self) -> list[dict]:
        """List all available configurations with their specifications."""
        return [
            {"name": s.name.value, "label": s.label,
             "depth_factor": s.depth_factor,
             "signal_strength": s.signal_strength,
             "horizontal_resolution": s.horizontal_resolution,
             "noise_sensitivity": s.noise_sensitivity}
            for s in list_configs()
        ]

    def analyze_sensitivity(self, cfg: ElectrodeConfig = ElectrodeConfig.WENNER,
                            n_electrodes: int = 24, spacing: float = 5.0) -> dict:
        """Analyze the sensitivity of a configuration on the target model."""
        return sensitivity_map(self.target, cfg, n_electrodes, spacing)

    def compare_all(self, n_electrodes: int = 24, spacing: float = 5.0) -> list[dict]:
        """Compare the sensitivity of all configurations."""
        return compare_configs(self.target, n_electrodes=n_electrodes,
                               spacing=spacing)

    def evaluate_information_gain(self, cfg: ElectrodeConfig,
                                  noise_level: float = 0.02,
                                  n_electrodes: int = 24,
                                  spacing: float = 5.0) -> dict:
        """Evaluate the information gain of a specific configuration."""
        return information_gain(self.target, self.background, cfg,
                                noise_level=noise_level,
                                n_electrodes=n_electrodes, spacing=spacing)

    def rank(self, noise_level: float = 0.02, n_electrodes: int = 24,
             spacing: float = 5.0) -> list[dict]:
        """Rank all configurations by information gain."""
        return rank_configs(self.target, self.background,
                            noise_level=noise_level,
                            n_electrodes=n_electrodes, spacing=spacing)

    def recommend(self, noise_level: float = 0.02, n_electrodes: int = 24,
                  spacing: float = 5.0) -> dict:
        """Recommend the optimal configuration with a full explanation."""
        return recommend_config(self.target, self.background,
                                noise_level=noise_level,
                                n_electrodes=n_electrodes, spacing=spacing)

    def full_experiment(self, noise_level: float = 0.02,
                        n_electrodes: int = 24, spacing: float = 5.0) -> dict:
        """Full experiment: sensitivity + information gain + recommendation."""
        rec = self.recommend(noise_level=noise_level, n_electrodes=n_electrodes,
                             spacing=spacing)
        sens = self.compare_all(n_electrodes=n_electrodes, spacing=spacing)
        return {
            "target_scenario": self.target.bodies[0].label if self.target.bodies else "background",
            "n_bodies": len(self.target.bodies),
            "noise_level": noise_level,
            "n_electrodes": n_electrodes,
            "spacing": spacing,
            "recommendation": rec,
            "sensitivity_comparison": [
                {"config": s["config"], "peak_depth": s["peak_depth"],
                 "max_depth": s["max_depth"]} for s in sens
            ],
            "ranking": rec["ranking"],
        }

    def to_report(self, noise_level: float = 0.02) -> str:
        """Generate a text report of the experiment."""
        exp = self.full_experiment(noise_level=noise_level)
        lines = [
            "=== Measurement Research Lab Report ===",
            f"Target model: {exp['target_scenario']} ({exp['n_bodies']} bodies)",
            f"Noise level: {exp['noise_level']*100:.0f}%",
            f"Electrodes: {exp['n_electrodes']} | Spacing: {exp['spacing']} m",
            "",
            "Configuration ranking by information gain:",
        ]
        for i, r in enumerate(exp["ranking"], 1):
            lines.append(
                f"  {i}. {r['label']:18s} | IG={r['ig']:7.2f} | "
                f"SNR_max={r['snr_max']:6.2f} | Detection={r['detection_rate']*100:4.0f}%"
            )
        lines.append("")
        lines.append(f"Recommendation: {exp['recommendation']['reason']}")
        return "\n".join(lines)
