"""Sensitivity analysis — where is each configuration most sensitive to changes?

Reading sensitivity = d(rho_a)/d(rho_layer), i.e., how much the apparent resistivity
is affected by a change in resistivity of a given cell/layer.
"""
from __future__ import annotations

import numpy as np

from ..core import EarthModel, get_logger
from ..simulator.forward import forward_ert, wenner_geometry, dipole_dipole_geometry
from .configs import ElectrodeConfig, get_spec

_log = get_logger("lab.sensitivity")


def sensitivity_map(model: EarthModel, cfg: ElectrodeConfig,
                    n_electrodes: int = 24, spacing: float = 5.0,
                    delta: float = 1.1) -> dict:
    """Compute the sensitivity map of a configuration across the section.

    Method: multiply the resistivity of each layer by ``delta``, re-run the
    forward model, and compute the relative difference in readings. This is an
    approximation of the column-wise Jacobian.

    Returns a dict with:
      'depths', 'sensitivity' per layer -> sensitivity at each depth
    """
    if cfg in (ElectrodeConfig.WENNER, ElectrodeConfig.SCHLUMBERGER,
               ElectrodeConfig.WENNER_BETA, ElectrodeConfig.WENNER_GAMMA,
               ElectrodeConfig.POLE_DIPOLE, ElectrodeConfig.POLE_POLE):
        geom_fn = wenner_geometry
    else:
        geom_fn = dipole_dipole_geometry

    geometry = geom_fn(n_electrodes, spacing)
    baseline = forward_ert(model, geometry, noise=0.0)

    # Approximate investigation depth for each reading
    depths = sorted({round(r["depth"], 1) for r in baseline})
    spec = get_spec(cfg)

    # Sensitivity at each depth: multiply all layers deeper than that depth by delta
    sens_per_depth = {}
    for d in depths:
        modified = _perturb_layers(model, below_depth=d, factor=delta)
        res = forward_ert(modified, geometry, noise=0.0)
        diffs = []
        for b, r in zip(baseline, res):
            if abs(b["depth"] - d) < 1e-6 and b["rho_a"] != 0:
                diffs.append(abs(r["rho_a"] - b["rho_a"]) / abs(b["rho_a"]))
        sens_per_depth[d] = float(np.mean(diffs)) if diffs else 0.0

    return {
        "config": cfg.value,
        "depths": depths,
        "sensitivity": [sens_per_depth[d] for d in depths],
        "max_depth": max(depths) if depths else 0.0,
        "peak_depth": depths[int(np.argmax([sens_per_depth[d] for d in depths]))] if depths else 0.0,
        "spec": spec,
    }


def _perturb_layers(model: EarthModel, below_depth: float,
                    factor: float) -> EarthModel:
    """Multiply the resistivity of layers deeper than ``below_depth`` by ``factor``."""
    from ..core import Layer
    new_layers = []
    for lay in model.layers:
        if lay.top_depth >= below_depth:
            new_layers.append(Layer(
                name=lay.name + "*",
                top_depth=lay.top_depth, bottom_depth=lay.bottom_depth,
                resistivity=lay.resistivity * factor,
                density=lay.density,
                magnetic_susceptibility=lay.magnetic_susceptibility,
                color=lay.color,
            ))
        else:
            new_layers.append(lay)
    new_model = EarthModel(
        name=model.name,
        layers=new_layers,
        bodies=list(model.bodies),
        extent_x=model.extent_x, extent_y=model.extent_y,
        max_depth=model.max_depth,
        background_resistivity=model.background_resistivity,
    )
    return new_model


def compare_configs(model: EarthModel,
                    configs: list[ElectrodeConfig] | None = None,
                    n_electrodes: int = 24, spacing: float = 5.0) -> list[dict]:
    """Compare the sensitivity of several configurations on the same model."""
    if configs is None:
        configs = [ElectrodeConfig.WENNER, ElectrodeConfig.DIPOLE_DIPOLE,
                   ElectrodeConfig.SCHLUMBERGER, ElectrodeConfig.POLE_DIPOLE]
    results = []
    for cfg in configs:
        try:
            results.append(sensitivity_map(model, cfg, n_electrodes, spacing))
        except Exception as exc:
            _log.warning("Sensitivity computation failed for %s: %s", cfg.value, exc)
    return results
