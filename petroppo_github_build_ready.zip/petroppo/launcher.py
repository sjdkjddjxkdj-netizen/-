"""petroppo — frozen launcher entry point for PyInstaller.

This is the single module that PyInstaller packages as the executable.
On first run it copies the bundled sample/demo data and the read-only
assets into the user's writable data directory, then starts the desktop
application (login gate + main window).

Place this file at:  petroppo/launcher.py
"""
from __future__ import annotations

import os
import sys
import shutil
from pathlib import Path


def _bundled_dir() -> Path:
    """Return the directory containing the bundled resources."""
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            return Path(meipass)
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent  # project root in dev


def _writable_data_dir() -> Path:
    """Writable per-user data directory."""
    home = Path.home()
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", home)) / "petroppo" / "data"
    elif sys.platform == "darwin":
        base = home / "Library" / "Application Support" / "petroppo" / "data"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share")) / "petroppo" / "data"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _bootstrap() -> None:
    """First-run setup: copy bundled sample data + assets to user dir."""
    data_dir = _writable_data_dir()
    os.environ["PETROPPO_DATA_DIR"] = str(data_dir)

    bundled = _bundled_dir() / "petroppo" / "data"
    if not bundled.exists():
        return
    # assets (logo etc.)
    bundled_assets = bundled / "assets"
    if bundled_assets.exists():
        dst_assets = data_dir / "assets"
        dst_assets.mkdir(parents=True, exist_ok=True)
        for f in bundled_assets.iterdir():
            dst = dst_assets / f.name
            if not dst.exists():
                try:
                    shutil.copy2(f, dst)
                except Exception:
                    pass
    # sample/demo data
    bundled_samples = bundled / "samples"
    if bundled_samples.exists():
        dst_samples = data_dir / "samples"
        dst_samples.mkdir(parents=True, exist_ok=True)
        for f in bundled_samples.rglob("*"):
            rel = f.relative_to(bundled_samples)
            dst = dst_samples / rel
            if f.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            elif not dst.exists():
                try:
                    shutil.copy2(f, dst)
                except Exception:
                    pass


def main() -> int:
    _bootstrap()
    os.environ.pop("QT_QPA_PLATFORM", None)  # never offscreen in production
    from petroppo.gui.pro_main_window import run_app
    return run_app()


if __name__ == "__main__":
    sys.exit(main())
