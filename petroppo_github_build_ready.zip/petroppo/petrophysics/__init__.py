"""
petroppo V10 — Petrophysics & Rock Physics Engine.

Connects geophysical observables to petrophysical properties through
the three cornerstone rock-physics models:

* **Archie's Law** — resistivity ↔ water saturation
* **Gassmann's Equation** — fluid substitution for seismic velocities
* **CRIM** — dielectric permittivity ↔ water saturation

Plus velocity-porosity models (Wyllie, Raymer-Hunt-Gardner, critical
porosity), density models, fluid mixing (Brie), and a joint
petrophysical interpreter that fuses all three methods.
"""
from .rock_physics import (
    # Archie
    ArchieParams, archie_water_saturation, archie_resistivity,
    archie_porosity_from_rt, waxman_smits_saturation,
    # Gassmann
    GassmannParams, gassmann_fluid_substitution,
    gassmann_dry_from_saturated, brie_fluid_modulus,
    reuss_average, voigt_average, hill_average,
    # CRIM
    crim_permittivity, crim_water_saturation,
    tpw_permittivity, looyenga_permittivity,
    # Velocity-porosity
    wyllie_time_average, raymer_hunt_gardner,
    critical_porosity_model, han_empirical_sandstone,
    # Density & fluid
    fluid_density, bulk_density, rho_sat_from_components,
    # Composite transforms
    PetrophysicalTransform, ResistivityToSaturation,
    VelocityToPorosity, PermittivityToSaturation,
    JointPetrophysics,
    # Constants
    WATER_DENSITY, OIL_DENSITY, GAS_DENSITY,
    WATER_MODULUS, OIL_MODULUS, GAS_MODULUS,
    WATER_PERMITTIVITY, OIL_PERMITTIVITY, GAS_PERMITTIVITY,
    QUARTZ_DENSITY, QUARTZ_K, QUARTZ_MU,
    CLAY_DENSITY, CLAY_K, CLAY_MU,
)

__all__ = [
    "ArchieParams", "archie_water_saturation", "archie_resistivity",
    "archie_porosity_from_rt", "waxman_smits_saturation",
    "GassmannParams", "gassmann_fluid_substitution",
    "gassmann_dry_from_saturated", "brie_fluid_modulus",
    "reuss_average", "voigt_average", "hill_average",
    "crim_permittivity", "crim_water_saturation",
    "tpw_permittivity", "looyenga_permittivity",
    "wyllie_time_average", "raymer_hunt_gardner",
    "critical_porosity_model", "han_empirical_sandstone",
    "fluid_density", "bulk_density", "rho_sat_from_components",
    "PetrophysicalTransform", "ResistivityToSaturation",
    "VelocityToPorosity", "PermittivityToSaturation",
    "JointPetrophysics",
    "WATER_DENSITY", "OIL_DENSITY", "GAS_DENSITY",
    "WATER_MODULUS", "OIL_MODULUS", "GAS_MODULUS",
    "WATER_PERMITTIVITY", "OIL_PERMITTIVITY", "GAS_PERMITTIVITY",
    "QUARTZ_DENSITY", "QUARTZ_K", "QUARTZ_MU",
    "CLAY_DENSITY", "CLAY_K", "CLAY_MU",
]
