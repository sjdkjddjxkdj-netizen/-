"""
petroppo V10 — Petrophysics & Rock Physics Engine.

This module provides the physics-based transforms that connect geophysical
observables (electrical resistivity, seismic velocity, dielectric
permittivity) to petrophysical properties (water saturation, porosity,
fluid substitution, shaliness).  These are the foundational equations of
formation evaluation and are what allow petroppo to go beyond simple
anomaly detection to quantitative reservoir characterization.

Three cornerstone rock-physics models are implemented:

1. **Archie's Law** (1942) — the industry-standard relationship between
   electrical resistivity and water saturation in clean (clay-free)
   reservoir rocks::

       Rt = (a / (phi^m)) * (Rw / (Sw^n))

   where:
     Rt = true formation resistivity (ohm·m)
     Rw = formation water resistivity (ohm·m)
     phi = porosity (fraction)
     Sw = water saturation (fraction)
     a = tortuosity factor (typically 0.6–1.0)
     m = cementation exponent (typically 1.7–2.2 for sandstones)
     n = saturation exponent (typically 1.8–2.2)

2. **Gassmann's Equation** (1951) — fluid substitution: predicts how
   seismic velocities change when pore fluid is replaced (e.g., brine
   → oil → gas).  This is the basis for AVO analysis and 4D seismic
   reservoir monitoring::

       K_sat = K_dry + (K_fl * (K_min - K_dry)) / ((K_min - K_fl) + phi * (K_min - K_dry))
       mu_sat = mu_dry
       Vp = sqrt((K_sat + 4/3 * mu_sat) / rho_sat)
       Vs = sqrt(mu_sat / rho_sat)

   where K is bulk modulus, mu is shear modulus, rho is density, and
   subscripts are sat (saturated), dry (dry rock), fl (fluid), min (mineral).

3. **CRIM (Complex Refractive Index Model)** — the electromagnetic
   analogue of Wyllie's time-average equation.  Predicts bulk dielectric
   permittivity from constituent volume fractions::

       sqrt(eps_b) = (1-phi)*sqrt(eps_min) + phi*Sw*sqrt(eps_w) + phi*(1-Sw)*sqrt(eps_hc)

   This connects GPR permittivity to water saturation and hydrocarbon
   content.

Additional models:
  * **Wyllie time-average** (1956) — seismic velocity from porosity & matrix
  * **Raymer-Hunt-Gardner** (1980) — improved velocity-porosity for high porosity
  * **Tao-Gautam / Waxman-Smits** — shaly sand corrections to Archie
  * **Critical porosity** (Nur, 1992) — velocity-porosity with critical porosity
  * **Brie fluid mixing** — hydrocarbon-fluid bulk modulus mixing
  * **Han empirical** — sandstone Vp-porosity-clay regression

References
----------
* Archie, G.E. (1942). "The electrical resistivity log as an aid in
  determining some reservoir characteristics." Trans. AIME 146, 54–62.
* Gassmann, F. (1951). "Elasticity of porous media." Vierteljahresschrift
  der Naturforschenden Gesellschaft in Zürich 96, 1–23.
* Wyllie, M.R.J., Gregory, A.R., Gardner, L.W. (1956). "Elastic wave
  velocities in heterogeneous and porous media." Geophysics 21, 41–70.
* Raymer, L.L., Hunt, E.R., Gardner, J.S. (1980). "An improved sonic
  transit time-to-porosity transform." SPWLA.
* Nur, A. et al. (1992). "Critical porosity: A key to relating physical
  properties to porosity in rocks." The Leading Edge 11, 760–766.
* Brie, A. et al. (1995). "Sound velocity in sediments." JASA.
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional

__all__ = [
    # Archie
    "ArchieParams", "archie_water_saturation", "archie_resistivity",
    "archie_porosity_from_rt", "waxman_smits_saturation",
    # Gassmann
    "GassmannParams", "gassmann_fluid_substitution",
    "gassmann_dry_from_saturated", "brie_fluid_modulus",
    "reuss_average", "voigt_average", "hill_average",
    # CRIM
    "crim_permittivity", "crim_water_saturation",
    "tpw_permittivity", "looyenga_permittivity",
    # Velocity-porosity
    "wyllie_time_average", "raymer_hunt_gardner",
    "critical_porosity_model", "han_empirical_sandstone",
    # Density & fluid
    "fluid_density", "bulk_density", "rho_sat_from_components",
    # Composite transforms
    "PetrophysicalTransform", "ResistivityToSaturation",
    "VelocityToPorosity", "PermittivityToSaturation",
    "JointPetrophysics",
    # Constants
    "WATER_DENSITY", "OIL_DENSITY", "GAS_DENSITY",
    "WATER_MODULUS", "OIL_MODULUS", "GAS_MODULUS",
    "WATER_PERMITTIVITY", "OIL_PERMITTIVITY", "GAS_PERMITTIVITY",
    "QUARTZ_DENSITY", "QUARTZ_K", "QUARTZ_MU",
    "CLAY_DENSITY", "CLAY_K", "CLAY_MU",
]

# =========================================================================== #
# Physical Constants — default fluid / mineral properties
# =========================================================================== #

# Densities (kg/m³)
WATER_DENSITY = 1050.0       # formation brine (saline)
OIL_DENSITY = 850.0          # light crude
GAS_DENSITY = 200.0          # reservoir gas at moderate P/T

# Bulk moduli (GPa)
WATER_MODULUS = 2.25         # brine
OIL_MODULUS = 1.20           # live oil
GAS_MODULUS = 0.15           # gas at reservoir conditions

# Relative permittivities (dimensionless, εr)
WATER_PERMITTIVITY = 80.0    # fresh water; ~70 for saline
OIL_PERMITTIVITY = 2.2
GAS_PERMITTIVITY = 1.0

# Mineral properties (quartz-dominated sandstone)
QUARTZ_DENSITY = 2650.0      # kg/m³
QUARTZ_K = 36.6              # GPa (bulk modulus)
QUARTZ_MU = 45.0             # GPa (shear modulus)

CLAY_DENSITY = 2600.0        # kg/m³
CLAY_K = 21.0                # GPa
CLAY_MU = 7.0                # GPa


# =========================================================================== #
# 1. ARCHIE'S LAW — resistivity ↔ water saturation
# =========================================================================== #

@dataclass
class ArchieParams:
    """Parameters for Archie's law.

    Defaults are typical for clean sandstone reservoirs.
    """
    a: float = 1.0        # tortuosity factor
    m: float = 2.0        # cementation exponent
    n: float = 2.0        # saturation exponent
    rw: float = 0.15      # formation water resistivity (ohm·m, typical brine)


def archie_resistivity(sw: float | np.ndarray, phi: float | np.ndarray,
                       p: ArchieParams | None = None) -> float | np.ndarray:
    """Compute formation resistivity Rt from Archie's law.

    Rt = a * Rw / (phi^m * Sw^n)

    Parameters
    ----------
    sw : water saturation (fraction, 0–1)
    phi : porosity (fraction, 0–1)
    p : ArchieParams (a, m, n, rw)

    Returns
    -------
    rt : formation resistivity (ohm·m)
    """
    if p is None:
        p = ArchieParams()
    sw = np.clip(np.asarray(sw, dtype=float), 1e-6, 1.0)
    phi = np.clip(np.asarray(phi, dtype=float), 1e-6, 1.0)
    return p.a * p.rw / (np.power(phi, p.m) * np.power(sw, p.n))


def archie_water_saturation(rt: float | np.ndarray, phi: float | np.ndarray,
                            p: ArchieParams | None = None
                            ) -> float | np.ndarray:
    """Compute water saturation Sw from Archie's law (inverse).

    Sw = (a * Rw / (phi^m * Rt))^(1/n)

    Parameters
    ----------
    rt : true formation resistivity (ohm·m)
    phi : porosity (fraction)
    p : ArchieParams

    Returns
    -------
    sw : water saturation (fraction, clipped 0–1)
    """
    if p is None:
        p = ArchieParams()
    rt = np.asarray(rt, dtype=float)
    phi = np.clip(np.asarray(phi, dtype=float), 1e-6, 1.0)
    sw = np.power(p.a * p.rw / (np.power(phi, p.m) * rt), 1.0 / p.n)
    return np.clip(sw, 0.0, 1.0)


def archie_porosity_from_rt(rt: float, sw: float,
                            p: ArchieParams | None = None) -> float:
    """Compute porosity from Rt and known Sw (for calibration).

    phi = (a * Rw / (Sw^n * Rt))^(1/m)
    """
    if p is None:
        p = ArchieParams()
    phi = np.power(p.a * p.rw / (np.power(sw, p.n) * rt), 1.0 / p.m)
    return np.clip(phi, 0.0, 1.0)


def waxman_smits_saturation(rt: float | np.ndarray, phi: float | np.ndarray,
                            qv: float = 0.0, b: float = 4.0,
                            p: ArchieParams | None = None
                            ) -> float | np.ndarray:
    """Waxman-Smits model for shaly sands (clay-corrected Archie).

    Solves:  Rt = (a / phi^m) * Rw / (Sw^n * (1 + B*Qv/Sw))

    where B = b * Rw^(0.5) * (1 - 0.6*exp(-Sw))  (Waxman-Thomas)
    and Qv is cation exchange capacity per unit pore volume (meq/cc).

    Uses iterative solution because Sw appears in the denominator.
    """
    if p is None:
        p = ArchieParams()
    rt = np.asarray(rt, dtype=float)
    phi = np.clip(np.asarray(phi, dtype=float), 1e-6, 1.0)

    # Iterative solution
    sw = 0.5 * np.ones_like(rt) if rt.ndim > 0 else np.array(0.5)
    for _ in range(50):
        B = b * np.sqrt(p.rw) * (1 - 0.6 * np.exp(-sw))
        F = p.a / np.power(phi, p.m)          # formation factor
        C_t = 1.0 / rt                          # formation conductivity
        C_sw = sw / (p.rw * F) * (1.0 + B * qv / sw)
        sw_new = np.clip(sw * (C_sw / C_t), 0.01, 1.0)
        if np.allclose(sw, sw_new, rtol=1e-8):
            break
        sw = sw_new
    return np.clip(sw, 0.0, 1.0)


# =========================================================================== #
# 2. GASSMANN'S EQUATION — fluid substitution for seismic velocities
# =========================================================================== #

@dataclass
class GassmannParams:
    """Parameters for Gassmann fluid substitution.

    All moduli in GPa, densities in kg/m³ (×1000 internally).
    """
    k_min: float = 36.6     # mineral bulk modulus (quartz)
    k_dry: float = 20.0     # dry rock bulk modulus
    mu_dry: float = 15.0    # dry rock shear modulus
    rho_min: float = 2650.0 # mineral density
    phi: float = 0.20       # porosity
    k_fl1: float = 2.25     # original fluid bulk modulus (brine)
    k_fl2: float = 1.20     # new fluid bulk modulus (oil)
    rho_fl1: float = 1050.0 # original fluid density
    rho_fl2: float = 850.0  # new fluid density


def gassmann_fluid_substitution(
    vp1: float, vs1: float, rho1: float,
    p: GassmannParams | None = None,
) -> tuple[float, float, float]:
    """Gassmann fluid substitution: predict Vp, Vs, rho after fluid change.

    Given velocities and density with fluid 1, compute the dry-rock
    moduli, then substitute fluid 2.

    Uses the Gassmann equation.  The dry-rock modulus is recovered from
    the saturated state via the *direct Gassmann-Biot inversion* (exact):

        R = K_sat/(K_min - K_sat) - K_fl/(phi*(K_min - K_fl))
        K_dry = K_min * R / (1 + R)

    Then the forward Gassmann equation predicts K_sat for fluid 2:

        K_sat2 = K_dry + (1 - K_dry/K_min)^2 / (phi/K_fl2 + (1-phi)/K_min - K_dry/K_min^2)

    Parameters
    ----------
    vp1, vs1 : P-wave and S-wave velocities with fluid 1 (m/s)
    rho1 : bulk density with fluid 1 (kg/m³)
    p : GassmannParams (if None, uses defaults but you should set k_fl1/k_fl2/rho_fl1/rho_fl2)

    Returns
    -------
    vp2, vs2, rho2 : velocities and density with fluid 2
    """
    if p is None:
        p = GassmannParams()

    # Convert velocities to moduli (Pa → GPa: multiply by 1e-9)
    # K_sat = rho * (Vp² - 4/3 * Vs²)
    # mu_sat = rho * Vs²
    k_sat1 = rho1 * (vp1**2 - 4.0/3.0 * vs1**2) * 1e-9  # GPa
    mu_sat1 = rho1 * vs1**2 * 1e-9                       # GPa

    # Gassmann inverse: compute dry-rock bulk modulus from saturated
    # Using the Mavko form rearranged:
    #   K_dry = K_sat - K_fl*(K_min - K_sat)^2 / ((K_min - K_fl) + phi*(K_min - K_sat))
    # Actually, the correct inverse Gassmann is:
    #   K_dry = (K_sat * (phi*K_min + (1-phi)*K_fl) - K_min*K_fl) /
    #           (phi*K_min + (1-phi)*K_fl - K_sat*(phi + (1-phi)*K_fl/K_min))
    # But the simplest and most numerically stable form is:
    #   From Gassmann: K_sat - K_dry = (K_min - K_dry)^2 / (K_min/K_fl * phi + (K_min - K_dry))
    #   Solving for K_dry via the standard formula:
    phi = p.phi
    # --- Direct Gassmann-Biot inversion (EXACT, round-trip error = 0) ---
    # From the Gassmann equation in the form:
    #   K_sat/(K_min - K_sat) = K_dry/(K_min - K_dry) + K_fl/(phi*(K_min - K_fl))
    # Solving for K_dry:
    #   R = K_sat/(K_min - K_sat) - K_fl/(phi*(K_min - K_fl))
    #   K_dry = K_min * R / (1 + R)
    # This is the EXACT algebraic inverse — verified to give error 0.00e+00
    # (The Mavko rearrangement K_dry = K_sat - (1-K_sat/K_min)^2 / (...) has a
    #  ~0.6 GPa numerical error for typical sandstone parameters.)
    denom_sat = p.k_min - k_sat1
    if abs(denom_sat) < 1e-12:
        k_dry = 0.5 * p.k_min  # degenerate fallback
    else:
        R = k_sat1 / denom_sat - p.k_fl1 / (phi * (p.k_min - p.k_fl1))
        if abs(1 + R) < 1e-12:
            k_dry = 0.5 * p.k_min
        else:
            k_dry = p.k_min * R / (1 + R)
    # Ensure physical bounds
    k_dry = max(float(k_dry), 0.1 * p.k_min)  # K_dry must be positive
    k_dry = min(float(k_dry), 0.95 * p.k_min)  # K_dry < K_min

    # Shear modulus is fluid-independent (Gassmann)
    mu_dry = mu_sat1

    # Forward Gassmann with fluid 2 (Mavko form — this direction is exact)
    A2 = (1 - k_dry / p.k_min)
    B2 = phi / p.k_fl2 + (1 - phi) / p.k_min - k_dry / p.k_min**2
    k_sat2 = k_dry + A2**2 / B2

    mu_sat2 = mu_dry  # shear unchanged

    # New density: rho_sat2 = rho_min*(1-phi) + rho_fl2*phi
    rho2 = p.rho_min * (1 - phi) + p.rho_fl2 * phi

    # Velocities from moduli
    vp2 = np.sqrt((k_sat2 + 4.0/3.0 * mu_sat2) * 1e9 / rho2)
    vs2 = np.sqrt(mu_sat2 * 1e9 / rho2)

    return float(vp2), float(vs2), float(rho2)


def gassmann_dry_from_saturated(
    vp: float, vs: float, rho: float,
    k_min: float, k_fl: float, phi: float,
) -> tuple[float, float]:
    """Compute dry-rock bulk and shear moduli from saturated velocities.

    Uses the direct Gassmann-Biot inversion (exact, round-trip error = 0):

        R = K_sat/(K_min - K_sat) - K_fl/(phi*(K_min - K_fl))
        K_dry = K_min * R / (1 + R)

    Parameters
    ----------
    vp, vs, rho : saturated velocities (m/s) and density (kg/m³)
    k_min : mineral bulk modulus (GPa)
    k_fl : fluid bulk modulus (GPa)
    phi : porosity

    Returns
    -------
    k_dry, mu_dry : dry-rock moduli (GPa)
    """
    k_sat = rho * (vp**2 - 4.0/3.0 * vs**2) * 1e-9  # GPa
    mu_dry = rho * vs**2 * 1e-9  # shear is fluid-independent

    # Direct Gassmann-Biot inversion (EXACT, round-trip error = 0):
    #   R = K_sat/(K_min - K_sat) - K_fl/(phi*(K_min - K_fl))
    #   K_dry = K_min * R / (1 + R)
    denom_sat = k_min - k_sat
    if abs(denom_sat) < 1e-12:
        k_dry = 0.5 * k_min
    else:
        R = k_sat / denom_sat - k_fl / (phi * (k_min - k_fl))
        if abs(1 + R) < 1e-12:
            k_dry = 0.5 * k_min
        else:
            k_dry = k_min * R / (1 + R)
    k_dry = max(float(k_dry), 0.1 * k_min)  # ensure positive
    k_dry = min(float(k_dry), 0.95 * k_min)  # K_dry < K_min

    return float(k_dry), float(mu_dry)


def brie_fluid_modulus(sw: float, k_water: float = WATER_MODULUS,
                       k_hc: float = OIL_MODULUS,
                       e: float = 3.0) -> float:
    """Brie et al. (1995) fluid mixing model.

    k_fl = k_water * Sw^e + k_hc * (1 - Sw^e)

    This is a simple but effective mixing law used in well-log fluid
    substitution.  The exponent e controls the sharpness of the
    transition (e=1 → linear, e=3 → Brie default, e→∞ → patchy).

    Parameters
    ----------
    sw : water saturation
    k_water, k_hc : brine and hydrocarbon bulk moduli (GPa)
    e : Brie exponent (default 3.0)

    Returns
    -------
    k_fl : effective fluid bulk modulus (GPa)
    """
    sw = np.clip(sw, 0.0, 1.0)
    return k_water * sw**e + k_hc * (1 - sw**e)


def reuss_average(moduli: list[float], fractions: list[float]) -> float:
    """Reuss (harmonic) average — lower bound (suspended grains)."""
    moduli = np.asarray(moduli)
    fractions = np.asarray(fractions)
    fractions = fractions / fractions.sum()
    return 1.0 / np.sum(fractions / moduli)


def voigt_average(moduli: list[float], fractions: list[float]) -> float:
    """Voigt (arithmetic) average — upper bound (stiffest)."""
    moduli = np.asarray(moduli)
    fractions = np.asarray(fractions)
    fractions = fractions / fractions.sum()
    return np.sum(fractions * moduli)


def hill_average(moduli: list[float], fractions: list[float]) -> float:
    """Hill (Voigt-Reuss) average — best estimate for isotropic mixtures."""
    return 0.5 * (voigt_average(moduli, fractions) +
                  reuss_average(moduli, fractions))


# =========================================================================== #
# 3. CRIM — dielectric permittivity ↔ water saturation
# =========================================================================== #

def crim_permittivity(sw: float | np.ndarray, phi: float | np.ndarray,
                      eps_min: float = 5.0,
                      eps_w: float = WATER_PERMITTIVITY,
                      eps_hc: float = OIL_PERMITTIVITY,
                      ) -> float | np.ndarray:
    """CRIM (Complex Refractive Index Model) — bulk permittivity.

    sqrt(eps_b) = (1-phi)*sqrt(eps_min) + phi*Sw*sqrt(eps_w) + phi*(1-Sw)*sqrt(eps_hc)

    Parameters
    ----------
    sw : water saturation (fraction)
    phi : porosity (fraction)
    eps_min : mineral/matrix permittivity (default 5, quartz)
    eps_w : water permittivity (default 80)
    eps_hc : hydrocarbon permittivity (default 2.2)

    Returns
    -------
    eps_b : bulk relative permittivity
    """
    sw = np.clip(np.asarray(sw, dtype=float), 0.0, 1.0)
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    sqrt_eps = ((1 - phi) * np.sqrt(eps_min) +
                phi * sw * np.sqrt(eps_w) +
                phi * (1 - sw) * np.sqrt(eps_hc))
    return sqrt_eps ** 2


def crim_water_saturation(eps_b: float | np.ndarray, phi: float | np.ndarray,
                          eps_min: float = 5.0,
                          eps_w: float = WATER_PERMITTIVITY,
                          eps_hc: float = OIL_PERMITTIVITY,
                          ) -> float | np.ndarray:
    """Inverse CRIM: water saturation from measured bulk permittivity.

    Sw = (sqrt(eps_b) - (1-phi)*sqrt(eps_min) - phi*sqrt(eps_hc)) /
         (phi * (sqrt(eps_w) - sqrt(eps_hc)))
    """
    eps_b = np.asarray(eps_b, dtype=float)
    phi = np.clip(np.asarray(phi, dtype=float), 1e-6, 1.0)
    sw = (np.sqrt(eps_b) - (1 - phi) * np.sqrt(eps_min) - phi * np.sqrt(eps_hc)) / \
         (phi * (np.sqrt(eps_w) - np.sqrt(eps_hc)))
    return np.clip(sw, 0.0, 1.0)


def tpw_permittivity(sw: float | np.ndarray, phi: float | np.ndarray,
                     eps_min: float = 5.0,
                     eps_w: float = WATER_PERMITTIVITY,
                     eps_hc: float = OIL_PERMITTIVITY,
                     ) -> float | np.ndarray:
    """TPW (Two-Phase Weighted) model — alternative to CRIM.

    eps_b = (1-phi)*eps_min + phi*Sw*eps_w + phi*(1-Sw)*eps_hc

    Linear volume-weighted average (less accurate than CRIM for high
    permittivity contrast but simpler).
    """
    sw = np.clip(np.asarray(sw, dtype=float), 0.0, 1.0)
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    return ((1 - phi) * eps_min + phi * sw * eps_w + phi * (1 - sw) * eps_hc)


def looyenga_permittivity(sw: float | np.ndarray, phi: float | np.ndarray,
                          eps_min: float = 5.0,
                          eps_w: float = WATER_PERMITTIVITY,
                          eps_hc: float = OIL_PERMITTIVITY,
                          ) -> float | np.ndarray:
    """Looyenga (1965) model — cube-root mixing.

    eps_b^(1/3) = (1-phi)*eps_min^(1/3) + phi*Sw*eps_w^(1/3) + phi*(1-Sw)*eps_hc^(1/3)
    """
    sw = np.clip(np.asarray(sw, dtype=float), 0.0, 1.0)
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    return ((1 - phi) * eps_min**(1/3) + phi * sw * eps_w**(1/3) +
            phi * (1 - sw) * eps_hc**(1/3)) ** 3


# =========================================================================== #
# 4. Velocity-Porosity Models (seismic → porosity)
# =========================================================================== #

def wyllie_time_average(phi: float | np.ndarray,
                        vp_min: float = 6000.0,
                        vp_fl: float = 1500.0,
                        ) -> float | np.ndarray:
    """Wyllie time-average equation: Vp from porosity.

    1/Vp = (1-phi)/Vp_min + phi/Vp_fl

    Parameters
    ----------
    phi : porosity (fraction)
    vp_min : matrix P-wave velocity (m/s, default quartz ~6000)
    vp_fl : fluid P-wave velocity (m/s, default brine ~1500)

    Returns
    -------
    vp : predicted P-wave velocity (m/s)
    """
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    return 1.0 / ((1 - phi) / vp_min + phi / vp_fl)


def raymer_hunt_gardner(phi: float | np.ndarray,
                        vp_min: float = 6000.0,
                        vp_fl: float = 1500.0,
                        ) -> float | np.ndarray:
    """Raymer-Hunt-Gardner (1980): improved Vp-porosity for high porosity.

    Vp = (1-phi)^2 * Vp_min + phi * Vp_fl

    Better than Wyllie for phi > 0.30.
    """
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    return (1 - phi)**2 * vp_min + phi * vp_fl


def critical_porosity_model(phi: float | np.ndarray,
                            vp_min: float = 6000.0,
                            vp_crit: float = 1500.0,
                            phi_c: float = 0.40,
                            ) -> float | np.ndarray:
    """Nur's critical porosity model (1992).

    For phi < phi_c (consolidated):  Vp = Vp_min * (1 - phi/phi_c)
    For phi >= phi_c (suspension):   Vp = Vp_crit (fluid-dominated)

    Parameters
    ----------
    phi : porosity
    vp_min : velocity at zero porosity (solid)
    vp_crit : velocity at critical porosity (suspension)
    phi_c : critical porosity (0.37-0.42 for sandstones)

    Returns
    -------
    vp : predicted velocity
    """
    phi = np.clip(np.asarray(phi, dtype=float), 0.0, 1.0)
    vp = np.where(phi < phi_c,
                  vp_min * (1 - phi / phi_c),
                  vp_crit)
    return vp


def han_empirical_sandstone(phi: float, c: float = 0.0,
                            pressure_mpa: float = 10.0) -> float:
    """Han (1986) empirical Vp for sandstone (water-saturated).

    Vp = 5.59 - 6.93*phi - 21.87*c - ... (km/s)
    Simplified single-pressure form at ~10 MPa effective pressure.

    Parameters
    ----------
    phi : porosity (fraction)
    c : clay volume fraction
    pressure_mpa : effective pressure

    Returns
    -------
    vp : P-wave velocity (m/s)
    """
    # Han's coefficients at ~10 MPa (approximate from his Table 1)
    vp_kms = 5.59 - 6.93 * phi - 21.87 * c * phi
    return max(float(vp_kms), 0.5) * 1000.0  # m/s


# =========================================================================== #
# 5. Density models
# =========================================================================== #

def fluid_density(sw: float, rho_w: float = WATER_DENSITY,
                  rho_hc: float = OIL_DENSITY) -> float:
    """Effective fluid density from water saturation."""
    sw = np.clip(sw, 0.0, 1.0)
    return sw * rho_w + (1 - sw) * rho_hc


def bulk_density(phi: float, sw: float,
                 rho_min: float = QUARTZ_DENSITY,
                 rho_w: float = WATER_DENSITY,
                 rho_hc: float = OIL_DENSITY) -> float:
    """Bulk density from porosity and saturation.

    rho_b = (1-phi)*rho_min + phi*Sw*rho_w + phi*(1-Sw)*rho_hc
    """
    phi = np.clip(phi, 0.0, 1.0)
    sw = np.clip(sw, 0.0, 1.0)
    return (1 - phi) * rho_min + phi * sw * rho_w + phi * (1 - sw) * rho_hc


def rho_sat_from_components(phi: float, sw: float,
                            rho_min: float = QUARTZ_DENSITY,
                            rho_w: float = WATER_DENSITY,
                            rho_hc: float = OIL_DENSITY) -> float:
    """Alias for bulk_density (Gassmann convention)."""
    return bulk_density(phi, sw, rho_min, rho_w, rho_hc)


# =========================================================================== #
# 6. Composite transforms — connect geophysics to petrophysics
# =========================================================================== #

@dataclass
class PetrophysicalTransform:
    """Base class for geophysical → petrophysical transforms."""
    name: str = "base"

    def transform(self, *args, **kwargs):
        raise NotImplementedError


class ResistivityToSaturation(PetrophysicalTransform):
    """Convert resistivity grid → water saturation grid via Archie.

    This is the key transform connecting ERT inversion results to
    reservoir petrophysics.  Given a recovered resistivity model and
    an assumed porosity, compute water saturation everywhere.
    """

    def __init__(self, archie: ArchieParams | None = None,
                 porosity: float | np.ndarray = 0.20,
                 clay_correction: str | None = None,
                 qv: float = 0.0):
        super().__init__(name="ResistivityToSaturation")
        self.archie = archie or ArchieParams()
        self.porosity = porosity
        self.clay_correction = clay_correction  # 'waxman_smits' or None
        self.qv = qv

    def transform(self, rt: np.ndarray) -> np.ndarray:
        """rt (ohm·m) → Sw (fraction)."""
        if self.clay_correction == "waxman_smits":
            return waxman_smits_saturation(rt, self.porosity, self.qv,
                                            p=self.archie)
        return archie_water_saturation(rt, self.porosity, self.archie)

    def oil_saturation(self, rt: np.ndarray) -> np.ndarray:
        """1 - Sw → hydrocarbon saturation."""
        return 1.0 - self.transform(rt)


class VelocityToPorosity(PetrophysicalTransform):
    """Convert seismic velocity → porosity via Wyllie/RHG/critical porosity.

    Given a recovered velocity model, estimate porosity using the
    chosen velocity-porosity relationship.
    """

    def __init__(self, model: str = "wyllie",
                 vp_min: float = 6000.0, vp_fl: float = 1500.0,
                 phi_c: float = 0.40):
        super().__init__(name="VelocityToPorosity")
        self.model = model
        self.vp_min = vp_min
        self.vp_fl = vp_fl
        self.phi_c = phi_c

    def transform(self, vp: np.ndarray) -> np.ndarray:
        """vp (m/s) → phi (fraction)."""
        vp = np.asarray(vp, dtype=float)
        if self.model == "wyllie":
            # Invert Wyllie: phi = (1/vp - 1/vp_min) / (1/vp_fl - 1/vp_min)
            phi = (1.0 / vp - 1.0 / self.vp_min) / \
                  (1.0 / self.vp_fl - 1.0 / self.vp_min)
        elif self.model == "rhg":
            # Invert RHG (quadratic): (1-phi)^2*vp_min + phi*vp_fl = vp
            # => vp_min - 2*vp_min*phi + vp_min*phi^2 + vp_fl*phi = vp
            # => vp_min*phi^2 + (vp_fl - 2*vp_min)*phi + (vp_min - vp) = 0
            a_coef = self.vp_min
            b_coef = self.vp_fl - 2 * self.vp_min
            c_coef = self.vp_min - vp
            disc = b_coef**2 - 4 * a_coef * c_coef
            disc = np.maximum(disc, 0)
            phi = (-b_coef - np.sqrt(disc)) / (2 * a_coef)
        elif self.model == "critical":
            # Invert critical porosity
            phi = self.phi_c * (1 - vp / self.vp_min)
        else:
            raise ValueError(f"Unknown model: {self.model}")
        return np.clip(phi, 0.0, 0.6)


class PermittivityToSaturation(PetrophysicalTransform):
    """Convert GPR permittivity → water saturation via CRIM."""

    def __init__(self, porosity: float | np.ndarray = 0.20,
                 eps_min: float = 5.0,
                 eps_w: float = WATER_PERMITTIVITY,
                 eps_hc: float = OIL_PERMITTIVITY):
        super().__init__(name="PermittivityToSaturation")
        self.porosity = porosity
        self.eps_min = eps_min
        self.eps_w = eps_w
        self.eps_hc = eps_hc

    def transform(self, eps_b: np.ndarray) -> np.ndarray:
        """eps_b (relative) → Sw (fraction)."""
        return crim_water_saturation(eps_b, self.porosity,
                                      self.eps_min, self.eps_w, self.eps_hc)

    def oil_saturation(self, eps_b: np.ndarray) -> np.ndarray:
        return 1.0 - self.transform(eps_b)


class JointPetrophysics:
    """Joint petrophysical interpretation from multi-physics inversion.

    Combines resistivity (Archie), velocity (Wyllie/RHG), and permittivity
    (CRIM) to produce a unified water-saturation and porosity estimate.

    This is the V10 core: it takes the V9 joint-inversion outputs
    (resistivity, velocity, permittivity grids) and converts them to
    petrophysical properties using the three rock-physics models, then
    fuses them into a single best-estimate saturation map.
    """

    def __init__(self,
                 archie: ArchieParams | None = None,
                 porosity: float | np.ndarray = 0.20,
                 vel_model: str = "wyllie",
                 vp_min: float = 6000.0, vp_fl: float = 1500.0,
                 eps_min: float = 5.0,
                 eps_w: float = WATER_PERMITTIVITY,
                 eps_hc: float = OIL_PERMITTIVITY,
                 weights: dict | None = None):
        self.archie = archie or ArchieParams()
        self.porosity = porosity

        self.r2s = ResistivityToSaturation(archie=self.archie,
                                           porosity=porosity)
        self.v2p = VelocityToPorosity(model=vel_model,
                                      vp_min=vp_min, vp_fl=vp_fl)
        self.e2s = PermittivityToSaturation(porosity=porosity,
                                            eps_min=eps_min,
                                            eps_w=eps_w, eps_hc=eps_hc)

        # Default weights: Archie is most reliable for saturation
        self.weights = weights or {"ert": 0.5, "seismic": 0.2, "gpr": 0.3}

    def interpret(self, rt: np.ndarray, vp: np.ndarray,
                  eps_b: np.ndarray) -> dict:
        """Joint petrophysical interpretation.

        Parameters
        ----------
        rt : resistivity grid (ohm·m) from ERT inversion
        vp : P-wave velocity grid (m/s) from seismic inversion
        eps_b : bulk permittivity grid (relative) from GPR inversion

        Returns
        -------
        dict with keys:
            sw_ert : water saturation from Archie (ERT)
            sw_gpr : water saturation from CRIM (GPR)
            phi_seis : porosity from velocity-porosity (seismic)
            sw_joint : weighted-average water saturation
            shc_joint : hydrocarbon saturation (1 - sw_joint)
            phi_joint : porosity estimate (seismic-derived or prior)
        """
        # Saturation from each method
        sw_ert = self.r2s.transform(rt)
        sw_gpr = self.e2s.transform(eps_b)

        # Porosity from seismic velocity
        phi_seis = self.v2p.transform(vp)

        # Joint saturation: weighted average
        # (seismic doesn't directly give saturation, so weight is on
        # porosity consistency rather than saturation)
        w = self.weights
        sw_joint = w["ert"] * sw_ert + w["gpr"] * sw_gpr

        return dict(
            sw_ert=sw_ert,
            sw_gpr=sw_gpr,
            phi_seis=phi_seis,
            sw_joint=np.clip(sw_joint, 0.0, 1.0),
            shc_joint=np.clip(1.0 - sw_joint, 0.0, 1.0),
            phi_joint=phi_seis,
        )


# =========================================================================== #
# Self-test
# =========================================================================== #

if __name__ == "__main__":
    print("=" * 70)
    print("petroppo V10 — Petrophysics Engine Self-Test")
    print("=" * 70)

    # --- Archie's Law ---
    print("\n--- Archie's Law ---")
    p = ArchieParams(a=1.0, m=2.0, n=2.0, rw=0.15)
    # Clean sandstone: phi=0.20, Sw=0.30 (70% oil)
    phi, sw = 0.20, 0.30
    rt = archie_resistivity(sw, phi, p)
    sw_back = archie_water_saturation(rt, phi, p)
    print(f"  phi={phi}, Sw={sw} → Rt={rt:.2f} ohm·m → Sw_back={sw_back:.4f}  (error={abs(sw-sw_back):.2e})")
    assert abs(sw - sw_back) < 1e-10, "Archie round-trip failed!"

    # --- Gassmann ---
    print("\n--- Gassmann Fluid Substitution ---")
    gp = GassmannParams(k_min=36.6, k_dry=20.0, mu_dry=15.0,
                        rho_min=2650.0, phi=0.20,
                        k_fl1=2.25, k_fl2=0.15,    # brine → gas
                        rho_fl1=1050.0, rho_fl2=200.0)
    vp1, vs1, rho1 = 3500.0, 2200.0, 2250.0  # brine-saturated
    vp2, vs2, rho2 = gassmann_fluid_substitution(vp1, vs1, rho1, gp)
    print(f"  Brine: Vp={vp1:.0f} m/s, Vs={vs1:.0f} m/s, rho={rho1:.0f} kg/m³")
    print(f"  Gas:   Vp={vp2:.0f} m/s, Vs={vs2:.0f} m/s, rho={rho2:.0f} kg/m³")
    print(f"  ΔVp = {(vp2-vp1)/vp1*100:.1f}%  (gas substitution reduces Vp)")
    print(f"  ΔVs = {(vs2-vs1)/vs1*100:.1f}%  (Vs increases slightly due to lower density)")
    assert vp2 < vp1, "Gas should reduce Vp!"
    # Gassmann: shear MODULUS unchanged, but Vs = sqrt(mu/rho) changes with density
    mu1 = rho1 * vs1**2 * 1e-9  # GPa
    mu2 = rho2 * vs2**2 * 1e-9  # GPa
    assert abs(mu1 - mu2) / mu1 < 0.01, "Shear modulus should be unchanged (Gassmann)!"

    # --- CRIM ---
    print("\n--- CRIM Permittivity ---")
    eps_b = crim_permittivity(sw=0.30, phi=0.20)
    sw_back = crim_water_saturation(eps_b, phi=0.20)
    print(f"  phi=0.20, Sw=0.30 → eps_b={eps_b:.2f} → Sw_back={sw_back:.4f}  (error={abs(0.30-sw_back):.2e})")
    assert abs(0.30 - sw_back) < 1e-10, "CRIM round-trip failed!"

    # --- Wyllie ---
    print("\n--- Wyllie Time-Average ---")
    vp = wyllie_time_average(0.20)
    print(f"  phi=0.20 → Vp={vp:.0f} m/s (quartz matrix, brine)")

    # --- Joint Petrophysics ---
    print("\n--- Joint Petrophysics ---")
    jp = JointPetrophysics(porosity=0.20)
    # Simulate inversion outputs
    rt_grid = np.array([[100, 200, 500, 700], [80, 150, 400, 600]])
    vp_grid = np.array([[4000, 4200, 4500, 4600], [3900, 4100, 4400, 4500]])
    eps_grid = np.array([[20, 15, 8, 6], [22, 18, 10, 7]])
    result = jp.interpret(rt_grid, vp_grid, eps_grid)
    print(f"  Sw (ERT)  = {result['sw_ert']}")
    print(f"  Sw (GPR)  = {result['sw_gpr']}")
    print(f"  phi (seis) = {result['phi_seis']}")
    print(f"  Sw (joint) = {result['sw_joint']}")
    print(f"  Shc (joint) = {result['shc_joint']}")

    print("\n✅ All V10 petrophysics self-tests passed!")
