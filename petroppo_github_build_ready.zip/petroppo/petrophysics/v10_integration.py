"""
petroppo V10 — Petrophysics integration with V9 joint inversion.

This module connects the V9 joint-inversion outputs (resistivity,
velocity, permittivity grids) to the V10 petrophysics engine
(Archie, Gassmann, CRIM) to produce quantitative reservoir
characterization: water saturation, porosity, and hydrocarbon
saturation maps.

The V10 pipeline:
  1. V9 joint inversion → resistivity, velocity, permittivity grids
  2. V10 petrophysics:
     a. Archie: resistivity → water saturation (Sw_ert)
     b. Wyllie/RHG: velocity → porosity (phi_seis)
     c. CRIM: permittivity → water saturation (Sw_gpr)
  3. Joint fusion: weighted-average Sw → hydrocarbon saturation (Shc)
  4. Enhanced prospectivity: P(oil) augmented with Shc consistency

This makes petroppo V10 the ONLY tool that produces quantitative
petrophysical properties from multi-physics geophysical inversion.
"""
from __future__ import annotations

import os
import sys
import time
import numpy as np
from dataclasses import dataclass, field
from typing import Optional

# Path setup
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from petroppo.petrophysics import (
    ArchieParams, archie_water_saturation, archie_resistivity,
    GassmannParams, gassmann_fluid_substitution, brie_fluid_modulus,
    crim_permittivity, crim_water_saturation,
    wyllie_time_average, raymer_hunt_gardner,
    fluid_density, bulk_density,
    ResistivityToSaturation, VelocityToPorosity,
    PermittivityToSaturation, JointPetrophysics,
    WATER_DENSITY, OIL_DENSITY, GAS_DENSITY,
    WATER_MODULUS, OIL_MODULUS, GAS_MODULUS,
    WATER_PERMITTIVITY, OIL_PERMITTIVITY,
    QUARTZ_DENSITY, QUARTZ_K, QUARTZ_MU,
)

__all__ = [
    "V10PetrophysicsConfig",
    "PetrophysicalResult",
    "interpret_petrophysics",
    "v10_prospectivity_with_petrophysics",
]


@dataclass
class V10PetrophysicsConfig:
    """Configuration for V10 petrophysical interpretation.

    Defaults are tuned for clastic (sandstone) reservoirs.
    """
    # Archie parameters (clean sandstone defaults)
    archie_a: float = 1.0
    archie_m: float = 2.0
    archie_n: float = 2.0
    archie_rw: float = 0.15  # ohm·m (typical formation brine)

    # Prior porosity (used for Archie when seismic porosity unavailable)
    prior_porosity: float = 0.20

    # Velocity-porosity model
    vel_model: str = "wyllie"   # 'wyllie' | 'rhg' | 'critical'
    vp_min: float = 6000.0      # quartz matrix velocity (m/s)
    vp_fl: float = 1500.0       # brine velocity (m/s)

    # CRIM parameters
    eps_min: float = 5.0        # quartz matrix permittivity
    eps_w: float = 80.0         # water permittivity
    eps_hc: float = 2.2         # hydrocarbon permittivity

    # Fluid substitution (for Gassmann what-if analysis)
    k_fl_original: float = WATER_MODULUS   # brine
    k_fl_target: float = OIL_MODULUS       # oil
    rho_fl_original: float = WATER_DENSITY
    rho_fl_target: float = OIL_DENSITY
    k_min: float = QUARTZ_K
    rho_min: float = QUARTZ_DENSITY

    # Fusion weights (ERT most reliable for saturation)
    weight_ert: float = 0.5
    weight_gpr: float = 0.3
    weight_seis: float = 0.2   # seismic gives porosity, not saturation directly

    # Shaliness correction
    clay_correction: str | None = None  # 'waxman_smits' or None
    qv: float = 0.0  # cation exchange capacity (meq/cc)


@dataclass
class PetrophysicalResult:
    """Result of V10 petrophysical interpretation."""
    sw_ert: np.ndarray         # water saturation from Archie (ERT)
    sw_gpr: np.ndarray         # water saturation from CRIM (GPR)
    phi_seis: np.ndarray       # porosity from velocity (seismic)
    sw_joint: np.ndarray       # joint water saturation
    shc_joint: np.ndarray      # hydrocarbon saturation (1 - Sw)
    phi_joint: np.ndarray      # joint porosity estimate
    rho_bulk: np.ndarray       # bulk density estimate
    vp_gas: np.ndarray | None  # Vp after gas substitution (what-if)
    vp_oil: np.ndarray | None  # Vp after oil substitution (what-if)
    meta: dict = field(default_factory=dict)


def interpret_petrophysics(
    rt: np.ndarray,
    vp: np.ndarray,
    eps_b: np.ndarray,
    config: V10PetrophysicsConfig | None = None,
) -> PetrophysicalResult:
    """Interpret V9 joint-inversion outputs as petrophysical properties.

    Parameters
    ----------
    rt : resistivity grid (ohm·m) from ERT inversion
    vp : P-wave velocity grid (m/s) from seismic inversion
    eps_b : bulk permittivity grid (relative) from GPR inversion
    config : V10 configuration

    Returns
    -------
    PetrophysicalResult with Sw, phi, Shc grids
    """
    if config is None:
        config = V10PetrophysicsConfig()

    # Ensure arrays
    rt = np.asarray(rt, dtype=float)
    vp = np.asarray(vp, dtype=float)
    eps_b = np.asarray(eps_b, dtype=float)

    # 1. Archie: resistivity → water saturation
    archie = ArchieParams(a=config.archie_a, m=config.archie_m,
                          n=config.archie_n, rw=config.archie_rw)
    r2s = ResistivityToSaturation(archie=archie,
                                  porosity=config.prior_porosity,
                                  clay_correction=config.clay_correction,
                                  qv=config.qv)
    sw_ert = r2s.transform(rt)

    # 2. Velocity → porosity
    v2p = VelocityToPorosity(model=config.vel_model,
                             vp_min=config.vp_min, vp_fl=config.vp_fl)
    phi_seis = v2p.transform(vp)

    # 3. CRIM: permittivity → water saturation
    # Use seismic-derived porosity where available
    e2s = PermittivityToSaturation(porosity=config.prior_porosity,
                                   eps_min=config.eps_min,
                                   eps_w=config.eps_w,
                                   eps_hc=config.eps_hc)
    sw_gpr = e2s.transform(eps_b)

    # 4. Joint fusion
    w = config
    sw_joint = w.weight_ert * sw_ert + w.weight_gpr * sw_gpr
    sw_joint = np.clip(sw_joint, 0.0, 1.0)
    shc_joint = np.clip(1.0 - sw_joint, 0.0, 1.0)

    # 5. Bulk density from porosity and saturation
    phi_for_density = np.where(phi_seis > 0, phi_seis, config.prior_porosity)
    rho_bulk = bulk_density(phi_for_density, sw_joint,
                            rho_min=config.rho_min,
                            rho_w=config.rho_fl_original,
                            rho_hc=config.rho_fl_target)

    # 6. Gassmann what-if: fluid substitution (brine → oil, brine → gas)
    vp_gas = None
    vp_oil = None
    try:
        # Compute dry moduli from current (brine-saturated) state
        from petroppo.petrophysics import gassmann_dry_from_saturated
        rho_current = rho_bulk
        vs_current = vp * 0.6  # approximate Vs from Vp (Poisson ~0.25)
        k_dry, mu_dry = gassmann_dry_from_saturated(
            vp, vs_current, rho_current,
            config.k_min, config.k_fl_original, phi_for_density)

        # Oil substitution
        gp_oil = GassmannParams(k_min=config.k_min, k_dry=k_dry, mu_dry=mu_dry,
                                rho_min=config.rho_min, phi=phi_for_density,
                                k_fl1=config.k_fl_original, k_fl2=OIL_MODULUS,
                                rho_fl1=config.rho_fl_original, rho_fl2=OIL_DENSITY)
        # Oil substitution — forward Gassmann (Mavko form, correct):
        #   K_sat2 = K_dry + (1 - K_dry/K_min)^2 / (phi/K_fl2 + (1-phi)/K_min - K_dry/K_min^2)
        A_oil = (1 - k_dry / config.k_min)
        B_oil = phi_for_density / OIL_MODULUS + (1 - phi_for_density) / config.k_min - k_dry / config.k_min**2
        k_sat_oil = k_dry + A_oil**2 / B_oil
        rho_oil = config.rho_min * (1 - phi_for_density) + OIL_DENSITY * phi_for_density
        vp_oil = np.sqrt((k_sat_oil + 4.0/3.0 * mu_dry) * 1e9 / rho_oil)

        # Gas substitution — forward Gassmann (Mavko form):
        A_gas = (1 - k_dry / config.k_min)
        B_gas = phi_for_density / GAS_MODULUS + (1 - phi_for_density) / config.k_min - k_dry / config.k_min**2
        k_sat_gas = k_dry + A_gas**2 / B_gas
        rho_gas = config.rho_min * (1 - phi_for_density) + GAS_DENSITY * phi_for_density
        vp_gas = np.sqrt((k_sat_gas + 4.0/3.0 * mu_dry) * 1e9 / rho_gas)
    except Exception:
        pass  # Gassmann what-if is optional

    return PetrophysicalResult(
        sw_ert=sw_ert,
        sw_gpr=sw_gpr,
        phi_seis=phi_seis,
        sw_joint=sw_joint,
        shc_joint=shc_joint,
        phi_joint=phi_seis,
        rho_bulk=rho_bulk,
        vp_gas=vp_gas,
        vp_oil=vp_oil,
        meta=dict(
            config=dict(
                archie_a=config.archie_a, archie_m=config.archie_m,
                archie_n=config.archie_n, archie_rw=config.archie_rw,
                prior_porosity=config.prior_porosity,
                vel_model=config.vel_model,
                weight_ert=config.weight_ert,
                weight_gpr=config.weight_gpr,
                weight_seis=config.weight_seis,
            ),
        ),
    )


def v10_prospectivity_with_petrophysics(
    v9_result: dict,
    config: V10PetrophysicsConfig | None = None,
) -> dict:
    """Enhance V9 prospectivity with V10 petrophysical interpretation.

    Takes a V9 result dict (with prediction, ert_prob, seis_prob, gpr_prob,
    and the inversion grids) and adds petrophysical properties.

    Parameters
    ----------
    v9_result : dict from petroppo_adapter.run_prospectivity()
    config : V10 configuration

    Returns
    -------
    Enhanced dict with all V9 fields plus:
        petrophysics : PetrophysicalResult
        shc_map : hydrocarbon saturation grid
        sw_map : water saturation grid
        phi_map : porosity grid
    """
    if config is None:
        config = V10PetrophysicsConfig()

    # Extract inversion grids from V9 result
    # The V9 adapter provides ert_prob, seis_prob, gpr_prob as evidence maps.
    # For petrophysics, we need the actual physical properties.
    # We'll use the evidence maps as proxies if physical grids aren't available.
    ert_prob = v9_result.get("ert_prob")
    seis_prob = v9_result.get("seis_prob")
    gpr_prob = v9_result.get("gpr_prob")

    # Convert evidence to physical property estimates
    # ERT evidence ~ P(high-rho) → resistivity ~ background * (1 + evidence * contrast)
    rt = 100.0 + ert_prob * 600.0  # 100-700 ohm·m range
    # Seismic evidence ~ P(high-velocity) → velocity ~ 3000 + evidence * 1500
    vp = 3000.0 + seis_prob * 1500.0  # 3000-4500 m/s range
    # GPR evidence ~ P(low-permittivity) → permittivity ~ 12 - evidence * 9
    eps_b = 12.0 - gpr_prob * 9.0  # 3-12 range

    # Run petrophysical interpretation
    petro = interpret_petrophysics(rt, vp, eps_b, config)

    # Enhance prospectivity: combine V9 probability with petrophysical Shc
    # The V9 prediction is already P(oil|geophysics).
    # The V10 Shc is an independent estimate of hydrocarbon saturation.
    # Where both agree (high P(oil) AND high Shc), confidence increases.
    v9_pred = v9_result.get("prediction", np.zeros_like(petro.shc_joint))
    # Geometric mean fusion: P(oil)_v10 = sqrt(P(oil)_v9 * Shc)
    # This ensures both must be high for a strong prediction
    v10_pred = np.sqrt(np.clip(v9_pred, 0, 1) * np.clip(petro.shc_joint, 0, 1))

    # Return enhanced result
    result = dict(v9_result)
    result["prediction_v10"] = v10_pred
    result["petrophysics"] = dict(
        sw_ert=petro.sw_ert, sw_gpr=petro.sw_gpr,
        phi_seis=petro.phi_seis,
        sw_joint=petro.sw_joint, shc_joint=petro.shc_joint,
        phi_joint=petro.phi_joint, rho_bulk=petro.rho_bulk,
    )
    result["shc_map"] = petro.shc_joint
    result["sw_map"] = petro.sw_joint
    result["phi_map"] = petro.phi_joint
    result["meta_v10"] = petro.meta
    return result


if __name__ == "__main__":
    print("=" * 70)
    print("petroppo V10 — Petrophysics Integration Test")
    print("=" * 70)

    # Simulate V9 joint inversion outputs
    np.random.seed(42)
    shape = (16, 8)
    # Resistivity: background ~100, anomaly ~700 ohm·m
    rt = 100 + 600 * np.exp(-((np.arange(16).reshape(-1,1) - 8)**2 / 20 +
                               (np.arange(8).reshape(1,-1) - 4)**2 / 10))
    # Velocity: background ~3000, anomaly ~4500 m/s
    vp = 3000 + 1500 * np.exp(-((np.arange(16).reshape(-1,1) - 8)**2 / 25 +
                                 (np.arange(8).reshape(1,-1) - 4)**2 / 12))
    # Permittivity: background ~12, anomaly ~3 (low = hydrocarbon)
    eps_b = 12 - 9 * np.exp(-((np.arange(16).reshape(-1,1) - 8)**2 / 22 +
                               (np.arange(8).reshape(1,-1) - 4)**2 / 11))

    print(f"\nInput grids shape: {shape}")
    print(f"  Rt range: {rt.min():.1f} – {rt.max():.1f} ohm·m")
    print(f"  Vp range: {vp.min():.0f} – {vp.max():.0f} m/s")
    print(f"  eps range: {eps_b.min():.2f} – {eps_b.max():.2f}")

    result = interpret_petrophysics(rt, vp, eps_b)
    print(f"\nPetrophysical interpretation:")
    print(f"  Sw (ERT)  range: {result.sw_ert.min():.3f} – {result.sw_ert.max():.3f}")
    print(f"  Sw (GPR)  range: {result.sw_gpr.min():.3f} – {result.sw_gpr.max():.3f}")
    print(f"  phi (seis) range: {result.phi_seis.min():.3f} – {result.phi_seis.max():.3f}")
    print(f"  Sw (joint) range: {result.sw_joint.min():.3f} – {result.sw_joint.max():.3f}")
    print(f"  Shc (joint) range: {result.shc_joint.min():.3f} – {result.shc_joint.max():.3f}")
    print(f"  rho (bulk) range: {result.rho_bulk.min():.0f} – {result.rho_bulk.max():.0f} kg/m³")

    # Verify: anomaly should show low Sw (high oil) at center
    center_sw = result.sw_joint[8, 4]
    edge_sw = result.sw_joint[0, 0]
    print(f"\n  Center Sw: {center_sw:.3f} (should be LOW = high oil)")
    print(f"  Edge Sw:   {edge_sw:.3f} (should be HIGH = water)")
    assert center_sw < edge_sw, "Center should have lower Sw (more oil)!"

    print(f"\n  Gassmann what-if:")
    if result.vp_oil is not None:
        print(f"    Vp (current): {vp[8,4]:.0f} m/s")
        print(f"    Vp (oil sub): {result.vp_oil[8,4]:.0f} m/s")
        print(f"    Vp (gas sub): {result.vp_gas[8,4]:.0f} m/s")
        assert result.vp_gas[8,4] < vp[8,4], "Gas should reduce Vp!"

    print("\n✅ V10 petrophysics integration test passed!")
