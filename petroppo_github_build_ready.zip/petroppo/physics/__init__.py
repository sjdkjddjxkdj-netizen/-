"""petroppo V20 — Scientific Core: ``physics`` package.

This package is the contract layer of petroppo.  It defines the abstractions
that every forward model, inverse problem, and benchmark must satisfy:

* :mod:`units`         — dimensioned quantities, DimensionError
* :mod:`coordinates`   — CRS framework (WGS84 / UTM / local ENU)
* :mod:`result`        — ScientificResult, QCReport, Provenance envelope
* :mod:`convergence`   — ConvergenceDiag (residual / parameter histories)
* :mod:`forward`       — ForwardModel ABC
* :mod:`inverse`       — InverseProblem ABC
* :mod:`jacobian`      — JacobianStrategy (analytic / adjoint / FD)
* :mod:`regularization`— Tikhonov / Smoothness / L1 / Huber / DepthWeighting
* :mod:`optimization`  — GaussNewton / LevenbergMarquardt / Occam / IRLS
* :mod:`uncertainty`   — linearised covariance, confidence intervals

Every module is importable with *only* numpy + scipy installed.
"""

from . import units, coordinates  # noqa: F401

__all__ = ["units", "coordinates"]

# Optional sub-imports (imported lazily to keep import cost low)
try:
    from . import result  # noqa: F401
    __all__.append("result")
except Exception:
    pass

# --- V22: seismic interpretation ---
try:
    from . import seismic  # noqa: F401
    __all__.append("seismic")
except Exception:
    pass

# --- V23: geological modeling ---
try:
    from . import geology  # noqa: F401
    __all__.append("geology")
except Exception:
    pass
try:
    from . import convergence  # noqa: F401
    __all__.append("convergence")
except Exception:
    pass
try:
    from . import forward  # noqa: F401
    __all__.append("forward")
except Exception:
    pass
try:
    from . import inverse  # noqa: F401
    __all__.append("inverse")
except Exception:
    pass
try:
    from . import jacobian  # noqa: F401
    __all__.append("jacobian")
except Exception:
    pass
try:
    from . import regularization  # noqa: F401
    __all__.append("regularization")
except Exception:
    pass
try:
    from . import optimization  # noqa: F401
    __all__.append("optimization")
except Exception:
    pass
try:
    from . import uncertainty  # noqa: F401
    __all__.append("uncertainty")
except Exception:
    pass

# --- V22: reservoir simulation (single/blackoil/IMPES) ---
try:
    from . import reservoir  # noqa: F401
    __all__.append("reservoir")
except Exception:
    pass
