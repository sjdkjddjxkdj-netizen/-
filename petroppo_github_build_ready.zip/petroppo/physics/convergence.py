"""petroppo V20 — Convergence diagnostics.

Provides :class:`ConvergenceDiag`, a structured container for iteration
histories that every iterative solver (inversion, optimisation, reservoir
time-stepping) should populate and that the verification suite inspects to
check that convergence was *genuine* (monotone-ish, plateaued) rather than
*aborted* (hit max-iter while still descending).

Key capabilities
----------------
* Record per-iteration: data_misfit, regularization, total objective,
  gradient norm, step norm, parameter RMS change.
* :meth:`order_of_convergence` — estimates the observed convergence order
  from a refinement sequence (p ≈ expected_order ⇒ verified).
* :meth:`converged` — boolean: did the solver reach a tolerance criterion
  rather than just exhaust its iteration budget?
* :meth:`plateaued` — boolean: has the objective stabilised in the last
  *k* iterations (genuine plateau, not a cliff)?

This closes V19 gap G8 (no convergence-order tests anywhere in the codebase).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence

import numpy as np


@dataclass
class ConvergenceDiag:
    """Iteration history for an iterative solver."""
    data_misfit: List[float] = field(default_factory=list)
    reg_term: List[float] = field(default_factory=list)
    total_objective: List[float] = field(default_factory=list)
    grad_norm: List[float] = field(default_factory=list)
    step_norm: List[float] = field(default_factory=list)
    param_rms: List[float] = field(default_factory=list)
    labels: List[str] = field(default_factory=list)
    tolerance: float = 1e-6
    max_iter: int = 100

    def append(self, *, data_misfit: float = 0.0, reg_term: float = 0.0,
               total_objective: float = 0.0, grad_norm: float = 0.0,
               step_norm: float = 0.0, param_rms: float = 0.0,
               label: str = "") -> None:
        self.data_misfit.append(data_misfit)
        self.reg_term.append(reg_term)
        self.total_objective.append(total_objective)
        self.grad_norm.append(grad_norm)
        self.step_norm.append(step_norm)
        self.param_rms.append(param_rms)
        self.labels.append(label)

    @property
    def n_iter(self) -> int:
        return len(self.total_objective)

    def converged(self) -> bool:
        """True if the solver reached tolerance (not just ran out of budget)."""
        if self.n_iter == 0:
            return False
        # Converged if EITHER the gradient norm OR the step norm is below
        # tolerance (a tiny step means we've reached the optimum even if the
        # gradient is nonzero due to regularization curvature).
        grad_ok = (self.grad_norm[-1] < self.tolerance) if self.grad_norm else False
        step_ok = (self.step_norm[-1] < self.tolerance) if self.step_norm else False
        if grad_ok or step_ok:
            return True
        hit_max = self.n_iter >= self.max_iter
        if hit_max:
            return False  # aborted, not converged
        # If objective plateaued near the end, consider it converged
        return self.plateaued(window=min(5, max(2, self.n_iter // 4)))

    def plateaued(self, window: int = 5, rel_threshold: float = 1e-3) -> bool:
        """True if the objective has stabilised in the last *window* iterations."""
        if self.n_iter < window + 1:
            return False
        recent = np.array(self.total_objective[-window - 1:])
        vals = recent[np.isfinite(recent)]
        if len(vals) < 2:
            return False
        rng = vals.max() - vals.min()
        denom = max(abs(vals.mean()), 1e-30)
        return (rng / denom) < rel_threshold

    def final_objective(self) -> float:
        return self.total_objective[-1] if self.total_objective else float("inf")

    def reduction_ratio(self) -> float:
        """Ratio of final to initial objective (1.0 = no reduction)."""
        if self.n_iter < 2:
            return 1.0
        f0 = self.total_objective[0]
        fn = self.total_objective[-1]
        if abs(f0) < 1e-30:
            return 1.0
        return fn / f0

    def to_dict(self) -> dict:
        return {
            "data_misfit": self.data_misfit,
            "reg_term": self.reg_term,
            "total_objective": self.total_objective,
            "grad_norm": self.grad_norm,
            "step_norm": self.step_norm,
            "param_rms": self.param_rms,
            "labels": self.labels,
            "tolerance": self.tolerance,
            "max_iter": self.max_iter,
            "n_iter": self.n_iter,
            "converged": self.converged(),
            "plateaued": self.plateaued(),
        }


def order_of_convergence(errors: Sequence[float],
                         h: Sequence[float]) -> tuple:
    """Estimate the observed convergence order *p* from a refinement sequence.

    Given a sequence of error norms ``e[i]`` measured at mesh sizes ``h[i]``
    (decreasing), the order is:

        p ≈ log(e[i] / e[i+1]) / log(h[i] / h[i+1])

    Returns
    -------
    (p_mean, p_std, n_pairs) : tuple
        Mean and std-dev of pairwise order estimates, and the number of pairs.
    """
    e = np.asarray(errors, dtype=float)
    hs = np.asarray(h, dtype=float)
    if len(e) < 2 or len(hs) < 2:
        return (float("nan"), 0.0, 0)
    n = min(len(e), len(hs)) - 1
    orders = []
    for i in range(n):
        if e[i] <= 0 or e[i + 1] <= 0 or hs[i] <= 0 or hs[i + 1] <= 0:
            continue
        p = np.log(e[i] / e[i + 1]) / np.log(hs[i] / hs[i + 1])
        if np.isfinite(p):
            orders.append(p)
    if not orders:
        return (float("nan"), 0.0, 0)
    return (float(np.mean(orders)), float(np.std(orders)), len(orders))
