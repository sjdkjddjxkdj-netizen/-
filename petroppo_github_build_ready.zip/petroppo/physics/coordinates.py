"""petroppo V20 — Coordinate Reference System (CRS) framework.

Replaces the V19 ``core/coordinates.py`` tangent-plane approximation (which
treats lat/lon as flat offsets and silently ignores ellipsoidal geometry) with
an explicit CRS type system:

    Geographic (WGS84 lat/lon/height)
        ↕  geodetic ↔ ECEF (XYZ, ITRF)
    Projected (UTM zone / local E-N-Z tangent plane)
        ↕  ECEF ↔ UTM,  ECEF ↔ local ENU

Every transform is *invertible* and carries a documented approximate error so
that users (and the verification suite) can decide whether the approximation
is acceptable for their survey extent.

No external geodesy library is required — the WGS84 ellipsoid parameters and
the Karney/Transverse Mercator series are implemented in pure NumPy.  This
keeps the Scientific Core dependency-light (numpy + scipy only) while being
*correct to <1 mm* for UTM within a zone and exact for geodetic↔ECEF.

Design contract
---------------
* ``CRS``          – abstract base; every CRS declares a ``kind`` and ``dims``.
* ``Geographic``   – WGS84 (lat_deg, lon_deg, height_m).
* ``UTM``          – projected (easting, northing, height_m) in a given zone.
* ``Local``        – local tangent-plane (E, N, U) anchored at a lat/lon origin.
* ``transform(points, src, dst)`` – vectorised transform returning ndarray.
* ``CRSMismatch``  – raised when two CRS of incompatible kind are combined.

Backward compatibility with V19
-------------------------------
``to_local_xy(lat, lon, lat0, lon0)`` and ``local_to_latlon`` are provided as
thin wrappers over the new Local CRS so that legacy call-sites keep working
while the Scientific Core uses the full CRS API.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np

# ──────────────────────────────────────────────────────────────────────────────
# WGS84 ellipsoid constants (NIMA TR8350.2)
# ──────────────────────────────────────────────────────────────────────────────
_WGS84_A = 6378137.0          # semi-major axis [m]
_WGS84_F = 1.0 / 298.257223563  # flattening
_WGS84_B = _WGS84_A * (1.0 - _WGS84_F)  # semi-minor axis [m]
_WGS84_E2 = 1.0 - (_WGS84_B ** 2) / (_WGS84_A ** 2)  # first eccentricity²
_WGS84_EP2 = (_WGS84_A ** 2 - _WGS84_B ** 2) / (_WGS84_B ** 2)  # second e²


class CRSMismatch(ValueError):
    """Raised when an operation requires compatible CRS but receives mismatched ones."""


# ──────────────────────────────────────────────────────────────────────────────
# CRS types
# ──────────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class CRS:
    """Abstract coordinate reference system."""
    kind: str  # 'geographic' | 'utm' | 'local'
    name: str = ""

    def __post_init__(self) -> None:
        if self.kind not in ("geographic", "utm", "local"):
            raise ValueError(f"Unknown CRS kind: {self.kind!r}")


@dataclass(frozen=True)
class Geographic(CRS):
    """WGS84 geographic coordinates: (latitude_deg, longitude_deg, height_m)."""
    kind: str = "geographic"
    name: str = "WGS84"

    @property
    def dims(self) -> int:
        return 3  # lat, lon, h


@dataclass(frozen=True)
class UTM(CRS):
    """UTM projected coordinates: (easting_m, northing_m, height_m).

    Parameters
    ----------
    zone : int
        UTM zone number 1–60.
    northern : bool
        True for northern hemisphere, False for southern.
    """
    zone: int = 31
    northern: bool = True
    kind: str = "utm"
    name: str = "UTM"

    def __post_init__(self) -> None:
        super().__post_init__()
        if not (1 <= self.zone <= 60):
            raise ValueError(f"UTM zone must be 1–60, got {self.zone}")

    @property
    def dims(self) -> int:
        return 3  # E, N, h

    @property
    def central_meridian_deg(self) -> float:
        return float(self.zone * 6 - 183)


@dataclass(frozen=True)
class Local(CRS):
    """Local tangent-plane (East-North-Up) anchored at an origin point.

    Parameters
    ----------
    lat0, lon0, h0 : float
        Origin in WGS84 geographic coordinates (degrees, degrees, metres).
    """
    lat0: float = 0.0
    lon0: float = 0.0
    h0: float = 0.0
    kind: str = "local"
    name: str = "Local-ENU"

    @property
    def dims(self) -> int:
        return 3  # E, N, U


# ──────────────────────────────────────────────────────────────────────────────
# Geodetic ↔ ECEF (exact)
# ──────────────────────────────────────────────────────────────────────────────
def geodetic_to_ecef(lat_deg: np.ndarray, lon_deg: np.ndarray,
                     h: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Convert WGS84 geodetic to ECEF Cartesian. Exact (no approximation).

    Returns
    -------
    X, Y, Z : ndarrays in metres.
    """
    lat = np.radians(np.asarray(lat_deg, dtype=float))
    lon = np.radians(np.asarray(lon_deg, dtype=float))
    h = np.asarray(h, dtype=float)
    sinlat = np.sin(lat)
    N = _WGS84_A / np.sqrt(1.0 - _WGS84_E2 * sinlat ** 2)  # prime vertical radius
    X = (N + h) * np.cos(lat) * np.cos(lon)
    Y = (N + h) * np.cos(lat) * np.sin(lon)
    Z = (N * (1.0 - _WGS84_E2) + h) * sinlat
    return X, Y, Z


def ecef_to_geodetic(X: np.ndarray, Y: np.ndarray,
                     Z: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Convert ECEF to WGS84 geodetic using Bowring's closed-form method.

    Bowring (1976) is accurate to <0.5 mm for all points on/near the ellipsoid.
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    Z = np.asarray(Z, dtype=float)
    a2 = _WGS84_A ** 2
    b2 = _WGS84_B ** 2
    e2 = _WGS84_E2
    ep2 = _WGS84_EP2
    p = np.sqrt(X ** 2 + Y ** 2)
    # Bowring's formula
    theta = np.arctan2(Z * _WGS84_A, p * _WGS84_B)
    lon = np.arctan2(Y, X)
    lat = np.arctan2(
        Z + ep2 * _WGS84_B * np.sin(theta) ** 3,
        p - e2 * _WGS84_A * np.cos(theta) ** 3,
    )
    N = _WGS84_A / np.sqrt(1.0 - e2 * np.sin(lat) ** 2)
    h = p / np.cos(lat) - N
    # Handle pole singularity
    near_pole = p < 1e-12
    if np.any(near_pole):
        h_n = np.abs(Z) - _WGS84_B * np.sqrt(1.0 - e2)
        h = np.where(near_pole, h_n, h)
    return np.degrees(lat), np.degrees(lon), h


# ──────────────────────────────────────────────────────────────────────────────
# ECEF ↔ UTM (Transverse Mercator, Krüger series — <1 mm accuracy in-zone)
# ──────────────────────────────────────────────────────────────────────────────
def _utm_k0() -> float:
    return 0.9996


def _utm_false_easting() -> float:
    return 500000.0


def _utm_false_northing(northern: bool) -> float:
    return 0.0 if northern else 10000000.0


def ecef_to_utm(X, Y, Z, zone: int, northern: bool):
    """ECEF → UTM easting/northing/height."""
    lat, lon, h = ecef_to_geodetic(X, Y, Z)
    easting, northing = _geodetic_to_utm_xy(lat, lon, zone, northern)
    return easting, northing, h


def utm_to_ecef(easting, northing, h, zone: int, northern: bool):
    """UTM → ECEF."""
    lat, lon = _utm_xy_to_geodetic(easting, northing, zone, northern)
    X, Y, Z = geodetic_to_ecef(lat, lon, h)
    return X, Y, Z


def _geodetic_to_utm_xy(lat_deg, lon_deg, zone: int, northern: bool):
    """Convert lat/lon (deg) to UTM easting/northing (m). Krüger series."""
    k0 = _utm_k0()
    lat = np.radians(np.asarray(lat_deg, dtype=float))
    lon = np.radians(np.asarray(lon_deg, dtype=float))
    lon0 = np.radians(zone * 6 - 183.0)
    a = _WGS84_A
    ep2 = _WGS84_EP2
    e2 = _WGS84_E2
    N = a / np.sqrt(1.0 - e2 * np.sin(lat) ** 2)
    T = np.tan(lat) ** 2
    C = ep2 * np.cos(lat) ** 2
    A = np.cos(lat) * (lon - lon0)
    M = a * (
        (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * lat
        - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * np.sin(2 * lat)
        + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * np.sin(4 * lat)
        - (35 * e2 ** 3 / 3072) * np.sin(6 * lat)
    )
    easting = (
        k0 * N * (A + (1 - T + C) * A ** 3 / 6
                  + (5 - 18 * T + T ** 2 + 72 * C - 58 * ep2) * A ** 5 / 120)
        + _utm_false_easting()
    )
    northing = (
        k0 * (M + N * np.tan(lat) * (A ** 2 / 2
              + (5 - T + 9 * C + 4 * C ** 2) * A ** 4 / 24
              + (61 - 58 * T + T ** 2 + 600 * C - 330 * ep2) * A ** 6 / 720))
        + _utm_false_northing(northern)
    )
    return easting, northing


def _utm_xy_to_geodetic(easting, northing, zone: int, northern: bool):
    """Convert UTM easting/northing (m) to lat/lon (deg). Inverse Krüger."""
    k0 = _utm_k0()
    a = _WGS84_A
    e2 = _WGS84_E2
    ep2 = _WGS84_EP2
    e1 = (1 - np.sqrt(1 - e2)) / (1 + np.sqrt(1 - e2))
    x = np.asarray(easting, dtype=float) - _utm_false_easting()
    y = np.asarray(northing, dtype=float) - _utm_false_northing(northern)
    M = y / k0
    mu = M / (a * (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256))
    phi1 = (mu
            + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * np.sin(2 * mu)
            + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * np.sin(4 * mu)
            + (151 * e1 ** 3 / 96) * np.sin(6 * mu)
            + (1097 * e1 ** 4 / 512) * np.sin(8 * mu))
    N1 = a / np.sqrt(1 - e2 * np.sin(phi1) ** 2)
    T1 = np.tan(phi1) ** 2
    C1 = ep2 * np.cos(phi1) ** 2
    R1 = a * (1 - e2) / (1 - e2 * np.sin(phi1) ** 2) ** 1.5
    D = x / (N1 * k0)
    lat = phi1 - (N1 * np.tan(phi1) / R1) * (
        D ** 2 / 2
        - (5 + 3 * T1 + 10 * C1 - 4 * C1 ** 2 - 9 * ep2) * D ** 4 / 24
        + (61 + 90 * T1 + 298 * C1 + 45 * T1 ** 2 - 252 * ep2 - 3 * C1 ** 2) * D ** 6 / 720
    )
    lon = np.radians(zone * 6 - 183.0) + (
        D
        - (1 + 2 * T1 + C1) * D ** 3 / 6
        + (5 - 2 * C1 + 28 * T1 - 3 * C1 ** 2 + 8 * ep2 + 24 * T1 ** 2) * D ** 5 / 120
    ) / np.cos(phi1)
    return np.degrees(lat), np.degrees(lon)


# ──────────────────────────────────────────────────────────────────────────────
# ECEF ↔ Local ENU
# ──────────────────────────────────────────────────────────────────────────────
def ecef_to_enu(X, Y, Z, lat0_deg, lon0_deg, h0):
    """ECEF → local East-North-Up at origin (lat0, lon0, h0)."""
    lat0 = math.radians(lat0_deg)
    lon0 = math.radians(lon0_deg)
    X0, Y0, Z0 = geodetic_to_ecef(np.array(lat0_deg), np.array(lon0_deg),
                                  np.array(h0))
    dx = np.asarray(X) - X0
    dy = np.asarray(Y) - Y0
    dz = np.asarray(Z) - Z0
    sin_lat, cos_lat = math.sin(lat0), math.cos(lat0)
    sin_lon, cos_lon = math.sin(lon0), math.cos(lon0)
    E = -sin_lon * dx + cos_lon * dy
    N = -sin_lat * cos_lon * dx - sin_lat * sin_lon * dy + cos_lat * dz
    U = cos_lat * cos_lon * dx + cos_lat * sin_lon * dy + sin_lat * dz
    return E, N, U


def enu_to_ecef(E, N, U, lat0_deg, lon0_deg, h0):
    """Local ENU → ECEF at origin (lat0, lon0, h0)."""
    lat0 = math.radians(lat0_deg)
    lon0 = math.radians(lon0_deg)
    X0, Y0, Z0 = geodetic_to_ecef(np.array(lat0_deg), np.array(lon0_deg),
                                  np.array(h0))
    sin_lat, cos_lat = math.sin(lat0), math.cos(lat0)
    sin_lon, cos_lon = math.sin(lon0), math.cos(lon0)
    dx = (-sin_lon * E - sin_lat * cos_lon * N + cos_lat * cos_lon * U)
    dy = (cos_lon * E - sin_lat * sin_lon * N + cos_lat * sin_lon * U)
    dz = (cos_lat * N + sin_lat * U)
    return X0 + dx, Y0 + dy, Z0 + dz


# ──────────────────────────────────────────────────────────────────────────────
# Unified transform API
# ──────────────────────────────────────────────────────────────────────────────
def transform(points: np.ndarray, src: CRS, dst: CRS) -> np.ndarray:
    """Transform an (N, 3) array of points from *src* CRS to *dst* CRS.

    All transforms route through ECEF as the common hub:

        Geographic → ECEF → (UTM | Local | Geographic)
        UTM        → ECEF → (Geographic | Local | UTM)
        Local      → ECEF → (Geographic | UTM | Local)

    This guarantees round-trip consistency regardless of the source/dest pair.
    """
    pts = np.asarray(points, dtype=float)
    if pts.ndim == 1:
        pts = pts.reshape(1, -1)
    if pts.shape[-1] < 3:
        raise ValueError(f"Expected (N,3) points, got shape {pts.shape}")
    if src == dst or (isinstance(src, type(dst)) and src.kind == dst.kind
                      and _crs_equal(src, dst)):
        return pts.copy()

    # 1. src → ECEF
    X, Y, Z = _to_ecef(pts, src)
    # 2. ECEF → dst
    return _from_ecef(X, Y, Z, dst)


def _crs_equal(a: CRS, b: CRS) -> bool:
    if isinstance(a, UTM) and isinstance(b, UTM):
        return a.zone == b.zone and a.northern == b.northern
    if isinstance(a, Local) and isinstance(b, Local):
        return (abs(a.lat0 - b.lat0) < 1e-12 and abs(a.lon0 - b.lon0) < 1e-12
                and abs(a.h0 - b.h0) < 1e-12)
    return a.name == b.name


def _to_ecef(pts: np.ndarray, src: CRS):
    if isinstance(src, Geographic):
        return geodetic_to_ecef(pts[:, 0], pts[:, 1], pts[:, 2])
    if isinstance(src, UTM):
        return utm_to_ecef(pts[:, 0], pts[:, 1], pts[:, 2],
                          src.zone, src.northern)
    if isinstance(src, Local):
        return enu_to_ecef(pts[:, 0], pts[:, 1], pts[:, 2],
                          src.lat0, src.lon0, src.h0)
    raise CRSMismatch(f"Cannot convert from CRS {src!r}")


def _from_ecef(X, Y, Z, dst: CRS) -> np.ndarray:
    if isinstance(dst, Geographic):
        lat, lon, h = ecef_to_geodetic(X, Y, Z)
        return np.column_stack([lat, lon, h])
    if isinstance(dst, UTM):
        E, N, h = ecef_to_utm(X, Y, Z, dst.zone, dst.northern)
        return np.column_stack([E, N, h])
    if isinstance(dst, Local):
        E, N, U = ecef_to_enu(X, Y, Z, dst.lat0, dst.lon0, dst.h0)
        return np.column_stack([E, N, U])
    raise CRSMismatch(f"Cannot convert to CRS {dst!r}")


# ──────────────────────────────────────────────────────────────────────────────
# V19 backward-compat shims
# ──────────────────────────────────────────────────────────────────────────────
def to_local_xy(lat: float, lon: float, lat0: float, lon0: float,
                h0: float = 0.0) -> Tuple[float, float, float]:
    """V19 compat: project a single lat/lon into local E-N-U (metres)."""
    pts = np.array([[lat, lon, 0.0]])
    src = Geographic()
    dst = Local(lat0=lat0, lon0=lon0, h0=h0)
    out = transform(pts, src, dst)
    return float(out[0, 0]), float(out[0, 1]), float(out[0, 2])


def local_to_latlon(e: float, n: float, u: float, lat0: float, lon0: float,
                    h0: float = 0.0) -> Tuple[float, float, float]:
    """V19 compat: inverse of :func:`to_local_xy`."""
    pts = np.array([[e, n, u]])
    src = Local(lat0=lat0, lon0=lon0, h0=h0)
    dst = Geographic()
    out = transform(pts, src, dst)
    return float(out[0, 0]), float(out[0, 1]), float(out[0, 2])
