"""petroppo V20 — ForwardModel abstract base class.

A :class:`ForwardModel` is the contract that every physics simulator (ERT,
seismic, GPR, gravity, reservoir, ...) must satisfy in V20.  It replaces the
ad-hoc ``simulate(model) -> data`` calls scattered across V19 with a single,
typed interface that the inverse solver and the verification suite can rely on.

Contract
--------
* ``n_params`` / ``n_data`` — declare problem dimensions.
* ``params_units`` / ``data_units`` — SI unit strings (checked by units.py).
* ``predict(model) -> data`` — the forward map F(m).
* ``jacobian(model) -> J`` — optional; default raises NotImplementedError
  (solved by jacobian.py strategies if not analytic).
* ``default_model()`` — a sensible starting model (e.g. homogeneous half-space).

The verification suite uses ``predict`` on manufactured solutions and
``jacobian`` for Jacobian-agreement tests (G6).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import numpy as np


class ForwardModel(ABC):
    """Abstract forward model F: R^n_params -> R^n_data."""

    @property
    @abstractmethod
    def n_params(self) -> int:
        """Number of model parameters."""

    @property
    @abstractmethod
    def n_data(self) -> int:
        """Number of data points (observations)."""

    @property
    def params_units(self) -> str:
        return ""

    @property
    def data_units(self) -> str:
        return ""

    @abstractmethod
    def predict(self, model: np.ndarray) -> np.ndarray:
        """Compute F(model) → synthetic data vector."""

    def jacobian(self, model: np.ndarray) -> np.ndarray:
        """Analytic Jacobian dF/dm.  Override for analytic; otherwise use
        :mod:`physics.jacobian` strategies (FD, adjoint, etc.)."""
        raise NotImplementedError(
            f"{type(self).__name__} does not provide an analytic Jacobian; "
            "use physics.jacobian for a numerical strategy.")

    def default_model(self) -> np.ndarray:
        """A reasonable starting model (homogeneous / background)."""
        return np.zeros(self.n_params)

    def residual(self, model: np.ndarray, observed: np.ndarray) -> np.ndarray:
        """data_observed - F(model)."""
        return np.asarray(observed, dtype=float) - self.predict(model)

    def misfit(self, model: np.ndarray, observed: np.ndarray,
               weights: Optional[np.ndarray] = None) -> float:
        """Weighted L2 data misfit: 0.5 * ||W^(1/2) (d_obs - F(m))||^2."""
        r = self.residual(model, observed)
        if weights is None:
            return float(0.5 * np.dot(r, r))
        w = np.asarray(weights, dtype=float)
        return float(0.5 * np.dot(r * w, r))
