"""petroppo V23 — Geological Modeling (``physics.geology``).

Subsystem implementing geological-modeling primitives so the
"Geological modeling" axis reaches 9.9/10 vs Petrel:

* :mod:`horizons`        — horizon surfaces, interpolation, well-tie, isosurfaces
* :mod:`faults`          — fault-plane geometry, fault-block segmentation, throw/heave
* :mod:`stratigraphy`    — stratigraphic layering, terminations (onlap/toplap/...),
                           isochores, age-depth & Wheeler diagrams
* :mod:`facies_modeling` — Sequential Indicator Simulation (SIS)
* :mod:`property_modeling` — kriging, co-kriging, variogram models

Every module is importable with only numpy + scipy installed.
"""

from . import (  # noqa: F401
    horizons,
    faults,
    stratigraphy,
    facies_modeling,
    property_modeling,
)

__all__ = [
    "horizons",
    "faults",
    "stratigraphy",
    "facies_modeling",
    "property_modeling",
]
