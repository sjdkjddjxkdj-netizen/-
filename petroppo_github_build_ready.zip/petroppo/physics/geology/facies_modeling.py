"""petroppo V23 — Sequential Indicator Simulation (SIS).

Sequential Indicator Simulation (Journel & Alabert 1989; Goovaerts 1997)
is the standard geostatistical method for modelling categorical facies
fields.  It visits grid nodes in a random path; at each node it builds
the conditional probability of each facies from the indicator kriging
of nearby data (wells + previously simulated nodes) and draws a facies
from that distribution.

This module provides:

* :func:`indicator_variogram` — experimental + modelled indicator variogram,
* :func:`sis_realization`    — one SIS realization on a regular grid,
* :func:`facies_proportions` — realized proportions vs target,
* :func:`conditional_to_wells` — verify wells are honored exactly.

All routines are pure numpy/scipy and verified against controlled cases.

References
----------
Journel & Alabert (1989), *Non-Gaussian data expansion*.
Goovaerts (1997), *Geostatistics for Natural Resources Evaluation*, ch. 8.
Deutsch (2002), *Geostatistical Reservoir Modeling*, ch. 6.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------
# Variogram helpers
# ---------------------------------------------------------------------
def _spherical(h, rng, sill):
    return np.where(h <= 0, 0.0,
                    np.where(h <= rng, sill * (1.5 * h / rng - 0.5 * (h / rng) ** 3), sill))


def _exponential(h, rng, sill):
    return sill * (1.0 - np.exp(-3.0 * h / rng))


def _gaussian(h, rng, sill):
    return sill * (1.0 - np.exp(-3.0 * (h / rng) ** 2))


_VARIO_MODELS = {"spherical": _spherical, "exponential": _exponential, "gaussian": _gaussian}


def variogram_model(model: str, rng: float, sill: float, h: np.ndarray) -> np.ndarray:
    """Evaluate a 1-D variogram model at lags ``h``."""
    h = np.asarray(h, float)
    if model not in _VARIO_MODELS:
        raise ValueError(f"model must be one of {list(_VARIO_MODELS)}.")
    return _VARIO_MODELS[model](h, rng, sill)


@dataclass
class IndicatorVariogram:
    """Experimental + modelled indicator variogram for one facies class."""

    lags: np.ndarray
    experimental: np.ndarray
    model_name: str
    rng: float
    sill: float

    def model(self, h: np.ndarray) -> np.ndarray:
        return variogram_model(self.model_name, self.rng, self.sill, h)


def indicator_variogram(
    grid: np.ndarray, indicator: np.ndarray,
    lag: float, nlag: int, model: str = "spherical",
) -> IndicatorVariogram:
    """Compute the experimental indicator variogram along axis 0.

    ``indicator`` is a binary 0/1 field on ``grid`` (same shape).  Lags
    are multiples of ``lag`` along the first axis.
    """
    indicator = np.asarray(indicator, float)
    lags = np.arange(1, nlag + 1) * lag
    gam = np.empty(nlag)
    n = indicator.shape[0]
    for k in range(1, nlag + 1):
        diff = indicator[k:] - indicator[:-k]
        gam[k - 1] = 0.5 * np.mean(diff ** 2)
    # fit range/sill by simple least squares over the experimental values
    h = np.linspace(0, lags[-1] * 1.5, 200)
    sill0 = float(np.mean(gam[-3:])) if nlag >= 3 else float(np.max(gam))
    rng0 = lags[-1] * 0.5
    # crude 1-D refinement of range
    best = (rng0, sill0)
    best_err = np.inf
    for r in np.linspace(lag, lags[-1], 30):
        for s in np.linspace(0.01, max(sill0 * 1.5, 0.1), 20):
            pred = variogram_model(model, r, s, lags)
            err = np.sum((pred - gam) ** 2)
            if err < best_err:
                best_err = err; best = (r, s)
    return IndicatorVariogram(
        lags=lags, experimental=gam, model_name=model, rng=best[0], sill=best[1],
    )


# ---------------------------------------------------------------------
# Indicator kriging (simple, 1-D / 2-D isotropic)
# ---------------------------------------------------------------------
def _dist(a, b):
    a = np.atleast_2d(a); b = np.atleast_2d(b)
    return np.sqrt(((a[:, None, :] - b[None, :, :]) ** 2).sum(-1))


def _simple_indicator_kriging(
    target_xy, data_xy, data_vals, mean, vmodel, rng, sill,
):
    """Simple indicator kriging estimate at target from data."""
    if data_xy.shape[0] == 0:
        return float(mean)
    h_dd = _dist(data_xy, data_xy)
    h_td = _dist(target_xy, data_xy)[0]
    G = variogram_model(vmodel, rng, sill, h_dd)
    g = variogram_model(vmodel, rng, sill, h_td)
    n = data_xy.shape[0]
    A = np.ones((n + 1, n + 1))
    A[:n, :n] = G
    A[-1, -1] = 0.0
    rhs = np.concatenate([g, [1.0]])
    # simple kriging: weights w, drift = mean handled by subtracting mean
    # here we use ordinary-style system but weight to mean via last eq
    try:
        w = np.linalg.solve(A, rhs)
    except np.linalg.LinAlgError:
        w = np.linalg.lstsq(A, rhs, rcond=None)[0]
    lam = w[:n]
    est = mean + np.sum(lam * (data_vals - mean))
    return float(np.clip(est, 0.0, 1.0))


# ---------------------------------------------------------------------
# SIS realization
# ---------------------------------------------------------------------
def sis_realization(
    shape: Tuple[int, int],
    well_cells: Sequence[Tuple[int, int]],
    well_facies: Sequence[int],
    variograms: Dict[int, IndicatorVariogram],
    proportions: Sequence[float],
    rng_seed: Optional[int] = None,
    n_neighbours: int = 8,
    search_radius: float = 8.0,
) -> np.ndarray:
    """Generate one Sequential Indicator Simulation realization.

    Parameters
    ----------
    shape : (ny, nx)
    well_cells : list of (i, j) cell indices with hard data.
    well_facies : list of facies codes (same length).
    variograms : {facies_code: IndicatorVariogram} per class.
    proportions : target proportion of each facies (in variograms order).
    rng_seed : optional numpy seed.
    n_neighbours, search_radius : SIS neighbourhood.

    Returns
    -------
    ndarray, shape ``shape``, int facies codes.
    """
    ny, nx = shape
    facies_codes = list(variograms.keys())
    nclass = len(facies_codes)
    if len(proportions) != nclass:
        raise ValueError("proportions must match variograms length.")
    proportions = np.asarray(proportions, float)
    proportions = proportions / proportions.sum()

    rng = np.random.default_rng(rng_seed)
    field = np.full(shape, -1, dtype=int)

    # plant hard data
    hard = {}
    for (i, j), f in zip(well_cells, well_facies):
        field[i, j] = f
        hard[(i, j)] = f

    # random path over non-hard cells
    free_cells = [(i, j) for i in range(ny) for j in range(nx) if (i, j) not in hard]
    rng.shuffle(free_cells)

    coords = np.array([(i, j) for i in range(ny) for j in range(nx)])
    coords = coords.reshape(ny, nx, 2)

    for (i, j) in free_cells:
        target = np.array([[i, j]], float)
        # gather neighbourhood (hard + previously simulated)
        known = []
        for (ii, jj) in hard:
            known.append((ii, jj, hard[(ii, jj)]))
        # add simulated
        sim_idx = np.argwhere(field >= 0)
        for (ii, jj) in sim_idx:
            if (ii, jj) in hard:
                continue
            known.append((int(ii), int(jj), field[ii, jj]))
        if not known:
            # draw from global proportions
            probs = proportions.copy()
        else:
            ka = np.array([(k[0], k[1]) for k in known], float)
            kv = np.array([k[2] for k in known])
            d = np.sqrt(((ka - target) ** 2).sum(1))
            near = np.argsort(d)[:n_neighbours]
            keep = d[near] <= search_radius
            near = near[keep]
            if near.size == 0:
                probs = proportions.copy()
            else:
                xy_d = ka[near]
                probs = np.empty(nclass)
                for ci, code in enumerate(facies_codes):
                    ind = (kv[near] == code).astype(float)
                    vm = variograms[code]
                    est = _simple_indicator_kriging(
                        target, xy_d, ind, proportions[ci],
                        vm.model_name, vm.rng, vm.sill,
                    )
                    probs[ci] = est
                s = probs.sum()
                if s <= 0:
                    probs = proportions.copy()
                else:
                    probs = probs / s
        # draw
        cump = np.cumsum(probs)
        r = rng.random()
        chosen = facies_codes[int(np.searchsorted(cump, r))]
        field[i, j] = chosen
    return field


# ---------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------
def facies_proportions(
    realization: np.ndarray, facies_codes: Sequence[int]
) -> Dict[int, float]:
    """Realized proportion of each facies code (excluding -1)."""
    realization = np.asarray(realization)
    valid = realization[realization >= 0]
    n = valid.size
    out = {}
    for code in facies_codes:
        out[code] = float(np.mean(valid == code)) if n else 0.0
    return out


def conditional_to_wells(
    realization: np.ndarray,
    well_cells: Sequence[Tuple[int, int]],
    well_facies: Sequence[int],
) -> bool:
    """Return True iff every well cell carries its hard facies value."""
    realization = np.asarray(realization)
    for (i, j), f in zip(well_cells, well_facies):
        if realization[i, j] != f:
            return False
    return True
