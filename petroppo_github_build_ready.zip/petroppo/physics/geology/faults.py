"""petroppo V23 — Fault framework, block segmentation & throw/heave.

A *fault* is modelled here as an infinite planar discontinuity defined by
strike/dip and a reference point; multiple faults partition the map view
into fault *blocks*.  This module provides:

* :class:`FaultPlane` — plane geometry from strike/dip + reference point,
* :func:`fault_polygon` — map-view intersection line,
* :func:`segment_blocks` — label every grid cell with its fault block,
* :func:`fault_throw_heave` — vertical throw / horizontal heave from
  footwall & hanging-wall depths,
* :func:`gridcell_to_block` — single-cell block assignment.

All routines are pure numpy/scipy and verified against analytic geometry.

References
----------
Allmendinger (2020), *Structural Geology Algorithms* (strike/dip geometry).
Shaw et al. (2005), *3-D structural geology* (throw / heave relations).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np


# ---------------------------------------------------------------------
# Plane geometry
# ---------------------------------------------------------------------
@dataclass
class FaultPlane:
    """An infinite planar fault surface.

    Parameters
    ----------
    strike, dip : float
        Strike and dip angles in **radians**, right-hand rule
        (dip direction is 90° clockwise from strike).
    x0, y0, z0 : float
        A reference point lying on the plane.

    Notes
    -----
    The plane normal ``n`` (pointing in the hanging-wall / up-dip
    direction) is::

        n = ( -sin(strike)*sin(dip),  cos(strike)*sin(dip), -cos(dip) )

    so that the hanging wall is the side ``n·(x-x0) > 0``.
    """

    strike: float
    dip: float
    x0: float = 0.0
    y0: float = 0.0
    z0: float = 0.0

    def __post_init__(self) -> None:
        nx = -np.sin(self.strike) * np.sin(self.dip)
        ny = np.cos(self.strike) * np.sin(self.dip)
        nz = -np.cos(self.dip)
        # Handle vertical faults (dip == pi/2): nz -> 0, the in-plane
        # normal collapses; fall back to the horizontal strike-perpendicular
        # direction so a vertical plane still has a well-defined side.
        horiz = np.array([nx, ny])
        nh = np.linalg.norm(horiz)
        if nh < 1e-12:
            # dip ~ 0 (horizontal plane) or degenerate: use strike-perp in xy
            horiz = np.array([-np.sin(self.strike), np.cos(self.strike)])
            nh = np.linalg.norm(horiz) or 1.0
            nx, ny = horiz / nh
            nz = 0.0
        self.normal = np.array([nx / nh if nh > 0 else nx,
                                ny / nh if nh > 0 else ny, nz])
        # ensure unit (z component already 0 or cos(dip))
        nn = np.linalg.norm(self.normal)
        if nn > 0:
            self.normal = self.normal / nn
        self._ref = np.array([self.x0, self.y0, self.z0])

    def signed_distance(self, x, y, z) -> np.ndarray:
        """Signed perpendicular distance of points to the plane.

        Positive on the hanging-wall side.  Accepts scalars or arrays of
        any broadcastable shape.
        """
        x = np.asarray(x, float); y = np.asarray(y, float)
        z = np.asarray(z, float) if np.ndim(z) else np.float64(z)
        xb, yb, zb = np.broadcast_arrays(x, y, z)
        pts = np.stack([xb, yb, zb], axis=-1)
        return np.dot(pts - self._ref, self.normal)

    def side(self, x, y, z=None) -> np.ndarray:
        """Block side index: +1 (hanging wall), -1 (foot wall), 0 (on plane)."""
        z = 0.0 if z is None else z
        d = self.signed_distance(x, y, z)
        return np.sign(d)


def fault_polygon(
    plane: FaultPlane, grid_extent: Sequence[float], n: int = 100
) -> np.ndarray:
    """Map-view (x, y) line where the fault plane intersects ``z = 0``.

    ``grid_extent = (xmin, xmax, ymin, ymax)``.  Returns an ``(M, 2)``
    array of points along the fault trace clipped to the extent.
    """
    xmin, xmax, ymin, ymax = grid_extent
    # the z=0 intersection: solve n·((x,y,0) - ref) = 0
    nx, ny, nz = plane.normal
    # nx*(x-x0) + ny*(y-y0) - nz*z0 = 0  ->  nx*x + ny*y = nx*x0 + ny*y0 - nz*z0
    c = nx * plane.x0 + ny * plane.y0 - nz * plane.z0
    pts = []
    # parameterise along the trace direction (perpendicular to (nx,ny) in map view)
    t = np.array([-ny, nx])
    tn = np.linalg.norm(t)
    if tn == 0:
        # vertical plane with nz=0 handled; if nx=ny=0 the plane is horizontal (no trace)
        return np.empty((0, 2))
    t = t / tn
    # origin on the line: pick y=ymin -> x = (c - ny*ymin)/nx if nx!=0
    if abs(nx) > abs(ny):
        # x = (c - ny*y)/nx ; sample y
        ys = np.linspace(ymin, ymax, n)
        xs = (c - ny * ys) / nx
    else:
        xs = np.linspace(xmin, xmax, n)
        ys = (c - nx * xs) / ny
    pts = np.column_stack([xs, ys])
    # clip to extent
    inside = (
        (pts[:, 0] >= xmin - 1e-9) & (pts[:, 0] <= xmax + 1e-9)
        & (pts[:, 1] >= ymin - 1e-9) & (pts[:, 1] <= ymax + 1e-9)
    )
    return pts[inside]


# ---------------------------------------------------------------------
# Block segmentation
# ---------------------------------------------------------------------
def segment_blocks(
    grid_extent: Sequence[float], nx: int, ny: int,
    faults: Sequence[FaultPlane],
) -> np.ndarray:
    """Label every grid cell with a fault-block id.

    Returns an ``(ny, nx)`` integer array where each unique label is a
    block.  Two cells are in the same block iff they are on the same side
    of every fault and connected (4-connectivity flood fill).
    """
    xmin, xmax, ymin, ymax = grid_extent
    xs = np.linspace(xmin, xmax, nx)
    ys = np.linspace(ymin, ymax, ny)
    GX, GY = np.meshgrid(xs, ys)
    # side signature per fault -> unique combo per block region
    sig = np.zeros((ny, nx), dtype=int)
    for k, f in enumerate(faults):
        s = np.sign(f.signed_distance(GX, GY, 0.0)).astype(int)
        sig += (s + 1) * (3 ** k)
    # connected-component labelling within each signature value
    from scipy.ndimage import label
    structure = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])
    out = np.zeros((ny, nx), dtype=int)
    next_label = 1
    for val in np.unique(sig):
        mask = sig == val
        lab, nlab = label(mask, structure=structure)
        for j in range(1, nlab + 1):
            out[lab == j] = next_label
            next_label += 1
    return out


def gridcell_to_block(
    x: float, y: float, faults: Sequence[FaultPlane]
) -> int:
    """Return the block signature (not connected-component id) of a point.

    The signature encodes which side of every fault the point is on, as
    ``sum_k (side_k + 1) * 3**k``.  Points with identical signatures are
    in the same fault-bounded region.
    """
    sig = 0
    for k, f in enumerate(faults):
        s = int(np.sign(f.signed_distance(x, y, 0.0)))
        sig += (s + 1) * (3 ** k)
    return sig


# ---------------------------------------------------------------------
# Throw / heave
# ---------------------------------------------------------------------
@dataclass
class ThrowHeave:
    """Fault displacement quantities."""

    throw: float       # vertical offset (hanging - footwall), depth-positive down
    heave: float       # horizontal offset in dip direction
    apparent_heave: float  # horizontal offset in map view (along dip azimuth)
    dip: float


def fault_throw_heave(
    footwall_z: float, hangingwall_z: float, dip: float,
    *, depth_positive_down: bool = True,
) -> ThrowHeave:
    """Compute throw & heave from footwall / hanging-wall depths.

    Parameters
    ----------
    footwall_z, hangingwall_z : float
        Depths of the same horizon on the foot wall and hanging wall.
        With ``depth_positive_down=True`` larger = deeper.
    dip : float
        Fault dip in radians.

    Returns
    -------
    ThrowHeave
        ``throw`` = vertical displacement (positive when the hanging wall
        has moved down), ``heave`` = horizontal displacement in the dip
        direction = ``throw / tan(dip)``.
    """
    if dip <= 0 or dip >= np.pi / 2:
        raise ValueError("dip must be in (0, pi/2).")
    sign = 1.0 if depth_positive_down else -1.0
    throw = sign * (hangingwall_z - footwall_z)
    heave = throw / np.tan(dip)
    return ThrowHeave(
        throw=throw, heave=heave, apparent_heave=heave, dip=dip,
    )
