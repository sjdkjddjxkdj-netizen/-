"""petroppo V23 — Horizon surfaces, interpolation & well-tie.

A *horizon* is a single-valued surface ``z = f(x, y)`` representing a
geological interface (e.g. a reflector picked on seismic).  This module
provides the primitives a structural model needs:

* building gridded surfaces from sparse picks,
* interpolating / resampling them,
* tying them to well control points and reporting residuals,
* extracting isosurfaces from a 3-D scalar volume.

All routines are pure numpy/scipy and are verified in
``verification/test_geology.py`` against analytically-known surfaces.

References
----------
Deutsch (2002), *Geostatistical Reservoir Modeling*, ch. 4 (surfaces & gridding).
Cressie (1993), *Statistics for Spatial Data* (interpolation).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.ndimage import map_coordinates


# ---------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------
@dataclass
class HorizonSurface:
    """A gridded single-valued horizon ``z = f(x, y)``.

    Parameters
    ----------
    x, y : 1-D arrays
        Monotonically increasing grid coordinates.
    z : 2-D array, shape (ny, nx)
        Surface depths, ``z[j, i]`` at ``(x[i], y[j])``.
    """

    x: np.ndarray
    y: np.ndarray
    z: np.ndarray

    def __post_init__(self) -> None:
        self.x = np.asarray(self.x, dtype=float)
        self.y = np.asarray(self.y, dtype=float)
        self.z = np.asarray(self.z, dtype=float)
        if self.z.shape != (self.y.size, self.x.size):
            raise ValueError(
                f"z shape {self.z.shape} != (ny={self.y.size}, nx={self.x.size})"
            )
        if np.any(np.diff(self.x) <= 0) or np.any(np.diff(self.y) <= 0):
            raise ValueError("x and y must be strictly increasing.")

    @property
    def shape(self) -> tuple:
        return self.z.shape

    def as_interpolator(self, method: str = "linear") -> RegularGridInterpolator:
        """Return a scipy interpolator over this surface."""
        return RegularGridInterpolator(
            (self.y, self.x), self.z, method=method,
            bounds_error=False, fill_value=None,
        )

    def evaluate(self, xq: np.ndarray, yq: np.ndarray, method: str = "linear") -> np.ndarray:
        """Evaluate the surface at query points ``(xq, yq)``."""
        xq = np.asarray(xq, dtype=float)
        yq = np.asarray(yq, dtype=float)
        pts = np.column_stack([yq.ravel(), xq.ravel()])
        zq = self.as_interpolator(method=method)(pts)
        return zq.reshape(np.broadcast(xq, yq).shape)


# ---------------------------------------------------------------------
# Construction & interpolation
# ---------------------------------------------------------------------
def make_horizon_surface(
    x: np.ndarray, y: np.ndarray, z: np.ndarray
) -> HorizonSurface:
    """Assemble a :class:`HorizonSurface` from grid axes and a ``z`` matrix."""
    return HorizonSurface(x=x, y=y, z=z)


def interpolate_horizon(
    px: np.ndarray, py: np.ndarray, pz: np.ndarray,
    x_grid: np.ndarray, y_grid: np.ndarray,
    method: str = "linear",
) -> HorizonSurface:
    """Interpolate sparse picks ``(px, py, pz)`` onto a regular grid.

    Uses scipy's scattered ``LinearNDInterpolator`` / ``NearestNDInterpolator``
    depending on ``method``.
    """
    from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

    px = np.asarray(px, float); py = np.asarray(py, float); pz = np.asarray(pz, float)
    x_grid = np.asarray(x_grid, float); y_grid = np.asarray(y_grid, float)
    pts = np.column_stack([px, py])
    near = NearestNDInterpolator(pts, pz)
    if method == "nearest":
        def interp(q):
            return near(q)
    else:
        lin = LinearNDInterpolator(pts, pz)
        def interp(q):
            v = lin(q)
            bad = ~np.isfinite(v)
            if np.any(bad):
                v = np.where(bad, near(q), v)
            return v

    GX, GY = np.meshgrid(x_grid, y_grid)
    Q = np.column_stack([GX.ravel(), GY.ravel()])
    Z = interp(Q).reshape(GX.shape)
    return HorizonSurface(x=x_grid, y=y_grid, z=Z)


def resample_horizon(
    surf: HorizonSurface,
    new_x: np.ndarray, new_y: np.ndarray,
    method: str = "linear",
) -> HorizonSurface:
    """Resample ``surf`` onto a new ``(new_x, new_y)`` grid."""
    new_x = np.asarray(new_x, float); new_y = np.asarray(new_y, float)
    Z = surf.evaluate(new_x, new_y, method=method)
    # evaluate returns shape broadcast(new_x,new_y); force 2-D grid
    if Z.ndim != 2:
        GX, GY = np.meshgrid(new_x, new_y)
        Z = surf.evaluate(GX, GY, method=method)
    return HorizonSurface(x=new_x, y=new_y, z=Z)


# ---------------------------------------------------------------------
# Well-tie & residuals
# ---------------------------------------------------------------------
@dataclass
class WellTieResult:
    """Outcome of tying a horizon to well control points."""

    predicted_z: np.ndarray
    residuals: np.ndarray
    mean_residual: float
    rmse: float
    max_abs_residual: float


def well_tie(
    surf: HorizonSurface, well_x: np.ndarray, well_y: np.ndarray,
    well_z: np.ndarray,
) -> WellTieResult:
    """Tie ``surf`` to well picks ``(well_x, well_y, well_z)``.

    Returns the predicted depths at the wells and the residuals
    (predicted - observed).
    """
    well_x = np.asarray(well_x, float); well_y = np.asarray(well_y, float)
    well_z = np.asarray(well_z, float)
    pred = surf.evaluate(well_x, well_y)
    res = pred - well_z
    return WellTieResult(
        predicted_z=pred, residuals=res,
        mean_residual=float(np.mean(res)),
        rmse=float(np.sqrt(np.mean(res ** 2))),
        max_abs_residual=float(np.max(np.abs(res))),
    )


def horizon_residual(
    surf: HorizonSurface, well_x: np.ndarray, well_y: np.ndarray,
    well_z: np.ndarray,
) -> WellTieResult:
    """Alias of :func:`well_tie` returning residual statistics."""
    return well_tie(surf, well_x, well_y, well_z)


# ---------------------------------------------------------------------
# Isosurface extraction (2-D map view via marching squares / contours)
# ---------------------------------------------------------------------
def isosurface_horizon(
    volume: np.ndarray, value: float,
    x: np.ndarray, y: np.ndarray,
) -> np.ndarray:
    """Extract the ``(x, y)`` contour of ``volume == value`` in map view.

    ``volume`` is a 2-D scalar field sampled on ``(y, x)``.  Returns an
    ``(M, 2)`` array of contour point coordinates.  This is the map-view
    equivalent of a horizon slice at a constant value.
    """
    import matplotlib
    matplotlib.use("Agg")  # noqa
    from matplotlib import _contour  # type: ignore

    x = np.asarray(x, float); y = np.asarray(y, float)
    volume = np.asarray(volume, float)
    # matplotlib contour without drawing: use Cntr directly
    from matplotlib._contour import Cntr
    X, Y = np.meshgrid(x, y)
    c = Cntr(X, Y, volume)
    segs = c.trace(value, value, 0)
    # trace returns [segs...] then [holes...]; take the first list
    if not segs:
        return np.empty((0, 2))
    pts = np.asarray(segs[0])
    return pts


def isosurface_volume(
    volume: np.ndarray, value: float,
    spacing: Sequence[float] = (1.0, 1.0, 1.0),
) -> tuple:
    """Return the voxels (indices) whose value straddles ``value``.

    A lightweight marching-cubes-free isosurface indicator: returns the
    set of voxel indices where the level set crosses.  Useful for
    verifying that an analytic blob is recovered.
    """
    volume = np.asarray(volume, float)
    above = volume >= value
    # crossing = neighbour differs
    crossing = np.zeros_like(above)
    crossing[:-1] |= above[:-1] != above[1:]
    crossing[1:] |= above[:-1] != above[1:]
    idx = np.argwhere(crossing)
    return idx, above
