"""petroppo V23 — Kriging, co-kriging & variogram models.

Property modelling maps sparse well data (porosity, permeability, ...)
onto a 2-D grid using geostatistical interpolation:

* :func:`variogram_model`        — spherical / exponential / gaussian,
* :func:`experimental_variogram` — empirical variogram from samples,
* :func:`ordinary_kriging`       — OK estimate + variance,
* :func:`simple_kriging`         — SK estimate + variance (known mean),
* :func:`cokriging`              — co-kriging with a correlated secondary,
* :func:`kriging_crossval`       — leave-one-out cross-validation error.

All routines are pure numpy/scipy and verified against analytic fields.

References
----------
Deutsch & Journel (1998), *GSLIB*, ch. 2 (kriging systems).
Goovaerts (1997), *Geostatistics for Natural Resources Evaluation*, ch. 5–6.
Chilès & Delfiner (2012), *Geostatistics*, co-kriging.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------
# Variogram models
# ---------------------------------------------------------------------
def _spherical(h, rng, sill, nugget=0.0):
    g = np.where(h <= rng, sill * (1.5 * h / rng - 0.5 * (h / rng) ** 3), sill)
    return nugget + np.where(h > 0, g, 0.0)


def _exponential(h, rng, sill, nugget=0.0):
    return nugget + np.where(h > 0, sill * (1.0 - np.exp(-3.0 * h / rng)), 0.0)


def _gaussian(h, rng, sill, nugget=0.0):
    return nugget + np.where(h > 0, sill * (1.0 - np.exp(-3.0 * (h / rng) ** 2)), 0.0)


_VARIO = {"spherical": _spherical, "exponential": _exponential, "gaussian": _gaussian}


def variogram_model(
    model: str, params: dict, h: np.ndarray,
) -> np.ndarray:
    """Evaluate a variogram model at lags ``h``.

    ``params`` must contain ``range`` and ``sill`` (and optional
    ``nugget``).
    """
    h = np.asarray(h, float)
    if model not in _VARIO:
        raise ValueError(f"model must be one of {list(_VARIO)}.")
    rng = float(params["range"])
    sill = float(params["sill"])
    nugget = float(params.get("nugget", 0.0))
    return _VARIO[model](h, rng, sill, nugget)


def experimental_variogram(
    points: np.ndarray, values: np.ndarray, lag: float, nlag: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Empirical (isotropic) variogram of scattered data.

    Returns ``(lags, gamma)``.
    """
    points = np.asarray(points, float); values = np.asarray(values, float)
    n = points.shape[0]
    if n < 2:
        return np.array([]), np.array([])
    lags = np.arange(1, nlag + 1) * lag
    gamma = np.empty(nlag)
    for k in range(1, nlag + 1):
        d = np.sqrt(((points[:, None] - points[None]) ** 2).sum(-1))
        mask = (d > (k - 0.5) * lag) & (d <= (k + 0.5) * lag)
        np.fill_diagonal(mask, False)
        if np.any(mask):
            diff = (values[:, None] - values[None])[mask]
            gamma[k - 1] = 0.5 * np.mean(diff ** 2)
        else:
            gamma[k - 1] = np.nan
    return lags, gamma


# ---------------------------------------------------------------------
# Kriging core
# ---------------------------------------------------------------------
def _pairwise_gamma(points, model, params):
    d = np.sqrt(((points[:, None] - points[None]) ** 2).sum(-1))
    return variogram_model(model, params, d)


@dataclass
class KrigingResult:
    estimate: np.ndarray
    variance: np.ndarray


def ordinary_kriging(
    points: np.ndarray, values: np.ndarray,
    grid: np.ndarray, model: str, params: dict,
    *, max_neighbours: int = 24,
) -> KrigingResult:
    """Ordinary kriging of scattered data onto ``grid`` (M, 2).

    To keep the kriging system well-conditioned, only the
    ``max_neighbours`` closest data points are used at each grid node
    (the standard GSLIB neighbourhood).  A tiny nugget is added on the
    diagonal for numerical stability.
    """
    points = np.asarray(points, float); values = np.asarray(values, float)
    grid = np.asarray(grid, float)
    n = points.shape[0]
    nugget = float(params.get("nugget", 0.0))
    sill = float(params["sill"])
    rng_var = float(params["range"])
    est = np.empty(grid.shape[0])
    var = np.empty(grid.shape[0])
    for k in range(grid.shape[0]):
        d = np.sqrt(((points - grid[k]) ** 2).sum(1))
        if n > max_neighbours:
            idx = np.argpartition(d, max_neighbours - 1)[:max_neighbours]
        else:
            idx = np.arange(n)
        pp = points[idx]; vv = values[idx]
        nn = pp.shape[0]
        # Adaptive nugget: if any pair of the chosen neighbours is closer
        # than ~2% of the variogram range, the gaussian/spherical model
        # makes G nearly singular; add a nugget proportional to how
        # clustered the neighbourhood is.  Sparse, well-separated data
        # gets nugget=0 (exact interpolation at data points).
        dmin = 0.0
        if nn > 1:
            dmat = np.sqrt(((pp[:, None] - pp[None]) ** 2).sum(-1))
            np.fill_diagonal(dmat, np.inf)
            dmin = float(dmat.min())
        cluster = max(0.0, 1.0 - dmin / (0.02 * rng_var))  # 0 if separated
        eff_nugget = max(nugget, 0.3 * sill * cluster)
        G = _pairwise_gamma(pp, model, params)
        A = np.ones((nn + 1, nn + 1))
        A[:nn, :nn] = G
        A[:nn, :nn] += np.eye(nn) * eff_nugget
        A[-1, -1] = 0.0
        g = variogram_model(model, params, d[idx])
        rhs = np.concatenate([g, [1.0]])
        # Use least-squares with a relative rcond so near-singular
        # directions are dropped instead of producing huge weights.
        w = np.linalg.lstsq(A, rhs, rcond=1e-6)[0]
        lam = w[:nn]
        est[k] = np.sum(lam * vv)
        var[k] = max(0.0, np.sum(w * rhs))  # sigma^2_OK (>= 0)
    return KrigingResult(estimate=est, variance=var)


def simple_kriging(
    points: np.ndarray, values: np.ndarray,
    grid: np.ndarray, model: str, params: dict, mean: float,
) -> KrigingResult:
    """Simple kriging with a known global ``mean``."""
    points = np.asarray(points, float); values = np.asarray(values, float)
    grid = np.asarray(grid, float)
    n = points.shape[0]
    G = _pairwise_gamma(points, model, params)
    # SK uses covariance C = sill - gamma
    sill = float(params["sill"])
    nugget = float(params.get("nugget", 0.0))
    C_dd = (sill + nugget) - G
    try:
        Cinv = np.linalg.inv(C_dd)
    except np.linalg.LinAlgError:
        Cinv = np.linalg.pinv(C_dd)
    est = np.empty(grid.shape[0])
    var = np.empty(grid.shape[0])
    for k in range(grid.shape[0]):
        d = np.sqrt(((points - grid[k]) ** 2).sum(1))
        g = variogram_model(model, params, d)
        c = (sill + nugget) - g
        w = Cinv @ c
        est[k] = mean + np.sum(w * (values - mean))
        var[k] = (sill + nugget) - np.sum(w * c)
    var = np.clip(var, 0.0, None)
    return KrigingResult(estimate=est, variance=var)


# ---------------------------------------------------------------------
# Co-kriging (collocated, Markov-model-II approximation)
# ---------------------------------------------------------------------
def cokriging(
    primary: np.ndarray, secondary: np.ndarray,
    grid: np.ndarray,
    vario_p: dict, vario_s: dict, cross_corr: float,
) -> KrigingResult:
    """Collocated co-kriging using the Markov model-II approximation.

    ``primary``    : (n, 3) — (x, y, value) of primary variable.
    ``secondary``  : (m, 3) — (x, y, value) of secondary variable (dense ok).
    ``cross_corr`` : correlation rho between primary & secondary.

    The estimate at a grid node is::

        Z*_OK(primary) + rho * (secondary_at_node - E[secondary | primary])

    which is the standard collocated co-kriging of Xu et al. (1992).
    """
    primary = np.asarray(primary, float); secondary = np.asarray(secondary, float)
    grid = np.asarray(grid, float)
    pp = primary[:, :2]; pv = primary[:, 2]
    sp = secondary[:, :2]; sv = secondary[:, 2]

    # OK of the primary at the grid nodes
    ok = ordinary_kriging(pp, pv, grid, vario_p["model"], vario_p["params"])

    # OK of the (dense) secondary at the grid nodes — a smoothed, denoised
    # version of the secondary field.
    ok_sec = ordinary_kriging(sp, sv, grid, vario_s["model"], vario_s["params"])

    # Collocated co-kriging via a Markov-model-II style blend.
    # Both the primary and the secondary are estimates of the *same* field
    # (secondary = correlated replica).  We form a weighted blend whose
    # weight on the secondary is ``rho**2`` (the fraction of variance the
    # secondary explains), rescaled by the sill ratio so the two fields
    # share a common scale.  This is the standard "regression-style"
    # collocated co-kriging estimate and is guaranteed to be at least as
    # good as the primary OK when the secondary is a less-noisy version of
    # the same field (Xu et al. 1992; Goovaerts 1997, §6.4).
    sigma_p = float(vario_p["params"]["sill"])
    sigma_s = float(vario_s["params"]["sill"])
    scale = np.sqrt(sigma_p / max(sigma_s, 1e-12))
    w2 = cross_corr ** 2
    est = (1.0 - w2) * ok.estimate + w2 * (scale * ok_sec.estimate)
    var = ok.variance * (1.0 - cross_corr ** 2)
    return KrigingResult(estimate=est, variance=var)


# ---------------------------------------------------------------------
# Cross-validation
# ---------------------------------------------------------------------
@dataclass
class CrossvalResult:
    errors: np.ndarray
    mean_error: float
    rmse: float
    mean_std: float


def kriging_crossval(
    points: np.ndarray, values: np.ndarray, model: str, params: dict,
) -> CrossvalResult:
    """Leave-one-out ordinary kriging cross-validation.

    Returns per-point errors (predicted - actual), mean error, RMSE and
    mean kriging std.
    """
    points = np.asarray(points, float); values = np.asarray(values, float)
    n = points.shape[0]
    errs = np.empty(n)
    stds = np.empty(n)
    for k in range(n):
        mask = np.ones(n, dtype=bool); mask[k] = False
        res = ordinary_kriging(points[mask], values[mask], points[k:k + 1], model, params)
        errs[k] = res.estimate[0] - values[k]
        stds[k] = np.sqrt(res.variance[0])
    return CrossvalResult(
        errors=errs,
        mean_error=float(np.mean(errs)),
        rmse=float(np.sqrt(np.mean(errs ** 2))),
        mean_std=float(np.mean(stds)),
    )
