"""petroppo V23 — Stratigraphic layering, terminations & Wheeler diagrams.

A *stratigraphic model* is an ordered stack of intervals bounded by
horizons.  This module provides:

* :func:`build_strata` — assemble intervals from a list of horizons,
* :func:`apply_termination` — insert onlap / toplap / truncation / downlap,
* :func:`isochore` — thickness map between two horizons,
* :func:`age_depth` — age-depth model (linear / compaction),
* :func:`sequence_stratigraphy_wheeler` — Wheeler diagram matrix.

All routines are pure numpy/scipy and verified against analytic cases.

References
----------
Catuneanu (2006), *Principles of Sequence Stratigraphy*.
Vail et al. (1977), seismic stratigraphy & terminations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence

import numpy as np

from .horizons import HorizonSurface


# ---------------------------------------------------------------------
# Stratigraphic model
# ---------------------------------------------------------------------
@dataclass
class Interval:
    """A single stratigraphic interval between two horizons."""

    top: HorizonSurface
    base: HorizonSurface
    name: str = ""

    @property
    def thickness(self) -> np.ndarray:
        """Grid of thicknesses (base - top)."""
        return self.base.z - self.top.z


@dataclass
class StrataModel:
    """Ordered stack of intervals (top first)."""

    intervals: List[Interval] = field(default_factory=list)

    @property
    def n_layers(self) -> int:
        return len(self.intervals)

    @property
    def horizons(self) -> List[HorizonSurface]:
        hz = [self.intervals[0].top] if self.intervals else []
        for iv in self.intervals:
            hz.append(iv.base)
        return hz


def build_strata(
    horizons: Sequence[HorizonSurface],
    names: Optional[Sequence[str]] = None,
) -> StrataModel:
    """Build a :class:`StrataModel` from an ordered list of horizons.

    ``horizons`` must share the same grid.  Consecutive horizons form
    intervals.
    """
    if len(horizons) < 2:
        raise ValueError("need at least 2 horizons to build strata.")
    ref_shape = horizons[0].shape
    for h in horizons:
        if h.shape != ref_shape:
            raise ValueError("all horizons must share the same grid.")
    if names is None:
        names = [f"L{i}" for i in range(len(horizons) - 1)]
    ivs = [
        Interval(top=horizons[i], base=horizons[i + 1], name=names[i])
        for i in range(len(horizons) - 1)
    ]
    return StrataModel(intervals=ivs)


# ---------------------------------------------------------------------
# Terminations
# ---------------------------------------------------------------------
TERMINATIONS = ("onlap", "toplap", "truncation", "downlap")


def apply_termination(
    strata: StrataModel,
    term_type: str,
    layer_index: int,
    mask: Optional[np.ndarray] = None,
) -> StrataModel:
    """Apply a stratigraphic termination to one interval.

    The termination is encoded by blanking (``NaN``) the interval's
    thickness where ``mask`` is True:

    * **onlap**     — the layer laps onto the base; thickness set to 0
      (not NaN) where it pinches out, preserving the base surface.
    * **toplap**    — the layer thins at the top; thickness clipped to 0
      where ``mask``.
    * **truncation**— an overlying erosional surface removes the layer;
      thickness set to 0 where ``mask``.
    * **downlap**   — the layer thins basinward onto the base; thickness
      set to 0 where ``mask``.

    Returns a **new** StrataModel (the input is not mutated).
    """
    if term_type not in TERMINATIONS:
        raise ValueError(f"term_type must be one of {TERMINATIONS}.")
    if not (0 <= layer_index < strata.n_layers):
        raise IndexError("layer_index out of range.")
    iv = strata.intervals[layer_index]
    thk = iv.thickness.copy()
    top = iv.top
    base = iv.base
    if mask is None:
        mask = np.zeros_like(thk, dtype=bool)
    mask = np.asarray(mask, dtype=bool)
    new_thk = thk.copy()
    if term_type in ("onlap", "toplap", "truncation", "downlap"):
        new_thk[mask] = 0.0
    # rebuild surfaces preserving the base for onlap/downlap, top otherwise
    if term_type in ("onlap", "downlap"):
        new_top = HorizonSurface(x=top.x, y=top.y, z=base.z - new_thk)
        new_base = base
    else:  # toplap / truncation preserve the top
        new_top = top
        new_base = HorizonSurface(x=base.x, y=base.y, z=top.z + new_thk)
    new_iv = Interval(top=new_top, base=new_base, name=iv.name)
    new_intervals = list(strata.intervals)
    new_intervals[layer_index] = new_iv
    return StrataModel(intervals=new_intervals)


# ---------------------------------------------------------------------
# Isochore
# ---------------------------------------------------------------------
def isochore(
    strata: StrataModel, top_index: int, base_index: int
) -> np.ndarray:
    """Thickness map between horizon ``top_index`` and ``base_index``.

    Indices refer to the horizon list (0 = topmost).  Returns
    ``base - top`` as a 2-D array.
    """
    hz = strata.horizons
    if not (0 <= top_index < len(hz)) or not (0 <= base_index < len(hz)):
        raise IndexError("horizon index out of range.")
    if base_index <= top_index:
        raise ValueError("base_index must be greater than top_index.")
    return hz[base_index].z - hz[top_index].z


def isochore_interval(
    top: HorizonSurface, base: HorizonSurface
) -> np.ndarray:
    """Thickness map (base - top) for two arbitrary horizons."""
    if top.shape != base.shape:
        raise ValueError("horizons must share the same grid.")
    return base.z - top.z


# ---------------------------------------------------------------------
# Age-depth model
# ---------------------------------------------------------------------
def age_depth(
    depths: np.ndarray, ages: np.ndarray,
    z_query: np.ndarray, model: str = "linear",
    *, phi0: float = 0.5, c: float = 0.27e-3,
) -> np.ndarray:
    """Map depth → age via a linear or compaction (Athy) age-depth model.

    Parameters
    ----------
    depths, ages : 1-D arrays
        Control points (depth [m], age [Ma]).
    z_query : array
        Depths at which to predict ages.
    model : {'linear', 'compaction'}
        * 'linear'      — piecewise-linear interpolation.
        * 'compaction'  — uses Athy porosity ``phi = phi0*exp(-c*z)``
          to decompact; implemented as depth rescaled by the cumulative
          solid-thickness, then linearly interpolated in age.
    phi0, c : float
        Surface porosity and compaction coefficient for the
        'compaction' model.

    Returns
    -------
    ndarray
        Predicted ages at ``z_query``.
    """
    depths = np.asarray(depths, float); ages = np.asarray(ages, float)
    z_query = np.asarray(z_query, float)
    if model == "linear":
        return np.interp(z_query, depths, ages)
    elif model == "compaction":
        # solid thickness s(z) = integral_0^z (1-phi) dz
        # = z - phi0/c*(1 - exp(-c z))
        def solid(z):
            return z - (phi0 / c) * (1.0 - np.exp(-c * z))
        s_ctrl = solid(depths)
        s_q = solid(z_query)
        return np.interp(s_q, s_ctrl, ages)
    else:
        raise ValueError("model must be 'linear' or 'compaction'.")


# ---------------------------------------------------------------------
# Wheeler diagram
# ---------------------------------------------------------------------
def sequence_stratigraphy_wheeler(
    strata: StrataModel, ages: Sequence[float],
    n_time: int = 100,
) -> np.ndarray:
    """Build a Wheeler (time-stratigraphic) diagram matrix.

    Each row is a time step (youngest → oldest, top → bottom), each
    column is a horizontal location index.  The cell value is the index
    of the interval deposited at that time/location, or ``-1`` if none
    (hiatus / non-deposition).

    Parameters
    ----------
    strata : StrataModel
    ages : sequence
        Age of each horizon (length = n horizons = n layers + 1),
        oldest last.  Must be monotonic increasing.
    n_time : int
        Number of time rows in the output.

    Returns
    -------
    ndarray, shape (n_time, nx)
    """
    hz = strata.horizons
    ages = np.asarray(ages, float)
    if len(ages) != len(hz):
        raise ValueError("ages must have one entry per horizon.")
    if np.any(np.diff(ages) <= 0):
        raise ValueError("ages must be strictly increasing (old last).")
    nx = hz[0].x.size
    t_axis = np.linspace(ages[0], ages[-1], n_time)
    out = np.full((n_time, nx), -1, dtype=int)
    for i, iv in enumerate(strata.intervals):
        t_top = ages[i]
        t_base = ages[i + 1]
        rows = (t_axis >= t_top) & (t_axis <= t_base)
        out[rows, :] = i
    return out
