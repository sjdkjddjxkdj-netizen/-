"""petroppo V20 — InverseProblem abstract base class.

An :class:`InverseProblem` ties together a :class:`ForwardModel`, an observed
data vector, a regularization operator, and an optimization strategy.  It is
the high-level contract that the benchmark harness calls — the harness never
imports a specific solver; it imports an InverseProblem and calls
``solve()`` which returns a :class:`ScientificResult`.

This replaces the V19 pattern where benchmark adapters called solver-specific
functions (``run_petroppo_inversion(...)``) with differing signatures and
return shapes.

Contract
--------
* ``forward`` — the ForwardModel.
* ``observed`` — observed data vector (same length as forward.n_data).
* ``uncertainty`` — per-datum standard deviation (for weighting / QC).
* ``regularization`` — a RegularizationOperator (from physics.regularization).
* ``optimizer`` — an Optimizer (from physics.optimization).
* ``solve(initial_model=None) -> ScientificResult`` — run the inversion and
  return a fully-provenanced, QC-flagged result.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import numpy as np

from .result import ScientificResult, Provenance, QCReport
from .forward import ForwardModel


class InverseProblem(ABC):
    """Abstract inverse problem: find m such that F(m) ≈ d_obs."""

    def __init__(self, forward: ForwardModel, observed: np.ndarray,
                 uncertainty: Optional[np.ndarray] = None):
        self.forward = forward
        self.observed = np.asarray(observed, dtype=float)
        if self.observed.shape[0] != forward.n_data:
            raise ValueError(
                f"observed length {self.observed.shape[0]} != n_data {forward.n_data}")
        if uncertainty is not None:
            self.uncertainty = np.asarray(uncertainty, dtype=float)
            if self.uncertainty.shape[0] != forward.n_data:
                raise ValueError("uncertainty length mismatch")
            if np.any(self.uncertainty <= 0):
                raise ValueError("uncertainty must be strictly positive")
        else:
            self.uncertainty = np.ones(forward.n_data)

    @property
    def weights(self) -> np.ndarray:
        """Diagonal data weights = 1 / sigma^2."""
        return 1.0 / (self.uncertainty ** 2)

    @abstractmethod
    def solve(self, initial_model: Optional[np.ndarray] = None,
              max_iter: int = 20, tolerance: float = 1e-4,
              seed: Optional[int] = None) -> ScientificResult:
        """Run the inversion and return a ScientificResult."""
        ...

    def _base_provenance(self, seed: Optional[int], wall_time: float,
                         solver_name: str, solver_version: str = "20.0.0",
                         config: Optional[dict] = None) -> Provenance:
        return Provenance(
            solver_name=solver_name,
            solver_version=solver_version,
            seed=seed,
            wall_time_s=wall_time,
            config=config or {},
        )

    def _qc_basic(self, model: np.ndarray) -> QCReport:
        """Compute basic QC flags that *any* inversion should satisfy."""
        qc = QCReport()
        pred = self.forward.predict(model)
        r = self.observed - pred
        wr = r / self.uncertainty
        chi2 = float(np.dot(wr, wr)) / max(self.forward.n_data, 1)
        rms = float(np.sqrt(np.mean(r ** 2)))
        qc.add("chi_square_per_n", chi2 < 2.0, chi2,
               "weighted misfit should be ≤2 (low = good fit, >2 = underfit)")
        qc.add("rms_finite", np.isfinite(rms), rms, "RMS must be finite")
        qc.add("model_finite", bool(np.all(np.isfinite(model))), float(np.sum(~np.isfinite(model))),
               "all model parameters must be finite")
        qc.add("prediction_finite", bool(np.all(np.isfinite(pred))),
               float(np.sum(~np.isfinite(pred))),
               "all predicted data must be finite")
        return qc
