"""
Geophysical inversion subpackage (V26 upgrade).

Provides multi-scale, joint-3D, and 4D time-lapse inversion on top of the
core ERT / joint-inversion modules in :mod:`petroppo.processing`.

Modules
-------
* :mod:`petroppo.physics.inversion.multi_scale` — coarse-to-fine multi-scale
  inversion with model prolongation between resolution levels.
* :mod:`petroppo.physics.inversion.joint_3d` — 3-D joint inversion of
  gravity + EM + seismic travel-time with cross-gradient structural coupling.
* :mod:`petroppo.physics.inversion.time_lapse` — 4D time-lapse inversion
  with temporal regularisation and anomaly detection.
"""

from __future__ import annotations

__all__: list[str] = []

# --- multi-scale ----------------------------------------------------------- #
try:
    from . import multi_scale  # noqa: F401
    from .multi_scale import (
        MultiScaleGrid,
        MultiScaleResult,
        prolongate,
        restrict,
        single_scale_invert,
        multi_scale_invert,
    )
    __all__ += [
        "multi_scale",
        "MultiScaleGrid",
        "MultiScaleResult",
        "prolongate",
        "restrict",
        "single_scale_invert",
        "multi_scale_invert",
    ]
except Exception:  # pragma: no cover
    pass

# --- joint 3-D ------------------------------------------------------------- #
try:
    from . import joint_3d  # noqa: F401
    from .joint_3d import (
        Joint3DGrid,
        GravityForward,
        EMForward,
        SeismicTomographyForward,
        joint_3d_invert,
        Joint3DResult,
        cross_gradient_3d,
    )
    __all__ += [
        "joint_3d",
        "Joint3DGrid",
        "GravityForward",
        "EMForward",
        "SeismicTomographyForward",
        "joint_3d_invert",
        "Joint3DResult",
        "cross_gradient_3d",
    ]
except Exception:  # pragma: no cover
    pass

# --- time-lapse / 4D ------------------------------------------------------- #
try:
    from . import time_lapse  # noqa: F401
    from .time_lapse import (
        TimeLapseResult,
        time_lapse_invert,
        detect_4d_anomaly,
    )
    __all__ += [
        "time_lapse",
        "TimeLapseResult",
        "time_lapse_invert",
        "detect_4d_anomaly",
    ]
except Exception:  # pragma: no cover
    pass
