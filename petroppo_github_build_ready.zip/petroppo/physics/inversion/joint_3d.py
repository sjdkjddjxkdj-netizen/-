"""
3-D joint inversion of gravity, EM (DC resistivity), and seismic
travel-time data with cross-gradient structural coupling.

Joint inversion combines multiple geophysical methods that are sensitive
to different physical properties (density, resistivity, velocity) but are
often caused by the **same** subsurface structure.  By coupling the
property models through a **cross-gradient** term — which drives the
boundaries of all property models to coincide — the recovered models are
structurally consistent and the individual inversions are better
constrained than if inverted independently (Gallardo & Meju, 2003).

This module implements:

* :class:`Joint3DGrid` — a regular 3-D voxel grid.
* :class:`GravityForward` — Bouguer-slab / vertical-line-element gravity
  forward for density contrast (g_z at surface stations).
* :class:`EMForward` — DC-resistivity 3-D sensitivity (Gaussian footprint
  approximation, same family as the 2-D operator in
  :mod:`petroppo.processing.inversion`).
* :class:`SeismicTomographyForward` — straight-ray travel-time forward
  (sum of slowness along ray path).
* :func:`joint_3d_invert` — alternating / simultaneous Gauss-Newton
  inversion minimising data misfit + smoothness + cross-gradient.
* :func:`cross_gradient_3d` — discrete cross-gradient vector.

All operators are linear(ised) so that analytic Jacobians are available,
keeping the module dependency-light (numpy + scipy only).

References
----------
* Gallardo, L.A. & Meju, M.A. (2003), "Characterisation of heterogeneous
  near-surface materials by 3D inversion of resistivity and seismic
  travel-time data", *Geophysical Research Letters* 30(13).
* Moorkamp, M., Heincke, B., Jegen, M., Roberts, A.W. & Hobbs, R.W.
  (2011), "A framework for 3-D joint inversion of MT, gravity and seismic
  refraction data", *Geophysical Journal International* 184.
* Tarantola, A. (2005), *Inverse Problem Theory*, SIAM.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import lsqr

__all__ = [
    "Joint3DGrid",
    "GravityForward",
    "EMForward",
    "SeismicTomographyForward",
    "Joint3DResult",
    "cross_gradient_3d",
    "joint_3d_invert",
]


# --------------------------------------------------------------------------- #
# 3-D voxel grid
# --------------------------------------------------------------------------- #
@dataclass
class Joint3DGrid:
    """A regular 3-D voxel grid for joint inversion.

    Attributes
    ----------
    x_min, x_max : float
        Horizontal extent in x (m).
    y_min, y_max : float
        Horizontal extent in y (m).
    z_min, z_max : float
        Vertical extent (m); z_min is the top (surface), z_max the bottom.
    n_x, n_y, n_z : int
        Number of voxels along each axis.
    """

    x_min: float = 0.0
    x_max: float = 1000.0
    y_min: float = 0.0
    y_max: float = 1000.0
    z_min: float = 0.0
    z_max: float = 500.0
    n_x: int = 10
    n_y: int = 10
    n_z: int = 5

    @property
    def dx(self) -> float:
        return (self.x_max - self.x_min) / self.n_x

    @property
    def dy(self) -> float:
        return (self.y_max - self.y_min) / self.n_y

    @property
    def dz(self) -> float:
        return (self.z_max - self.z_min) / self.n_z

    @property
    def n_cells(self) -> int:
        return self.n_x * self.n_y * self.n_z

    def cell_index(self, ix: int, iy: int, iz: int) -> int:
        """Cell ordering: x-fastest, then y, then z (C-order)."""
        return (iz * self.n_y + iy) * self.n_x + ix

    def cell_centres(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (X, Y, Z) arrays of cell centre coordinates, each shape
        (n_cells,)."""
        X, Y, Z = np.meshgrid(
            self.x_min + (np.arange(self.n_x) + 0.5) * self.dx,
            self.y_min + (np.arange(self.n_y) + 0.5) * self.dy,
            self.z_min + (np.arange(self.n_z) + 0.5) * self.dz,
            indexing="ij",
        )
        return X.ravel(), Y.ravel(), Z.ravel()

    def cell_volume(self) -> float:
        return self.dx * self.dy * self.dz


# --------------------------------------------------------------------------- #
# Cross-gradient (structural coupling)
# --------------------------------------------------------------------------- #
def cross_gradient_3d(grid: Joint3DGrid,
                      m1: np.ndarray, m2: np.ndarray) -> np.ndarray:
    """Compute the discrete cross-gradient of two 3-D property models.

    The continuous cross-gradient is  ``τ = ∇m₁ × ∇m₂``; its magnitude is
    zero where the two models have parallel (or no) gradients, i.e. where
    their boundaries coincide.  The discrete form uses first-order central
    finite differences along x, y, z (one-sided / zero at boundaries).

    Returns the **magnitude** |τ| at every cell (shape n_cells,).
    """
    nx, ny, nz = grid.n_x, grid.n_y, grid.n_z
    a = np.asarray(m1, float).reshape(nx, ny, nz)
    b = np.asarray(m2, float).reshape(nx, ny, nz)

    def grad(v: np.ndarray, axis: int) -> np.ndarray:
        d = np.zeros_like(v)
        if axis == 0:
            d[1:-1, :, :] = (v[2:, :, :] - v[:-2, :, :]) / (2 * grid.dx)
        elif axis == 1:
            d[:, 1:-1, :] = (v[:, 2:, :] - v[:, :-2, :]) / (2 * grid.dy)
        else:
            d[:, :, 1:-1] = (v[:, :, 2:] - v[:, :, :-2]) / (2 * grid.dz)
        return d

    ga_x = grad(a, 0); ga_y = grad(a, 1); ga_z = grad(a, 2)
    gb_x = grad(b, 0); gb_y = grad(b, 1); gb_z = grad(b, 2)
    tau_x = ga_y * gb_z - ga_z * gb_y
    tau_y = ga_z * gb_x - ga_x * gb_z
    tau_z = ga_x * gb_y - ga_y * gb_x
    mag = np.sqrt(tau_x ** 2 + tau_y ** 2 + tau_z ** 2)
    return mag.ravel()


# --------------------------------------------------------------------------- #
# Forward operators
# --------------------------------------------------------------------------- #
@dataclass
class GravityForward:
    """Gravity (g_z) forward operator for density contrast.

    Uses the vertical component of the gravitational attraction of each
    voxel approximated as a point mass at its centre (Blakely, 1995):

        g_z = G * Σ_i  Δρ_i * V_i * (z_i) / r_i³

    where r_i is the distance from the voxel centre to the surface
    station, and z_i is the depth of the voxel centre below the station.
    The result is in mGal when density is in kg/m³ and distances in m,
    with G = 6.674e-11 and a conversion factor 1e5 m/s² → mGal.
    """

    grid: Joint3DGrid
    stations: np.ndarray  # shape (n_stations, 2) — (x, y) at surface z=z_min
    G: float = 6.674e-11

    def sensitivity(self) -> np.ndarray:
        """Return the sensitivity matrix S (n_stations × n_cells) such that
        g_z = S @ Δρ  (Δρ in kg/m³, g_z in mGal)."""
        n = self.grid.n_cells
        cx, cy, cz = self.grid.cell_centres()
        vol = self.grid.cell_volume()
        ns = len(self.stations)
        S = np.zeros((ns, n))
        for s in range(ns):
            sx, sy = self.stations[s]
            dx = cx - sx
            dy = cy - sy
            dz = cz - self.grid.z_min  # depth below surface (positive down)
            r2 = dx ** 2 + dy ** 2 + dz ** 2
            r3 = r2 ** 1.5
            # g_z point-mass: G * m * dz / r³  (dz positive = downward)
            # m = Δρ * V ; convert m/s² → mGal via *1e5
            S[s, :] = self.G * vol * dz / np.where(r3 > 0, r3, 1.0) * 1e5
        return S

    def forward(self, density_contrast: np.ndarray) -> np.ndarray:
        """Predict g_z (mGal) for a density-contrast model (kg/m³)."""
        S = self.sensitivity()
        return S @ np.asarray(density_contrast, float)


@dataclass
class EMForward:
    """DC-resistivity 3-D forward (Gaussian-footprint approximation).

    Each measurement is an apparent-resistivity reading sensitive to a
    Gaussian volume beneath the electrode midpoint.  The predicted
    apparent resistivity is the volume-weighted average of the cell
    resistivities.
    """

    grid: Joint3DGrid
    readings: list  # list of dicts: 'x','y','a','depth','rho_a'

    def _footprint(self, x, y, a, depth):
        nx, ny, nz = self.grid.n_x, self.grid.n_y, self.grid.n_z
        cx, cy, cz = self.grid.cell_centres()
        sigma_x = max(a, self.grid.dx)
        sigma_y = max(a, self.grid.dy)
        sigma_z = max(a / 2, self.grid.dz)
        w = (np.exp(-0.5 * ((cx - x) / sigma_x) ** 2)
             * np.exp(-0.5 * ((cy - y) / sigma_y) ** 2)
             * np.exp(-0.5 * ((cz - (self.grid.z_min + depth)) / sigma_z) ** 2))
        s = w.sum()
        if s > 0:
            w /= s
        return w

    def sensitivity(self) -> np.ndarray:
        ns = len(self.readings)
        S = np.zeros((ns, self.grid.n_cells))
        for i, r in enumerate(self.readings):
            S[i, :] = self._footprint(r["x"], r["y"], r["a"], r["depth"])
        return S

    def forward(self, resistivity: np.ndarray) -> np.ndarray:
        """Predict apparent resistivity (ohm.m) for a resistivity model."""
        S = self.sensitivity()
        return S @ np.asarray(resistivity, float)


@dataclass
class SeismicTomographyForward:
    """Straight-ray seismic travel-time forward.

    Each ray travels from a source to a receiver along a straight line at
    the surface (2-D refraction geometry).  The travel time is the sum of
    (cell slowness × ray length within cell) over all cells the ray
    crosses.  Sensitivity = ray length per cell.

    For simplicity rays are vertical (down-hole) or straight lines between
    surface points; the ray-length through each voxel is computed by
    sampling along the ray.
    """

    grid: Joint3DGrid
    rays: list  # list of (src_xy, rec_xy) tuples

    def _ray_length(self, src, rec):
        """Compute ray length per cell for a straight ray from src to rec."""
        n = self.grid.n_cells
        L = np.zeros(n)
        cx, cy, cz = self.grid.cell_centres()
        # sample the ray densely
        n_samples = max(200, int(np.linalg.norm(np.array(rec) - np.array(src)) / min(self.grid.dx, self.grid.dy) * 5))
        ts = np.linspace(0, 1, n_samples)
        pts = np.outer(1 - ts, np.array(src)) + np.outer(ts, np.array(rec))
        # for each sample find nearest cell centre and accumulate length
        seg = np.linalg.norm(np.array(rec) - np.array(src)) / (n_samples - 1)
        for p in pts:
            d2 = (cx - p[0]) ** 2 + (cy - p[1]) ** 2 + (cz - p[2]) ** 2
            idx = np.argmin(d2)
            L[idx] += seg
        return L

    def sensitivity(self) -> np.ndarray:
        nr = len(self.rays)
        S = np.zeros((nr, self.grid.n_cells))
        for i, (src, rec) in enumerate(self.rays):
            S[i, :] = self._ray_length(src, rec)
        return S

    def forward(self, slowness: np.ndarray) -> np.ndarray:
        """Predict travel time (s) for a slowness model (s/m)."""
        S = self.sensitivity()
        return S @ np.asarray(slowness, float)


# --------------------------------------------------------------------------- #
# Smoothness (first-order) for a 3-D grid
# --------------------------------------------------------------------------- #
def _smoothness_3d(grid: Joint3DGrid) -> sparse.csr_matrix:
    """First-order smoothness (Laplacian-like) on the 3-D voxel grid."""
    nx, ny, nz = grid.n_x, grid.n_y, grid.n_z
    n = grid.n_cells
    rows, cols, vals = [], [], []
    for iz in range(nz):
        for iy in range(ny):
            for ix in range(nx):
                idx = grid.cell_index(ix, iy, iz)
                # x-neighbour
                if ix + 1 < nx:
                    j = grid.cell_index(ix + 1, iy, iz)
                    rows += [idx, j, idx, j]
                    cols += [idx, j, j, idx]
                    vals += [1, 1, -1, -1]
                # y-neighbour
                if iy + 1 < ny:
                    j = grid.cell_index(ix, iy + 1, iz)
                    rows += [idx, j, idx, j]
                    cols += [idx, j, j, idx]
                    vals += [1, 1, -1, -1]
                # z-neighbour
                if iz + 1 < nz:
                    j = grid.cell_index(ix, iy, iz + 1)
                    rows += [idx, j, idx, j]
                    cols += [idx, j, j, idx]
                    vals += [1, 1, -1, -1]
    return sparse.csr_matrix((vals, (rows, cols)), shape=(n, n))


# --------------------------------------------------------------------------- #
# Joint inversion driver
# --------------------------------------------------------------------------- #
@dataclass
class Joint3DResult:
    """Result of a 3-D joint inversion.

    Attributes
    ----------
    density : np.ndarray
        Recovered density-contrast model (kg/m³).
    resistivity : np.ndarray
        Recovered resistivity model (ohm.m).
    slowness : np.ndarray
        Recovered slowness model (s/m).
    misfits : dict
        Final RMS misfit per method ('gravity', 'em', 'seismic').
    cross_gradient_norm : float
        Final cross-gradient (τ) norm between density & resistivity.
    iterations : int
        Number of outer iterations performed.
    converged : bool
    """

    density: np.ndarray
    resistivity: np.ndarray
    slowness: np.ndarray
    misfits: dict = field(default_factory=dict)
    cross_gradient_norm: float = 0.0
    iterations: int = 0
    converged: bool = False


def joint_3d_invert(
    gravity_fwd: GravityForward,
    em_fwd: EMForward,
    seismic_fwd: SeismicTomographyForward,
    grid: Joint3DGrid,
    gravity_data: np.ndarray,
    em_data: np.ndarray,
    seismic_data: np.ndarray,
    initial_density: float = 0.0,
    initial_resistivity: float = 100.0,
    initial_slowness: float = 0.0005,
    w_gravity: float = 1.0,
    w_em: float = 1.0,
    w_seismic: float = 1.0,
    w_smooth: float = 1.0,
    w_cross: float = 1.0,
    max_iter: int = 10,
    bounds_density: tuple = (-1000.0, 1000.0),
    bounds_resistivity: tuple = (1.0, 10000.0),
    bounds_slowness: tuple = (1e-5, 1e-2),
    tol: float = 1e-6,
) -> Joint3DResult:
    """Joint 3-D inversion with cross-gradient coupling.

    Minimises the objective::

        Φ = w_g‖S_g ρ_d − d_g‖² + w_e‖S_e ρ_e − d_e‖² + w_s‖S_s s − d_s‖²
          + w_smooth (‖Lρ_d‖² + ‖Lρ_e‖² + ‖Ls‖²)
          + w_cross ‖τ(ρ_d, ρ_e)‖²

    via an alternating Gauss-Newton scheme: at each iteration each property
    model is updated by solving its own least-squares system (data +
    smoothness), then the cross-gradient is evaluated.  When a method
    weight is zero that method is skipped (decoupled / single-method
    mode).

    Parameters
    ----------
    *_fwd : forward-operator instances
    *_data : observed data arrays
    initial_* : homogeneous starting values
    w_* : weights for each method, smoothness, and cross-gradient
    bounds_* : clip bounds for each property
    max_iter : outer iterations
    tol : convergence tolerance on total misfit change

    Returns
    -------
    Joint3DResult
    """
    n = grid.n_cells
    Sg = gravity_fwd.sensitivity()
    Se = em_fwd.sensitivity()
    Ss = seismic_fwd.sensitivity()
    L = _smoothness_3d(grid)
    LtL = (L.T @ L).toarray()

    dg = np.asarray(gravity_data, float)
    de = np.asarray(em_data, float)
    ds = np.asarray(seismic_data, float)

    # data-error weighting (simple 5 % relative + floor)
    errg = 0.05 * np.abs(dg) + 1e-3
    erre = 0.05 * np.abs(de) + 0.1
    errs = 0.05 * np.abs(ds) + 1e-4
    Wg = np.diag(1.0 / errg)
    We = np.diag(1.0 / erre)
    Ws = np.diag(1.0 / errs)

    rho_d = np.full(n, initial_density, float)
    rho_e = np.full(n, initial_resistivity, float)
    slow = np.full(n, initial_slowness, float)

    prev_total = np.inf
    converged = False
    last_misfits = {}
    last_cgn = 0.0

    for it in range(max_iter):
        # --- gravity update (linear in density contrast) ---
        if w_gravity > 0 and Sg.shape[0] > 0:
            A = w_gravity * (Sg.T @ (Wg @ Sg)) + w_smooth * LtL + 1e-6 * np.eye(n)
            b = w_gravity * Sg.T @ (Wg @ dg)
            rho_d = np.clip(np.linalg.solve(A, b), *bounds_density)
        # --- EM update (log-resistivity linearised) ---
        if w_em > 0 and Se.shape[0] > 0:
            # work in log space
            m = np.log(np.clip(rho_e, *bounds_resistivity))
            d_pred = np.clip(Se @ np.exp(m), 1e-6, None)
            res = np.log(np.clip(de, 1e-6, None)) - np.log(d_pred)
            J = Se * np.exp(m)[None, :] / d_pred[:, None]
            A = w_em * (J.T @ (We @ J)) + w_smooth * LtL + 1e-6 * np.eye(n)
            b = w_em * J.T @ (We @ res) - w_smooth * LtL @ m
            dm = np.linalg.solve(A, b)
            m = m + dm
            rho_e = np.clip(np.exp(m), *bounds_resistivity)
        # --- seismic update (linear in slowness) ---
        if w_seismic > 0 and Ss.shape[0] > 0:
            A = w_seismic * (Ss.T @ (Ws @ Ss)) + w_smooth * LtL + 1e-6 * np.eye(n)
            b = w_seismic * Ss.T @ (Ws @ ds)
            slow = np.clip(np.linalg.solve(A, b), *bounds_slowness)

        # --- misfits ---
        mg = float(np.sqrt(np.mean((Sg @ rho_d - dg) ** 2))) if w_gravity > 0 and Sg.shape[0] > 0 else 0.0
        me = float(np.sqrt(np.mean((Se @ rho_e - de) ** 2))) if w_em > 0 and Se.shape[0] > 0 else 0.0
        ms = float(np.sqrt(np.mean((Ss @ slow - ds) ** 2))) if w_seismic > 0 and Ss.shape[0] > 0 else 0.0
        cgn = float(np.linalg.norm(cross_gradient_3d(grid, rho_d, rho_e)))
        total = w_gravity * mg + w_em * me + w_seismic * ms + w_cross * cgn
        last_misfits = {"gravity": mg, "em": me, "seismic": ms}
        last_cgn = cgn

        if abs(prev_total - total) < tol:
            converged = True
            break
        prev_total = total

    return Joint3DResult(
        density=rho_d,
        resistivity=rho_e,
        slowness=slow,
        misfits=last_misfits,
        cross_gradient_norm=last_cgn,
        iterations=it + 1,
        converged=converged,
    )
