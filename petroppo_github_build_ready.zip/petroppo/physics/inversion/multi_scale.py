"""
Multi-scale geophysical inversion (coarse-to-fine).

Implements the multi-scale (multi-resolution) inversion strategy widely
used in geophysical tomography (e.g. RES2DINV, Occam): the inverse problem
is first solved on a **coarse** grid where the sensitivity kernel averages
over many cells and the problem is well-posed, then the recovered model is
**prolongated** (interpolated) onto a **finer** grid and used as the
starting model for the next level.  This dramatically improves stability
and avoids local minima compared with inverting directly on the fine grid.

The forward operator used here is the sensitivity-footprint apparent
resistivity operator (same as :mod:`petroppo.processing.inversion`),
keeping the module dependency-light (numpy + scipy only).

References
----------
* Loke, M.H. & Barker, R.D. (1996), "Practical techniques for 3D
  resistivity surveys and data inversion", *Geophysical Prospecting*.
* Constable, S.C., Parker, R.L. & Constable, C.G. (1987), "Occam's
  inversion: a practical algorithm for generating smooth models from
  EM sounding data", *Geophysics* 52(3).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "MultiScaleGrid",
    "MultiScaleResult",
    "prolongate",
    "restrict",
    "multi_scale_invert",
    "single_scale_invert",
]


# --------------------------------------------------------------------------- #
# Grid
# --------------------------------------------------------------------------- #
@dataclass
class MultiScaleGrid:
    """A 2-D rectangular inversion grid (one level of the multi-scale pyramid).

    Attributes
    ----------
    x_min, x_max : float
        Horizontal extent (m).
    max_depth : float
        Vertical extent (m).
    n_x, n_z : int
        Number of cells in x and z.
    """

    x_min: float
    x_max: float
    max_depth: float
    n_x: int = 20
    n_z: int = 10

    @property
    def dx(self) -> float:
        return (self.x_max - self.x_min) / self.n_x

    @property
    def dz(self) -> float:
        return self.max_depth / self.n_z

    @property
    def xc(self) -> np.ndarray:
        return self.x_min + (np.arange(self.n_x) + 0.5) * self.dx

    @property
    def zc(self) -> np.ndarray:
        return (np.arange(self.n_z) + 0.5) * self.dz

    @property
    def n_cells(self) -> int:
        return self.n_x * self.n_z

    def cell_index(self, ix: int, iz: int) -> int:
        return ix * self.n_z + iz

    def model_to_2d(self, m: np.ndarray) -> np.ndarray:
        return m.reshape(self.n_x, self.n_z)

    def model_from_2d(self, m2d: np.ndarray) -> np.ndarray:
        return m2d.flatten()


# --------------------------------------------------------------------------- #
# Prolongation / restriction (grid transfer operators)
# --------------------------------------------------------------------------- #
def prolongate(m_coarse: np.ndarray, coarse: MultiScaleGrid,
               fine: MultiScaleGrid) -> np.ndarray:
    """Prolongate a coarse model onto a fine grid by nearest-neighbour +
    bilinear interpolation of the *log-resistivity*.

    Parameters
    ----------
    m_coarse : np.ndarray, shape (coarse.n_cells,)
        Coarse model (physical or log — interpolation is linear either way).
    coarse, fine : MultiScaleGrid

    Returns
    -------
    m_fine : np.ndarray, shape (fine.n_cells,)
    """
    m2d = coarse.model_to_2d(np.asarray(m_coarse, float))
    # bilinear interpolation from coarse cell centres to fine cell centres
    xc_c = coarse.xc
    zc_c = coarse.zc
    xc_f = fine.xc
    zc_f = fine.zc
    out = np.zeros((fine.n_x, fine.n_z))
    for ix in range(fine.n_x):
        x = xc_f[ix]
        # find coarse i-bucket
        if x <= xc_c[0]:
            i0 = 0; i1 = 0; tx = 0.0
        elif x >= xc_c[-1]:
            i0 = coarse.n_x - 1; i1 = i0; tx = 0.0
        else:
            i0 = int(np.searchsorted(xc_c, x) - 1)
            i1 = i0 + 1
            tx = (x - xc_c[i0]) / (xc_c[i1] - xc_c[i0])
        for iz in range(fine.n_z):
            z = zc_f[iz]
            if z <= zc_c[0]:
                k0 = 0; k1 = 0; tz = 0.0
            elif z >= zc_c[-1]:
                k0 = coarse.n_z - 1; k1 = k0; tz = 0.0
            else:
                k0 = int(np.searchsorted(zc_c, z) - 1)
                k1 = k0 + 1
                tz = (z - zc_c[k0]) / (zc_c[k1] - zc_c[k0])
            v00 = m2d[i0, k0]; v01 = m2d[i0, k1]
            v10 = m2d[i1, k0]; v11 = m2d[i1, k1]
            out[ix, iz] = ((1 - tx) * (1 - tz) * v00
                           + (1 - tx) * tz * v01
                           + tx * (1 - tz) * v10
                           + tx * tz * v11)
    return out.flatten()


def restrict(m_fine: np.ndarray, fine: MultiScaleGrid,
             coarse: MultiScaleGrid) -> np.ndarray:
    """Restrict a fine model onto a coarse grid by cell averaging."""
    m2d = fine.model_to_2d(np.asarray(m_fine, float))
    out = np.zeros((coarse.n_x, coarse.n_z))
    # for each coarse cell, average the fine cells whose centres fall inside
    for ix in range(coarse.n_x):
        x0 = coarse.x_min + ix * coarse.dx
        x1 = x0 + coarse.dx
        for iz in range(coarse.n_z):
            z0 = iz * coarse.dz
            z1 = z0 + coarse.dz
            mask_x = (fine.xc >= x0) & (fine.xc < x1)
            mask_z = (fine.zc >= z0) & (fine.zc < z1)
            block = m2d[np.ix_(mask_x, mask_z)]
            if block.size > 0:
                out[ix, iz] = block.mean()
            else:
                # nearest
                ix_f = np.argmin(np.abs(fine.xc - (x0 + x1) / 2))
                iz_f = np.argmin(np.abs(fine.zc - (z0 + z1) / 2))
                out[ix, iz] = m2d[ix_f, iz_f]
    return out.flatten()


# --------------------------------------------------------------------------- #
# Forward + sensitivity (footprint model)
# --------------------------------------------------------------------------- #
def _footprint_weights(grid: MultiScaleGrid, x_mid: float,
                       a_eff: float, depth: float) -> np.ndarray:
    sigma_x = max(a_eff, grid.dx)
    sigma_z = max(a_eff / 2.0, grid.dz)
    w = np.zeros(grid.n_cells)
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            dx = grid.xc[ix] - x_mid
            dz = grid.zc[iz] - depth
            w[grid.cell_index(ix, iz)] = (
                np.exp(-0.5 * (dx / sigma_x) ** 2)
                * np.exp(-0.5 * (dz / sigma_z) ** 2)
            )
    s = w.sum()
    if s > 0:
        w /= s
    return w


def _forward(grid: MultiScaleGrid, m_phys: np.ndarray,
             readings: list[dict]) -> np.ndarray:
    pred = np.zeros(len(readings))
    for i, r in enumerate(readings):
        w = _footprint_weights(grid, r["x_mid"], r["a"], r["depth"])
        pred[i] = np.dot(w, m_phys)
    return pred


def _jacobian(grid: MultiScaleGrid, m_phys: np.ndarray,
              readings: list[dict]) -> np.ndarray:
    J = np.zeros((len(readings), grid.n_cells))
    for i, r in enumerate(readings):
        w = _footprint_weights(grid, r["x_mid"], r["a"], r["depth"])
        J[i, :] = w * m_phys
    rs = J.sum(axis=1, keepdims=True)
    rs[rs == 0] = 1.0
    J /= rs
    return J


def _smoothness(grid: MultiScaleGrid) -> np.ndarray:
    n = grid.n_cells
    R = np.zeros((n, n))
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            if ix + 1 < grid.n_x:
                ir = grid.cell_index(ix + 1, iz)
                R[idx, idx] += 1; R[ir, ir] += 1
                R[idx, ir] -= 1; R[ir, idx] -= 1
            if iz + 1 < grid.n_z:
                idn = grid.cell_index(ix, iz + 1)
                R[idx, idx] += 1; R[idn, idn] += 1
                R[idx, idn] -= 1; R[idn, idx] -= 1
    return R


# --------------------------------------------------------------------------- #
# Single-level Gauss-Newton invert (used at each scale)
# --------------------------------------------------------------------------- #
def single_scale_invert(
    readings: list[dict],
    grid: MultiScaleGrid,
    initial_model: np.ndarray,
    max_iter: int = 12,
    lambda_reg: float = 5.0,
    lambda_decay: float = 0.8,
    bounds: tuple[float, float] = (1.0, 10000.0),
) -> tuple[np.ndarray, list[float]]:
    """Run Gauss-Newton inversion on a single grid.

    Parameters
    ----------
    readings : list of dict with keys 'x_mid', 'a', 'rho_a', 'depth'
    grid : MultiScaleGrid
    initial_model : np.ndarray, shape (grid.n_cells,)
        Starting model in **physical** units (ohm.m).  Converted to log
        internally.

    Returns
    -------
    model_phys, rmse_history : (np.ndarray, list[float])
        Final model in physical units and the per-iteration RMSE.
    """
    d_obs = np.array([r["rho_a"] for r in readings])
    d_log = np.log(np.clip(d_obs, 1e-6, None))
    m = np.log(np.clip(initial_model, bounds[0], bounds[1]))
    m0 = m.copy()
    err = 0.02 * d_obs + 0.1
    Wd = np.diag(1.0 / err)
    R = _smoothness(grid)
    rmse_hist = []
    lam = lambda_reg
    best_m = m.copy()
    best_rmse = np.inf
    for _ in range(max_iter):
        m_phys = np.exp(m)
        d_pred = np.clip(_forward(grid, m_phys, readings), 1e-3, None)
        d_pred_log = np.log(d_pred)
        residual = d_log - d_pred_log
        rmse = float(np.sqrt(np.mean(residual ** 2)))
        rmse_hist.append(rmse)
        if rmse < best_rmse:
            best_rmse = rmse
            best_m = m.copy()
        # Jacobian of log-data w.r.t. log-model:  d ln ρ_a / d ln m
        #   = (w_i * m_i) / (Σ w m)  (normalised footprint × model)
        J_raw = _jacobian(grid, m_phys, readings)
        J = J_raw / np.clip(d_pred_log[:, None], 1e-6, None)
        J = np.nan_to_num(J, nan=0.0, posinf=0.0, neginf=0.0)
        JtWJ = J.T @ (Wd @ J)
        JtWr = J.T @ (Wd @ residual)
        A = JtWJ + lam * R + 1e-6 * np.eye(grid.n_cells)
        b = JtWr - lam * R @ (m - m0)
        try:
            dm = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            dm = np.linalg.lstsq(A, b, rcond=None)[0]
        # step-length limiter: cap |dm| to avoid exp overflow
        max_step = 2.0  # max log-unit change per iteration
        norm_dm = np.max(np.abs(dm))
        if norm_dm > max_step:
            dm = dm * (max_step / norm_dm)
        m = m + dm
        m = np.clip(m, np.log(bounds[0]), np.log(bounds[1]))
        lam *= lambda_decay
    # if we diverged, return the best model found
    if not np.isfinite(rmse_hist[-1]) or rmse_hist[-1] > best_rmse * 2:
        m = best_m
    return np.exp(m), rmse_hist


# --------------------------------------------------------------------------- #
# Result container
# --------------------------------------------------------------------------- #
@dataclass
class MultiScaleResult:
    """Outcome of a multi-scale inversion.

    Attributes
    ----------
    final_model : np.ndarray
        Recovered model on the finest grid (physical units).
    models : list of np.ndarray
        Model recovered at each level (finest last).
    misfits : list of float
        Final RMSE at each level.
    grids : list of MultiScaleGrid
        The grid at each level.
    """

    final_model: np.ndarray
    models: list = field(default_factory=list)
    misfits: list = field(default_factory=list)
    grids: list = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Multi-scale driver
# --------------------------------------------------------------------------- #
def multi_scale_invert(
    readings: list[dict],
    finest_grid: MultiScaleGrid,
    levels: int = 3,
    initial_resistivity: float = 100.0,
    max_iter_per_level: int = 12,
    lambda_reg: float = 5.0,
    bounds: tuple[float, float] = (1.0, 10000.0),
) -> MultiScaleResult:
    """Coarse-to-fine multi-scale inversion.

    Builds a pyramid of ``levels`` grids by halving the cell count each
    level (coarsest first), inverts on the coarsest grid, prolongates the
    result to the next-finer grid as the starting model, and repeats.

    Parameters
    ----------
    readings : list of dict
        ERT readings with keys 'x_mid', 'a', 'rho_a', 'depth'.
    finest_grid : MultiScaleGrid
        The target (finest) grid.
    levels : int
        Number of pyramid levels (≥ 1).  Level 1 = finest only.
    initial_resistivity : float
        Homogeneous starting resistivity for the coarsest level.

    Returns
    -------
    MultiScaleResult
    """
    if levels < 1:
        raise ValueError("levels must be >= 1")
    # build pyramid: coarsest = grids[0], finest = grids[-1]
    grids = []
    for lev in range(levels):
        factor = 2 ** (levels - 1 - lev)
        nx = max(finest_grid.n_x // factor, 2)
        nz = max(finest_grid.n_z // factor, 2)
        grids.append(MultiScaleGrid(
            x_min=finest_grid.x_min, x_max=finest_grid.x_max,
            max_depth=finest_grid.max_depth, n_x=nx, n_z=nz,
        ))
    models, misfits = [], []
    m_init = np.full(grids[0].n_cells, initial_resistivity)
    for lev, g in enumerate(grids):
        m_phys, rmse = single_scale_invert(
            readings, g, m_init,
            max_iter=max_iter_per_level, lambda_reg=lambda_reg,
            bounds=bounds,
        )
        models.append(m_phys)
        misfits.append(rmse[-1] if rmse else 0.0)
        if lev < len(grids) - 1:
            m_init = prolongate(m_phys, g, grids[lev + 1])
    return MultiScaleResult(
        final_model=models[-1],
        models=models,
        misfits=misfits,
        grids=grids,
    )
