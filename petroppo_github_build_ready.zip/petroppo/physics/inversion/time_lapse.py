"""
4-D time-lapse (monitoring) inversion with temporal regularisation.

Time-lapse geophysical monitoring acquires the same survey at multiple
epochs (e.g. baseline before CO₂ injection / waterflood and one or more
monitor surveys afterwards) to detect changes in the subsurface caused
by fluid movement.  Inverting each epoch independently produces
 artefacts that look like "4-D anomalies" but are really acquisition /
processing noise.  The standard remedy (e.g. simultaneous time-lapse
inversion, Hayley et al. 2011; Kim et al. 2014) inverts **all epochs
together** with a temporal regularisation term that penalises the
difference between consecutive models, so that only **genuine** changes
survive.

This module provides:

* :func:`time_lapse_invert` — simultaneous inversion of baseline + monitor
  surveys with a temporal smoothness term  ‖m_mon − m_base‖² .
* :func:`detect_4d_anomaly` — threshold the 4-D difference model
  (monitor − baseline) to flag cells where a genuine change occurred.
* :class:`TimeLapseResult` — container holding the baseline, monitor and
  difference models plus per-epoch misfits.

The forward operator is the same Gaussian-footprint apparent-resistivity
operator used in :mod:`petroppo.processing.inversion` and
:mod:`petroppo.physics.inversion.multi_scale`, keeping the module
dependency-light (numpy + scipy only).

References
----------
* Hayley, K., Pidlisecky, A. & Oldenburg, D.W. (2011), "Three-dimensional
  inversion of time-lapse gravity monitoring data", *Journal of Applied
  Geophysics* 74(1).
* Kim, J.H., Yi, M.J., Cho, S.J., Son, M. & Song, W.J. (2014),
  "Time-lapse inversion of 4-D DC resistivity monitoring data for
  anomaly detection", *Journal of Applied Geophysics* 116.
* Loke, M.H., Dahlin, T., Rucker, D.F., Chambers, J.E. & Wilkinson, P.B.
  (2014), "4-D resistivity inversion and synthetic modelling", in *NSG
  EAGE Workshop on Permanent Reservoir Monitoring 2011*.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "TimeLapseResult",
    "time_lapse_invert",
    "detect_4d_anomaly",
]


# --------------------------------------------------------------------------- #
# Lightweight 2-D grid (shared structure with multi_scale.MultiScaleGrid)
# --------------------------------------------------------------------------- #
class _Grid2D:
    """Minimal 2-D rectangular grid for the time-lapse forward operator.

    Kept self-contained so the module has no inter-module import coupling.
    """

    def __init__(self, x_min, x_max, max_depth, n_x, n_z):
        self.x_min = float(x_min)
        self.x_max = float(x_max)
        self.max_depth = float(max_depth)
        self.n_x = int(n_x)
        self.n_z = int(n_z)

    @property
    def dx(self):
        return (self.x_max - self.x_min) / self.n_x

    @property
    def dz(self):
        return self.max_depth / self.n_z

    @property
    def xc(self):
        return self.x_min + (np.arange(self.n_x) + 0.5) * self.dx

    @property
    def zc(self):
        return (np.arange(self.n_z) + 0.5) * self.dz

    @property
    def n_cells(self):
        return self.n_x * self.n_z

    def cell_index(self, ix, iz):
        return ix * self.n_z + iz


# --------------------------------------------------------------------------- #
# Forward + sensitivity (footprint apparent-resistivity, shared kernel)
# --------------------------------------------------------------------------- #
def _footprint_weights(grid, x_mid, a_eff, depth):
    sigma_x = max(a_eff, grid.dx)
    sigma_z = max(a_eff / 2.0, grid.dz)
    w = np.zeros(grid.n_cells)
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            dx = grid.xc[ix] - x_mid
            dz = grid.zc[iz] - depth
            w[grid.cell_index(ix, iz)] = (
                np.exp(-0.5 * (dx / sigma_x) ** 2)
                * np.exp(-0.5 * (dz / sigma_z) ** 2)
            )
    s = w.sum()
    if s > 0:
        w /= s
    return w


def _forward(grid, m_phys, readings):
    pred = np.zeros(len(readings))
    for i, r in enumerate(readings):
        w = _footprint_weights(grid, r["x_mid"], r["a"], r["depth"])
        pred[i] = np.dot(w, m_phys)
    return pred


def _jacobian(grid, m_phys, readings):
    J = np.zeros((len(readings), grid.n_cells))
    for i, r in enumerate(readings):
        w = _footprint_weights(grid, r["x_mid"], r["a"], r["depth"])
        J[i, :] = w * m_phys
    rs = J.sum(axis=1, keepdims=True)
    rs[rs == 0] = 1.0
    J /= rs
    return J


def _smoothness(grid):
    n = grid.n_cells
    R = np.zeros((n, n))
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            if ix + 1 < grid.n_x:
                ir = grid.cell_index(ix + 1, iz)
                R[idx, idx] += 1; R[ir, ir] += 1
                R[idx, ir] -= 1; R[ir, idx] -= 1
            if iz + 1 < grid.n_z:
                idn = grid.cell_index(ix, iz + 1)
                R[idx, idx] += 1; R[idn, idn] += 1
                R[idx, idn] -= 1; R[idn, idx] -= 1
    return R


# --------------------------------------------------------------------------- #
# Result container
# --------------------------------------------------------------------------- #
@dataclass
class TimeLapseResult:
    """Outcome of a time-lapse (4-D) inversion.

    Attributes
    ----------
    baseline_model : np.ndarray
        Recovered model at the baseline epoch (physical units).
    monitor_model : np.ndarray
        Recovered model at the monitor epoch (physical units).
    difference_model : np.ndarray
        ``monitor_model - baseline_model`` (the 4-D change).
    baseline_misfit : float
        Final RMS log-misfit at baseline.
    monitor_misfit : float
        Final RMS log-misfit at monitor.
    iterations : int
    converged : bool
    """

    baseline_model: np.ndarray
    monitor_model: np.ndarray
    difference_model: np.ndarray = field(default_factory=lambda: np.empty(0))
    baseline_misfit: float = 0.0
    monitor_misfit: float = 0.0
    iterations: int = 0
    converged: bool = False


# --------------------------------------------------------------------------- #
# Simultaneous time-lapse inversion
# --------------------------------------------------------------------------- #
def time_lapse_invert(
    baseline_readings: list,
    monitor_readings: list,
    grid,
    initial_resistivity: float = 100.0,
    max_iter: int = 15,
    lambda_spatial: float = 5.0,
    lambda_temporal: float = 10.0,
    bounds: tuple = (1.0, 10000.0),
    tol: float = 1e-7,
) -> TimeLapseResult:
    """Simultaneous time-lapse inversion of baseline + monitor surveys.

    Inverts both epochs jointly in **log-resistivity** space minimising::

        Φ = ‖W_d (ln d_base − ln F(m_base))‖²
          + ‖W_d (ln d_mon  − ln F(m_mon ))‖²
          + λ_spatial (‖L m_base‖² + ‖L m_mon‖²)
          + λ_temporal ‖m_mon − m_base‖²

    The temporal term forces the monitor model to stay close to the
    baseline **except** where the data require a change, which suppresses
    spurious 4-D artefacts and isolates genuine anomalies.

    Parameters
    ----------
    baseline_readings, monitor_readings : list of dict
        ERT readings (keys 'x_mid', 'a', 'rho_a', 'depth') per epoch.
    grid : _Grid2D or MultiScaleGrid-like
        2-D inversion grid with n_x, n_z, xc, zc, cell_index, n_cells.
    initial_resistivity : float
        Homogeneous starting resistivity.
    max_iter : int
        Gauss-Newton iterations.
    lambda_spatial : float
        Spatial smoothness weight.
    lambda_temporal : float
        Temporal coupling weight (higher ⇒ monitor stays closer to
        baseline ⇒ fewer spurious 4-D changes).
    bounds : tuple
        Resistivity clip bounds.
    tol : float
        Convergence tolerance on total objective change.

    Returns
    -------
    TimeLapseResult
    """
    n = grid.n_cells
    L = _smoothness(grid)
    LtL = L.T @ L
    I = np.eye(n)

    db = np.array([r["rho_a"] for r in baseline_readings])
    dm_obs = np.array([r["rho_a"] for r in monitor_readings])
    dlb = np.log(np.clip(db, 1e-6, None))
    dlm = np.log(np.clip(dm_obs, 1e-6, None))

    errb = 0.05 * db + 0.1
    errm = 0.05 * dm_obs + 0.1
    Wb = np.diag(1.0 / errb)
    Wm = np.diag(1.0 / errm)

    m_base = np.full(n, np.log(initial_resistivity))
    m_mon = m_base.copy()
    m_base0 = m_base.copy()  # reference for spatial smoothness

    prev_obj = np.inf
    converged = False
    it = 0
    mb_misfit = 0.0
    mn_misfit = 0.0

    for it in range(max_iter):
        # --- baseline update (treat m_mon as fixed for the temporal term) ---
        pb = np.clip(_forward(grid, np.exp(m_base), baseline_readings), 1e-6, None)
        lpb = np.log(pb)
        resb = dlb - lpb
        Jb = _jacobian(grid, np.exp(m_base), baseline_readings) / lpb[:, None]
        Ab = (Jb.T @ (Wb @ Jb)
              + lambda_spatial * LtL
              + lambda_temporal * I
              + 1e-6 * I)
        bb = (Jb.T @ (Wb @ resb)
              - lambda_spatial * LtL @ (m_base - m_base0)
              + lambda_temporal * (m_mon - m_base))
        m_base = m_base + np.linalg.solve(Ab, bb)
        m_base = np.clip(m_base, np.log(bounds[0]), np.log(bounds[1]))

        # --- monitor update (treat m_base as fixed) ---
        pm = np.clip(_forward(grid, np.exp(m_mon), monitor_readings), 1e-6, None)
        lpm = np.log(pm)
        resm = dlm - lpm
        Jm = _jacobian(grid, np.exp(m_mon), monitor_readings) / lpm[:, None]
        Am = (Jm.T @ (Wm @ Jm)
              + lambda_spatial * LtL
              + lambda_temporal * I
              + 1e-6 * I)
        bm = (Jm.T @ (Wm @ resm)
              - lambda_spatial * LtL @ (m_mon - m_base0)
              + lambda_temporal * (m_base - m_mon))
        m_mon = m_mon + np.linalg.solve(Am, bm)
        m_mon = np.clip(m_mon, np.log(bounds[0]), np.log(bounds[1]))

        mb_misfit = float(np.sqrt(np.mean(resb ** 2)))
        mn_misfit = float(np.sqrt(np.mean(resm ** 2)))
        obj = (np.sum((Wb @ resb) ** 2) + np.sum((Wm @ resm) ** 2)
               + lambda_spatial * (m_base - m_base0) @ LtL @ (m_base - m_base0)
               + lambda_spatial * (m_mon - m_base0) @ LtL @ (m_mon - m_base0)
               + lambda_temporal * np.sum((m_mon - m_base) ** 2))
        if abs(prev_obj - obj) < tol:
            converged = True
            break
        prev_obj = obj

    rb = np.exp(m_base)
    rm = np.exp(m_mon)
    diff = rm - rb
    return TimeLapseResult(
        baseline_model=rb,
        monitor_model=rm,
        difference_model=diff,
        baseline_misfit=mb_misfit,
        monitor_misfit=mn_misfit,
        iterations=it + 1,
        converged=converged,
    )


# --------------------------------------------------------------------------- #
# 4-D anomaly detection
# --------------------------------------------------------------------------- #
@dataclass
class Anomaly4D:
    """Detected 4-D anomaly summary.

    Attributes
    ----------
    n_anomalies : int
        Number of flagged cells.
    anomaly_fraction : float
        Fraction of total cells flagged.
    max_change : float
        Largest magnitude change in the difference model (physical units).
    indices : np.ndarray
        Indices of flagged cells.
    threshold : float
        Threshold used.
    """

    n_anomalies: int
    anomaly_fraction: float
    max_change: float
    indices: np.ndarray
    threshold: float


def detect_4d_anomaly(
    difference_model: np.ndarray,
    baseline_model: np.ndarray,
    threshold: float = 0.1,
) -> Anomaly4D:
    """Detect 4-D anomalies from a difference model.

    Flags cells where the **relative** change exceeds ``threshold``::

        |Δm| / |m_base|  >  threshold

    This is robust to the absolute resistivity level and highlights
    genuine fluid-induced changes.

    Parameters
    ----------
    difference_model : np.ndarray
        ``monitor − baseline`` model (physical units).
    baseline_model : np.ndarray
        Baseline model (physical units, same shape).
    threshold : float
        Relative-change threshold (e.g. 0.1 = 10 %).

    Returns
    -------
    Anomaly4D
    """
    diff = np.asarray(difference_model, float)
    base = np.asarray(baseline_model, float)
    rel = np.abs(diff) / np.clip(np.abs(base), 1e-9, None)
    flagged = rel > threshold
    return Anomaly4D(
        n_anomalies=int(flagged.sum()),
        anomaly_fraction=float(flagged.mean()),
        max_change=float(np.max(np.abs(diff))) if diff.size else 0.0,
        indices=np.where(flagged)[0],
        threshold=threshold,
    )
