"""petroppo V20 — Jacobian computation strategies.

Provides three strategies for computing dF/dm and an *agreement test* that
compares a claimed-analytic (or adjoint) Jacobian against a finite-difference
reference.  This directly closes V19 gap G3/G6 (ERT Jacobian was an
unvalidated FD-on-coarse-grid + primary-field approximation).

Strategies
----------
* :class:`FiniteDifference` — central differences with configurable step.
* :class:`Adjoint` — wraps a user-provided adjoint function (for large-scale
  problems where full FD is too expensive).
* :func:`jacobian_agreement` — computes the relative error between a
  "candidate" Jacobian (analytic or adjoint) and an FD reference, returns
  (max_rel_err, passed) where passed = max_rel_err < tol (default 1e-4).

The agreement test is the V20 Gate criterion G6: no Jacobian is trusted
unless it agrees with FD to the specified tolerance.
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple

import numpy as np

from .forward import ForwardModel


class FiniteDifference:
    """Central finite-difference Jacobian.

    J[:, j] = (F(m + eps * e_j) - F(m - eps * e_j)) / (2 * eps)
    """

    def __init__(self, forward: ForwardModel, eps: float = 1e-6,
                 relative_step: bool = True):
        self.forward = forward
        self.eps = eps
        self.relative_step = relative_step

    def __call__(self, model: np.ndarray) -> np.ndarray:
        m = np.asarray(model, dtype=float)
        n_p = self.forward.n_params
        n_d = self.forward.n_data
        J = np.zeros((n_d, n_p))
        f0 = self.forward.predict(m)
        for j in range(n_p):
            step = self.eps * (abs(m[j]) + 1.0) if self.relative_step else self.eps
            mp = m.copy()
            mm = m.copy()
            mp[j] += step
            mm[j] -= step
            fp = self.forward.predict(mp)
            fm = self.forward.predict(mm)
            J[:, j] = (fp - fm) / (2.0 * step)
        return J


class Adjoint:
    """Adjoint-based Jacobian-vector product (or full Jacobian via columns).

    For problems where the full Jacobian is too large to form, the adjoint
    provides J^T * v efficiently.  Here we expose a callable that either
    returns the full J or a J^T-product function.
    """

    def __init__(self, forward: ForwardModel,
                 adjoint_fn: Callable[[np.ndarray, np.ndarray], np.ndarray]):
        self.forward = forward
        self.adjoint_fn = adjoint_fn

    def __call__(self, model: np.ndarray) -> np.ndarray:
        """Build full Jacobian by applying adjoint to each basis vector."""
        m = np.asarray(model, dtype=float)
        n_p = self.forward.n_params
        n_d = self.forward.n_data
        J = np.zeros((n_d, n_p))
        for j in range(n_p):
            e_j = np.zeros(n_p)
            e_j[j] = 1.0
            # adjoint_fn should return J[:, j] (a column) given (model, e_j)
            col = self.adjoint_fn(m, e_j)
            J[:, j] = np.asarray(col, dtype=float)
        return J


def jacobian_agreement(forward: ForwardModel, model: np.ndarray,
                       candidate_jac: np.ndarray,
                       eps: float = 1e-6,
                       tol: float = 1e-4) -> Tuple[float, bool]:
    """Compare a candidate Jacobian against a finite-difference reference.

    Parameters
    ----------
    forward : ForwardModel
    model : np.ndarray
        Point at which to evaluate.
    candidate_jac : np.ndarray, shape (n_data, n_params)
        The Jacobian to validate (analytic or adjoint).
    eps : float
        FD step size.
    tol : float
        Maximum acceptable relative error per entry.

    Returns
    -------
    (max_rel_err, passed) : (float, bool)
        ``passed`` is True iff max_rel_err < tol — this is V20 Gate G6.
    """
    fd = FiniteDifference(forward, eps=eps)
    J_ref = fd(model)
    J_cand = np.asarray(candidate_jac, dtype=float)
    if J_cand.shape != J_ref.shape:
        raise ValueError(
            f"Jacobian shape mismatch: candidate {J_cand.shape} vs FD {J_ref.shape}")
    # Relative error per entry, guarding against division by zero
    denom = np.maximum(np.abs(J_ref), 1e-12)
    rel_err = np.abs(J_cand - J_ref) / denom
    max_rel_err = float(np.nanmax(rel_err))
    return max_rel_err, bool(max_rel_err < tol)
