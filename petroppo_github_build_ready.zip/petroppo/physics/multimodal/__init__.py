"""petroppo V35 -- Multimodal joint-inversion package.

``petroppo.physics.multimodal`` provides cross-gradient coupled joint
inversion of multiple geophysical methods (seismic, gravity, magnetic,
electromagnetic) sharing a common earth model, as well as petrophysical
constraint links (Gardner density-velocity, Faust resistivity-velocity).
"""
from __future__ import annotations

__all__: list = []

try:
    from . import joint_inversion  # noqa: F401
    __all__.append("joint_inversion")
except Exception:  # pragma: no cover
    pass
