"""petroppo V20 — Optimization strategies for inverse problems.

Implements iterative optimizers that minimise:

    Φ(m) = ½ ||W^(1/2)(d_obs - F(m))||²  +  R(m)

Each optimizer follows a uniform interface:

* ``optimize(forward, observed, reg, initial_model, ...) -> (model, ConvergenceDiag)``

Optimizers
----------
* :class:`GaussNewton` — full-step GN with damping, LU factorisation reuse.
* :class:`LevenbergMarquardt` — adaptive damping (trust-region-ish).
* :class:`Occam` — fixed-regularization Gauss-Newton with cooling schedule
  (Constable et al. style — decrease alpha when data misfit is below target).
* :class:`IRLS` — outer IRLS loop for L1/Huber regularization (calls an inner
  L2 optimizer with reweighted matrices).

This refactors V19's v8_inversion.py into a reusable, testable component.
The V19 version hardcoded everything in one 640-LoC function; here the
Gauss-Newton core is ~80 lines and the rest is composable regularization.
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple

import numpy as np
from scipy.linalg import lu_factor, lu_solve

from .forward import ForwardModel
from .regularization import RegularizationOperator, L1, Huber
from .convergence import ConvergenceDiag
from .jacobian import FiniteDifference


class Optimizer:
    """Base optimizer interface."""
    name = "Optimizer"

    def __init__(self, jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6):
        self.jacobian_strategy = jacobian_strategy
        self.eps = eps

    def _get_jacobian(self, forward: ForwardModel, model: np.ndarray) -> np.ndarray:
        if self.jacobian_strategy is not None:
            return self.jacobian_strategy(model)
        try:
            return forward.jacobian(model)
        except NotImplementedError:
            return FiniteDifference(forward, eps=self.eps)(model)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 20, tolerance: float = 1e-4
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        raise NotImplementedError


# ──────────────────────────────────────────────────────────────────────────────
# Gauss-Newton
# ──────────────────────────────────────────────────────────────────────────────
class GaussNewton(Optimizer):
    """Damped Gauss-Newton: solve (J^T W J + R'') Δm = J^T W r - R'.

    At each iteration:
      1. Compute J = dF/dm (analytic if available, else FD).
      2. Compute residual r = d_obs - F(m).
      3. Solve the GN normal equations with regularization Hessian.
      4. Line search (backtracking) to ensure objective decrease.
    """

    name = "GaussNewton"

    def __init__(self, jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6, damping: float = 1e-3,
                 line_search: bool = True):
        super().__init__(jacobian_strategy, eps)
        self.damping = damping
        self.line_search = line_search

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 20, tolerance: float = 1e-4
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        m = np.asarray(initial_model, dtype=float).copy()
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)
        for it in range(max_iter):
            J = self._get_jacobian(forward, m)
            pred = forward.predict(m)
            r = observed - pred
            JtWJ = J.T @ (W[:, None] * J)
            JtWr = J.T @ (W * r)
            R_hess = reg.hessian(m)
            R_grad = reg.gradient(m)
            A = JtWJ + R_hess + self.damping * np.eye(forward.n_params)
            b = JtWr - R_grad
            lu_piv = lu_factor(A)
            dm = lu_solve(lu_piv, b)
            # Line search
            alpha = 1.0
            if self.line_search:
                f0 = 0.5 * np.dot(W * r, r) + reg.value(m)
                for _ in range(20):
                    m_try = m + alpha * dm
                    r_try = observed - forward.predict(m_try)
                    f_try = 0.5 * np.dot(W * r_try, r_try) + reg.value(m_try)
                    if f_try < f0:
                        break
                    alpha *= 0.5
            m = m + alpha * dm
            # Diagnostics
            pred_new = forward.predict(m)
            r_new = observed - pred_new
            data_misfit = 0.5 * np.dot(W * r_new, r_new)
            reg_val = reg.value(m)
            total = data_misfit + reg_val
            grad_norm = float(np.linalg.norm(JtWr - R_grad))
            step_norm = float(np.linalg.norm(alpha * dm))
            diag.append(
                data_misfit=data_misfit, reg_term=reg_val,
                total_objective=total, grad_norm=grad_norm,
                step_norm=step_norm, param_rms=float(np.sqrt(np.mean(m ** 2))),
                label=f"GN-{it}",
            )
            if step_norm < tolerance:
                break
        return m, diag


# ──────────────────────────────────────────────────────────────────────────────
# Levenberg-Marquardt
# ──────────────────────────────────────────────────────────────────────────────
class LevenbergMarquardt(Optimizer):
    """Levenberg-Marquardt with adaptive lambda (trust region).

    If a step reduces the objective → accept, decrease lambda.
    If it increases → reject, increase lambda, retry.
    """

    name = "LevenbergMarquardt"

    def __init__(self, jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6, lambda_init: float = 1e-2,
                 lambda_up: float = 10.0, lambda_down: float = 0.1,
                 max_sub_iter: int = 10):
        super().__init__(jacobian_strategy, eps)
        self.lambda_ = lambda_init
        self.lambda_up = lambda_up
        self.lambda_down = lambda_down
        self.max_sub_iter = max_sub_iter

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 30, tolerance: float = 1e-4
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        m = np.asarray(initial_model, dtype=float).copy()
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)
        lam = self.lambda_
        for it in range(max_iter):
            J = self._get_jacobian(forward, m)
            pred = forward.predict(m)
            r = observed - pred
            f0 = 0.5 * np.dot(W * r, r) + reg.value(m)
            JtWJ = J.T @ (W[:, None] * J)
            JtWr = J.T @ (W * r)
            R_hess = reg.hessian(m)
            R_grad = reg.gradient(m)
            accepted = False
            for _ in range(self.max_sub_iter):
                A = JtWJ + R_hess + lam * np.diag(np.diag(JtWJ + R_hess) + 1e-12)
                b = JtWr - R_grad
                try:
                    dm = np.linalg.solve(A, b)
                except np.linalg.LinAlgError:
                    lam *= self.lambda_up
                    continue
                m_try = m + dm
                r_try = observed - forward.predict(m_try)
                f_try = 0.5 * np.dot(W * r_try, r_try) + reg.value(m_try)
                if f_try < f0:
                    m = m_try
                    lam *= self.lambda_down
                    accepted = True
                    break
                else:
                    lam *= self.lambda_up
            if not accepted:
                # Stuck — record and break
                diag.append(data_misfit=f0, reg_term=reg.value(m),
                            total_objective=f0, grad_norm=float(np.linalg.norm(JtWr - R_grad)),
                            step_norm=0.0, param_rms=float(np.sqrt(np.mean(m ** 2))),
                            label=f"LM-{it}-stuck")
                break
            r_new = observed - forward.predict(m)
            data_misfit = 0.5 * np.dot(W * r_new, r_new)
            reg_val = reg.value(m)
            total = data_misfit + reg_val
            step_norm = float(np.linalg.norm(dm))
            grad_norm = float(np.linalg.norm(JtWr - R_grad))
            diag.append(data_misfit=data_misfit, reg_term=reg_val,
                        total_objective=total, grad_norm=grad_norm,
                        step_norm=step_norm, param_rms=float(np.sqrt(np.mean(m ** 2))),
                        label=f"LM-{it}")
            if step_norm < tolerance:
                break
        return m, diag


# ──────────────────────────────────────────────────────────────────────────────
# Occam (regularization cooling)
# ──────────────────────────────────────────────────────────────────────────────
class Occam(Optimizer):
    """Occam-style inversion: cool the regularization weight until data misfit
    reaches the target chi-square, then keep the smoothest model that fits.

    This wraps GaussNewton and reduces ``reg.alpha`` when the data misfit is
    below the target (more freedom) or increases it when above (more smoothing).
    """

    name = "Occam"

    def __init__(self, target_chi2: float = 1.0, jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6, cooling_factor: float = 0.5,
                 warming_factor: float = 2.0):
        super().__init__(jacobian_strategy, eps)
        self.target_chi2 = target_chi2
        self.cooling_factor = cooling_factor
        self.warming_factor = warming_factor
        self._gn = GaussNewton(jacobian_strategy, eps, line_search=True)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 40, tolerance: float = 1e-4
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        m = np.asarray(initial_model, dtype=float).copy()
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)
        original_alpha = reg.alpha
        for outer in range(max_iter):
            m, inner_diag = self._gn.optimize(
                forward, observed, reg, m, weights=W,
                max_iter=5, tolerance=tolerance)
            r = observed - forward.predict(m)
            chi2 = np.dot(W * r, r) / max(forward.n_data, 1)
            data_misfit = 0.5 * np.dot(W * r, r)
            reg_val = reg.value(m)
            diag.append(data_misfit=data_misfit, reg_term=reg_val,
                        total_objective=data_misfit + reg_val,
                        grad_norm=abs(chi2 - self.target_chi2),
                        step_norm=float(np.linalg.norm(m - initial_model)),
                        param_rms=float(np.sqrt(np.mean(m ** 2))),
                        label=f"Occam-{outer}-chi2={chi2:.3f}")
            if abs(chi2 - self.target_chi2) < 0.1 * self.target_chi2:
                break
            if chi2 < self.target_chi2:
                reg.alpha *= self.cooling_factor  # give more freedom
            else:
                reg.alpha *= self.warming_factor  # smooth more
        reg.alpha = original_alpha  # restore
        return m, diag


# ──────────────────────────────────────────────────────────────────────────────
# IRLS (for L1 / Huber regularization)
# ──────────────────────────────────────────────────────────────────────────────
class IRLS(Optimizer):
    """Iteratively Reweighted Least Squares wrapper for L1/Huber regularization.

    At each outer iteration, update the IRLS weights from the current model,
    then solve a weighted L2 sub-problem with GaussNewton.
    """

    name = "IRLS"

    def __init__(self, jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6, max_outer: int = 5):
        super().__init__(jacobian_strategy, eps)
        self.max_outer = max_outer
        self._gn = GaussNewton(jacobian_strategy, eps, line_search=True)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 20, tolerance: float = 1e-4
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        m = np.asarray(initial_model, dtype=float).copy()
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)
        for outer in range(self.max_outer):
            if isinstance(reg, (L1, Huber)):
                reg.update_weights(m)
            m, inner = self._gn.optimize(forward, observed, reg, m, weights=W,
                                         max_iter=max_iter // self.max_outer + 2,
                                         tolerance=tolerance)
            r = observed - forward.predict(m)
            data_misfit = 0.5 * np.dot(W * r, r)
            reg_val = reg.value(m)
            diag.append(data_misfit=data_misfit, reg_term=reg_val,
                        total_objective=data_misfit + reg_val,
                        grad_norm=float(inner.grad_norm[-1] if inner.grad_norm else 0),
                        step_norm=float(inner.step_norm[-1] if inner.step_norm else 0),
                        param_rms=float(np.sqrt(np.mean(m ** 2))),
                        label=f"IRLS-{outer}")
            if inner.converged():
                break
        return m, diag
