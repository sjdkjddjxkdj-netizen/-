"""
Reservoir-engineering quality-control (QC) subpackage (V27).

Provides well-data QC (outlier / gap / consistency detection), reservoir-
simulation QC (material balance, Newton convergence, well diagnostics),
and an automated QC framework that ties everything into a structured
pass / fail report.

Modules
-------
* :mod:`petroppo.physics.qc.data_qc` — well-log outlier, gap, and
  cross-curve consistency checks.
* :mod:`petroppo.physics.qc.simulation_qc` — material-balance,
  convergence, and well-rate/BHP diagnostics.
* :mod:`petroppo.physics.qc.automated_qc` — automated QC pipeline runner.
"""

from __future__ import annotations

__all__: list[str] = []

# --- data QC --------------------------------------------------------------- #
try:
    from . import data_qc  # noqa: F401
    from .data_qc import (
        DataQCResult,
        OutlierInfo,
        GapInfo,
        detect_outliers,
        detect_gaps,
        check_consistency,
        qc_well_data,
    )
    __all__ += [
        "data_qc",
        "DataQCResult",
        "OutlierInfo",
        "GapInfo",
        "detect_outliers",
        "detect_gaps",
        "check_consistency",
        "qc_well_data",
    ]
except Exception:  # pragma: no cover
    pass

# --- simulation QC --------------------------------------------------------- #
try:
    from . import simulation_qc  # noqa: F401
    from .simulation_qc import (
        SimulationQCResult,
        MaterialBalanceReport,
        ConvergenceReport,
        WellDiagnosticReport,
        material_balance_check,
        convergence_check,
        well_diagnostics,
        qc_simulation,
    )
    __all__ += [
        "simulation_qc",
        "SimulationQCResult",
        "MaterialBalanceReport",
        "ConvergenceReport",
        "WellDiagnosticReport",
        "material_balance_check",
        "convergence_check",
        "well_diagnostics",
        "qc_simulation",
    ]
except Exception:  # pragma: no cover
    pass

# --- automated QC ---------------------------------------------------------- #
try:
    from . import automated_qc  # noqa: F401
    from .automated_qc import (
        QCCheck,
        QCCategory,
        QCSeverity,
        QCReport,
        AutomatedQC,
        run_full_qc,
    )
    __all__ += [
        "automated_qc",
        "QCCheck",
        "QCCategory",
        "QCSeverity",
        "QCReport",
        "AutomatedQC",
        "run_full_qc",
    ]
except Exception:  # pragma: no cover
    pass
