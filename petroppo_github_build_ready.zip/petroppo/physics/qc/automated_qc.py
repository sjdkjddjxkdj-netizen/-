"""
Automated QC framework.

Ties together the data-QC (:mod:`petroppo.physics.qc.data_qc`) and
simulation-QC (:mod:`petroppo.physics.qc.simulation_qc`) modules into a
single automated pipeline that runs a configurable suite of checks and
produces a structured pass / fail / warn report.

The framework is extensible: custom checks can be registered as
:class:`QCCheck` objects and added to the :class:`AutomatedQC` runner.

References
----------
* Coats, K.H. (1969), "Use and misuse of reservoir simulation models",
  *JPT* 21(11).
* Hurtado, G.L. et al. (2007), "Automated quality control of reservoir
  simulation models", *SPE Reservoir Simulation Symposium*.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from .data_qc import DataQCResult, qc_well_data
from .simulation_qc import SimulationQCResult, qc_simulation

__all__ = [
    "QCCheck",
    "QCCategory",
    "QCSeverity",
    "QCReport",
    "AutomatedQC",
    "run_full_qc",
]


# --------------------------------------------------------------------------- #
# Enums (as plain strings for simplicity)
# --------------------------------------------------------------------------- #
class QCCategory:
    """QC check categories."""
    DATA = "data"
    SIMULATION = "simulation"
    MODEL = "model"
    CUSTOM = "custom"


class QCSeverity:
    """QC check severity levels."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


# --------------------------------------------------------------------------- #
# QCCheck
# --------------------------------------------------------------------------- #
@dataclass
class QCCheck:
    """A single QC check.

    Attributes
    ----------
    name : str
        Human-readable check name.
    category : str
        One of QCCategory.* .
    severity : str
        One of QCSeverity.* .
    check_fn : callable
        A callable that returns (passed: bool, message: str).
    passed : bool
        Result of the last run (False before first run).
    message : str
        Result message from the last run.
    """

    name: str
    category: str = QCCategory.CUSTOM
    severity: str = QCSeverity.WARNING
    check_fn: Optional[Callable] = None
    passed: bool = False
    message: str = ""

    def run(self) -> tuple[bool, str]:
        """Execute the check and store the result."""
        if self.check_fn is None:
            self.passed = True
            self.message = "No check function defined"
            return True, self.message
        try:
            result = self.check_fn()
            if isinstance(result, tuple):
                self.passed, self.message = result
            elif isinstance(result, bool):
                self.passed = result
                self.message = "OK" if result else "Failed"
            else:
                self.passed = bool(result)
                self.message = str(result)
        except Exception as exc:
            self.passed = False
            self.message = f"Check raised exception: {exc}"
        return self.passed, self.message


# --------------------------------------------------------------------------- #
# QCReport
# --------------------------------------------------------------------------- #
@dataclass
class QCReport:
    """Aggregated QC report.

    Attributes
    ----------
    checks : list of QCCheck
        All checks with their results.
    n_checks : int
    n_passed : int
    n_failed : int
    n_warnings : int
    overall_passed : bool
        True only if no ERROR or CRITICAL check failed.
    overall_quality : float
        Fraction of checks passed.
    summary : str
        Human-readable summary.
    """

    checks: list = field(default_factory=list)
    n_checks: int = 0
    n_passed: int = 0
    n_failed: int = 0
    n_warnings: int = 0
    overall_passed: bool = False
    overall_quality: float = 0.0
    summary: str = ""

    def failed_checks(self) -> list:
        """Return only the failed checks."""
        return [c for c in self.checks if not c.passed]

    def checks_by_category(self, category: str) -> list:
        """Return checks filtered by category."""
        return [c for c in self.checks if c.category == category]


# --------------------------------------------------------------------------- #
# AutomatedQC runner
# --------------------------------------------------------------------------- #
class AutomatedQC:
    """Automated QC pipeline runner.

    Register checks via :meth:`add_check` or :meth:`add_data_qc` /
    :meth:`add_simulation_qc`, then call :meth:`run` to execute all checks
    and produce a :class:`QCReport`.

    Example
    -------
    >>> qc = AutomatedQC()
    >>> qc.add_data_qc(depths, curves)
    >>> qc.add_simulation_qc(inj, prod, accum, reports, wells)
    >>> qc.add_check("custom", lambda: (True, "ok"))
    >>> report = qc.run()
    >>> print(report.summary)
    """

    def __init__(self):
        self._checks: list[QCCheck] = []

    def add_check(self, name: str, check_fn: Callable,
                  category: str = QCCategory.CUSTOM,
                  severity: str = QCSeverity.WARNING) -> None:
        """Register a custom QC check."""
        self._checks.append(QCCheck(
            name=name, category=category, severity=severity,
            check_fn=check_fn,
        ))

    def add_data_qc(self, depths: np.ndarray, curves: dict,
                    outlier_threshold: float = 3.5,
                    sentinel: float = -999.25) -> DataQCResult:
        """Register and run well-data QC checks.

        Returns the :class:`DataQCResult` so the caller can inspect details.
        """
        result = qc_well_data(depths, curves, outlier_threshold=outlier_threshold,
                              sentinel=sentinel)
        n_outliers = sum(o.n_outliers for o in result.outliers)
        n_gaps = len(result.gaps)
        n_issues = len(result.consistency_issues)
        self._checks.append(QCCheck(
            name="Data QC: outlier detection",
            category=QCCategory.DATA,
            severity=QCSeverity.WARNING,
            check_fn=lambda: (
                n_outliers == 0,
                f"{n_outliers} outliers detected across {len(result.outliers)} curves"
            ),
        ))
        self._checks.append(QCCheck(
            name="Data QC: gap detection",
            category=QCCategory.DATA,
            severity=QCSeverity.WARNING,
            check_fn=lambda: (
                n_gaps == 0,
                f"{n_gaps} gaps detected (depth + value)"
            ),
        ))
        self._checks.append(QCCheck(
            name="Data QC: cross-curve consistency",
            category=QCCategory.DATA,
            severity=QCSeverity.ERROR,
            check_fn=lambda: (
                n_issues == 0,
                f"{n_issues} consistency issues: {result.consistency_issues[:3]}"
            ),
        ))
        return result

    def add_simulation_qc(
        self,
        cumulative_injection: float,
        cumulative_production: float,
        net_accumulation: float,
        convergence_reports,
        wells: list,
        reservoir_pressure_range: tuple = (1e6, 5e7),
        mb_tolerance: float = 1e-3,
    ) -> SimulationQCResult:
        """Register and run simulation QC checks.

        Returns the :class:`SimulationQCResult` for inspection.
        """
        result = qc_simulation(
            cumulative_injection, cumulative_production, net_accumulation,
            convergence_reports, wells, reservoir_pressure_range,
            mb_tolerance=mb_tolerance,
        )
        self._checks.append(QCCheck(
            name="Simulation QC: material balance",
            category=QCCategory.SIMULATION,
            severity=QCSeverity.CRITICAL,
            check_fn=lambda: (
                result.material_balance.passed,
                f"Relative error: {result.material_balance.relative_error:.2e} "
                f"(tol: {result.material_balance.tolerance:.2e})"
            ),
        ))
        self._checks.append(QCCheck(
            name="Simulation QC: Newton convergence",
            category=QCCategory.SIMULATION,
            severity=QCSeverity.ERROR,
            check_fn=lambda: (
                result.convergence.passed,
                f"{result.convergence.n_converged}/{result.convergence.n_steps} "
                f"steps converged, max {result.convergence.max_newton_iters} iters"
            ),
        ))
        self._checks.append(QCCheck(
            name="Simulation QC: well diagnostics",
            category=QCCategory.SIMULATION,
            severity=QCSeverity.WARNING,
            check_fn=lambda: (
                result.wells.passed,
                f"{len(result.wells.rate_sign_issues)} sign issues, "
                f"{len(result.wells.bhp_range_issues)} BHP issues, "
                f"{len(result.wells.crossflow_wells)} crossflow"
            ),
        ))
        return result

    def run(self) -> QCReport:
        """Execute all registered checks and return a QCReport."""
        report = QCReport()
        for check in self._checks:
            check.run()
            report.checks.append(check)
        report.n_checks = len(report.checks)
        report.n_passed = sum(1 for c in report.checks if c.passed)
        report.n_failed = sum(1 for c in report.checks
                              if not c.passed and c.severity in
                              (QCSeverity.ERROR, QCSeverity.CRITICAL))
        report.n_warnings = sum(1 for c in report.checks
                                if not c.passed and c.severity == QCSeverity.WARNING)
        report.overall_passed = report.n_failed == 0
        report.overall_quality = (report.n_passed / report.n_checks
                                  if report.n_checks > 0 else 0.0)
        report.summary = self._make_summary(report)
        return report

    @staticmethod
    def _make_summary(report: QCReport) -> str:
        lines = [
            f"QC Report: {report.n_passed}/{report.n_checks} checks passed",
            f"  Failed (error/critical): {report.n_failed}",
            f"  Warnings: {report.n_warnings}",
            f"  Overall: {'PASS' if report.overall_passed else 'FAIL'} "
            f"(quality: {report.overall_quality:.1%})",
        ]
        for c in report.checks:
            status = "✓" if c.passed else "✗"
            lines.append(f"  [{c.category}] {status} {c.name}: {c.message}")
        return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Convenience: run full QC pipeline in one call
# --------------------------------------------------------------------------- #
def run_full_qc(
    depths: Optional[np.ndarray] = None,
    curves: Optional[dict] = None,
    cumulative_injection: float = 0.0,
    cumulative_production: float = 0.0,
    net_accumulation: float = 0.0,
    convergence_reports=None,
    wells: Optional[list] = None,
    reservoir_pressure_range: tuple = (1e6, 5e7),
    extra_checks: Optional[list] = None,
) -> QCReport:
    """Run the full automated QC pipeline (data + simulation + custom).

    Parameters
    ----------
    depths, curves : well data (optional; skip data QC if None)
    cumulative_injection, cumulative_production, net_accumulation :
        material-balance quantities.
    convergence_reports : per-time-step convergence reports.
    wells : list of well dicts.
    reservoir_pressure_range : (p_min, p_max) for BHP checks.
    extra_checks : list of (name, check_fn, category, severity) tuples.

    Returns
    -------
    QCReport
    """
    runner = AutomatedQC()
    if depths is not None and curves is not None:
        runner.add_data_qc(depths, curves)
    if convergence_reports is not None or wells is not None:
        runner.add_simulation_qc(
            cumulative_injection, cumulative_production, net_accumulation,
            convergence_reports or [], wells or [],
            reservoir_pressure_range=reservoir_pressure_range,
        )
    if extra_checks:
        for name, fn, cat, sev in extra_checks:
            runner.add_check(name, fn, category=cat, severity=sev)
    return runner.run()
