"""
Well-data quality control (QC).

Provides tools to validate well-log and well-test data **before** they
enter the reservoir model or simulation.  This is the engineering-data
analogue of :mod:`petroppo.processing.qc` (which handles geophysical
survey data): outlier detection, gap detection, and cross-curve
consistency checks for wireline logs and production data.

Checks implemented
------------------
* :func:`detect_outliers` — modified-z (MAD) outlier detection on any
  1-D log curve; flags samples whose deviation from the local median
  exceeds a threshold.
* :func:`detect_gaps` — finds missing depth intervals (depths where the
  sampling step deviates from the nominal step by more than a tolerance)
  and NaN / sentinel-value gaps within a curve.
* :func:`check_consistency` — cross-curve physical-consistency checks
  (e.g. density must be positive and within a plausible lithology range;
  sonic transit-time must be positive; GR and SP should not contradict
  each other in terms of shale indication).
* :class:`DataQCResult` — structured result aggregating all findings.

All checks are deterministic and verified against analytic ground truth
in :mod:`petroppo.verification.test_qc_upgrade`.

References
----------
* Hurley, N.F. & Cosenza, P.A. (1992), "Automated quality control of
  wireline logs", *The Log Analyst* 33(3).
* Shalaby, M.R. & Islam, M.A. (2017), "Well log data quality control:
  A review", *Journal of Petroleum Science and Engineering*.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "DataQCResult",
    "GapInfo",
    "OutlierInfo",
    "detect_outliers",
    "detect_gaps",
    "check_consistency",
    "qc_well_data",
]


# --------------------------------------------------------------------------- #
# Data containers
# --------------------------------------------------------------------------- #
@dataclass
class OutlierInfo:
    """Information about detected outliers in a single curve.

    Attributes
    ----------
    curve_name : str
    indices : np.ndarray
        Sample indices flagged as outliers.
    values : np.ndarray
        The flagged values.
    threshold : float
        Modified-z threshold used.
    """

    curve_name: str
    indices: np.ndarray
    values: np.ndarray
    threshold: float

    @property
    def n_outliers(self) -> int:
        return int(len(self.indices))


@dataclass
class GapInfo:
    """Information about detected gaps in a well log.

    Attributes
    ----------
    curve_name : str
        Name of the curve (or 'depth' for depth gaps).
    start_depth : float
    end_depth : float
    n_missing : int
        Estimated number of missing samples in the gap.
    gap_type : str
        'depth_gap' (irregular sampling) or 'value_gap' (NaN / sentinel).
    """

    curve_name: str
    start_depth: float
    end_depth: float
    n_missing: int
    gap_type: str


@dataclass
class DataQCResult:
    """Aggregated QC result for well data.

    Attributes
    ----------
    outliers : list of OutlierInfo
    gaps : list of GapInfo
    consistency_issues : list of str
    overall_quality : float
        Fraction of checks passed (0–1).
    n_checks : int
    n_passed : int
    n_failed : int
    """

    outliers: list = field(default_factory=list)
    gaps: list = field(default_factory=list)
    consistency_issues: list = field(default_factory=list)
    overall_quality: float = 0.0
    n_checks: int = 0
    n_passed: int = 0
    n_failed: int = 0


# --------------------------------------------------------------------------- #
# Outlier detection (modified z-score / MAD)
# --------------------------------------------------------------------------- #
def detect_outliers(
    values: np.ndarray,
    threshold: float = 3.5,
    window: Optional[int] = None,
) -> OutlierInfo:
    """Detect outliers in a 1-D curve using the modified z-score (MAD).

    The modified z-score is::

        z_i = 0.6745 * (x_i - median) / MAD

    where ``MAD = median(|x - median|)``.  Values with ``|z_i| > threshold``
    are flagged.  If ``window`` is given, the MAD and median are computed
    locally (running window) to detect local spikes rather than global
    outliers.

    Parameters
    ----------
    values : np.ndarray
        1-D array of log values (NaNs are ignored).
    threshold : float
        Modified-z threshold (default 3.5 = standard for MAD outliers).
    window : int, optional
        If given, use a running window of this size for local statistics.

    Returns
    -------
    OutlierInfo
    """
    v = np.asarray(values, float)
    n = len(v)
    if n == 0:
        return OutlierInfo(curve_name="", indices=np.array([], int),
                           values=np.array([]), threshold=threshold)
    flagged = np.zeros(n, dtype=bool)
    if window is None or window >= n:
        # global
        valid = ~np.isnan(v)
        if valid.sum() < 3:
            return OutlierInfo(curve_name="", indices=np.array([], int),
                               values=np.array([]), threshold=threshold)
        med = np.median(v[valid])
        mad = np.median(np.abs(v[valid] - med))
        if mad == 0:
            mad = np.std(v[valid]) / 0.6745 + 1e-9
        z = 0.6745 * (v - med) / mad
        flagged = np.abs(z) > threshold
        flagged &= valid
    else:
        half = window // 2
        for i in range(n):
            lo = max(0, i - half)
            hi = min(n, i + half + 1)
            local = v[lo:hi]
            valid = ~np.isnan(local)
            if valid.sum() < 3:
                continue
            med = np.median(local[valid])
            mad = np.median(np.abs(local[valid] - med))
            if mad == 0:
                continue
            z = 0.6745 * (v[i] - med) / mad
            if abs(z) > threshold and not np.isnan(v[i]):
                flagged[i] = True
    idx = np.where(flagged)[0]
    return OutlierInfo(
        curve_name="",
        indices=idx,
        values=v[idx],
        threshold=threshold,
    )


# --------------------------------------------------------------------------- #
# Gap detection
# --------------------------------------------------------------------------- #
def detect_gaps(
    depths: np.ndarray,
    values: np.ndarray,
    nominal_step: Optional[float] = None,
    step_tolerance: float = 0.5,
    sentinel: Optional[float] = None,
) -> list[GapInfo]:
    """Detect gaps in a well log.

    Two types of gaps are detected:

    1. **Depth gaps**: intervals where the depth sampling step deviates
       from the nominal step by more than ``step_tolerance`` (fractional).
       E.g. if nominal step = 0.5 m and a jump of 2.0 m occurs, that is a
       4× deviation → flagged.
    2. **Value gaps**: NaN values or sentinel values (e.g. -999.25) within
       the curve at regularly sampled depths.

    Parameters
    ----------
    depths : np.ndarray
        Monotonically increasing depth array.
    values : np.ndarray
        Log values aligned with depths.
    nominal_step : float, optional
        Expected sampling step.  If None, inferred from the median of
        consecutive differences.
    step_tolerance : float
        Fractional tolerance for depth-gap detection (default 0.5 means a
        step > 1.5× nominal is a gap).
    sentinel : float, optional
        Sentinel "no-data" value to treat as a gap (e.g. -999.25).

    Returns
    -------
    list of GapInfo
    """
    d = np.asarray(depths, float)
    v = np.asarray(values, float)
    gaps: list[GapInfo] = []
    n = len(d)
    if n < 2:
        return gaps
    diffs = np.diff(d)
    if nominal_step is None:
        nominal_step = float(np.median(diffs))
    if nominal_step <= 0:
        nominal_step = float(np.mean(diffs)) if np.mean(diffs) > 0 else 1.0
    # --- depth gaps ---
    for i in range(len(diffs)):
        ratio = diffs[i] / nominal_step
        if ratio > (1.0 + step_tolerance):
            n_missing = int(round(ratio - 1.0))
            gaps.append(GapInfo(
                curve_name="depth",
                start_depth=float(d[i]),
                end_depth=float(d[i + 1]),
                n_missing=max(n_missing, 1),
                gap_type="depth_gap",
            ))
    # --- value gaps (NaN or sentinel) ---
    for i in range(n):
        is_gap = np.isnan(v[i])
        if sentinel is not None and not is_gap:
            is_gap = abs(v[i] - sentinel) < 1e-6
        if is_gap:
            # merge consecutive value-gaps into one interval
            if (gaps and gaps[-1].gap_type == "value_gap"
                    and abs(gaps[-1].end_depth - d[i]) < nominal_step * 1.5):
                gaps[-1].end_depth = float(d[i])
                gaps[-1].n_missing += 1
            else:
                gaps.append(GapInfo(
                    curve_name="value",
                    start_depth=float(d[i]),
                    end_depth=float(d[i]),
                    n_missing=1,
                    gap_type="value_gap",
                ))
    return gaps


# --------------------------------------------------------------------------- #
# Cross-curve consistency
# --------------------------------------------------------------------------- #
def check_consistency(
    curves: dict,
    depths: np.ndarray,
    rules: Optional[list] = None,
) -> list[str]:
    """Check cross-curve physical consistency.

    Built-in rules (applied when ``rules`` is None):
    - **density positive**: RHOB > 0 and within [1.0, 3.5] g/cc.
    - **sonic positive**: DT > 0 and within [40, 200] us/ft.
    - **gamma ray positive**: GR >= 0 and within [0, 300] gAPI.
    - **neutron porosity bounded**: NPHI within [-0.05, 0.6].
    - **density-sonic consistency**: if RHOB > 2.8 (likely carbonate/
      anhydrite) then DT should be < 90 (fast formation); this is a soft
      check that reports violations but does not fail.
    - **GR-SP shale indication**: high GR should correspond to negative
      SP (shale baseline); reports contradictions.

    Parameters
    ----------
    curves : dict
        Mapping of curve name → 1-D array.  Expected keys (optional):
        'GR', 'SP', 'RHOB', 'DT', 'NPHI'.
    depths : np.ndarray
        Depths aligned with the curves.
    rules : list, optional
        Custom rule callables, each taking (curves, depths) and returning
        a list of issue strings.

    Returns
    -------
    list of str
        Human-readable consistency issues.
    """
    issues: list[str] = []
    d = np.asarray(depths, float)
    n = len(d)

    def _check_range(name, arr, lo, hi, unit=""):
        if name not in curves:
            return
        a = np.asarray(curves[name], float)
        mask = ~np.isnan(a)
        if mask.sum() == 0:
            return
        bad = mask & ((a < lo) | (a > hi))
        if bad.any():
            issues.append(
                f"{name}: {int(bad.sum())} samples outside plausible "
                f"range [{lo}, {hi}] {unit}"
            )

    # built-in physical-range checks
    _check_range("RHOB", curves.get("RHOB"), 1.0, 3.5, "g/cc")
    _check_range("DT", curves.get("DT"), 40, 200, "us/ft")
    _check_range("GR", curves.get("GR"), 0, 300, "gAPI")
    _check_range("NPHI", curves.get("NPHI"), -0.05, 0.6, "v/v")

    # density-sonic consistency (carbonate/fast formation)
    if "RHOB" in curves and "DT" in curves:
        rhob = np.asarray(curves["RHOB"], float)
        dt = np.asarray(curves["DT"], float)
        mask = ~np.isnan(rhob) & ~np.isnan(dt)
        if mask.sum() > 0:
            dense_fast = mask & (rhob > 2.8) & (dt > 90)
            if dense_fast.any():
                issues.append(
                    f"RHOB-DT: {int(dense_fast.sum())} samples with high "
                    f"density (>2.8) but slow sonic (DT>90) — possible "
                    f"consistency issue"
                )

    # GR-SP shale indication
    if "GR" in curves and "SP" in curves:
        gr = np.asarray(curves["GR"], float)
        sp = np.asarray(curves["SP"], float)
        mask = ~np.isnan(gr) & ~np.isnan(sp)
        if mask.sum() > 10:
            gr_med = np.median(gr[mask])
            # high GR (above median) should correspond to negative SP (shale)
            high_gr = mask & (gr > gr_med) & (sp > 0)
            if high_gr.sum() > 0.3 * mask.sum():
                issues.append(
                    f"GR-SP: {int(high_gr.sum())} samples with high GR but "
                    f"positive SP — shale/sand indication contradicts"
                )

    # custom rules
    if rules:
        for rule in rules:
            issues.extend(rule(curves, depths))
    return issues


# --------------------------------------------------------------------------- #
# Top-level well-data QC driver
# --------------------------------------------------------------------------- #
def qc_well_data(
    depths: np.ndarray,
    curves: dict,
    outlier_threshold: float = 3.5,
    nominal_step: Optional[float] = None,
    sentinel: Optional[float] = -999.25,
) -> DataQCResult:
    """Run the full well-data QC pipeline on a set of log curves.

    Parameters
    ----------
    depths : np.ndarray
        Depth array (monotonic).
    curves : dict
        Curve name → 1-D array.
    outlier_threshold : float
        Modified-z threshold for outlier detection.
    nominal_step : float, optional
        Expected depth sampling step.
    sentinel : float, optional
        No-data sentinel value.

    Returns
    -------
    DataQCResult
    """
    result = DataQCResult()
    n_checks = 0
    n_passed = 0

    # outlier detection per curve
    for name, arr in curves.items():
        arr = np.asarray(arr, float)
        oi = detect_outliers(arr, threshold=outlier_threshold)
        oi.curve_name = name
        result.outliers.append(oi)
        n_checks += 1
        if oi.n_outliers == 0:
            n_passed += 1

        # gap detection per curve
        gaps = detect_gaps(depths, arr, nominal_step=nominal_step,
                           sentinel=sentinel)
        for g in gaps:
            g.curve_name = name
        result.gaps.extend(gaps)
        n_checks += 1
        if len(gaps) == 0:
            n_passed += 1

    # consistency checks
    issues = check_consistency(curves, depths)
    result.consistency_issues = issues
    n_checks += 1
    if len(issues) == 0:
        n_passed += 1

    result.n_checks = n_checks
    result.n_passed = n_passed
    result.n_failed = n_checks - n_passed
    result.overall_quality = n_passed / n_checks if n_checks > 0 else 0.0
    return result
