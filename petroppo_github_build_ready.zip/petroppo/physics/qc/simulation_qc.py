"""
Reservoir-simulation quality control (QC).

Provides tools to verify the **correctness** of a reservoir simulation run:
material-balance checking, Newton-convergence diagnostics, and well-rate /
BHP consistency.  These are the standard QC checks performed by reservoir
engineers before trusting a simulation model (e.g. in CMG, ECLIPSE, or
Petrel's reservoir simulator).

Checks implemented
------------------
* :func:`material_balance_check` — verifies mass conservation:
  cumulative injection − cumulative production = net accumulation in the
  reservoir.  Reports the absolute and relative material-balance error.
* :func:`convergence_check` — analyses a sequence of
  :class:`~petroppo.physics.reservoir.fully_implicit.ImplicitReport`
  objects (or raw Newton-iteration / residual-norm histories) to flag
  time steps that failed to converge, required too many iterations, or
  had large residuals.
* :func:`well_diagnostics` — checks well rate / BHP consistency: rates
  should have the correct sign (producer negative / injector positive),
  BHP should be within reservoir pressure bounds, and crossflow
  (back-flow into an injector or inflow into a producer) should be
  flagged.
* :class:`SimulationQCResult` — structured result aggregating all findings.

References
----------
* Mattax, C.C. & Dalton, R.L. (1990), *Reservoir Simulation*, SPE
  Monograph Vol. 13, Chapter 9 (History Matching & QC).
* Coats, K.H. (1969), "Use and misuse of reservoir simulation models",
  *JPT* 21(11).
* ECLIPSE Reference Manual (Schlumberger), "Section: Convergence control
  and output diagnostics".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

__all__ = [
    "SimulationQCResult",
    "MaterialBalanceReport",
    "ConvergenceReport",
    "WellDiagnosticReport",
    "material_balance_check",
    "convergence_check",
    "well_diagnostics",
    "qc_simulation",
]


# --------------------------------------------------------------------------- #
# Data containers
# --------------------------------------------------------------------------- #
@dataclass
class MaterialBalanceReport:
    """Material-balance check result.

    Attributes
    ----------
    cumulative_injection : float
    cumulative_production : float
    net_accumulation : float
        Change in reservoir mass (final − initial).
    absolute_error : float
        |injection − production − accumulation|
    relative_error : float
        absolute_error / max(|cumulative_injection|, |cumulative_production|, 1)
    passed : bool
        True if relative_error < tolerance.
    tolerance : float
    """

    cumulative_injection: float = 0.0
    cumulative_production: float = 0.0
    net_accumulation: float = 0.0
    absolute_error: float = 0.0
    relative_error: float = 0.0
    passed: bool = False
    tolerance: float = 1e-3


@dataclass
class ConvergenceReport:
    """Newton-convergence diagnostics.

    Attributes
    ----------
    n_steps : int
        Total time steps analysed.
    n_converged : int
        Steps that converged.
    n_failed : int
        Steps that did not converge.
    max_newton_iters : int
        Maximum Newton iterations across all steps.
    avg_newton_iters : float
    max_residual_norm : float
    failed_steps : list of int
        Indices of failed time steps.
    slow_steps : list of int
        Indices of steps requiring many iterations (> slow_threshold).
    passed : bool
        True if all steps converged and none were slow.
    """

    n_steps: int = 0
    n_converged: int = 0
    n_failed: int = 0
    max_newton_iters: int = 0
    avg_newton_iters: float = 0.0
    max_residual_norm: float = 0.0
    failed_steps: list = field(default_factory=list)
    slow_steps: list = field(default_factory=list)
    slow_threshold: int = 8
    passed: bool = False


@dataclass
class WellDiagnosticReport:
    """Well-rate / BHP consistency diagnostics.

    Attributes
    ----------
    n_wells : int
    rate_sign_issues : list of str
        Wells with wrong rate sign.
    bhp_range_issues : list of str
        Wells with BHP outside reservoir pressure bounds.
    crossflow_wells : list of str
        Wells exhibiting crossflow.
    passed : bool
    """

    n_wells: int = 0
    rate_sign_issues: list = field(default_factory=list)
    bhp_range_issues: list = field(default_factory=list)
    crossflow_wells: list = field(default_factory=list)
    passed: bool = False


@dataclass
class SimulationQCResult:
    """Aggregated simulation QC result.

    Attributes
    ----------
    material_balance : MaterialBalanceReport
    convergence : ConvergenceReport
    wells : WellDiagnosticReport
    overall_quality : float
        Fraction of checks passed (0–1).
    n_checks : int
    n_passed : int
    issues : list of str
        All issues concatenated.
    """

    material_balance: MaterialBalanceReport = field(
        default_factory=MaterialBalanceReport)
    convergence: ConvergenceReport = field(default_factory=ConvergenceReport)
    wells: WellDiagnosticReport = field(default_factory=WellDiagnosticReport)
    overall_quality: float = 0.0
    n_checks: int = 0
    n_passed: int = 0
    issues: list = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Material balance
# --------------------------------------------------------------------------- #
def material_balance_check(
    cumulative_injection: float,
    cumulative_production: float,
    net_accumulation: float,
    tolerance: float = 1e-3,
) -> MaterialBalanceReport:
    """Verify mass conservation: injection − production = accumulation.

    The material-balance equation is::

        Σ Q_inj − Σ Q_prod = ΔM_reservoir

    where ``ΔM_reservoir`` is the net change in reservoir mass (final −
    initial).  The check computes the absolute and relative error and
    passes if the relative error is below ``tolerance``.

    Parameters
    ----------
    cumulative_injection : float
        Total mass/volume injected over the simulation.
    cumulative_production : float
        Total mass/volume produced (positive number).
    net_accumulation : float
        Change in reservoir mass (final − initial).  For a depletion
        drive (no injection) this should be negative (reservoir loses
        mass).
    tolerance : float
        Relative error tolerance (default 1e-3 = 0.1 %).

    Returns
    -------
    MaterialBalanceReport
    """
    # injection is positive (in), production is positive (out)
    # accumulation = injection - production
    expected_accumulation = cumulative_injection - cumulative_production
    abs_err = abs(expected_accumulation - net_accumulation)
    denom = max(abs(cumulative_injection), abs(cumulative_production), 1.0)
    rel_err = abs_err / denom
    return MaterialBalanceReport(
        cumulative_injection=cumulative_injection,
        cumulative_production=cumulative_production,
        net_accumulation=net_accumulation,
        absolute_error=abs_err,
        relative_error=rel_err,
        passed=rel_err < tolerance,
        tolerance=tolerance,
    )


# --------------------------------------------------------------------------- #
# Convergence check
# --------------------------------------------------------------------------- #
def convergence_check(
    reports: Sequence,
    slow_threshold: int = 8,
) -> ConvergenceReport:
    """Analyse Newton-convergence across time steps.

    Accepts either a sequence of
    :class:`~petroppo.physics.reservoir.fully_implicit.ImplicitReport`
    objects (with ``converged``, ``newton_iters``, ``residual_norm``
    attributes) or a sequence of dicts with the same keys.

    Parameters
    ----------
    reports : sequence
        One per time step.
    slow_threshold : int
        A step requiring more than this many Newton iterations is flagged
        as "slow" (potential convergence difficulty).

    Returns
    -------
    ConvergenceReport
    """
    n = len(reports)
    if n == 0:
        return ConvergenceReport(passed=True)
    iters = []
    residuals = []
    converged_flags = []
    for r in reports:
        if hasattr(r, "converged"):
            conv = bool(r.converged)
            ni = int(getattr(r, "newton_iters", 0))
            rn = float(getattr(r, "residual_norm", 0.0))
        elif isinstance(r, dict):
            conv = bool(r.get("converged", False))
            ni = int(r.get("newton_iters", 0))
            rn = float(r.get("residual_norm", 0.0))
        else:
            conv = False
            ni = 0
            rn = 0.0
        iters.append(ni)
        residuals.append(rn)
        converged_flags.append(conv)
    iters = np.array(iters)
    residuals = np.array(residuals)
    n_conv = int(np.sum(converged_flags))
    failed = [i for i, c in enumerate(converged_flags) if not c]
    slow = [i for i, ni in enumerate(iters) if ni > slow_threshold]
    rep = ConvergenceReport(
        n_steps=n,
        n_converged=n_conv,
        n_failed=n - n_conv,
        max_newton_iters=int(iters.max()) if n > 0 else 0,
        avg_newton_iters=float(iters.mean()) if n > 0 else 0.0,
        max_residual_norm=float(residuals.max()) if n > 0 else 0.0,
        failed_steps=failed,
        slow_steps=slow,
        slow_threshold=slow_threshold,
        passed=(n_conv == n and len(slow) == 0),
    )
    return rep


# --------------------------------------------------------------------------- #
# Well diagnostics
# --------------------------------------------------------------------------- #
def well_diagnostics(
    wells: list,
    reservoir_pressure_range: tuple = (1e6, 5e7),
    layer_pressures: Optional[dict] = None,
) -> WellDiagnosticReport:
    """Check well rate / BHP consistency.

    Parameters
    ----------
    wells : list of dict
        Each well dict should have:
        - 'name': str
        - 'type': 'producer' or 'injector'
        - 'rate': float (total rate; positive = injection, negative =
          production) — optional
        - 'bhp': float — optional
        - 'layers': list of dict with 'rate' (per-layer), 'pressure'
          (layer pressure) — optional, used for crossflow detection
    reservoir_pressure_range : tuple
        (p_min, p_max) — BHP should fall within this range.
    layer_pressures : dict, optional
        Well name → list of layer pressures, for crossflow detection.

    Returns
    -------
    WellDiagnosticReport
    """
    rep = WellDiagnosticReport(n_wells=len(wells))
    p_min, p_max = reservoir_pressure_range
    for w in wells:
        name = w.get("name", "?")
        wtype = w.get("type", "producer")
        rate = w.get("rate")
        bhp = w.get("bhp")
        # rate sign check
        if rate is not None:
            if wtype == "producer" and rate > 0:
                rep.rate_sign_issues.append(
                    f"Well {name}: producer with positive rate ({rate}) — "
                    f"should be negative (production)"
                )
            elif wtype == "injector" and rate < 0:
                rep.rate_sign_issues.append(
                    f"Well {name}: injector with negative rate ({rate}) — "
                    f"should be positive (injection)"
                )
        # BHP range check
        if bhp is not None:
            if bhp < p_min or bhp > p_max:
                rep.bhp_range_issues.append(
                    f"Well {name}: BHP {bhp:.3e} outside reservoir pressure "
                    f"range [{p_min:.3e}, {p_max:.3e}]"
                )
        # crossflow detection
        layers = w.get("layers")
        if layers is not None:
            for li, lr in enumerate(layers):
                lrate = lr.get("rate", 0.0)
                lpress = lr.get("pressure", 0.0)
                if wtype == "injector" and lrate < 0:
                    rep.crossflow_wells.append(
                        f"Well {name} layer {li}: injector with back-flow "
                        f"(rate={lrate:.3e}) — crossflow"
                    )
                elif wtype == "producer" and lrate > 0:
                    rep.crossflow_wells.append(
                        f"Well {name} layer {li}: producer with inflow "
                        f"(rate={lrate:.3e}) — crossflow"
                    )
    rep.passed = (len(rep.rate_sign_issues) == 0
                  and len(rep.bhp_range_issues) == 0
                  and len(rep.crossflow_wells) == 0)
    return rep


# --------------------------------------------------------------------------- #
# Top-level simulation QC driver
# --------------------------------------------------------------------------- #
def qc_simulation(
    cumulative_injection: float,
    cumulative_production: float,
    net_accumulation: float,
    convergence_reports: Sequence,
    wells: list,
    reservoir_pressure_range: tuple = (1e6, 5e7),
    mb_tolerance: float = 1e-3,
    slow_threshold: int = 8,
) -> SimulationQCResult:
    """Run the full simulation QC pipeline.

    Parameters
    ----------
    cumulative_injection, cumulative_production, net_accumulation : float
        Material-balance quantities.
    convergence_reports : sequence
        Per-time-step convergence reports (ImplicitReport or dict).
    wells : list of dict
        Well definitions for diagnostics.
    reservoir_pressure_range : tuple
        (p_min, p_max) for BHP range checks.
    mb_tolerance : float
        Material-balance relative-error tolerance.
    slow_threshold : int
        Newton-iteration slow-step threshold.

    Returns
    -------
    SimulationQCResult
    """
    mb = material_balance_check(cumulative_injection, cumulative_production,
                                net_accumulation, tolerance=mb_tolerance)
    conv = convergence_check(convergence_reports, slow_threshold=slow_threshold)
    wd = well_diagnostics(wells, reservoir_pressure_range)

    issues: list[str] = []
    n_checks = 3
    n_passed = 0
    if mb.passed:
        n_passed += 1
    else:
        issues.append(
            f"Material balance: relative error {mb.relative_error:.2e} "
            f"> tolerance {mb.tolerance:.2e}"
        )
    if conv.passed:
        n_passed += 1
    else:
        if conv.n_failed > 0:
            issues.append(
                f"Convergence: {conv.n_failed}/{conv.n_steps} steps failed"
            )
        if len(conv.slow_steps) > 0:
            issues.append(
                f"Convergence: {len(conv.slow_steps)} steps required "
                f">{conv.slow_threshold} Newton iterations"
            )
    if wd.passed:
        n_passed += 1
    else:
        issues.extend(wd.rate_sign_issues)
        issues.extend(wd.bhp_range_issues)
        issues.extend(wd.crossflow_wells)

    return SimulationQCResult(
        material_balance=mb,
        convergence=conv,
        wells=wd,
        overall_quality=n_passed / n_checks,
        n_checks=n_checks,
        n_passed=n_passed,
        issues=issues,
    )
