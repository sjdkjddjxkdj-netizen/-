"""petroppo V20 — Regularization operators.

A regularization operator R(m) penalises model structure that is not required
by the data.  Each operator exposes a uniform interface:

* ``value(model)``  — scalar penalty R(m).
* ``gradient(model)`` — ∇R(m), shape (n_params,).
* ``hessian(model)`` — Hessian (or approximate), shape (n_params, n_params).
* ``operator_matrix()`` — the matrix L such that R = ||L m||² (for quadratic
  forms) or None for non-quadratic (L1/Huber).

Operators provided
------------------
* :class:`Tikhonov`      — ||m - m_ref||² (minimum-norm / reference).
* :class:`Smoothness`    — first- or second-order difference ||LΔm||².
* :class:`DepthWeighting`— β(z) ||∇m||², β = (z+z0)^(-β_exp) (Li & Oldenburg).
* :class:`L1`            — ||m||_1 via IRLS (iteratively reweighted least squares).
* :class:`Huber`         — robust data-norm equivalent for regularization.
* :class:`Composite`     — weighted sum of multiple operators.

This replaces V19's inline, undocumented regularization in v8_inversion.py
(which used a fixed scalar alpha with no spatial smoothness operator).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import aslinearoperator


# ──────────────────────────────────────────────────────────────────────────────
# Base
# ──────────────────────────────────────────────────────────────────────────────
class RegularizationOperator:
    """Base class for regularization operators."""

    def __init__(self, n_params: int, alpha: float = 1.0):
        self.n_params = n_params
        self.alpha = alpha

    def value(self, model: np.ndarray) -> float:
        raise NotImplementedError

    def gradient(self, model: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def hessian(self, model: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def operator_matrix(self) -> Optional[np.ndarray]:
        """Matrix L such that R = alpha * ||L (m - m_ref)||².  None if non-quadratic."""
        return None


# ──────────────────────────────────────────────────────────────────────────────
# Tikhonov (minimum norm / reference)
# ──────────────────────────────────────────────────────────────────────────────
class Tikhonov(RegularizationOperator):
    """R(m) = alpha * ||m - m_ref||²."""

    def __init__(self, n_params: int, alpha: float = 1.0,
                 m_ref: Optional[np.ndarray] = None):
        super().__init__(n_params, alpha)
        self.m_ref = np.zeros(n_params) if m_ref is None else np.asarray(m_ref, dtype=float)

    def value(self, model: np.ndarray) -> float:
        d = np.asarray(model, dtype=float) - self.m_ref
        return float(self.alpha * np.dot(d, d))

    def gradient(self, model: np.ndarray) -> np.ndarray:
        return 2.0 * self.alpha * (np.asarray(model, dtype=float) - self.m_ref)

    def hessian(self, model: np.ndarray) -> np.ndarray:
        return 2.0 * self.alpha * np.eye(self.n_params)

    def operator_matrix(self) -> np.ndarray:
        return np.sqrt(self.alpha) * np.eye(self.n_params)


# ──────────────────────────────────────────────────────────────────────────────
# Smoothness (1st / 2nd order finite differences)
# ──────────────────────────────────────────────────────────────────────────────
class Smoothness(RegularizationOperator):
    """R(m) = alpha * ||L m||²  where L is a 1st or 2nd difference matrix.

    order=1: L[i, i] = -1, L[i, i+1] = 1  (flatness / gradient penalty)
    order=2: L[i, i] = 1, L[i, i+1] = -2, L[i, i+2] = 1  (curvature penalty)
    """

    def __init__(self, n_params: int, alpha: float = 1.0, order: int = 1,
                 m_ref: Optional[np.ndarray] = None):
        super().__init__(n_params, alpha)
        if order not in (1, 2):
            raise ValueError("order must be 1 or 2")
        self.order = order
        self.m_ref = np.zeros(n_params) if m_ref is None else np.asarray(m_ref, dtype=float)
        self._L = self._build_L()

    def _build_L(self) -> np.ndarray:
        n = self.n_params
        if self.order == 1:
            L = np.zeros((n - 1, n))
            for i in range(n - 1):
                L[i, i] = -1.0
                L[i, i + 1] = 1.0
        else:
            L = np.zeros((n - 2, n))
            for i in range(n - 2):
                L[i, i] = 1.0
                L[i, i + 1] = -2.0
                L[i, i + 2] = 1.0
        return L

    def value(self, model: np.ndarray) -> float:
        d = np.asarray(model, dtype=float) - self.m_ref
        Ld = self._L @ d
        return float(self.alpha * np.dot(Ld, Ld))

    def gradient(self, model: np.ndarray) -> np.ndarray:
        d = np.asarray(model, dtype=float) - self.m_ref
        return 2.0 * self.alpha * (self._L.T @ (self._L @ d))

    def hessian(self, model: np.ndarray) -> np.ndarray:
        return 2.0 * self.alpha * (self._L.T @ self._L)

    def operator_matrix(self) -> np.ndarray:
        return np.sqrt(self.alpha) * self._L


# ──────────────────────────────────────────────────────────────────────────────
# Depth weighting (Li & Oldenburg 1996, 1998)
# ──────────────────────────────────────────────────────────────────────────────
class DepthWeighting(RegularizationOperator):
    """R(m) = alpha * ||W_z L m||²  with W_z = diag(1 / (z + z0)^β).

    Counteracts the inherent decay of sensitivity with depth so that structure
    at depth is not unfairly penalised.  *z* is the cell-centre depth of each
    parameter; *z0* and *β* are the standard Li-Oldenburg parameters.
    """

    def __init__(self, n_params: int, alpha: float = 1.0,
                 depths: Optional[np.ndarray] = None,
                 z0: float = 10.0, beta: float = 1.5, order: int = 1,
                 m_ref: Optional[np.ndarray] = None):
        super().__init__(n_params, alpha)
        self.z0 = z0
        self.beta = beta
        self.order = order
        self.m_ref = np.zeros(n_params) if m_ref is None else np.asarray(m_ref, dtype=float)
        if depths is None:
            depths = np.arange(1, n_params + 1, dtype=float)
        self.depths = np.asarray(depths, dtype=float)
        w = 1.0 / np.power(self.depths + self.z0, self.beta)
        self._Wz = diags(w)
        # Build smoothness L
        if order == 1:
            L = np.zeros((n_params - 1, n_params))
            for i in range(n_params - 1):
                L[i, i] = -1.0
                L[i, i + 1] = 1.0
        else:
            L = np.zeros((n_params - 2, n_params))
            for i in range(n_params - 2):
                L[i, i] = 1.0
                L[i, i + 1] = -2.0
                L[i, i + 2] = 1.0
        self._L = L
        # W_z * L as dense for simplicity (n_params is modest in V20)
        self._WL = (self._Wz @ self._L).toarray() if hasattr(self._Wz @ self._L, "toarray") else (self._Wz @ self._L)

    def value(self, model: np.ndarray) -> float:
        d = np.asarray(model, dtype=float) - self.m_ref
        WLd = self._WL @ d
        return float(self.alpha * np.dot(WLd, WLd))

    def gradient(self, model: np.ndarray) -> np.ndarray:
        d = np.asarray(model, dtype=float) - self.m_ref
        return 2.0 * self.alpha * (self._WL.T @ (self._WL @ d))

    def hessian(self, model: np.ndarray) -> np.ndarray:
        return 2.0 * self.alpha * (self._WL.T @ self._WL)

    def operator_matrix(self) -> np.ndarray:
        return np.sqrt(self.alpha) * self._WL


# ──────────────────────────────────────────────────────────────────────────────
# L1 (via IRLS)
# ──────────────────────────────────────────────────────────────────────────────
class L1(RegularizationOperator):
    """R(m) = alpha * ||m - m_ref||_1  implemented via IRLS.

    At each IRLS iteration the user calls :meth:`update_weights` with the
    current model; then ``value`` / ``gradient`` / ``hessian`` use the
    reweighted L2 approximation:

        ||m||_1 ≈ Σ w_i m_i²,  w_i = 1 / (|m_i| + eps)
    """

    def __init__(self, n_params: int, alpha: float = 1.0,
                 eps: float = 1e-8, m_ref: Optional[np.ndarray] = None):
        super().__init__(n_params, alpha)
        self.eps = eps
        self.m_ref = np.zeros(n_params) if m_ref is None else np.asarray(m_ref, dtype=float)
        self._w = np.ones(n_params)

    def update_weights(self, model: np.ndarray) -> None:
        d = np.abs(np.asarray(model, dtype=float) - self.m_ref)
        self._w = 1.0 / (d + self.eps)

    def value(self, model: np.ndarray) -> float:
        d = np.asarray(model, dtype=float) - self.m_ref
        return float(self.alpha * np.sum(self._w * d ** 2))

    def gradient(self, model: np.ndarray) -> np.ndarray:
        d = np.asarray(model, dtype=float) - self.m_ref
        return 2.0 * self.alpha * self._w * d

    def hessian(self, model: np.ndarray) -> np.ndarray:
        return 2.0 * self.alpha * np.diag(self._w)

    def operator_matrix(self) -> Optional[np.ndarray]:
        return None  # non-quadratic


# ──────────────────────────────────────────────────────────────────────────────
# Huber (robust)
# ──────────────────────────────────────────────────────────────────────────────
class Huber(RegularizationOperator):
    """Huber penalty on model deviation — robust to outliers in the model space.

    R(m) = alpha * Σ ρ_δ(d_i)  where d_i = m_i - m_ref_i and
    ρ_δ(x) = 0.5 x²  if |x| ≤ δ,  else δ(|x| - 0.5δ).
    """

    def __init__(self, n_params: int, alpha: float = 1.0, delta: float = 1.0,
                 m_ref: Optional[np.ndarray] = None):
        super().__init__(n_params, alpha)
        self.delta = delta
        self.m_ref = np.zeros(n_params) if m_ref is None else np.asarray(m_ref, dtype=float)

    def value(self, model: np.ndarray) -> float:
        d = np.abs(np.asarray(model, dtype=float) - self.m_ref)
        small = d <= self.delta
        val = np.where(small, 0.5 * d ** 2, self.delta * (d - 0.5 * self.delta))
        return float(self.alpha * np.sum(val))

    def gradient(self, model: np.ndarray) -> np.ndarray:
        d = np.asarray(model, dtype=float) - self.m_ref
        ad = np.abs(d)
        small = ad <= self.delta
        grad = np.where(small, d, self.delta * np.sign(d))
        return self.alpha * grad

    def hessian(self, model: np.ndarray) -> np.ndarray:
        d = np.abs(np.asarray(model, dtype=float) - self.m_ref)
        small = d <= self.delta
        diag = np.where(small, 1.0, 0.0)
        return self.alpha * np.diag(diag)

    def operator_matrix(self) -> Optional[np.ndarray]:
        return None


# ──────────────────────────────────────────────────────────────────────────────
# Composite
# ──────────────────────────────────────────────────────────────────────────────
class Composite(RegularizationOperator):
    """Weighted sum of regularization operators: R = Σ β_k R_k."""

    def __init__(self, operators: List[Tuple[float, RegularizationOperator]]):
        n = operators[0][1].n_params
        super().__init__(n, alpha=1.0)
        self.operators = operators
        for _, op in operators:
            if op.n_params != n:
                raise ValueError("All operators must have the same n_params")

    def value(self, model: np.ndarray) -> float:
        return sum(b * op.value(model) for b, op in self.operators)

    def gradient(self, model: np.ndarray) -> np.ndarray:
        g = np.zeros(self.n_params)
        for b, op in self.operators:
            g += b * op.gradient(model)
        return g

    def hessian(self, model: np.ndarray) -> np.ndarray:
        H = np.zeros((self.n_params, self.n_params))
        for b, op in self.operators:
            H += b * op.hessian(model)
        return H

    def operator_matrix(self) -> Optional[np.ndarray]:
        # Stack vertically if all are quadratic
        rows = []
        for b, op in self.operators:
            L = op.operator_matrix()
            if L is None:
                return None
            rows.append(np.sqrt(b) * L)
        return np.vstack(rows)
