"""
petroppo reservoir simulation & modeling package.

V20–V22: grid, single_phase, blackoil, pvt, rock, wells, history_match,
         vtk_output.
V24: structural_grid, upscaling, region_model, scal.
V25: fully_implicit, aquifer, compositional, well_dynamics.
"""

__all__ = []

# --- V20-V22 core ---
try:
    from . import grid  # noqa: F401
    __all__.append("grid")
except Exception:
    pass
try:
    from . import rock  # noqa: F401
    __all__.append("rock")
except Exception:
    pass
try:
    from . import pvt  # noqa: F401
    __all__.append("pvt")
except Exception:
    pass
try:
    from . import wells  # noqa: F401
    __all__.append("wells")
except Exception:
    pass
try:
    from . import single_phase  # noqa: F401
    __all__.append("single_phase")
except Exception:
    pass
try:
    from . import blackoil  # noqa: F401
    __all__.append("blackoil")
except Exception:
    pass
try:
    from . import history_match  # noqa: F401
    __all__.append("history_match")
except Exception:
    pass
try:
    from . import vtk_output  # noqa: F401
    __all__.append("vtk_output")
except Exception:
    pass

# --- V24: reservoir modeling ---
try:
    from . import structural_grid  # noqa: F401
    __all__.append("structural_grid")
except Exception:
    pass
try:
    from . import upscaling  # noqa: F401
    __all__.append("upscaling")
except Exception:
    pass
try:
    from . import region_model  # noqa: F401
    __all__.append("region_model")
except Exception:
    pass
try:
    from . import scal  # noqa: F401
    __all__.append("scal")
except Exception:
    pass

# --- V25: reservoir simulation upgrade ---
try:
    from . import fully_implicit  # noqa: F401
    __all__.append("fully_implicit")
except Exception:
    pass
try:
    from . import aquifer  # noqa: F401
    __all__.append("aquifer")
except Exception:
    pass
try:
    from . import compositional  # noqa: F401
    __all__.append("compositional")
except Exception:
    pass
try:
    from . import well_dynamics  # noqa: F401
    __all__.append("well_dynamics")
except Exception:
    pass
