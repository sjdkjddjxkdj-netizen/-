"""
Compositional simulation: Peng-Robinson EOS and phase equilibrium.

Compositional reservoir simulation tracks individual hydrocarbon
components (C1, C2, ... C7+) rather than the black-oil pseudo-phases.
The key building blocks are:

* **Peng-Robinson EOS** — cubic equation of state for the Z-factor and
  fugacity coefficients.
* **Wilson K-values** — initial estimate for flash calculations.
* **Rachford-Rice flash** — solve for the vapor fraction ``V`` that
  satisfies the material-balance equation, then split the mixture into
  vapor and liquid compositions.

These are the same components used by compositional simulators
(CMG-GEM, ECLIPSE-COMP, Intersect) for volatile-oil and gas-condensate
reservoirs.

References
----------
* Peng & Robinson, "A New Two-Constant Equation of State", IEC
  Fundamentals 1976.
* Wilson, "A Modified Redlich-Kwong Equation of State, Practical Use",
  Adv. Cryog. Eng. 1969 (K-value initial estimate).
* Rachford & Rice, "Procedure for Use of Electronic Digital Computers in
  Calculating Flash Vaporization Hydrocarbon Equilibrium", JPT 1952.
* Whitson & Brulé, "Phase Behavior", SPE Monograph Vol. 20, 2000.
* Michelsen & Mollerup, "Thermodynamic Models: Fundamentals & Computational
  Aspects", 2007.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

__all__ = [
    "PhaseSplit",
    "PengRobinsonEOS",
    "wilson_k",
    "rachford_rice_flash",
    "rr_flash",
    "eos_z_factor",
    "fugacity_coefficient",
]


# --------------------------------------------------------------------------- #
@dataclass
class PhaseSplit:
    """Result of a two-phase flash calculation.

    Attributes
    ----------
    V : float
        Vapor mole fraction (0 = all liquid, 1 = all vapor).
    L : float
        Liquid mole fraction (1 - V).
    x : np.ndarray
        Liquid composition (mole fractions).
    y : np.ndarray
        Vapor composition (mole fractions).
    K : np.ndarray
        K-values (y/x) used for the split.
    converged : bool
    iterations : int
    """

    V: float
    L: float
    x: np.ndarray
    y: np.ndarray
    K: np.ndarray
    converged: bool
    iterations: int


# ===================================================================== #
# Peng-Robinson EOS
# ===================================================================== #
@dataclass
class PengRobinsonEOS:
    """Peng-Robinson equation of state for a mixture.

    PR EOS:
        P = RT/(V-b) - aα/(V(V+b) + b(V-b))

    where a = 0.45724 R²Tc²/Pc, b = 0.07780 RTc/Pc,
    α = [1 + κ(1 - sqrt(T/Tc))]², κ = 0.37464 + 1.54226ω - 0.26992ω².

    Parameters
    ----------
    tc : np.ndarray
        Critical temperatures (K).
    pc : np.ndarray
        Critical pressures (Pa).
    omega : np.ndarray
        Acentric factors.
    bij : np.ndarray, optional
        Binary interaction parameters (ncomp x ncomp). Defaults to zeros.
    """

    tc: np.ndarray
    pc: np.ndarray
    omega: np.ndarray
    bij: Optional[np.ndarray] = None

    def __post_init__(self) -> None:
        self.tc = np.asarray(self.tc, dtype=float)
        self.pc = np.asarray(self.pc, dtype=float)
        self.omega = np.asarray(self.omega, dtype=float)
        self.ncomp = len(self.tc)
        if self.bij is None:
            self.bij = np.zeros((self.ncomp, self.ncomp))
        else:
            self.bij = np.asarray(self.bij, dtype=float)

    # universal gas constant (J/mol/K)
    R = 8.314462618

    def _kappa(self) -> np.ndarray:
        return 0.37464 + 1.54226 * self.omega - 0.26992 * self.omega ** 2

    def _alpha(self, T: float) -> np.ndarray:
        kappa = self._kappa()
        tr = T / self.tc
        return (1.0 + kappa * (1.0 - np.sqrt(tr))) ** 2

    def _a_ai(self, T: float) -> np.ndarray:
        """Pure-component a·α."""
        return 0.45724 * self.R ** 2 * self.tc ** 2 / self.pc * self._alpha(T)

    def _b_bi(self) -> np.ndarray:
        """Pure-component b."""
        return 0.07780 * self.R * self.tc / self.pc

    def am(self, z: np.ndarray, T: float) -> float:
        """Mixture a (with BIPs)."""
        ai = self._a_ai(T)
        a = 0.0
        for i in range(self.ncomp):
            for j in range(self.ncomp):
                a += z[i] * z[j] * np.sqrt(ai[i] * ai[j]) * (1 - self.bij[i, j])
        return a

    def bm(self, z: np.ndarray) -> float:
        """Mixture b."""
        return float(np.sum(z * self._b_bi()))

    def z_factor(self, P: float, T: float, z: np.ndarray,
                 phase: str = "vapor") -> float:
        """Compute the Z-factor for the mixture.

        Solves the cubic in Z::

            Z³ - (1-B)Z² + (A - 3B² - 2B)Z - (AB - B² - B³) = 0

        where A = aα P / (R T)², B = b P / (R T).

        Parameters
        ----------
        P : float
            Pressure (Pa).
        T : float
            Temperature (K).
        z : np.ndarray
            Mole fractions.
        phase : str
            ``'vapor'`` → largest root; ``'liquid'`` → smallest root.
        """
        a = self.am(z, T)
        b = self.bm(z)
        A = a * P / (self.R * T) ** 2
        B = b * P / (self.R * T)
        # cubic coefficients: Z^3 + c2 Z^2 + c1 Z + c0 = 0
        c2 = -(1 - B)
        c1 = A - 3 * B ** 2 - 2 * B
        c0 = -(A * B - B ** 2 - B ** 3)
        roots = np.roots([1.0, c2, c1, c0])
        real = roots[np.isreal(roots)].real
        if len(real) == 0:
            # use all roots (complex pair) — take real part of max
            return float(roots[np.argmax(roots.real)].real)
        if phase == "vapor":
            return float(np.max(real))
        else:
            return float(np.min(real))

    def fugacity_coefficient(self, P: float, T: float, z: np.ndarray,
                             phase: str = "vapor") -> np.ndarray:
        """Fugacity coefficients φi for each component.

        Uses the PR mixing-rule derivative.  See PR (1976) eq. 12.
        """
        a = self.am(z, T)
        b = self.bm(z)
        Z = self.z_factor(P, T, z, phase=phase)
        A = a * P / (self.R * T) ** 2
        B = b * P / (self.R * T)
        ai = self._a_ai(T)
        bi = self._b_bi()
        # dai/dzj term (for mixing rule with BIPs)
        # Σ_j zj sqrt(ai aj)(1-kij)
        dadz = np.zeros(self.ncomp)
        for i in range(self.ncomp):
            s = 0.0
            for j in range(self.ncomp):
                s += z[j] * np.sqrt(ai[i] * ai[j]) * (1 - self.bij[i, j])
            dadz[i] = 2.0 * s - 2.0 * a  # corrected for mixture a
        # ln φi = (bi/bm)(Z-1) - ln(Z-B) - A/(2√2 B) * (dadz/a - bi/bm) * ln((Z+(1+√2)B)/(Z+(1-√2)B))
        term1 = bi / b * (Z - 1)
        term2 = np.log(Z - B)
        sqrt2 = np.sqrt(2.0)
        term3_coeff = A / (2 * sqrt2 * B)
        arg = (Z + (1 + sqrt2) * B) / (Z + (1 - sqrt2) * B)
        term3 = term3_coeff * (dadz / a - bi / b) * np.log(arg)
        ln_phi = term1 - term2 - term3
        return np.exp(ln_phi)


# --------------------------------------------------------------------------- #
# Standalone helpers
# --------------------------------------------------------------------------- #
def eos_z_factor(P, T, tc, pc, omega, z=None, phase="vapor"):
    """Convenience: Z-factor without constructing the EOS object."""
    eos = PengRobinsonEOS(tc=tc, pc=pc, omega=omega)
    if z is None:
        z = np.ones(len(tc)) / len(tc)
    return eos.z_factor(P, T, z, phase=phase)


def fugacity_coefficient(P, T, z, tc, pc, omega, phase="vapor"):
    """Convenience: fugacity coefficients without constructing the EOS."""
    eos = PengRobinsonEOS(tc=tc, pc=pc, omega=omega)
    return eos.fugacity_coefficient(P, T, z, phase=phase)


# ===================================================================== #
# Wilson K-values
# ===================================================================== #
def wilson_k(P: float, T: float, tc: np.ndarray, pc: np.ndarray,
             omega: np.ndarray) -> np.ndarray:
    """Wilson K-value initial estimate::

        Ki = (Pci / P) * exp(5.37 * (1 + ωi) * (1 - Tci / T))
    """
    tc = np.asarray(tc, dtype=float)
    pc = np.asarray(pc, dtype=float)
    omega = np.asarray(omega, dtype=float)
    return (pc / P) * np.exp(5.37 * (1 + omega) * (1 - tc / T))


# ===================================================================== #
# Rachford-Rice flash
# ===================================================================== #
def rachford_rice_flash(
    z: np.ndarray,
    K: np.ndarray,
    tol: float = 1e-12,
    max_iter: int = 100,
) -> float:
    """Solve the Rachford-Rice equation for the vapor fraction V.

    The RR equation::

        f(V) = Σ zi (Ki - 1) / (1 + V (Ki - 1)) = 0

    is monotonic in V and solved by bisection / Newton.  Returns V in
    [0, 1].  If all K > 1 the mixture is all-vapor (V=1); if all K < 1
    all-liquid (V=0).
    """
    z = np.asarray(z, dtype=float)
    K = np.asarray(K, dtype=float)
    km1 = K - 1.0
    # check single-phase
    if np.all(km1 > 0):
        return 1.0
    if np.all(km1 < 0):
        return 0.0
    # bracket: V in [Vmin, Vmax] where denominators stay positive
    # 1 + V(K-1) > 0  →  V > -1/(K-1) for K<1 ; V < -1/(K-1) for K>1
    neg = km1[km1 < 0]
    pos = km1[km1 > 0]
    Vlo = max(-1.0 / neg.max(), 0.0) if len(neg) else 0.0
    Vhi = min(-1.0 / pos.min(), 1.0) if len(pos) else 1.0
    Vlo = max(Vlo, 0.0)
    Vhi = min(Vhi, 1.0)
    if Vlo > Vhi:
        Vlo, Vhi = 0.0, 1.0

    def f(V):
        return np.sum(z * km1 / (1.0 + V * km1))

    # bisection (robust)
    a, b = Vlo + 1e-14, Vhi - 1e-14
    fa = f(a)
    fb = f(b)
    if fa * fb > 0:
        # fallback Newton from 0.5
        V = 0.5
        for _ in range(max_iter):
            fv = f(V)
            if abs(fv) < tol:
                return float(np.clip(V, 0.0, 1.0))
            dfv = -np.sum(z * km1 ** 2 / (1.0 + V * km1) ** 2)
            if abs(dfv) < 1e-30:
                break
            V = V - fv / dfv
            V = np.clip(V, 1e-10, 1 - 1e-10)
        return float(np.clip(V, 0.0, 1.0))
    for _ in range(max_iter):
        m = 0.5 * (a + b)
        fm = f(m)
        if abs(fm) < tol or (b - a) < tol:
            return float(np.clip(m, 0.0, 1.0))
        if fa * fm < 0:
            b, fb = m, fm
        else:
            a, fa = m, fm
    return float(np.clip(0.5 * (a + b), 0.0, 1.0))


def rr_flash(
    z: np.ndarray,
    K: np.ndarray,
    tol: float = 1e-12,
    max_iter: int = 100,
) -> PhaseSplit:
    """Rachford-Rice flash: split mixture ``z`` using K-values.

    Returns the vapor fraction ``V``, liquid fraction ``L``, and the
    vapor (``y``) and liquid (``x``) compositions::

        xi = zi / (1 + V(Ki - 1))
        yi = Ki * xi
    """
    z = np.asarray(z, dtype=float)
    K = np.asarray(K, dtype=float)
    V = rachford_rice_flash(z, K, tol=tol, max_iter=max_iter)
    km1 = K - 1.0
    denom = 1.0 + V * km1
    x = z / denom
    y = K * x
    # normalize
    sx = x.sum()
    sy = y.sum()
    if sx > 0:
        x = x / sx
    if sy > 0:
        y = y / sy
    L = 1.0 - V
    return PhaseSplit(V=V, L=L, x=x, y=y, K=K,
                      converged=True, iterations=max_iter)
