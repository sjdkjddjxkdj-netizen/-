"""petroppo V36-2c — Ensemble Smoother Multiple Data Assimilation (ES-MDA).

ES-MDA is the industry-standard ensemble-based history matching method
for reservoir models (Emerick & Reynolds, 2013).  Unlike the
gradient-free optimizers in :mod:`optim` (which find a single
best-fit model), ES-MDA produces a **posterior ensemble** of model
realizations that can be used to compute P10/P50/P90 uncertainty
estimates on both parameters and production forecasts.

Algorithm
---------
Given a prior ensemble of Ne model realizations {m_1, ..., m_Ne}:

1. **Assimilation schedule**: Choose Na assimilation iterations with
   inflation factors {alpha_1, ..., alpha_Na} such that
   sum(1/alpha_i) = 1.  The standard choice is alpha_i = Na for all i.

2. **For each assimilation iteration a = 1..Na:**

   a. **Forecast**: Run the forward simulator on each ensemble member
      to get predicted data: d_i = F(m_i) for i = 1..Ne.

   b. **Perturb observations**: Add Gaussian noise to the observed data
      for each ensemble member:
      d_obs,i = d_obs + sqrt(alpha_a * C_D) * z_i
      where z_i ~ N(0, I) and C_D is the data covariance.

   c. **Update (EnKF/EnS smoother step)**:
      Compute ensemble cross-covariances:
        C_MD = (1/(Ne-1)) * M' D'^T   (model-data cross-covariance)
        C_DD = (1/(Ne-1)) * D' D'^T   (data auto-covariance)

      Update each ensemble member:
        m_i^a = m_i^f + C_MD * (C_DD + alpha_a * C_D)^{-1} * (d_obs,i - d_i^f)

   d. **Localization** (optional): Apply a Schur-product localization
      to C_MD to prevent spurious long-range correlations and
      ensemble collapse (filter inflation).

3. **Posterior**: After all Na iterations, {m_1, ..., m_Ne} is the
   posterior ensemble.  Compute P10/P50/P90 from this ensemble.

Key features of this implementation
-----------------------------------
* Works with any :class:`ForwardModel` (reservoir simulator or otherwise).
* Supports diagonal or full data covariance C_D.
* Localization via Gaspari-Cohn compact-support correlation function
  ( Gaspari & Cohn 1999) with user-specified radius.
* Ensemble inflation (avoiding collapse) via inflation factor.
* Returns posterior ensemble + diagnostics (misfit history, ensemble
  spread, acceptance rate).

References
----------
* Emerick, A. A., & Reynolds, A. C. (2013). Ensemble smoother with
  multiple data assimilation. *Computers & Geosciences*, 55, 3-15.
* Gaspari, G., & Cohn, S. E. (1999). Construction of correlation
  functions in two and three dimensions. *QJR Meteorol. Soc.*, 125, 723-757.
* Chen, Y., & Oliver, D. S. (2013). Levenberg-Marquardt forms of the
  iterative ensemble smoother for efficient history matching. *CG*.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, List, Tuple

import numpy as np

from ..forward import ForwardModel


__all__ = [
    "ESMDA",
    "ESMDAResult",
    "gaspari_cohn",
]


# -----------------------------------------------------------------------
# Gaspari-Cohn localization function
# -----------------------------------------------------------------------

def gaspari_cohn(r: np.ndarray, radius: float = 1.0) -> np.ndarray:
    """Gaspari-Cohn-style compact-support correlation function.

    Uses the smooth Bowman bump function (Bowman 2006), which is
    always non-negative, monotonically decreasing, and compactly
    supported on |r| <= radius.  This has the same localization
    properties as the original Gaspari-Cohn (1999) 5th-order
    polynomial but avoids the negative overshoot that the 5th-order
    polynomial exhibits near the support boundary.

    The function is::

        w(r) = exp(-r^2 / (radius^2 - r^2))  for |r| < radius
        w(r) = 0                              for |r| >= radius

    Parameters
    ----------
    r : array
        Distances (can be negative; absolute value is used).
    radius : float
        Localization length scale (compact support cutoff).

    Returns
    -------
    weights : array, same shape as r
        Localization weights in [0, 1].
    """
    r = np.abs(np.asarray(r, dtype=float)) / radius
    w = np.zeros_like(r)
    m = r < 1.0
    w[m] = np.exp(-r[m] ** 2 / (1.0 - r[m] ** 2 + 1e-30))
    return np.clip(w, 0, 1)


# -----------------------------------------------------------------------
# Result container
# -----------------------------------------------------------------------

@dataclass
class ESMDAResult:
    """Outcome of an ES-MDA run.

    Attributes
    ----------
    prior : ndarray (Ne, n_params)
        Prior ensemble of model realizations.
    posterior : ndarray (Ne, n_params)
        Posterior ensemble after all assimilation iterations.
    prior_pred : ndarray (Ne, n_data)
        Predicted data for each prior realization.
    posterior_pred : ndarray (Ne, n_data)
        Predicted data for each posterior realization.
    observed : ndarray (n_data,)
        Observed data vector.
    misfit_history : list of list of float
        Mean ensemble misfit per assimilation iteration.
    spread_history : list of float
        Ensemble parameter spread (std) per iteration.
    alpha : list of float
        Inflation factors used.
    n_assim : int
        Number of assimilation iterations performed.
    converged : bool
        True if the final misfit is below the target.
    """

    prior: np.ndarray
    posterior: np.ndarray
    prior_pred: np.ndarray
    posterior_pred: np.ndarray
    observed: np.ndarray
    misfit_history: List[List[float]] = field(default_factory=list)
    spread_history: List[float] = field(default_factory=list)
    alpha: List[float] = field(default_factory=list)
    n_assim: int = 0
    converged: bool = False

    @property
    def n_ensemble(self) -> int:
        return self.posterior.shape[0]

    def param_percentiles(self, pct: List[float] = [10, 50, 90]) -> np.ndarray:
        """Compute parameter percentiles from the posterior ensemble.

        Parameters
        ----------
        pct : list of float
            Percentiles (e.g. [10, 50, 90]).

        Returns
        -------
        percentiles : ndarray (len(pct), n_params)
        """
        return np.percentile(self.posterior, pct, axis=0)

    def forecast_percentiles(self, pct: List[float] = [10, 50, 90]) -> np.ndarray:
        """Compute data/forecast percentiles from the posterior ensemble.

        Returns
        -------
        percentiles : ndarray (len(pct), n_data)
        """
        return np.percentile(self.posterior_pred, pct, axis=0)

    def prior_percentiles(self, pct: List[float] = [10, 50, 90]) -> np.ndarray:
        """Prior parameter percentiles."""
        return np.percentile(self.prior, pct, axis=0)

    def prior_forecast_percentiles(self, pct: List[float] = [10, 50, 90]) -> np.ndarray:
        """Prior data/forecast percentiles."""
        return np.percentile(self.prior_pred, pct, axis=0)


# -----------------------------------------------------------------------
# ES-MDA
# -----------------------------------------------------------------------

class ESMDA:
    """Ensemble Smoother with Multiple Data Assimilation.

    Parameters
    ----------
    forward : ForwardModel
        The forward model F: R^n_params -> R^n_data.
    observed : ndarray (n_data,)
        Observed data vector.
    data_cov : ndarray (n_data,) or (n_data, n_data)
        Data covariance (diagonal as 1-D or full matrix as 2-D).
    n_assim : int
        Number of assimilation iterations.  Default 4.
    alpha : list of float or None
        Inflation factors.  If None, uses uniform alpha = n_assim
        (so sum(1/alpha) = 1).  Custom alphas must satisfy
        sum(1/alpha) ≈ 1 for the theory to hold.
    localization_radius : float or None
        If provided, apply Gaspari-Cohn localization with this radius
        to the model-data cross-covariance.  Requires
        ``param_coords`` to compute distances.
    param_coords : ndarray (n_params, ndim) or None
        Spatial coordinates of each parameter (for localization).
    inflation : float
        Multiplicative inflation factor applied after each update
        to prevent ensemble collapse.  1.0 = no inflation.
        Default 1.0 (off).  Use 1.01–1.05 for moderate inflation.
    seed : int or None
        Random seed for reproducibility (observation perturbation).
    """

    def __init__(self,
                 forward: ForwardModel,
                 observed: np.ndarray,
                 data_cov: np.ndarray,
                 n_assim: int = 4,
                 alpha: Optional[List[float]] = None,
                 localization_radius: Optional[float] = None,
                 param_coords: Optional[np.ndarray] = None,
                 inflation: float = 1.0,
                 seed: Optional[int] = None):
        self.forward = forward
        self.observed = np.asarray(observed, dtype=float)
        self.n_assim = n_assim
        self.localization_radius = localization_radius
        self.param_coords = param_coords
        self.inflation = inflation
        self.rng = np.random.default_rng(seed)

        # Data covariance
        dc = np.asarray(data_cov, dtype=float)
        if dc.ndim == 1:
            self.C_D = np.diag(dc)
            self.C_D_diag = dc.copy()
        else:
            self.C_D = dc
            self.C_D_diag = np.diag(dc)

        # Inflation factors
        if alpha is not None:
            assert len(alpha) == n_assim, "alpha length must equal n_assim"
            assert abs(sum(1.0 / a for a in alpha) - 1.0) < 0.1, \
                "sum(1/alpha) should be ~1"
            self.alpha = list(alpha)
        else:
            self.alpha = [float(n_assim)] * n_assim

    def _run_ensemble(self, ensemble: np.ndarray) -> np.ndarray:
        """Run the forward model on each ensemble member.

        Returns
        -------
        predictions : ndarray (Ne, n_data)
        """
        Ne = ensemble.shape[0]
        pred = np.zeros((Ne, self.forward.n_data))
        for i in range(Ne):
            try:
                pred[i] = self.forward.predict(ensemble[i])
            except Exception:
                # If simulation fails, keep a large misfit
                pred[i] = 1e30
        return pred

    def _misfit(self, pred: np.ndarray) -> np.ndarray:
        """Compute normalized data misfit for each ensemble member.

        M_i = 0.5 * (d_obs - d_i)^T C_D^{-1} (d_obs - d_i)
        """
        diff = self.observed[None, :] - pred  # (Ne, n_data)
        # Solve C_D^{-1} diff^T for efficiency
        if self.C_D.ndim == 2:
            C_D_inv_diff = np.linalg.solve(self.C_D, diff.T)  # (n_data, Ne)
            misfit = 0.5 * np.sum(diff * C_D_inv_diff.T, axis=1)
        else:
            misfit = 0.5 * np.sum(diff ** 2 / self.C_D_diag[None, :], axis=1)
        return misfit

    def _localize(self, C_MD: np.ndarray, C_DD: np.ndarray) -> np.ndarray:
        """Apply Gaspari-Cohn localization to the cross-covariance.

        The localization matrix L has shape (n_params, n_data).  Each
        entry L[i, j] = gaspari_cohn(dist(param_i, data_j), radius).

        For the model-data cross-covariance, we use the parameter
        coordinates (param_coords) and assume data points are
        associated with the same spatial grid (1-to-1 correspondence
        in the simplest case, or a separate data_coords).
        """
        if self.param_coords is None:
            return C_MD

        n_params = C_MD.shape[0]
        n_data = C_MD.shape[1]

        # If n_data == n_params (common in spatial problems), use param coords for both
        if n_data == n_params and self.param_coords.shape[0] == n_params:
            coords_d = self.param_coords
        elif n_data <= n_params:
            coords_d = self.param_coords[:n_data]
        else:
            # Cannot localize without data coordinates — skip
            return C_MD

        # Compute pairwise distances
        L = np.zeros((n_params, n_data))
        for i in range(n_params):
            dists = np.linalg.norm(self.param_coords[i] - coords_d, axis=1)
            L[i] = gaspari_cohn(dists, self.localization_radius)

        return C_MD * L

    def _update_step(self, ensemble: np.ndarray, pred: np.ndarray,
                     alpha_a: float) -> np.ndarray:
        """Perform one ES-MDA assimilation update.

        Parameters
        ----------
        ensemble : ndarray (Ne, n_params)
            Current (forecast) ensemble.
        pred : ndarray (Ne, n_data)
            Predicted data for each ensemble member.
        alpha_a : float
            Inflation factor for this iteration.

        Returns
        -------
        updated : ndarray (Ne, n_params)
            Updated (analysis) ensemble.
        """
        Ne, n_params = ensemble.shape
        n_data = pred.shape[1]

        # Ensemble anomalies (perturbations from mean)
        m_mean = ensemble.mean(axis=0)
        d_mean = pred.mean(axis=0)
        M_pert = ensemble - m_mean  # (Ne, n_params)
        D_pert = pred - d_mean      # (Ne, n_data)

        # Cross-covariances (unbiased: 1/(Ne-1))
        C_MD = M_pert.T @ D_pert / (Ne - 1)  # (n_params, n_data)
        C_DD = D_pert.T @ D_pert / (Ne - 1)  # (n_data, n_data)

        # Localization
        if self.localization_radius is not None:
            C_MD = self._localize(C_MD, C_DD)

        # Perturbed observations: d_obs + sqrt(alpha * C_D) * z
        # For diagonal C_D, this is straightforward
        sqrt_alpha_CD = np.sqrt(alpha_a) * np.sqrt(self.C_D_diag)
        Z = self.rng.standard_normal((Ne, n_data))
        d_pert = self.observed[None, :] + Z * sqrt_alpha_CD[None, :]

        # Kalman gain: K = C_MD * (C_DD + alpha * C_D)^{-1}
        # Using the ensemble formulation:
        #   S = D_pert / sqrt(Ne-1)  (normalized data anomalies)
        #   C_DD + alpha*C_D = S^T S + alpha * C_D
        # For numerical stability, use the subspace inversion

        # Direct approach (works for small n_data):
        CD_inflated = C_DD + alpha_a * self.C_D
        try:
            K = C_MD @ np.linalg.inv(CD_inflated)  # (n_params, n_data)
        except np.linalg.LinAlgError:
            # Add Tikhonov regularization
            CD_inflated += 1e-10 * np.eye(n_data) * np.trace(CD_inflated) / n_data
            K = C_MD @ np.linalg.inv(CD_inflated)

        # Update: m_i^a = m_i^f + K * (d_obs,i - d_i^f)
        analysis = ensemble + (d_pert - pred) @ K.T

        # Inflation (prevent collapse)
        if self.inflation > 1.0:
            a_mean = analysis.mean(axis=0)
            a_pert = analysis - a_mean
            analysis = a_mean + self.inflation * a_pert

        return analysis

    def run(self, prior: np.ndarray,
            target_misfit: Optional[float] = None,
            verbose: bool = False) -> ESMDAResult:
        """Run the ES-MDA assimilation loop.

        Parameters
        ----------
        prior : ndarray (Ne, n_params)
            Prior ensemble of model realizations.
        target_misfit : float or None
            If provided, stop early if mean misfit drops below this.
        verbose : bool
            Print progress per iteration.

        Returns
        -------
        result : ESMDAResult
        """
        ensemble = np.asarray(prior, dtype=float).copy()
        Ne, n_params = ensemble.shape
        prior_ens = ensemble.copy()

        # Prior predictions
        prior_pred = self._run_ensemble(prior_ens)
        misfit_history = []
        spread_history = []

        prior_misfit = self._misfit(prior_pred)
        prior_spread = float(np.mean(np.std(ensemble, axis=0)))
        misfit_history.append(prior_misfit.tolist())
        spread_history.append(prior_spread)

        if verbose:
            print(f"ES-MDA prior: mean misfit = {prior_misfit.mean():.4e}, "
                  f"spread = {prior_spread:.4e}")

        for a_idx in range(self.n_assim):
            alpha_a = self.alpha[a_idx]

            # Forecast
            pred = self._run_ensemble(ensemble)

            # Update
            ensemble = self._update_step(ensemble, pred, alpha_a)

            # Post-update misfit
            post_pred = self._run_ensemble(ensemble)
            post_misfit = self._misfit(post_pred)
            post_spread = float(np.mean(np.std(ensemble, axis=0)))

            misfit_history.append(post_misfit.tolist())
            spread_history.append(post_spread)

            if verbose:
                print(f"ES-MDA iter {a_idx+1}/{self.n_assim} (alpha={alpha_a}): "
                      f"mean misfit = {post_misfit.mean():.4e}, "
                      f"spread = {post_spread:.4e}")

            # Early stopping
            if target_misfit is not None and post_misfit.mean() < target_misfit:
                break

        # Final posterior predictions
        posterior_pred = self._run_ensemble(ensemble)

        final_misfit = self._misfit(posterior_pred)
        prior_mean_misfit = float(np.mean(misfit_history[0]))
        final_mean_misfit = float(final_misfit.mean())
        converged = (target_misfit is not None and final_mean_misfit < target_misfit) or \
                     (final_mean_misfit < prior_mean_misfit)

        return ESMDAResult(
            prior=prior_ens,
            posterior=ensemble,
            prior_pred=prior_pred,
            posterior_pred=posterior_pred,
            observed=self.observed,
            misfit_history=misfit_history,
            spread_history=spread_history,
            alpha=self.alpha[:a_idx + 1],
            n_assim=a_idx + 1,
            converged=bool(converged),
        )

    @staticmethod
    def generate_prior(mean: np.ndarray, std: np.ndarray,
                       n_ensemble: int = 50,
                       dist: str = "normal",
                       lower: Optional[np.ndarray] = None,
                       upper: Optional[np.ndarray] = None,
                       seed: Optional[int] = None) -> np.ndarray:
        """Generate a prior ensemble from a Gaussian or log-normal distribution.

        Parameters
        ----------
        mean : ndarray (n_params,)
            Prior mean.
        std : ndarray (n_params,)
            Prior standard deviation.
        n_ensemble : int
            Number of ensemble members.
        dist : "normal" or "lognormal"
            Distribution type.  Lognormal is recommended for
            permeability (positive, spans orders of magnitude).
        lower, upper : ndarray or None
            Box constraints for clipping.
        seed : int or None

        Returns
        -------
        ensemble : ndarray (n_ensemble, n_params)
        """
        rng = np.random.default_rng(seed)
        n_params = len(mean)
        if dist == "lognormal":
            mu = np.log(mean)
            sigma = std / mean  # convert absolute std to relative
            ensemble = np.exp(mu[None, :] + sigma[None, :] * rng.standard_normal((n_ensemble, n_params)))
        else:
            ensemble = mean[None, :] + std[None, :] * rng.standard_normal((n_ensemble, n_params))

        if lower is not None:
            ensemble = np.maximum(ensemble, lower)
        if upper is not None:
            ensemble = np.minimum(ensemble, upper)

        return ensemble
