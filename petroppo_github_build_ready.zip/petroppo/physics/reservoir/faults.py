"""petroppo V36 — Faults, barriers, and non-neighbour connections (NNC).

This module adds the **structural discontinuity** capability that V35's
reservoir simulator lacked: faults and barriers that reduce or block
transmissibility between otherwise-adjacent cells, plus non-neighbour
connections (NNCs) for throw-across-fault juxtaposition.

Industry simulators (ECLIPSE, INTERSECT) model faults via:

* **Transmissibility multipliers** (MULTX / MULTX- / MULTY / MULTY- /
  MULTZ / MULTZ- keywords) applied per face — a multiplier of 0 is a
  sealing fault, 1 is fully transmissive.
* **Non-neighbour connections (NNC)** — connections between cells that
  are *not* grid neighbours but are hydraulically connected across a
  fault (juxtaposed layers on opposite sides of a fault with throw).
* **Fault transmissibility** computed from the SGR (shale gouge ratio)
  or a fault-seal analysis, then applied as a face multiplier.

This module provides:

* :class:`Fault` — a structural fault defined by a plane + throw +
  transmissibility multiplier.
* :class:`Barrier` — a sealing or partial-flow barrier between cells.
* :class:`FaultNetwork` — a collection of faults + NNCs that produces
  (i) face multiplier arrays and (ii) an NNC connection list that the
  simulator adds to its transmissibility matrix.
* :func:`compute_fault_transmissibility` — fault transmissibility from
  the juxtaposed permeability, cell geometry, and a shale-gouge-ratio
  (SGR) seal estimate (Bretan et al. 2003).

All quantities are SI.  Multipliers are dimensionless in [0, 1].

References
----------
* Manzocchi et al., "Fault-Transmissibility Multipliers for Flow
  Simulation Models", Petroleum Geoscience 1999.
* Bretan, Yielding & Jones, "Using Calibrated Shale Gouge Ratio to
  Estimate Hydrocarbon Column Heights", Petroleum Geoscience 2003.
* ECLIPSE Reference Manual, "MULTX, MULTY, MULTZ, NNC" keywords.
* Walsh, Manzocchi & Carbon, "Fault Transmissibility — A Case Study",
  Geological Society London Special Publications 2007.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .grid import ReservoirGrid
from .rock import RockProperties

__all__ = [
    "Fault",
    "Barrier",
    "NNCConnection",
    "FaultNetwork",
    "compute_fault_transmissibility",
    "apply_fault_multipliers",
    "sgr_seal_multiplier",
]


# --------------------------------------------------------------------------- #
# Fault
# --------------------------------------------------------------------------- #
@dataclass
class Fault:
    """A planar fault cutting the reservoir grid.

    Parameters
    ----------
    name : str
    axis : str
        Which grid axis the fault is (mostly) perpendicular to: 'x' or 'y'.
        A fault perpendicular to x sits between cell columns i and i+1.
    position : int
        The (i) or (j) index of the low-side of the fault.
    throw : float
        Vertical throw across the fault, m (down-thrown side moves down).
    multiplier : float
        Transmissibility multiplier across the fault (1 = transmissive,
        0 = sealing).  Can be overridden by an SGR-based estimate.
    cells_low : list, optional
        Explicit list of cells on the low side (for non-planar faults).
    cells_high : list, optional
        Explicit list of cells on the high side.
    """
    name: str
    axis: str = "x"
    position: int = 0
    throw: float = 0.0
    multiplier: float = 1.0
    cells_low: Optional[list] = None
    cells_high: Optional[list] = None
    sgr: Optional[float] = None      # shale gouge ratio (0-1), if known


# --------------------------------------------------------------------------- #
# Barrier (a sealing cell-face, e.g. a shale break)
# --------------------------------------------------------------------------- #
@dataclass
class Barrier:
    """A barrier reducing transmissibility on specific faces.

    Parameters
    ----------
    faces : list of (cell_a, cell_b) tuples
        The cell pairs across which the barrier sits.
    multiplier : float
        Transmissibility multiplier (0 = sealing).
    """
    faces: list = field(default_factory=list)
    multiplier: float = 0.0


# --------------------------------------------------------------------------- #
# NNC connection
# --------------------------------------------------------------------------- #
@dataclass
class NNCConnection:
    """A non-neighbour connection between two cells.

    Used for fault juxtaposition: a layer on the low side of a fault is
    hydraulically connected to a *different* layer on the high side due
    to the throw.

    Parameters
    ----------
    cell_a : int   (global cell index, low side)
    cell_b : int   (global cell index, high side)
    transmissibility : float
        Connection transmissibility (m3/(Pa.s)), already includes the
        fault multiplier.
    """
    cell_a: int
    cell_b: int
    transmissibility: float


# --------------------------------------------------------------------------- #
# Fault network
# --------------------------------------------------------------------------- #
class FaultNetwork:
    """A collection of faults, barriers, and NNCs for a reservoir grid.

    Produces:

    * ``face_multipliers()`` — (multx, multy, multz) arrays to multiply
      the geometric face transmissibilities.
    * ``nnc_connections()`` — a list of :class:`NNCConnection` to add to
      the simulator's transmissibility matrix.
    """

    def __init__(self, grid: ReservoirGrid,
                 faults: Optional[list] = None,
                 barriers: Optional[list] = None) -> None:
        self.grid = grid
        self.faults = faults or []
        self.barriers = barriers or []
        self._nncs: list = []

    # -- face multipliers --------------------------------------------- #
    def face_multipliers(self) -> tuple:
        """Return (multx, multy, multz) arrays of shape matching the
        face arrays (nx-1, ny, nz), (nx, ny-1, nz), (nx, ny, nz-1)."""
        nx, ny, nz = self.grid.shape
        multx = np.ones((nx - 1, ny, nz))
        multy = np.ones((nx, ny - 1, nz))
        multz = np.ones((nx, ny, nz - 1))
        for f in self.faults:
            mult = f.multiplier
            if f.sgr is not None:
                mult = sgr_seal_multiplier(f.sgr)
            if f.axis == "x" and 0 <= f.position < nx - 1:
                multx[f.position, :, :] *= mult
            elif f.axis == "y" and 0 <= f.position < ny - 1:
                multy[:, f.position, :] *= mult
        for b in self.barriers:
            for (a, c) in b.faces:
                # determine which face this pair corresponds to
                ix = self._face_index(a, c)
                if ix is None:
                    continue
                axis, idx = ix
                if axis == "x":
                    i, j, k = idx
                    multx[i, j, k] *= b.multiplier
                elif axis == "y":
                    i, j, k = idx
                    multy[i, j, k] *= b.multiplier
                elif axis == "z":
                    i, j, k = idx
                    multz[i, j, k] *= b.multiplier
        return multx, multy, multz

    def _face_index(self, a: int, c: int):
        """Map a (cell_a, cell_b) pair to (axis, (i,j,k)) of the face."""
        nx, ny, nz = self.grid.shape
        ia = a % nx; ja = (a // nx) % ny; ka = a // (nx * ny)
        ic = c % nx; jc = (c // nx) % ny; kc = c // (nx * ny)
        if ka == kc and ja == jc and abs(ia - ic) == 1:
            i = min(ia, ic)
            return ("x", (i, ja, ka))
        if ka == kc and ia == ic and abs(ja - jc) == 1:
            j = min(ja, jc)
            return ("y", (ia, j, ka))
        if ia == ic and ja == jc and abs(ka - kc) == 1:
            k = min(ka, kc)
            return ("z", (ia, ja, k))
        return None

    # -- NNC connections ---------------------------------------------- #
    def nnc_connections(self, rock: Optional[RockProperties] = None) -> list:
        """Build non-neighbour connections from fault throw.

        For a fault with throw ``D`` and cell height ``dz``, the layer
        offset is ``round(D / dz)``.  The low-side cell at (i, j, k) is
        juxtaposed with the high-side cell at (i+1, j, k + offset).
        """
        self._nncs = []
        nx, ny, nz = self.grid.shape
        for f in self.faults:
            if f.throw == 0 or f.cells_low is not None:
                # explicit NNCs handled below
                continue
            if f.axis != "x":
                continue
            dz = self.grid.neighbour_distances()[2]
            # average dz
            dz_mean = float(np.mean(dz)) if dz.size else 10.0
            offset = int(round(f.throw / dz_mean))
            if offset == 0:
                continue
            i = f.position
            mult = f.multiplier
            if f.sgr is not None:
                mult = sgr_seal_multiplier(f.sgr)
            for j in range(ny):
                for k in range(nz):
                    k_high = k + offset
                    if 0 <= k_high < nz and 0 <= i < nx - 1:
                        a = i + j * nx + k * nx * ny
                        b = (i + 1) + j * nx + k_high * nx * ny
                        if rock is not None:
                            T = compute_fault_transmissibility(
                                self.grid, rock, a, b, mult)
                        else:
                            T = mult * 1.0e-13
                        self._nncs.append(NNCConnection(a, b, T))
        return self._nncs

    # -- summary ------------------------------------------------------ #
    def summary(self) -> dict:
        return {
            "n_faults": len(self.faults),
            "n_barriers": len(self.barriers),
            "n_nncs": len(self._nncs),
            "faults": [{"name": f.name, "axis": f.axis,
                        "position": f.position, "throw": f.throw,
                        "multiplier": f.multiplier, "sgr": f.sgr}
                       for f in self.faults],
        }


# --------------------------------------------------------------------------- #
# Fault transmissibility computation
# --------------------------------------------------------------------------- #
def compute_fault_transmissibility(
    grid: ReservoirGrid,
    rock: RockProperties,
    cell_a: int,
    cell_b: int,
    multiplier: float = 1.0,
) -> float:
    """Compute the transmissibility of a fault connection.

    Uses the harmonic mean of the two cells' permeability and the
    geometric face area, then applies the fault multiplier:

        T = multiplier * (k_a * k_b) / (k_a * d_b/2 + k_b * d_a/2) * A

    This is the same TPFA harmonic-mean rule ECLIPSE uses for NNCs.
    """
    nx, ny, nz = grid.shape
    kx = rock.kx().ravel()
    vol = grid.cell_volumes().ravel()
    # estimate cell linear dimension from volume (cubic root)
    da = (vol[cell_a] / (nx * ny * nz)) ** (1 / 3) if vol.size else 10.0
    db = (vol[cell_b] / (nx * ny * nz)) ** (1 / 3) if vol.size else 10.0
    ka = kx[cell_a]; kb = kx[cell_b]
    A = (vol[cell_a] ** (2 / 3) + vol[cell_b] ** (2 / 3)) * 0.5
    denom = ka * db * 0.5 + kb * da * 0.5 + 1e-30
    T = multiplier * (ka * kb) / denom * A
    return float(T)


def sgr_seal_multiplier(sgr: float) -> float:
    """Shale-gouge-ratio (SGR) to transmissibility multiplier.

    Empirical relationship (Bretan et al. 2003, simplified):
    * SGR < 0.2 -> mostly transmissive (mult ~ 1)
    * SGR 0.2-0.4 -> partial seal (mult 0.1-0.5)
    * SGR > 0.4 -> sealing (mult ~ 0.01)

    The multiplier is the *fault-zone* transmissibility reduction.
    """
    if sgr <= 0.2:
        return 1.0
    elif sgr <= 0.4:
        # linear ramp from 0.5 down to 0.1
        return 0.5 - 0.4 * (sgr - 0.2) / 0.2
    else:
        return 0.01


def apply_fault_multipliers(
    grid: ReservoirGrid,
    rock: RockProperties,
    fault_net: FaultNetwork,
) -> tuple:
    """Apply fault multipliers to the geometric transmissibilities.

    Returns (tx, ty, tz) — the transmissibility arrays already multiplied
    by the fault multipliers, ready for use in the simulator.
    """
    nx, ny, nz = grid.shape
    k = rock
    # base geometric T (harmonic mean, same as the simulators)
    ax = grid.face_area_x()
    dx = grid.neighbour_distances()[0]
    kx = k.kx()
    tl = kx[:-1] * ax / np.clip(0.5 * dx, 1e-12, None)
    tr = kx[1:] * ax / np.clip(0.5 * dx, 1e-12, None)
    tx = tl * tr / (tl + tr + 1e-30)

    ay = grid.face_area_y()
    dy = grid.neighbour_distances()[1]
    ky = k.ky()
    tl = ky[:, :-1] * ay / np.clip(0.5 * dy, 1e-12, None)
    tr = ky[:, 1:] * ay / np.clip(0.5 * dy, 1e-12, None)
    ty = tl * tr / (tl + tr + 1e-30)

    az = grid.face_area_z()
    dz = grid.neighbour_distances()[2]
    kz = k.kz()
    tl = kz[:, :, :-1] * az / np.clip(0.5 * dz, 1e-12, None)
    tr = kz[:, :, 1:] * az / np.clip(0.5 * dz, 1e-12, None)
    tz = tl * tr / (tl + tr + 1e-30)

    multx, multy, multz = fault_net.face_multipliers()
    return tx * multx, ty * multy, tz * multz
