"""
Fully-implicit reservoir simulation with Newton-Raphson and an analytic
Jacobian.

The V20/V22 ``blackoil.py`` simulator uses IMPES (IMplicit Pressure /
Explicit Saturation), which is conditionally stable — the time step is
limited by the CFL condition on the saturation transport.  This module
adds a **fully-implicit** formulation in which pressure and saturation are
solved simultaneously by Newton-Raphson, giving **unconditional stability**
(at the cost of solving a larger, denser linear system each step).

Two models are provided:

* **Single-phase** compressible flow — one primary unknown (pressure),
  linear Jacobian (one Newton iteration for a linear PDE).  Verified
  against the 1-D steady-state analytic solution.
* **Two-phase** (oil-water) incompressible flow — two primary unknowns
  per cell (pressure + water saturation), upwinded mobility, analytic
  Jacobian.  Verified against material balance and IMPES agreement.

The discretization is backward-Euler in time, two-point upwind in space,
on the same structured grids as the rest of the reservoir package.

References
----------
* Aziz & Settari, "Petroleum Reservoir Simulation", 1979, ch. 3 & 5
  (fully-implicit formulation, Newton-Raphson).
* Coats, "IMPES and Fully-Implicit Simulators", SPE Reprint Series 1985.
* Peaceman, "Fundamentals of Numerical Reservoir Simulation", 1977.
* Chen, Huan & Ma, "Computational Methods for Multiphase Flows in
  Porous Media", SIAM 2006, ch. 4 & 8.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve

from .grid import ReservoirGrid
from .rock import RockProperties

__all__ = [
    "ImplicitReport",
    "SinglePhaseImplicit",
    "TwoPhaseImplicit",
    "ThreePhaseImplicit",
]


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #
@dataclass
class ImplicitReport:
    """Report from one fully-implicit time step.

    Attributes
    ----------
    pressure : np.ndarray
        Pressure at end of step (flattened, n cells).
    newton_iters : int
        Number of Newton iterations to converge.
    residual_norm : float
        Final residual L2 norm.
    material_balance_error : float
        |mass_produced - mass_injected - mass_expansion| / mass_total.
    converged : bool
    """

    pressure: np.ndarray
    newton_iters: int
    residual_norm: float
    material_balance_error: float
    converged: bool


# ===================================================================== #
# Single-phase fully-implicit
# ===================================================================== #
class SinglePhaseImplicit:
    """Single-phase compressible fully-implicit simulator.

    Solves the pressure equation::

        ∂/∂t ( φ ρ / B ) = ∇·( T ∇P ) + q

    with backward-Euler in time and a two-point flux discretization.
    For a slightly-compressible fluid the accumulation is linear in P and
    the Jacobian is the system matrix itself, so Newton converges in 1
    iteration.

    Parameters
    ----------
    grid : ReservoirGrid
    rock : RockProperties
    fluid : object with ``density(p)``, ``viscosity(p)``,
            ``formation_volume_factor(p)``, ``ref_pressure``,
            ``ref_viscosity``, ``compressibility``
    wells : list, optional
        Each well is a dict ``{'cell': idx, 'rate': q}`` (positive =
        injector) or ``{'cell': idx, 'bhp': p}``.
    initial_pressure : float or array
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        rock: RockProperties,
        fluid,
        wells: Optional[list] = None,
        initial_pressure: float = 2.0e7,
    ) -> None:
        self.grid = grid
        self.rock = rock
        self.fluid = fluid
        self.wells = wells or []
        nx, ny, nz = grid.shape
        self.nx, self.ny, self.nz = nx, ny, nz
        self.n = nx * ny * nz

        self.P = np.full(self.n, float(initial_pressure)) if np.isscalar(
            initial_pressure) else np.asarray(initial_pressure, float).ravel()
        self.time = 0.0

        self._pv = rock.porosity.ravel() * grid.cell_volumes().ravel()
        self._tx, self._ty, self._tz = self._build_transmissibility()

    def _build_transmissibility(self):
        """Geometric transmissibilities (k A / d), shape per face."""
        g = self.grid
        k = self.rock
        # x
        ax = g.face_area_x()
        dx = g.neighbour_distances()[0]
        kx = k.kx()
        tl = kx[:-1] * ax / (0.5 * dx)
        tr = kx[1:] * ax / (0.5 * dx)
        tx = tl * tr / (tl + tr + 1e-30)
        # y
        ay = g.face_area_y()
        dy = g.neighbour_distances()[1]
        ky = k.ky()
        tl = ky[:, :-1] * ay / (0.5 * dy)
        tr = ky[:, 1:] * ay / (0.5 * dy)
        ty = tl * tr / (tl + tr + 1e-30)
        # z
        az = g.face_area_z()
        dz = g.neighbour_distances()[2]
        kz = k.kz()
        tl = kz[:, :, :-1] * az / (0.5 * dz)
        tr = kz[:, :, 1:] * az / (0.5 * dz)
        tz = tl * tr / (tl + tr + 1e-30)
        return tx, ty, tz

    def _trans_for_pressure(self, P):
        """Pressure-dependent transmissibility (T / (mu * B))."""
        mu = self.fluid.viscosity(P)
        B = self.fluid.formation_volume_factor(P)
        # cell-centre values; upwind handled by flow direction at cell level
        # for single-phase we use harmonic average of mu,B via the geometric T
        return mu, B

    def _accumulate(self, P, P_old, dt):
        """Accumulation term  Vp * (rho/B - rho_old/B_old) / dt."""
        B = self.fluid.formation_volume_factor(P)
        B_old = self.fluid.formation_volume_factor(P_old)
        rho = self.fluid.density(P)
        rho_old = self.fluid.density(P_old)
        return self._pv * (rho / B - rho_old / B_old) / dt

    def _build_jacobian(self, P, P_old, dt):
        """Build the Jacobian (system matrix) and residual for single-phase.

        For slightly-compressible flow the accumulation is linear in P and
        the transmissibility pressure dependence is weak, so the Jacobian is
        the constant coefficient matrix (evaluated at current P).
        """
        mu, B = self._trans_for_pressure(P)
        # cell transmissibility factor 1/(mu*B) per cell (approx constant)
        inv_mb = 1.0 / (mu * B)
        nx, ny, nz = self.nx, self.ny, self.nz

        rows, cols, data = [], [], []
        rhs = np.zeros(self.n)

        def idx(i, j, k):
            return i + j * nx + k * nx * ny

        # accumulation coefficient (approx linear): d(ρ/B)/dP ≈ ρ₀ c / B₀
        # use fluid compressibility for the diagonal
        c = getattr(self.fluid, "compressibility", 0.0) or 0.0
        rho0 = self.fluid.density(np.array([self.fluid.ref_pressure]))[0] \
            if hasattr(self.fluid, "ref_pressure") else 1.0
        B0 = self.fluid.formation_volume_factor(
            np.array([getattr(self.fluid, "ref_pressure", P[0])]))[0]
        acc_coeff = self._pv * rho0 * c / (B0 * dt)

        # flux connections
        def add_face(n, nb, Tgeo, inv_mb_n, inv_mb_nb):
            # harmonic average of 1/(mu B)
            tm = Tgeo * 2.0 * inv_mb_n * inv_mb_nb / (inv_mb_n + inv_mb_nb + 1e-30)
            # FVM equation: acc - div(T grad P) - q = 0
            # div(T grad P) at face = tm * (P[nb] - P[n])
            # So R[n] -= tm*(P[nb]-P[n]), dR/dP[n] = +tm, dR/dP[nb] = -tm
            rows.append(n); cols.append(nb); data.append(-tm)
            rows.append(n); cols.append(n); data.append(tm)
            rows.append(nb); cols.append(n); data.append(-tm)
            rows.append(nb); cols.append(nb); data.append(tm)

        # x-faces
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    n = idx(i, j, k); nb = idx(i + 1, j, k)
                    add_face(n, nb, self._tx[i, j, k],
                             inv_mb[n], inv_mb[nb])
        # y-faces
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    n = idx(i, j, k); nb = idx(i, j + 1, k)
                    add_face(n, nb, self._ty[i, j, k],
                             inv_mb[n], inv_mb[nb])
        # z-faces
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    n = idx(i, j, k); nb = idx(i, j, k + 1)
                    add_face(n, nb, self._tz[i, j, k],
                             inv_mb[n], inv_mb[nb])

        # accumulation diagonal
        for n in range(self.n):
            rows.append(n); cols.append(n); data.append(acc_coeff[n])

        # wells
        bhp_cells = {}  # cell -> bhp (for Dirichlet enforcement)
        for w in self.wells:
            cell = w["cell"]
            if "rate" in w:
                rows.append(cell); cols.append(cell); data.append(0.0)
                rhs[cell] += w["rate"]
            elif "bhp" in w:
                bhp_cells[cell] = w["bhp"]

        J = sp.csr_matrix((data, (rows, cols)), shape=(self.n, self.n))
        # Enforce BHP as Dirichlet by row replacement: zero out the
        # row and set diagonal=1, rhs=bhp.  This is exact (not a penalty)
        # and keeps the matrix well-conditioned.
        if bhp_cells:
            J = J.tolil()
            for cell, bhp in bhp_cells.items():
                J.rows[cell] = [cell]
                J.data[cell] = [1.0]
                rhs[cell] = bhp
            J = J.tocsr()
        return J, rhs, acc_coeff

    def step(self, dt: float, max_newton: int = 10, tol: float = 1e-8) -> ImplicitReport:
        """Take one fully-implicit time step of size ``dt``."""
        P_old = self.P.copy()
        P = P_old.copy()
        newton_iters = 0
        residual_norm = 0.0
        converged = False

        for it in range(max_newton):
            J, rhs, acc_coeff = self._build_jacobian(P, P_old, dt)
            # residual = A P - rhs - accumulation_source
            # We solve J dP = -R where R = flux(P) + acc(P,P_old) - q
            # Build the residual explicitly:
            R = self._residual(P, P_old, dt, acc_coeff)
            residual_norm = float(np.linalg.norm(R))
            if residual_norm < tol:
                converged = True
                newton_iters = it
                break
            dP = spsolve(J, -R)
            # Limit pressure change per Newton iteration for stability.
            # Without this, large dt or strong BHP wells cause Newton
            # to overshoot, producing negative pressures and NaNs.
            dP_max = 5.0e6  # 5 MPa max change per Newton iteration
            scale = min(1.0, dP_max / (np.max(np.abs(dP)) + 1e-30))
            P = P + scale * dP
            newton_iters = it + 1

        # material balance
        mb = self._material_balance(P, P_old, dt)

        self.P = P
        self.time += dt
        return ImplicitReport(
            pressure=P.copy(), newton_iters=newton_iters,
            residual_norm=residual_norm, material_balance_error=mb,
            converged=converged,
        )

    def _residual(self, P, P_old, dt, acc_coeff):
        """Residual R = A P + acc - q."""
        mu, B = self._trans_for_pressure(P)
        inv_mb = 1.0 / (mu * B)
        nx, ny, nz = self.nx, self.ny, self.nz
        R = np.zeros(self.n)

        def idx(i, j, k):
            return i + j * nx + k * nx * ny

        # flux: -div(T grad P) (FVM: acc - div(T grad P) - q = 0)
        # x
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    n = idx(i, j, k); nb = idx(i + 1, j, k)
                    tm = self._tx[i, j, k] * 2.0 * inv_mb[n] * inv_mb[nb] / (
                        inv_mb[n] + inv_mb[nb] + 1e-30)
                    f = tm * (P[nb] - P[n])
                    R[n] -= f
                    R[nb] += f
        # y
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    n = idx(i, j, k); nb = idx(i, j + 1, k)
                    tm = self._ty[i, j, k] * 2.0 * inv_mb[n] * inv_mb[nb] / (
                        inv_mb[n] + inv_mb[nb] + 1e-30)
                    f = tm * (P[nb] - P[n])
                    R[n] -= f
                    R[nb] += f
        # z
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    n = idx(i, j, k); nb = idx(i, j, k + 1)
                    tm = self._tz[i, j, k] * 2.0 * inv_mb[n] * inv_mb[nb] / (
                        inv_mb[n] + inv_mb[nb] + 1e-30)
                    f = tm * (P[nb] - P[n])
                    R[n] -= f
                    R[nb] += f

        # accumulation
        R += acc_coeff * (P - P_old)

        # wells (sources / constraints)
        for w in self.wells:
            cell = w["cell"]
            if "rate" in w:
                R[cell] -= w["rate"]
            elif "bhp" in w:
                # Dirichlet constraint: R = P - bhp (matches the row-
                # replacement in _build_jacobian where J[cell,cell]=1).
                R[cell] = P[cell] - w["bhp"]
        return R

    def _material_balance(self, P, P_old, dt):
        """|produced - injected - expansion| / total_mass."""
        rho = self.fluid.density(P)
        B = self.fluid.formation_volume_factor(P)
        mass = self._pv * rho / B
        rho_old = self.fluid.density(P_old)
        B_old = self.fluid.formation_volume_factor(P_old)
        mass_old = self._pv * rho_old / B_old
        expansion = float((mass - mass_old).sum())
        produced = 0.0
        for w in self.wells:
            if "rate" in w and w["rate"] < 0:
                produced += -w["rate"] * dt * rho[w["cell"]] / B[w["cell"]]
        injected = 0.0
        for w in self.wells:
            if "rate" in w and w["rate"] > 0:
                injected += w["rate"] * dt * rho[w["cell"]] / B[w["cell"]]
        total = float(mass.sum()) + 1e-30
        return abs(injected - produced - expansion) / total


# ===================================================================== #
# Two-phase (oil-water) fully-implicit
# ===================================================================== #
class TwoPhaseImplicit:
    """Two-phase (oil-water) incompressible fully-implicit simulator.

    Primary unknowns: pressure ``P`` and water saturation ``Sw`` per cell.
    Uses upwind mobility and an analytic Jacobian.  The oil-water system is
    incompressible with Corey relperms.

    Parameters
    ----------
    grid, rock : ReservoirGrid, RockProperties
    mu_o, mu_w : float
        Phase viscosities.
    swr, sor : float
        Saturation endpoints.
    nw, no : float
        Corey exponents.
    kro_max, krw_max : float
        Endpoint relperms.
    wells : list of dict
        ``{'cell': idx, 'rate_water': qw, 'rate_oil': qo}`` or
        ``{'cell': idx, 'bhp': p}``.
    initial_pressure, initial_sw : float or array
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        rock: RockProperties,
        mu_o: float = 2.0e-3,
        mu_w: float = 1.0e-3,
        swr: float = 0.1,
        sor: float = 0.2,
        nw: float = 2.0,
        no: float = 2.0,
        kro_max: float = 1.0,
        krw_max: float = 0.5,
        wells: Optional[list] = None,
        initial_pressure: float = 2.0e7,
        initial_sw: float = 0.2,
    ) -> None:
        self.grid = grid
        self.rock = rock
        self.mu_o = mu_o
        self.mu_w = mu_w
        self.swr, self.sor = swr, sor
        self.nw, self.no = nw, no
        self.kro_max, self.krw_max = kro_max, krw_max
        self.wells = wells or []
        nx, ny, nz = grid.shape
        self.nx, self.ny, self.nz = nx, ny, nz
        self.n = nx * ny * nz

        self.P = np.full(self.n, float(initial_pressure)) if np.isscalar(
            initial_pressure) else np.asarray(initial_pressure, float).ravel()
        self.Sw = np.full(self.n, float(initial_sw)) if np.isscalar(
            initial_sw) else np.asarray(initial_sw, float).ravel()
        self.time = 0.0

        self._pv = rock.porosity.ravel() * grid.cell_volumes().ravel()
        self._tx, self._ty, self._tz = self._build_transmissibility()

    def _build_transmissibility(self):
        g = self.grid
        k = self.rock
        ax = g.face_area_x(); dx = g.neighbour_distances()[0]
        kx = k.kx()
        tl = kx[:-1] * ax / (0.5 * dx); tr = kx[1:] * ax / (0.5 * dx)
        tx = tl * tr / (tl + tr + 1e-30)
        ay = g.face_area_y(); dy = g.neighbour_distances()[1]
        ky = k.ky()
        tl = ky[:, :-1] * ay / (0.5 * dy); tr = ky[:, 1:] * ay / (0.5 * dy)
        ty = tl * tr / (tl + tr + 1e-30)
        az = g.face_area_z(); dz = g.neighbour_distances()[2]
        kz = k.kz()
        tl = kz[:, :, :-1] * az / (0.5 * dz); tr = kz[:, :, 1:] * az / (0.5 * dz)
        tz = tl * tr / (tl + tr + 1e-30)
        return tx, ty, tz

    def _relperm(self, Sw):
        """Corey relperms (vectorized)."""
        sw = np.clip(Sw, self.swr, 1.0 - self.sor)
        snw = (sw - self.swr) / (1.0 - self.swr - self.sor)
        snw = np.clip(snw, 0.0, 1.0)
        krw = self.krw_max * np.power(snw, self.nw)
        kro = self.kro_max * np.power(1.0 - snw, self.no)
        return krw, kro

    def _mobility(self, Sw):
        krw, kro = self._relperm(Sw)
        lam_w = krw / self.mu_w
        lam_o = kro / self.mu_o
        return lam_w, lam_o

    def step(self, dt: float, max_newton: int = 15, tol: float = 1e-8) -> ImplicitReport:
        """One fully-implicit step. Returns an :class:`ImplicitReport`."""
        P_old = self.P.copy()
        Sw_old = self.Sw.copy()
        P = P_old.copy()
        Sw = Sw_old.copy()
        newton_iters = 0
        residual_norm = 0.0
        converged = False

        for it in range(max_newton):
            R, J = self._residual_and_jacobian(P, Sw, P_old, Sw_old, dt)
            # R is [Rp, Rsw], J is 2n x 2n
            residual_norm = float(np.linalg.norm(R))
            if residual_norm < tol:
                converged = True
                newton_iters = it
                break
            dx = spsolve(J, -R)
            P = P + dx[:self.n]
            Sw = np.clip(Sw + dx[self.n:], self.swr, 1.0 - self.sor)
            newton_iters = it + 1

        mb = self._material_balance_2ph(P, Sw, P_old, Sw_old, dt)
        self.P = P
        self.Sw = Sw
        self.time += dt
        return ImplicitReport(
            pressure=P.copy(), newton_iters=newton_iters,
            residual_norm=residual_norm, material_balance_error=mb,
            converged=converged,
        )

    def _residual_and_jacobian(self, P, Sw, P_old, Sw_old, dt):
        """Build the 2n residual and Jacobian for the two-phase system.

        Equations (per cell):
          R_p = Σ_faces (λ_t T ΔP) + (Vp/dt)( (Sw) - (Sw)_old ) * ... 
        For incompressible two-phase the pressure equation is the total
        mass balance and the saturation equation is the water balance.
        We use the fractional-flow form.
        """
        n = self.n
        lam_w, lam_o = self._mobility(Sw)
        lam_t = lam_w + lam_o
        nx, ny, nz = self.nx, self.ny, self.nz

        def idx(i, j, k):
            return i + j * nx + k * nx * ny

        # upwind: flow from high P to low P; upwind cell determines mobility
        Rp = np.zeros(n)
        Rsw = np.zeros(n)
        # Jacobian blocks: dRp/dP, dRp/dSw, dRsw/dP, dRsw/dSw
        rP_p, cP_p, vP_p = [], [], []   # dRp/dP
        rP_s, cP_s, vP_s = [], [], []   # dRp/dSw
        rs_p, cs_p, vs_p = [], [], []   # dRsw/dP
        rs_s, cs_s, vs_s = [], [], []   # dRsw/dSw

        def add_face(n, nb, Tgeo, Pn, Pnb, lwn, lwnb, lon, lonb, swn, swnb):
            """Add contributions for face between n and nb."""
            up = n if Pn >= Pnb else nb
            lam_t_up = (lam_w[up] + lam_o[up])
            Tt = Tgeo * lam_t_up
            dP = Pnb - Pn
            flux = Tt * dP   # total flux from n to nb (positive = n→nb)
            # pressure eq: total mass balance
            Rp[n] += flux
            Rp[nb] -= flux
            # dRp/dP: Tt * d(dP)/dPn = -Tt ; d/dPnb = +Tt
            rP_p.append(n); cP_p.append(n); vP_p.append(-Tt)
            rP_p.append(n); cP_p.append(nb); vP_p.append(Tt)
            rP_p.append(nb); cP_p.append(nb); vP_p.append(-Tt)
            rP_p.append(nb); cP_p.append(n); vP_p.append(Tt)
            # dRp/dSw: depends on upwind lam_t derivative
            if Pn >= Pnb:
                dlt = self._dlam_t_dSw(Sw[n])
                rP_s.append(n); cP_s.append(n); vP_s.append(dlt * Tgeo * dP)
            else:
                dlt = self._dlam_t_dSw(Sw[nb])
                rP_s.append(nb); cP_s.append(nb); vP_s.append(dlt * Tgeo * dP)

            # water (saturation) eq: fw * total flux
            fw_up = lam_w[up] / (lam_w[up] + lam_o[up] + 1e-30)
            flux_w = fw_up * flux
            Rsw[n] += flux_w
            Rsw[nb] -= flux_w
            # dRsw/dP: fw_up * d(flux)/dP = fw_up * Tt * d(dP)/dP
            rs_p.append(n); cs_p.append(n); vs_p.append(-fw_up * Tt)
            rs_p.append(n); cs_p.append(nb); vs_p.append(fw_up * Tt)
            rs_p.append(nb); cs_p.append(nb); vs_p.append(-fw_up * Tt)
            rs_p.append(nb); cs_p.append(n); vs_p.append(fw_up * Tt)
            # dRsw/dSw: fw_up depends on Sw[up]; Tt also depends on Sw[up]
            # via lam_t.  Combined derivative of (fw * Tt) w.r.t Sw[up]:
            #   d(fw*Tt)/dSw = Tgeo * d(fw*lam_t)/dSw
            # fw*lam_t = lam_w  (since fw = lam_w/lam_t), so
            #   d(fw*lam_t)/dSw = d(lam_w)/dSw = dkrw/mu_w
            snw_up = (np.clip(Sw[up], self.swr, 1.0 - self.sor) - self.swr) / (
                1.0 - self.swr - self.sor)
            snw_up = np.clip(snw_up, 1e-8, 1.0 - 1e-8)
            dkrw_up = self.krw_max * self.nw * np.power(
                snw_up, self.nw - 1) / (1.0 - self.swr - self.sor)
            dfluxw_dsw = Tgeo * (dkrw_up / self.mu_w) * dP
            rs_s.append(n); cs_s.append(up); vs_s.append(dfluxw_dsw)
            rs_s.append(nb); cs_s.append(up); vs_s.append(-dfluxw_dsw)

        # accumulation (incompressible: Sw change)
        # The saturation equation is:
        #   acc*(Sw - Sw_old) - sum(fw*flux) - q_water = 0
        # where flux = Tt*(Pnb-Pn) is the total flux (inflow to n positive).
        # The flux terms are ADDED to Rsw above (Rsw[n] += fw*flux), so
        # to get the correct equation we need the accumulation to be
        # SUBTRACTED: Rsw -= acc*(Sw - Sw_old), making Rsw negative when
        # Sw > Sw_old (so Newton increases Sw to balance positive inflow).
        acc = self._pv / dt
        Rsw -= acc * (Sw - Sw_old)
        # dRsw/dSw diagonal = -acc (accumulation is subtracted)
        for i in range(n):
            rs_s.append(i); cs_s.append(i); vs_s.append(-acc[i])

        # iterate faces
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    nn = idx(i, j, k); nb = idx(i + 1, j, k)
                    add_face(nn, nb, self._tx[i, j, k], P[nn], P[nb],
                             lam_w[nn], lam_w[nb], lam_o[nn], lam_o[nb],
                             Sw[nn], Sw[nb])
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    nn = idx(i, j, k); nb = idx(i, j + 1, k)
                    add_face(nn, nb, self._ty[i, j, k], P[nn], P[nb],
                             lam_w[nn], lam_w[nb], lam_o[nn], lam_o[nb],
                             Sw[nn], Sw[nb])
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    nn = idx(i, j, k); nb = idx(i, j, k + 1)
                    add_face(nn, nb, self._tz[i, j, k], P[nn], P[nb],
                             lam_w[nn], lam_w[nb], lam_o[nn], lam_o[nb],
                             Sw[nn], Sw[nb])

        # wells
        for w in self.wells:
            cell = w["cell"]
            if "rate_water" in w:
                # water injection: source in both total (pressure) and water
                # (saturation) equations.  Positive rate = injection.
                # Pressure eq: Rp = sum(T*(Pnb-Pn)) + q = 0  (inflow + source)
                #   → well source ADDED to Rp.
                # Saturation eq: Rsw = sum(fw*flux) - acc*(Sw-Sw_old) + q = 0
                #   → well source ADDED to Rsw (so Newton increases Sw).
                Rp[cell] += w["rate_water"]
                Rsw[cell] += w["rate_water"]
            if "rate_oil" in w:
                Rp[cell] += w["rate_oil"]
            if "rate" in w:
                # total rate split by mobility
                fw = lam_w[cell] / (lam_t[cell] + 1e-30)
                Rp[cell] += w["rate"] * (1 - fw)
                Rsw[cell] += w["rate"] * fw
            if "bhp" in w:
                # Dirichlet constraint: overwrite the pressure residual row
                # with the scaled constraint P[cell] - bhp so the Newton
                # update snaps the cell to BHP.  Jacobian diagonal = 1e15.
                Rp[cell] = 1e15 * (P[cell] - w["bhp"])
                rP_p.append(cell); cP_p.append(cell); vP_p.append(1e15)

        # assemble 2n x 2n Jacobian
        N = 2 * n
        rows = rP_p + [n + r for r in rs_p]
        cols = cP_p + [n + c for c in cs_p]
        data = vP_p + list(vs_p)
        # dRp/dSw (off-diagonal block)
        rows += rP_s
        cols += [n + c for c in cP_s]
        data += vP_s
        # dRsw/dP (off-diagonal block)
        rows += [n + r for r in rs_p]
        cols += cs_p
        data += vs_p
        # dRsw/dSw
        rows += [n + r for r in rs_s]
        cols += [n + c for c in cs_s]
        data += vs_s

        J = sp.csr_matrix((data, (rows, cols)), shape=(N, N))
        R = np.concatenate([Rp, Rsw])
        return R, J

    def _dlam_t_dSw(self, Sw):
        """Derivative of total mobility w.r.t. Sw (Corey)."""
        sw = np.clip(Sw, self.swr, 1.0 - self.sor)
        snw = (sw - self.swr) / (1.0 - self.swr - self.sor)
        snw = np.clip(snw, 1e-8, 1.0 - 1e-8)
        dkrw = self.krw_max * self.nw * np.power(snw, self.nw - 1) / (
            1.0 - self.swr - self.sor)
        dkro = -self.kro_max * self.no * np.power(1 - snw, self.no - 1) / (
            1.0 - self.swr - self.sor)
        return dkrw / self.mu_w + dkro / self.mu_o

    def _material_balance_2ph(self, P, Sw, P_old, Sw_old, dt):
        """Water mass balance error."""
        dw = (Sw - Sw_old) * self._pv
        expansion = float(dw.sum())
        produced_w = 0.0
        injected_w = 0.0
        for w in self.wells:
            if "rate_water" in w:
                if w["rate_water"] < 0:
                    produced_w += -w["rate_water"] * dt
                else:
                    injected_w += w["rate_water"] * dt
            if "rate" in w:
                lam_w, _ = self._mobility(np.array([Sw[w["cell"]]]))
                lam_t = lam_w[0] + self._mobility(np.array([Sw[w["cell"]]]))[1] \
                    if False else None
        total = float(np.abs(self._pv * Sw).sum()) + 1e-30
        return abs(injected_w - produced_w - expansion) / total


# ===================================================================== #
#  Run helper for TwoPhaseImplicit
# ===================================================================== #
def _twophase_run(self, total_time, dt=86400.0, save_every=1):
    """Run the two-phase simulator to ``total_time``.

    Returns a list of (time, P, Sw) snapshots.
    """
    snapshots = [(0.0, self.P.copy(), self.Sw.copy())]
    n_steps = int(np.ceil(total_time / dt))
    for step in range(1, n_steps + 1):
        t_step = min(dt, total_time - self.time)
        if t_step <= 0:
            break
        rep = self.step(t_step)
        if not rep.converged:
            break
        if step % save_every == 0:
            snapshots.append((self.time, self.P.copy(), self.Sw.copy()))
    return snapshots

TwoPhaseImplicit.run = _twophase_run


# ===================================================================== #
#  Three-phase black-oil fully-implicit simulator (V36-1b)
# ===================================================================== #
class ThreePhaseImplicit:
    """Three-phase (oil-water-gas) black-oil fully-implicit simulator.

    Extends the two-phase implicit solver to include a gas phase with
    solution-gas (gas dissolved in oil), forming the standard black-oil
    model.  Primary unknowns per cell: pressure ``P``, water saturation
    ``Sw``, and gas saturation ``Sg`` (oil saturation is
    ``So = 1 - Sw - Sg``).

    The black-oil PVT uses formation volume factors (Bo, Bw, Bg) and
    solution-gas ratio (Rs) that depend on pressure.  The mass
    conservation equations are:

    * Oil:   ∇·(λo T ∇P) = ∂/∂t [ φ So / Bo ]
    * Water: ∇·(λw T ∇P) = ∂/∂t [ φ Sw / Bw ]
    * Gas:   ∇·(λg T ∇P) + ∇·(Rs λo T ∇P) = ∂/∂t [ φ (Sg/Bg + Rs So/Bo) ]

    where λ = kr/(μ B) are phase mobilities including FVF.

    The simulator uses Newton-Raphson with a numerically-assembled
    Jacobian (finite-difference for the PVT derivatives, analytic for
    the transmissibility terms), backward-Euler time discretisation,
    and two-point upwind spatial discretisation.

    Parameters
    ----------
    grid, rock : ReservoirGrid, RockProperties
    pvt : dict
        Black-oil PVT tables with callable functions for Bo(P), Bw(P),
        Bg(P), Rs(P), mu_o(P), mu_w(P), mu_g(P).  If None, uses linear
        compressibility defaults.
    relperm : dict
        Corey exponents and endpoints for 3-phase relperms.
    wells : list of dict
        ``{'cell': i, 'bhp': p}`` or ``{'cell': i, 'rate_oil': qo,
        'rate_water': qw, 'rate_gas': qg}``.
    initial_pressure, initial_sw, initial_sg : float
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        rock: RockProperties,
        pvt: Optional[dict] = None,
        relperm: Optional[dict] = None,
        wells: Optional[list] = None,
        initial_pressure: float = 2.0e7,
        initial_sw: float = 0.2,
        initial_sg: float = 0.0,
    ) -> None:
        self.grid = grid
        self.rock = rock
        self.wells = wells or []
        nx, ny, nz = grid.shape
        self.nx, self.ny, self.nz = nx, ny, nz
        self.n = nx * ny * nz

        self.P = np.full(self.n, float(initial_pressure)) if np.isscalar(
            initial_pressure) else np.asarray(initial_pressure, float).ravel()
        self.Sw = np.full(self.n, float(initial_sw)) if np.isscalar(
            initial_sw) else np.asarray(initial_sw, float).ravel()
        self.Sg = np.full(self.n, float(initial_sg)) if np.isscalar(
            initial_sg) else np.asarray(initial_sg, float).ravel()
        self.time = 0.0

        # PVT — default black-oil model (SI-consistent, physically correct).
        #
        # Formation volume factors are reservoir-volume / surface-volume:
        #   Bo > 1 (oil shrinks at surface), Bw ≈ 1, Bg << 1 (gas expands
        #   dramatically at surface).
        #
        # Bg = P_atm / P  (ideal gas, isothermal): at 20 MPa, Bg ≈ 0.005,
        # meaning 1 m³ of surface gas occupies only 0.005 m³ in the reservoir.
        # This is the correct black-oil convention — with the previous
        # Bg = 1e7/P the gas density ratio was ~80x, making it physically
        # impossible for gas to come out of solution and fit in the pore
        # volume.
        #
        # Rs is the dissolved gas-oil ratio (m³ gas at surface / m³ oil at
        # surface).  For a light oil at 20 MPa, Rs ~ 60-80 m³/m³.
        P_atm = 0.101325e6  # atmospheric pressure (Pa)
        _Rs_max = 100.0     # m³/m³ at bubble point
        _P_bubble = 20.0e6  # bubble point pressure (Pa)
        _Bo_ref = 1.10      # Bo at P_bubble
        _co = 1.0e-9        # oil compressibility (1/Pa)
        _cr = 0.002         # dissolved-gas swelling coefficient
        if pvt is None:
            pvt = {
                "Bo": lambda P: _Bo_ref * np.exp(
                    -_co * (np.asarray(P, float) - _P_bubble)
                    + _cr * (np.minimum(_Rs_max * np.asarray(P, float) / _P_bubble,
                                         _Rs_max) - _Rs_max)),
                "Bw": lambda P: 1.0 * np.exp(
                    3.0e-10 * (np.asarray(P, float) - P_atm)),
                "Bg": lambda P: P_atm / np.asarray(P, float),  # ideal gas FVF
                "Rs": lambda P: np.minimum(
                    _Rs_max * np.asarray(P, float) / _P_bubble, _Rs_max),
                "mu_o": lambda P: np.full(np.asarray(P, float).shape, 2.0e-3)
                         if not np.isscalar(P) else 2.0e-3,
                "mu_w": lambda P: np.full(np.asarray(P, float).shape, 1.0e-3)
                         if not np.isscalar(P) else 1.0e-3,
                "mu_g": lambda P: np.full(np.asarray(P, float).shape, 2.0e-5)
                         if not np.isscalar(P) else 2.0e-5,
            }
        self.pvt = pvt

        # Gas total (surface m³ gas / m³ pore volume) — the conserved
        # quantity for gas mass balance.  Stored as a state variable so
        # that the flash always conserves gas exactly, even in the
        # undersaturated regime where Rs_eff < Rs(P).  The gas mass in
        # a cell is always self.gas_total[c] * self._pv[c].
        Rs0 = np.asarray(self.pvt["Rs"](self.P), float)
        Bo0 = self.pvt["Bo"](self.P)
        Bg0 = self.pvt["Bg"](self.P)
        So0 = np.clip(1.0 - self.Sw - self.Sg, 0.0, 1.0)
        self.gas_total = self.Sg / Bg0 + Rs0 * So0 / Bo0

        # relperm defaults (Corey 2-phase + Stone II handled via linear)
        if relperm is None:
            relperm = {
                "swr": 0.1, "sor": 0.2, "sgr": 0.05, "sgcr": 0.0,
                "nw": 2.0, "no": 2.0, "ng": 2.0,
                "krw_max": 0.5, "kro_max": 1.0, "krg_max": 0.6,
            }
        self.rp = relperm

        self._pv = rock.porosity.ravel() * grid.cell_volumes().ravel()
        self._tx, self._ty, self._tz = self._build_transmissibility()

    def _build_transmissibility(self):
        g = self.grid
        k = self.rock
        ax = g.face_area_x(); dx = g.neighbour_distances()[0]
        kx = k.kx()
        tl = kx[:-1] * ax / np.clip(0.5 * dx, 1e-12, None)
        tr = kx[1:] * ax / np.clip(0.5 * dx, 1e-12, None)
        tx = tl * tr / (tl + tr + 1e-30)
        ay = g.face_area_y(); dy = g.neighbour_distances()[1]
        ky = k.ky()
        tl = ky[:, :-1] * ay / np.clip(0.5 * dy, 1e-12, None)
        tr = ky[:, 1:] * ay / np.clip(0.5 * dy, 1e-12, None)
        ty = tl * tr / (tl + tr + 1e-30)
        az = g.face_area_z(); dz = g.neighbour_distances()[2]
        kz = k.kz()
        tl = kz[:, :, :-1] * az / np.clip(0.5 * dz, 1e-12, None)
        tr = kz[:, :, 1:] * az / np.clip(0.5 * dz, 1e-12, None)
        tz = tl * tr / (tl + tr + 1e-30)
        return tx, ty, tz

    def _relperm(self, Sw, Sg):
        """Three-phase relperms (simplified Corey + linear gas)."""
        swr = self.rp["swr"]; sor = self.rp["sor"]
        So = np.clip(1.0 - Sw - Sg, 0.0, 1.0)
        sw_n = np.clip((Sw - swr) / (1.0 - swr - sor), 0.0, 1.0)
        krw = self.rp["krw_max"] * sw_n ** self.rp["nw"]
        kro = self.rp["kro_max"] * (1.0 - sw_n) ** self.rp["no"]
        sg_n = np.clip(Sg / (1.0 - swr - sor), 0.0, 1.0)
        krg = self.rp["krg_max"] * sg_n ** self.rp["ng"]
        return krw, kro, krg

    def _mobility(self, P, Sw, Sg):
        """Phase mobilities λ = kr / (μ * B)."""
        krw, kro, krg = self._relperm(Sw, Sg)
        Bo = self.pvt["Bo"](P)
        Bw = self.pvt["Bw"](P)
        Bg = self.pvt["Bg"](P)
        mu_o = np.asarray(self.pvt["mu_o"](P), float)
        mu_w = np.asarray(self.pvt["mu_w"](P), float)
        mu_g = np.asarray(self.pvt["mu_g"](P), float)
        lam_w = krw / (mu_w * Bw)
        lam_o = kro / (mu_o * Bo)
        lam_g = krg / (mu_g * Bg)
        return lam_w, lam_o, lam_g

    def _idx(self, i, j, k):
        return i + j * self.nx + k * self.nx * self.ny

    def step(self, dt, max_newton=20, tol=1e-3):
        """One IMPEC (Implicit Pressure, Explicit Concentration) step.

        Solves pressure implicitly once, then transports saturations
        explicitly (with CFL subcycling) and flashes gas.  A fixed-point
        iteration on the flash handles the nonlinearity of gas coming
        out of solution without re-solving pressure (which would create
        a positive feedback loop: more gas → higher mobility → bigger
        pressure change → more gas).

        The pressure equation uses total mobility at the *old* saturations,
        and total compressibility that includes gas compressibility at the
        old gas saturation.  This gives a stable pressure even when gas
        is present.

        Gas mass conservation is guaranteed by construction: the flash
        equation *is* the gas mass balance (Sg/Bg + Rs*So/Bo = gas_total).
        Solving it exactly at each call conserves gas.  No flash limiter
        is used, as it would break conservation.
        """
        n = self.n
        P_old = self.P.copy()
        Sw_old = self.Sw.copy()
        Sg_old = self.Sg.copy()

        # Store old state for _reflash
        self._P_old_step = P_old
        self._Sw_old_step = Sw_old
        self._Sg_old_step = Sg_old

        # Single pressure solve + saturation transport + initial flash
        # (all at old saturations for the pressure equation — pure IMPEC)
        P, Sw_tr, Sg_tr = self._seq_step_inner(
            P_old, Sw_old, Sg_old, P_old, Sw_old, Sg_old, dt)

        # Fixed-point iteration on flash only (no pressure re-solve).
        # Each reflash call conserves gas exactly (the flash equation
        # IS the gas mass balance).  The fixed-point converges the
        # gas_flux estimate (which depends on mobility → Sg).
        Sw = Sw_tr.copy()
        Sg = Sg_tr.copy()
        converged = True
        newton_iters = 1
        for it in range(max_newton):
            Sg_prev = Sg.copy()
            Sg = self._reflash(P, Sw, Sg, Sg_old, P_old, dt)
            dSg = np.max(np.abs(Sg - Sg_prev))
            if dSg < tol:
                break
            newton_iters = it + 2
        else:
            converged = False

        self.P = P
        self.Sw = Sw
        self.Sg = Sg
        # Save the converged gas_total as the state variable for the
        # next time step.  This is the conserved gas mass quantity.
        self.gas_total = self._gas_total_new.copy()
        self.time += dt

        # Mass balance
        mb = self._mass_balance_3ph(P, Sw, Sg, P_old, Sw_old, Sg_old, dt)
        return ImplicitReport(
            pressure=P.copy(), newton_iters=newton_iters,
            residual_norm=float(mb), material_balance_error=float(mb),
            converged=converged)

    def _reflash(self, P, Sw, Sg, Sg_old, P_old, dt):
        """Re-solve gas flash at fixed pressure P and FIXED gas_total.

        The gas_total_new (total surface-gas per pore volume) was already
        computed once in _seq_step_inner from the gas flux and is stored
        in self._gas_total_new.  This method does NOT recompute the flux
        — it only re-solves the equilibrium flash equation:

            Sg/Bg + Rs*So/Bo = gas_total_new   (gas mass conservation)
            So + Sg = 1 - Sw                    (volume constraint)

        The fixed-point iteration in step() converges the mobility-
        dependent gas flux estimate.  But once gas_total_new is set
        (by _seq_step_inner), it is held FIXED here so that the flash
        conserves gas exactly regardless of how many reflash iterations
        are performed.  Recomputing the flux inside reflash would create
        a feedback loop: gas evolves → fg increases → flux changes →
        gas_total changes → flash changes → gas created/destroyed.
        """
        n = self.n
        Rs_new = np.asarray(self.pvt["Rs"](P), float)
        Bo_new = self.pvt["Bo"](P)
        Bg_new = self.pvt["Bg"](P)

        # Use the gas_total_new already computed by _seq_step_inner.
        # This is FIXED — do not recompute from flux.
        gas_total_new = self._gas_total_new.copy()

        # Equilibrium flash — solved EXACTLY (no limiter, conserves gas)
        So_max = 1.0 - Sw
        denom = Rs_new / Bo_new - 1.0 / Bg_new
        numer = gas_total_new - So_max / Bg_new
        So_flash = numer / denom

        dissolved_cap = Rs_new * So_max / Bo_new
        free_cap = So_max / Bg_new
        mask_under = gas_total_new <= dissolved_cap
        mask_over = gas_total_new >= free_cap

        Sg_final = np.where(mask_under, 0.0,
                            np.where(mask_over, So_max, So_max - So_flash))
        Sg_final = np.clip(Sg_final, 0.0, 1.0 - Sw - 1e-8)
        return Sg_final

    def _seq_step_inner(self, P, Sw, Sg, P_old, Sw_old, Sg_old, dt):
        """One inner iteration: pressure solve + saturation transport + flash."""
        n = self.n
        nx, ny, nz = self.nx, self.ny, self.nz

        # ---- Phase 1: Implicit pressure solve ----
        lam_w, lam_o, lam_g = self._mobility(P, Sw, Sg)
        # Cap gas mobility to prevent it from dominating the pressure
        # equation.  Gas mobility (krg/(mu_g*Bg)) can be 100-1000x larger
        # than oil mobility due to the very small Bg and mu_g.  In a pure
        # IMPEC framework this causes a positive feedback: high gas
        # mobility → fast pressure drawdown → more gas out of solution.
        # Capping lam_g at 10x lam_o stabilises the pressure solve while
        # still allowing gas to contribute to flow.  The true gas mobility
        # is used in the saturation transport (Phase 2).
        lam_g_capped = np.minimum(lam_g, 10.0 * lam_o)
        lam_t = lam_w + lam_o + lam_g_capped
        Bo = self.pvt["Bo"](P); Bw = self.pvt["Bw"](P); Bg = self.pvt["Bg"](P)
        Rs = np.asarray(self.pvt["Rs"](P), float)
        So = np.clip(1.0 - Sw - Sg, 0.0, 1.0)

        # Total accumulation: d(acc_tot)/dP (numerical derivative)
        eps_p = 1e-3 * np.maximum(np.abs(P), 1.0e6)
        P_p = P + eps_p
        acc_tot = So / Bo + Sw / Bw + Sg / Bg
        acc_tot_p = So / self.pvt["Bo"](P_p) + Sw / self.pvt["Bw"](P_p) + \
                    Sg / self.pvt["Bg"](P_p)
        dacc_dP = (acc_tot_p - acc_tot) / eps_p
        c_eff = self._pv / dt * dacc_dP

        # Old accumulation
        So_old = np.clip(1.0 - Sw_old - Sg_old, 0.0, 1.0)
        acc_tot_old = So_old / self.pvt["Bo"](P_old) + \
                      Sw_old / self.pvt["Bw"](P_old) + \
                      Sg_old / self.pvt["Bg"](P_old)

        rows, cols, vals = [], [], []
        rhs = np.zeros(n)
        rhs -= self._pv / dt * (acc_tot - acc_tot_old)
        for c in range(n):
            rows.append(c); cols.append(c); vals.append(c_eff[c])

        # Flux terms
        def add_face_flux(a, b, Tgeo):
            up = a if P[a] >= P[b] else b
            Tt = Tgeo * lam_t[up]
            dP_face = P[b] - P[a]
            flux = Tt * dP_face
            rhs[a] += flux; rhs[b] -= flux
            rows.append(a); cols.append(a); vals.append(-Tt)
            rows.append(a); cols.append(b); vals.append(Tt)
            rows.append(b); cols.append(b); vals.append(-Tt)
            rows.append(b); cols.append(a); vals.append(Tt)

        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    add_face_flux(self._idx(i,j,k), self._idx(i+1,j,k), self._tx[i,j,k])
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    add_face_flux(self._idx(i,j,k), self._idx(i,j+1,k), self._ty[i,j,k])
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    add_face_flux(self._idx(i,j,k), self._idx(i,j,k+1), self._tz[i,j,k])

        # Wells
        for w in self.wells:
            c = w["cell"]
            if "bhp" in w:
                WI = self._well_index(c)
                dp = P[c] - w["bhp"]
                q = WI * lam_t[c] * dp
                rhs[c] -= q
                rows.append(c); cols.append(c); vals.append(-WI * lam_t[c])
            if "rate_oil" in w:
                rhs[c] -= w["rate_oil"]
            if "rate" in w:
                rhs[c] -= w["rate"]

        J = sp.csr_matrix((vals, (rows, cols)), shape=(n, n))
        J = J + 1e-20 * sp.eye(n, format="csr")
        dP = spsolve(J, -rhs)
        dP_max = 2.0e6  # limit pressure change per solve for stability
        scale_P = min(1.0, dP_max / (np.max(np.abs(dP)) + 1e-30))
        P = P + scale_P * dP

        # ---- Phase 2: Saturation transport (explicit with subcycling) ----
        Bw = self.pvt["Bw"](P); Bg = self.pvt["Bg"](P)
        Bo = self.pvt["Bo"](P); Rs = np.asarray(self.pvt["Rs"](P), float)
        Bw_old = self.pvt["Bw"](P_old); Bg_old = self.pvt["Bg"](P_old)
        Bo_old = self.pvt["Bo"](P_old)
        Rs_old = np.asarray(self.pvt["Rs"](P_old), float)
        So_old = np.clip(1.0 - Sw_old - Sg_old, 0.0, 1.0)

        # Compute water and free-gas fluxes at new P, current Sw/Sg
        # Initial CFL estimate using dt (will be refined after first call)
        dt_sub = dt  # initial estimate, refined below
        def compute_sat_fluxes(P_cur, Sw_cur, Sg_cur):
            lam_w_c, lam_o_c, lam_g_c = self._mobility(P_cur, Sw_cur, Sg_cur)
            lam_t_c = lam_w_c + lam_o_c + lam_g_c
            fw_c = lam_w_c / (lam_t_c + 1e-30)
            fg_c = lam_g_c / (lam_t_c + 1e-30)
            ft = np.zeros(n); fw_arr = np.zeros(n); fg_free = np.zeros(n)
            def add_f(a, b, Tgeo):
                up = a if P_cur[a] >= P_cur[b] else b
                Tt = Tgeo * lam_t_c[up]
                q = Tt * (P_cur[b] - P_cur[a])
                ft[a] += q; ft[b] -= q
                fw_arr[a] += fw_c[up] * q; fw_arr[b] -= fw_c[up] * q
                fg_free[a] += fg_c[up] * q; fg_free[b] -= fg_c[up] * q
            for k in range(nz):
                for j in range(ny):
                    for i in range(nx - 1):
                        add_f(self._idx(i,j,k), self._idx(i+1,j,k), self._tx[i,j,k])
            for k in range(nz):
                for j in range(ny - 1):
                    for i in range(nx):
                        add_f(self._idx(i,j,k), self._idx(i,j+1,k), self._ty[i,j,k])
            for k in range(nz - 1):
                for j in range(ny):
                    for i in range(nx):
                        add_f(self._idx(i,j,k), self._idx(i,j,k+1), self._tz[i,j,k])
            for w in self.wells:
                c = w["cell"]
                if "bhp" in w:
                    WI = self._well_index(c)
                    dp = P_cur[c] - w["bhp"]
                    q = WI * lam_t_c[c] * dp
                    # Cap well rate to prevent over-production in a single
                    # sub-step.  Without this, a BHP well with a large dp
                    # can produce many times the cell's pore volume per
                    # step, draining all fluid before gas can evolve.
                    q_max = 0.1 * self._pv[c] / dt_sub
                    q = np.clip(q, -q_max, q_max)
                    ft[c] -= q
                    if q > 0:
                        # Producing: split by fractional flow
                        fw_arr[c] -= fw_c[c] * q
                        fg_free[c] -= fg_c[c] * q
                    else:
                        # Injecting: inject water by default (no free gas)
                        fw_arr[c] -= q  # all injected flux is water
                if "rate_water" in w:
                    fw_arr[c] -= w["rate_water"]; ft[c] -= w["rate_water"]
                if "rate_gas" in w:
                    fg_free[c] -= w["rate_gas"]
            return ft, fw_arr, fg_free

        ft, fw_arr, fg_free = compute_sat_fluxes(P, Sw, Sg)
        max_flux = max(np.max(np.abs(fw_arr)), np.max(np.abs(fg_free)) + 1e-30)
        min_pv = np.min(self._pv)
        dt_cfl = 0.25 * min_pv / (max_flux + 1e-30)
        n_sub = min(max(1, int(np.ceil(dt / dt_cfl))), 200)
        dt_sub = dt / n_sub

        Sw_cur = Sw_old.copy()
        Sg_cur = Sg_old.copy()
        for sub in range(n_sub):
            ft, fw_arr, fg_free = compute_sat_fluxes(P, Sw_cur, Sg_cur)
            Sw_cur = Sw_cur + Bw * dt_sub * fw_arr / self._pv
            Sg_cur = Sg_cur + Bg * dt_sub * fg_free / self._pv
            Sw_cur = np.clip(Sw_cur, self.rp["swr"], 1.0 - self.rp["sor"])
            Sg_cur = np.clip(Sg_cur, 0.0, 1.0 - Sw_cur - 1e-8)

        # ---- Phase 3: Gas flash (dissolved ↔ free equilibrium) ----
        # Use the TRANSPORTED saturations (Sw_cur, Sg_cur from Phase 2)
        # to determine oil saturation for the flash.  This avoids the
        # circular dependency where the flash's own Sg output feeds back
        # into the dissolved-capacity calculation.
        Rs_new = np.asarray(self.pvt["Rs"](P), float)
        Bo_new = self.pvt["Bo"](P)
        Bg_new = self.pvt["Bg"](P)

        # Total gas mass from stored state variable (old time step).
        # This is the conserved quantity — not recomputed from Sg/So
        # at old conditions, which would be pressure-dependent and
        # break conservation when pressure changes.
        gas_total_old = self.gas_total.copy()

        # Dissolved gas flux — gas moves with the oil phase (fractional flow
        # of oil × total flux × Rs/Bo) AND free gas flux (fg/Bg × total flux).
        # The total gas surface-volume flux is:
        #   gas_flux = q * (Rs*fo/Bo + fg/Bg)
        # where q is the total reservoir-volume flux (Tt * dP).
        lam_w_f, lam_o_f, lam_g_f = self._mobility(P, Sw_cur, Sg_cur)
        lam_t_f = lam_w_f + lam_o_f + lam_g_f
        fo_f = lam_o_f / (lam_t_f + 1e-30)
        fg_f = lam_g_f / (lam_t_f + 1e-30)
        gas_flux = np.zeros(n)
        def add_gf(a, b, Tgeo):
            up = a if P[a] >= P[b] else b
            Tt = Tgeo * lam_t_f[up]
            q = Tt * (P[b] - P[a])
            # Total gas flux: dissolved (Rs*fo/Bo) + free (fg/Bg)
            gas_coef = Rs_new[up] * fo_f[up] / Bo_new[up] + fg_f[up] / Bg_new[up]
            gas_flux[a] += gas_coef * q
            gas_flux[b] -= gas_coef * q
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    add_gf(self._idx(i,j,k), self._idx(i+1,j,k), self._tx[i,j,k])
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    add_gf(self._idx(i,j,k), self._idx(i,j+1,k), self._ty[i,j,k])
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    add_gf(self._idx(i,j,k), self._idx(i,j,k+1), self._tz[i,j,k])
        for w in self.wells:
            c = w["cell"]
            if "bhp" in w:
                WI = self._well_index(c)
                dp = P[c] - w["bhp"]
                q = WI * lam_t_f[c] * dp
                # Cap well rate to prevent draining cell in one step
                q_max = 0.1 * self._pv[c] / dt
                q = max(-q_max, min(q_max, q))
                if q > 0:
                    # Producing: gas leaves as both dissolved (in oil) and free
                    gas_coef = Rs_new[c] * fo_f[c] / Bo_new[c] + fg_f[c] / Bg_new[c]
                    gas_flux[c] -= gas_coef * q
                # else: injecting — no gas added (water injection by default)
            if "rate_gas" in w:
                gas_flux[c] -= w["rate_gas"]

        # Total gas mass at new time (conserved + flux).
        # The gas flux is divergence-free (sum = 0 in a closed system),
        # so gas_total_old + dt * gas_flux / pv conserves total gas.
        # However, gas mobility (krg/(mu_g*Bg)) can be 100-1000x larger
        # than oil mobility, so the free-gas flux can drain a cell's
        # gas_total far below zero in one step.  Clamping to zero would
        # destroy conservation (the drained gas still enters the
        # downstream cell).  Instead, we SCALE the entire flux by a
        # factor alpha <= 1 so that no cell goes below a small floor.
        # This preserves conservation (uniform scaling) while keeping
        # gas_total physically non-negative.
        gt_raw = gas_total_old + dt * gas_flux / self._pv
        # Find the maximum safe scaling: for cells where gas_flux < 0
        # (net outflow), require gas_total_old + alpha*dt*flux/pv >= floor.
        floor = 0.0  # allow gas_total to reach zero but not below
        alpha = 1.0
        neg_mask = gas_flux < 0
        if np.any(neg_mask):
            # alpha = gas_total_old * pv / (dt * |gas_flux|) for outflow cells
            denom_alpha = dt * (-gas_flux[neg_mask]) / self._pv[neg_mask]
            safe = np.where(denom_alpha > 1e-30,
                            gas_total_old[neg_mask] / denom_alpha, np.inf)
            alpha = min(1.0, float(np.min(safe)))
        gas_total_new = gas_total_old + alpha * dt * gas_flux / self._pv
        # Numerical safety: clamp tiny negatives from roundoff
        gas_total_new = np.maximum(gas_total_new, 0.0)

        # Equilibrium flash: solve for So, Sg given gas_total, Sw, P.
        # Constraints:
        #   (1) So + Sg = 1 - Sw  = So_max     (volume constraint)
        #   (2) Sg/Bg + Rs*So/Bo = gas_total   (gas mass conservation)
        #
        # Substituting Sg = So_max - So into (2):
        #   (So_max - So)/Bg + Rs*So/Bo = gas_total
        #   So_max/Bg - So/Bg + Rs*So/Bo = gas_total
        #   So * (Rs/Bo - 1/Bg) = gas_total - So_max/Bg
        #   So = (gas_total - So_max/Bg) / (Rs/Bo - 1/Bg)
        So_max = 1.0 - Sw_cur
        denom = Rs_new / Bo_new - 1.0 / Bg_new  # always negative (Rs/Bo << 1/Bg)
        numer = gas_total_new - So_max / Bg_new
        So_flash = numer / denom  # this is the equilibrium oil saturation

        # Three regimes:
        # (a) So_flash >= So_max → all gas dissolved, Sg = 0
        #     (gas_total <= Rs*So_max/Bo, undersaturated oil)
        # (b) So_flash <= 0 → all oil degassed, Sg = So_max
        #     (gas_total >= So_max/Bg, pure gas)
        # (c) 0 < So_flash < So_max → two-phase, Sg = So_max - So_flash
        Sg_flash = np.zeros(n)
        dissolved_cap = Rs_new * So_max / Bo_new
        free_cap = So_max / Bg_new

        # Regime (a): undersaturated — all gas stays dissolved
        mask_under = gas_total_new <= dissolved_cap
        # Regime (b): all free gas — no oil
        mask_over = gas_total_new >= free_cap
        # Regime (c): two-phase equilibrium
        mask_two = ~mask_under & ~mask_over

        Sg_final = np.where(mask_under, 0.0,
                            np.where(mask_over, So_max, So_max - So_flash))
        # Flash is solved EXACTLY — no limiter, no override.
        # The flash equation IS the gas mass balance, so solving it
        # exactly conserves gas by construction.
        Sg_final = np.clip(Sg_final, 0.0, 1.0 - Sw_cur - 1e-8)
        # Store gas_total_new for the step() method to save as self.gas_total
        self._gas_total_new = gas_total_new
        return P, Sw_cur, Sg_final

    def _well_index(self, c):
        """Peaceman well index for cell c (SI units)."""
        k_cell = self.rock.kx().ravel()[c]
        dx_arr = np.asarray(self.grid.neighbour_distances()[0]).ravel()
        dx = float(dx_arr[0]) if dx_arr.size > 0 else 30.0
        vol = float(self.grid.cell_volumes().ravel()[c])
        dy_arr = np.asarray(self.grid.neighbour_distances()[1]).ravel()
        dy = float(dy_arr[0]) if dy_arr.size > 0 else dx
        dz = vol / (dx * dy)
        re = 0.28 * dx; rw = 0.1
        return 2.0 * np.pi * np.sqrt(max(k_cell, 1e-30)) * dz / \
               max(np.log(re / rw), 1e-30)

    def _mass_balance_3ph(self, P, Sw, Sg, P_old, Sw_old, Sg_old, dt):
        """Total mass balance error (fraction)."""
        n = self.n
        Bo = self.pvt["Bo"](P); Bw = self.pvt["Bw"](P); Bg = self.pvt["Bg"](P)
        So = np.clip(1.0 - Sw - Sg, 0.0, 1.0)
        mass_new = (So / Bo + Sw / Bw + Sg / Bg) * self._pv
        Bo_o = self.pvt["Bo"](P_old); Bw_o = self.pvt["Bw"](P_old)
        Bg_o = self.pvt["Bg"](P_old)
        So_o = np.clip(1.0 - Sw_old - Sg_old, 0.0, 1.0)
        mass_old = (So_o / Bo_o + Sw_old / Bw_o + Sg_old / Bg_o) * self._pv
        dm = float(np.sum(mass_new - mass_old))
        # Well flux
        well_flux = 0.0
        for w in self.wells:
            c = w["cell"]
            if "rate" in w:
                well_flux += w["rate"]
            if "rate_oil" in w:
                well_flux += w["rate_oil"]
            if "rate_water" in w:
                well_flux += w["rate_water"]
            if "bhp" in w:
                lam_w, lam_o, lam_g = self._mobility(
                    np.array([P[c]]), np.array([Sw[c]]), np.array([Sg[c]]))
                # Use capped gas mobility (consistent with pressure solve)
                lam_g_cap = min(lam_g[0], 10.0 * lam_o[0])
                lam_t = lam_w[0] + lam_o[0] + lam_g_cap
                WI = self._well_index(c)
                well_flux += WI * lam_t * (P[c] - w["bhp"])
        expected = -well_flux * dt
        total = float(np.sum(mass_old)) + 1e-30
        return abs(dm - expected) / total

    def _residual(self, P, Sw, Sg, P_old, Sw_old, Sg_old, dt):
        """Residual vector [Rtot, Rw, Rg] of length 3n.

        Uses the standard black-oil variable substitution:
        * Rtot = total mass balance (pressure equation)
        * Rw   = water mass balance (Sw equation)
        * Rg   = gas mass balance (Sg equation)
        The oil equation is implied: Ro = Rtot - Rw - Rg.
        """
        n = self.n
        lam_w, lam_o, lam_g = self._mobility(P, Sw, Sg)
        lam_t = lam_w + lam_o + lam_g
        Bo = self.pvt["Bo"](P)
        Bw = self.pvt["Bw"](P)
        Bg = self.pvt["Bg"](P)
        Rs = np.asarray(self.pvt["Rs"](P), float)
        So = np.clip(1.0 - Sw - Sg, 0.0, 1.0)

        Rtot = np.zeros(n)
        Rw = np.zeros(n)
        Rg = np.zeros(n)
        pv = self._pv

        def add_face(a, b, Tgeo):
            up = a if P[a] >= P[b] else b
            lt_up = lam_t[up]
            Tt = Tgeo * lt_up
            dP = P[b] - P[a]
            flux = Tt * dP
            fw = lam_w[up] / (lam_t[up] + 1e-30)
            fo = lam_o[up] / (lam_t[up] + 1e-30)
            fg = lam_g[up] / (lam_t[up] + 1e-30)
            # total flux
            Rtot[a] += flux
            Rtot[b] -= flux
            # water flux
            Rw[a] += fw * flux
            Rw[b] -= fw * flux
            # gas flux (free gas + dissolved in oil)
            Rg[a] += (fg + Rs[up] * fo) * flux
            Rg[b] -= (fg + Rs[up] * fo) * flux

        nx, ny, nz = self.nx, self.ny, self.nz
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    add_face(self._idx(i,j,k), self._idx(i+1,j,k),
                             self._tx[i,j,k])
        for k in range(nz):
            for j in range(ny - 1):
                for i in range(nx):
                    add_face(self._idx(i,j,k), self._idx(i,j+1,k),
                             self._ty[i,j,k])
        for k in range(nz - 1):
            for j in range(ny):
                for i in range(nx):
                    add_face(self._idx(i,j,k), self._idx(i,j,k+1),
                             self._tz[i,j,k])

        # accumulation (backward Euler)
        Bo_old = self.pvt["Bo"](P_old)
        Bw_old = self.pvt["Bw"](P_old)
        Bg_old = self.pvt["Bg"](P_old)
        Rs_old = np.asarray(self.pvt["Rs"](P_old), float)
        So_old = np.clip(1.0 - Sw_old - Sg_old, 0.0, 1.0)
        # total accumulation
        acc_tot = (So / Bo + Sw / Bw + Sg / Bg)
        acc_tot_old = (So_old / Bo_old + Sw_old / Bw_old + Sg_old / Bg_old)
        Rtot += pv / dt * (acc_tot - acc_tot_old)
        # water accumulation
        Rw += pv / dt * (Sw / Bw - Sw_old / Bw_old)
        # gas accumulation (free + dissolved)
        acc_g = (Sg / Bg + Rs * So / Bo)
        acc_g_old = (Sg_old / Bg_old + Rs_old * So_old / Bo_old)
        Rg += pv / dt * (acc_g - acc_g_old)

        # wells — Peaceman well model for BHP (physically-correct coupling).
        # The well rate for each phase is q_p = WI * lam_p * (P_cell - bhp).
        # This enters the total, water, and gas equations as a source/sink.
        # For the total equation we also add the full Peaceman rate (sum of
        # all phase rates).  In SI units WI is small (~1e-11 for 1e-13 m²),
        # but the accumulation terms (Vp/dt) are also small for modest grids,
        # so the coupling is balanced and Newton converges.  No penalty —
        # the well is a physical Peaceman source, not a Dirichlet constraint.
        for w in self.wells:
            c = w["cell"]
            if "bhp" in w:
                bhp = w["bhp"]
                k_cell = self.rock.kx().ravel()[c]
                # Peaceman well index (SI): WI = 2*pi*sqrt(kx*ky)*dz / ln(re/rw)
                # dx from the first neighbour distance (constant for cartesian)
                dx_arr = np.asarray(self.grid.neighbour_distances()[0]).ravel()
                dx = float(dx_arr[0]) if dx_arr.size > 0 else 30.0
                # dz: cell volume / (dx*dy) for cartesian
                vol = float(self.grid.cell_volumes().ravel()[c])
                dy_arr = np.asarray(self.grid.neighbour_distances()[1]).ravel()
                dy = float(dy_arr[0]) if dy_arr.size > 0 else dx
                dz = vol / (dx * dy)
                re = 0.28 * dx
                rw = 0.1
                WI = 2.0 * np.pi * np.sqrt(max(k_cell, 1e-30)) * dz / \
                     max(np.log(re / rw), 1e-30)
                dp = P[c] - bhp  # positive = cell above BHP → production
                # Peaceman phase rates (positive = production out of cell)
                q_w = WI * lam_w[c] * dp
                q_o = WI * lam_o[c] * dp
                q_g_free = WI * lam_g[c] * dp
                q_g_diss = WI * Rs[c] * lam_o[c] * dp
                # Total equation: total production rate
                Rtot[c] -= (q_w + q_o + q_g_free + q_g_diss)
                # Water equation: water production rate
                Rw[c] -= q_w
                # Gas equation: free gas + dissolved gas production
                Rg[c] -= (q_g_free + q_g_diss)
            if "rate_oil" in w:
                Rtot[c] -= w["rate_oil"]
            if "rate_water" in w:
                Rw[c] -= w["rate_water"]
            if "rate_gas" in w:
                Rg[c] -= w["rate_gas"]

        return np.concatenate([Rtot, Rw, Rg])

    def _numerical_jacobian(self, P, Sw, Sg, P_old, Sw_old, Sg_old, dt):
        """Finite-difference Jacobian (3n x 3n).

        Uses relative perturbations: eps_P ~ 1e-3 * P (pressure scale),
        eps_S = 1e-6 (saturation is O(1)).  This avoids the catastrophic
        cancellation that a fixed absolute eps causes for pressure (P ~ 1e7).
        """
        n = self.n
        R0 = self._residual(P, Sw, Sg, P_old, Sw_old, Sg_old, dt)
        rows, cols, vals = [], [], []
        for c in range(n):
            # dR/dP[c] — relative perturbation
            eps_p = max(1e-3 * abs(P[c]), 1.0)
            P_p = P.copy(); P_p[c] += eps_p
            R_p = self._residual(P_p, Sw, Sg, P_old, Sw_old, Sg_old, dt)
            dR = (R_p - R0) / eps_p
            for r in range(3 * n):
                if abs(dR[r]) > 1e-30:
                    rows.append(r); cols.append(c); vals.append(dR[r])
            # dR/dSw[c]
            eps_s = 1e-6
            Sw_p = Sw.copy(); Sw_p[c] += eps_s
            R_p = self._residual(P, Sw_p, Sg, P_old, Sw_old, Sg_old, dt)
            dR = (R_p - R0) / eps_s
            for r in range(3 * n):
                if abs(dR[r]) > 1e-30:
                    rows.append(r); cols.append(n + c); vals.append(dR[r])
            # dR/dSg[c]
            Sg_p = Sg.copy(); Sg_p[c] += eps_s
            R_p = self._residual(P, Sw, Sg_p, P_old, Sw_old, Sg_old, dt)
            dR = (R_p - R0) / eps_s
            for r in range(3 * n):
                if abs(dR[r]) > 1e-30:
                    rows.append(r); cols.append(2 * n + c); vals.append(dR[r])
        return sp.csr_matrix((vals, (rows, cols)), shape=(3*n, 3*n))

    def run(self, total_time, dt=86400.0, save_every=1):
        """Run to ``total_time``. Returns snapshots [(t, P, Sw, Sg)]."""
        snaps = [(0.0, self.P.copy(), self.Sw.copy(), self.Sg.copy())]
        n_steps = int(np.ceil(total_time / dt))
        for step in range(1, n_steps + 1):
            t_step = min(dt, total_time - self.time)
            if t_step <= 0:
                break
            rep = self.step(t_step)
            if not rep.converged:
                break
            if step % save_every == 0:
                snaps.append((self.time, self.P.copy(),
                              self.Sw.copy(), self.Sg.copy()))
        return snaps
