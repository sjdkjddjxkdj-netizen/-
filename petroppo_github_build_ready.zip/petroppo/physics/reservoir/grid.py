"""
Reservoir simulation grids.

Provides structured Cartesian grids (1D, 2D, 3D) and corner-point grids
(the industry-standard format used by ECLIPSE/Intersect).  All grids expose
a uniform ``ReservoirGrid`` interface with cell volumes, transmissibility
geometrisers, and neighbour connectivity.

Design notes
------------
* Cell ordering follows the ECLIPSE convention: ``cell(i, j, k)`` has
  global index ``i + j*nx + k*nx*ny`` (I-fastest, then J, then K).
* Corner-point geometry stores 8 corner coordinates per cell so that
  faults, pinch-outs, and sloped layers are represented faithfully.
* A *cartesian* grid is a special case of corner-point with axis-aligned
  corners; the factory ``cartesian_grid`` builds one cheaply.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "ReservoirGrid",
    "cartesian_grid",
    "corner_point_grid",
    "GridError",
]


class GridError(Exception):
    """Raised for invalid grid construction or access."""


# ---------------------------------------------------------------------------
# Core grid class
# ---------------------------------------------------------------------------

@dataclass
class ReservoirGrid:
    """A structured (I, J, K) reservoir grid.

    Attributes
    ----------
    nx, ny, nz : int
        Number of cells along each axis.
    corners : np.ndarray, shape (nx, ny, nz, 8, 3)
        Eight corner coordinates per cell, ordered::

            6---7
           /|  /|
          4---5 |     (top face: 4,5,6,7  bottom face: 0,1,2,3)
          | 2-|-3
          |/  |/
          0---1

        Corner 0 is the (i, j, k) lower corner; corner 7 the diagonally
        opposite (i+1, j+1, k+1) upper corner.
    actnum : np.ndarray, shape (nx, ny, nz), bool
        Active-cell mask.  Inactive cells are skipped by the simulator.
    """

    nx: int
    ny: int
    nz: int
    corners: np.ndarray
    actnum: np.ndarray = field(default=None)

    # ------------------------------------------------------------------
    # construction
    # ------------------------------------------------------------------
    def __post_init__(self) -> None:
        if self.corners.shape != (self.nx, self.ny, self.nz, 8, 3):
            raise GridError(
                f"corners shape {self.corners.shape} incompatible with "
                f"grid dims ({self.nx},{self.ny},{self.nz})"
            )
        if self.actnum is None:
            self.actnum = np.ones((self.nx, self.ny, self.nz), dtype=bool)
        elif self.actnum.shape != (self.nx, self.ny, self.nz):
            raise GridError("actnum shape mismatch")

    # ------------------------------------------------------------------
    # basic properties
    # ------------------------------------------------------------------
    @property
    def n_cells(self) -> int:
        return self.nx * self.ny * self.nz

    @property
    def n_active(self) -> int:
        return int(self.actnum.sum())

    @property
    def shape(self) -> tuple[int, int, int]:
        return (self.nx, self.ny, self.nz)

    # ------------------------------------------------------------------
    # indexing helpers
    # ------------------------------------------------------------------
    def cell_index(self, i: int, j: int, k: int) -> int:
        """Global (flattened) index of cell (i, j, k)."""
        return i + j * self.nx + k * self.nx * self.ny

    def ijk_from_index(self, idx: int) -> tuple[int, int, int]:
        """Inverse of :meth:`cell_index`."""
        k, rem = divmod(idx, self.nx * self.ny)
        j, i = divmod(rem, self.nx)
        return i, j, k

    # ------------------------------------------------------------------
    # geometry
    # ------------------------------------------------------------------
    def cell_centres(self) -> np.ndarray:
        """Centroid of every cell, shape (nx, ny, nz, 3)."""
        return self.corners.mean(axis=3)

    def cell_volumes(self) -> np.ndarray:
        """Volume of each cell computed from the 8 corners.

        Uses a robust hexahedron decomposition into 6 tetrahedra
        (Fan et al. pattern) that is stable for mildly skewed cells.
        """
        c = self.corners  # (nx, ny, nz, 8, 3)
        tets = np.array([
            [0, 1, 2, 4],
            [1, 2, 4, 5],
            [2, 4, 5, 6],
            [2, 3, 5, 7],
            [2, 4, 6, 7],
            [2, 5, 6, 7],
        ])
        vols = np.zeros(self.shape)
        for tet in tets:
            a = c[..., tet[0], :]
            b = c[..., tet[1], :]
            d = c[..., tet[2], :]
            e = c[..., tet[3], :]
            vol = np.abs(np.einsum("...i,...i->...", b - a,
                                   np.cross(d - a, e - a))) / 6.0
            vols += vol
        return vols

    def cell_dxyz(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Approximate cell extents (dx, dy, dz) from corner spans."""
        c = self.corners
        dx = 0.5 * (
            np.linalg.norm(c[..., 1, :] - c[..., 0, :], axis=-1)
            + np.linalg.norm(c[..., 3, :] - c[..., 2, :], axis=-1)
        )
        dy = 0.5 * (
            np.linalg.norm(c[..., 2, :] - c[..., 0, :], axis=-1)
            + np.linalg.norm(c[..., 3, :] - c[..., 1, :], axis=-1)
        )
        dz = 0.5 * (
            np.linalg.norm(c[..., 4, :] - c[..., 0, :], axis=-1)
            + np.linalg.norm(c[..., 7, :] - c[..., 3, :], axis=-1)
        )
        return dx, dy, dz

    # ------------------------------------------------------------------
    # neighbour connectivity & transmissibility geometry
    # ------------------------------------------------------------------
    def face_area_x(self) -> np.ndarray:
        """Area of the (i+1/2) face between cell i and i+1, shape (nx-1, ny, nz).

        Uses the four corners with i_corner = 1 (the high-i face): corners
        1, 3, 5, 7 of cell i.
        """
        c = self.corners
        p0 = c[:-1, :, :, 1, :]
        p1 = c[:-1, :, :, 3, :]
        p2 = c[:-1, :, :, 5, :]
        p3 = c[:-1, :, :, 7, :]
        return _quad_area(p0, p1, p2, p3)

    def face_area_y(self) -> np.ndarray:
        """Area of the (j+1/2) face, shape (nx, ny-1, nz).

        Uses the four corners with j_corner = 1 (the high-j face): corners
        2, 3, 6, 7 of cell j.
        """
        c = self.corners
        p0 = c[:, :-1, :, 2, :]
        p1 = c[:, :-1, :, 3, :]
        p2 = c[:, :-1, :, 6, :]
        p3 = c[:, :-1, :, 7, :]
        return _quad_area(p0, p1, p2, p3)

    def face_area_z(self) -> np.ndarray:
        """Area of the (k+1/2) face (top face), shape (nx, ny, nz-1)."""
        c = self.corners
        p0 = c[:, :, :-1, 4, :]
        p1 = c[:, :, :-1, 5, :]
        p2 = c[:, :, :-1, 6, :]
        p3 = c[:, :, :-1, 7, :]
        return _quad_area(p0, p1, p2, p3)

    def neighbour_distances(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Centre-to-centre distances between neighbours in each direction."""
        centres = self.cell_centres()
        dx = np.linalg.norm(centres[1:, :, :, :] - centres[:-1, :, :, :], axis=-1)
        dy = np.linalg.norm(centres[:, 1:, :, :] - centres[:, :-1, :, :], axis=-1)
        dz = np.linalg.norm(centres[:, :, 1:, :] - centres[:, :, :-1, :], axis=-1)
        return dx, dy, dz


# ---------------------------------------------------------------------------
# Geometry helper
# ---------------------------------------------------------------------------

def _quad_area(p0, p1, p2, p3) -> np.ndarray:
    """Area of a (possibly non-planar) quadrilateral from 4 points.

    Splits into two triangles and sums their areas.
    """
    a1 = 0.5 * np.linalg.norm(np.cross(p1 - p0, p3 - p0), axis=-1)
    a2 = 0.5 * np.linalg.norm(np.cross(p1 - p2, p3 - p2), axis=-1)
    return a1 + a2


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------

def cartesian_grid(
    nx: int,
    ny: int,
    nz: int,
    dx: float | np.ndarray = 1.0,
    dy: float | np.ndarray = 1.0,
    dz: float | np.ndarray = 1.0,
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0),
    actnum: Optional[np.ndarray] = None,
) -> ReservoirGrid:
    """Build an axis-aligned uniform (or per-cell) Cartesian grid.

    Parameters
    ----------
    nx, ny, nz : int
        Cell counts.
    dx, dy, dz : float or array
        Cell sizes.  Scalars give uniform grids; arrays of shape
        ``(nx,)``, ``(ny,)``, ``(nz,)`` give graded grids.
    origin : 3-tuple
        Coordinates of the lower corner of cell (0, 0, 0).
    actnum : optional bool array
        Active-cell mask.
    """
    dx_a = np.broadcast_to(np.asarray(dx, float), (nx,)).copy()
    dy_a = np.broadcast_to(np.asarray(dy, float), (ny,)).copy()
    dz_a = np.broadcast_to(np.asarray(dz, float), (nz,)).copy()

    x = np.concatenate([[0.0], np.cumsum(dx_a)]) + origin[0]
    y = np.concatenate([[0.0], np.cumsum(dy_a)]) + origin[1]
    z = np.concatenate([[0.0], np.cumsum(dz_a)]) + origin[2]

    corners = np.zeros((nx, ny, nz, 8, 3))
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                x0, x1 = x[i], x[i + 1]
                y0, y1 = y[j], y[j + 1]
                z0, z1 = z[k], z[k + 1]
                corners[i, j, k, 0] = [x0, y0, z0]
                corners[i, j, k, 1] = [x1, y0, z0]
                corners[i, j, k, 2] = [x0, y1, z0]
                corners[i, j, k, 3] = [x1, y1, z0]
                corners[i, j, k, 4] = [x0, y0, z1]
                corners[i, j, k, 5] = [x1, y0, z1]
                corners[i, j, k, 6] = [x0, y1, z1]
                corners[i, j, k, 7] = [x1, y1, z1]

    return ReservoirGrid(nx, ny, nz, corners, actnum=actnum)


def corner_point_grid(
    nx: int,
    ny: int,
    nz: int,
    coord_lines: np.ndarray,
    zcorn: np.ndarray,
    actnum: Optional[np.ndarray] = None,
) -> ReservoirGrid:
    """Build a corner-point grid from COORD / ZCORN arrays (ECLIPSE style).

    Parameters
    ----------
    coord_lines : array, shape (nx+1, ny+1, 6)
        For each (i, j) grid pillar, six values:
        ``[x_top, y_top, z_top, x_bot, y_bot, z_bot]``.
    zcorn : array, shape (nx, 2, ny, 2, nz, 2)
        Depth of each of the 8 corners of every cell, ordered
        ``(i, i_corner, j, j_corner, k, k_corner)``.
    actnum : optional
        Active-cell mask.
    """
    if coord_lines.shape != (nx + 1, ny + 1, 6):
        raise GridError(f"coord_lines must have shape ({nx+1},{ny+1},6)")
    if zcorn.shape != (nx, 2, ny, 2, nz, 2):
        raise GridError(
            f"zcorn must have shape ({nx},2,{ny},2,{nz},2), got {zcorn.shape}"
        )

    corners = np.zeros((nx, ny, nz, 8, 3))
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                for ci in range(8):
                    ic = ci % 2
                    jc = (ci // 2) % 2
                    kc = ci // 4
                    pil = coord_lines[i + ic, j + jc]  # (6,)
                    zt, zb = pil[2], pil[5]
                    zc = zcorn[i, ic, j, jc, k, kc]
                    if abs(zb - zt) < 1e-30:
                        t = 0.0
                    else:
                        t = (zc - zt) / (zb - zt)
                    xc = pil[0] + t * (pil[3] - pil[0])
                    yc = pil[1] + t * (pil[4] - pil[1])
                    corners[i, j, k, ci] = [xc, yc, zc]

    return ReservoirGrid(nx, ny, nz, corners, actnum=actnum)
