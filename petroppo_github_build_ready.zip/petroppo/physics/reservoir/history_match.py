"""petroppo V21 — Reservoir history-matching integration.

This module bridges the V21 black-oil reservoir simulator to the V20
:class:`ForwardModel` / :class:`InverseProblem` framework, enabling
automatic history matching of reservoir properties (permeability,
porosity, fault transmissibility) against observed well production
data (oil rate, water cut, bottom-hole pressure).

The :class:`ReservoirForwardModel` wraps a pre-configured
:class:`BlackOilSimulator` (or :class:`SinglePhaseSimulator`) and
exposes a configurable parameter vector so that the V20 optimisation
machinery (Levenberg–Marquardt, Gauss–Newton, MCMC) can be used to
calibrate the reservoir model against field data.

Parameterisation
----------------
The model vector ``m`` is a 1-D array whose interpretation is set at
construction time via ``param_config`` — a list of dicts:

    [{"type": "permeability", "cells": [0,1,...], "log": True},
     {"type": "porosity",     "cells": [...],     "log": False},
     {"type": "fault_trans",  "faces": [...],     "log": True}]

Each entry contributes ``len(cells)`` (or ``len(faces)``) parameters.
``log=True`` means the optimiser works in log-space (recommended for
permeability which spans orders of magnitude).

Data vector
-----------
The predicted data vector is a concatenation of time-series from all
wells, e.g. [oil_rate_P(t0), oil_rate_P(t1), ..., wct_P(t0), ...,
bhp_INJ(t0), ...].  The mapping is controlled by ``data_config``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Any

import numpy as np

from ..forward import ForwardModel
from .grid import ReservoirGrid
from .rock import RockProperties
from .pvt import BlackOilPVT, SinglePhaseFluid
from .wells import Well
from .single_phase import SinglePhaseSimulator
from .blackoil import BlackOilSimulator

__all__ = [
    "ReservoirForwardModel",
    "ParamConfig",
    "DataConfig",
    "HistoryMatchResult",
]


# -----------------------------------------------------------------------
# Configuration dataclasses
# -----------------------------------------------------------------------

@dataclass
class ParamConfig:
    """Description of one parameter group in the model vector."""

    ptype: str               # "permeability", "porosity", "fault_trans"
    indices: list[int]       # cell or face indices
    log: bool = True         # optimise in log-space?
    lower: float = 1e-18     # bounds (for clipping after exp)
    upper: float = 1e-8

    @property
    def size(self) -> int:
        return len(self.indices)


@dataclass
class DataConfig:
    """Which well responses to extract as observed data."""

    well_name: str
    quantity: str            # "oil_rate", "water_rate", "wct", "bhp", "pressure"
    times: list[float] = field(default_factory=list)  # observation times (s)


@dataclass
class HistoryMatchResult:
    """Outcome of a history-matching run."""

    model: np.ndarray            # best-fit parameter vector
    predicted: np.ndarray        # F(model)
    observed: np.ndarray
    misfit: float
    n_evaluations: int
    converged: bool
    history: list[float] = field(default_factory=list)  # misfit per iteration


# -----------------------------------------------------------------------
# Forward model
# -----------------------------------------------------------------------

class ReservoirForwardModel(ForwardModel):
    """Wrap a reservoir simulator as a V20 ``ForwardModel`` for history matching.

    Parameters
    ----------
    grid : ReservoirGrid
    rock : RockProperties (template — will be modified per parameter set)
    pvt : BlackOilPVT or SinglePhaseFluid
    wells : list[Well]
    param_configs : list[ParamConfig]
    data_configs : list[DataConfig]
    sim_type : "blackoil" or "single"
    total_time, dt : float — simulation schedule
    initial_pressure, initial_sw : float
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        rock: RockProperties,
        pvt: Any,
        wells: list[Well],
        param_configs: list[ParamConfig],
        data_configs: list[DataConfig],
        sim_type: str = "blackoil",
        total_time: float = 1e7,
        dt: float = 1e5,
        initial_pressure: float = 2e7,
        initial_sw: float = 0.2,
        save_every: int = 1,
    ) -> None:
        self.grid = grid
        self._rock_template = rock
        self.pvt = pvt
        self.wells = wells
        self.param_configs = param_configs
        self.data_configs = data_configs
        self.sim_type = sim_type
        self.total_time = total_time
        self.dt = dt
        self.initial_pressure = initial_pressure
        self.initial_sw = initial_sw
        self.save_every = save_every
        self._n_eval = 0

    # -- ForwardModel contract --------------------------------------------

    @property
    def n_params(self) -> int:
        return sum(pc.size for pc in self.param_configs)

    @property
    def n_data(self) -> int:
        return sum(len(dc.times) for dc in self.data_configs)

    @property
    def params_units(self) -> str:
        # mixed; return generic
        return "varied (m2 for perm, fraction for porosity)"

    @property
    def data_units(self) -> str:
        return "varied (m3/s for rates, Pa for pressure, fraction for WCT)"

    def default_model(self) -> np.ndarray:
        """Start from the template rock values."""
        m = np.zeros(self.n_params)
        i = 0
        for pc in self.param_configs:
            vals = self._get_param_values(pc, self._rock_template)
            if pc.log:
                vals = np.log(vals)
            m[i:i + pc.size] = vals
            i += pc.size
        return m

    def predict(self, model: np.ndarray) -> np.ndarray:
        """Run the reservoir simulator with the given parameters and extract
        the well responses at the requested observation times."""
        self._n_eval += 1
        rock = self._build_rock(model)
        if self.sim_type == "blackoil":
            sim = BlackOilSimulator(
                self.grid, rock, self.pvt, wells=self.wells,
                initial_pressure=self.initial_pressure,
                initial_sw=self.initial_sw,
            )
        else:
            sim = SinglePhaseSimulator(
                self.grid, rock, self.pvt, wells=self.wells,
                initial_pressure=self.initial_pressure,
            )
        report = sim.run(self.total_time, self.dt, save_every=self.save_every)

        # extract data at requested times
        data = np.zeros(self.n_data)
        di = 0
        for dc in self.data_configs:
            for t_obs in dc.times:
                val = self._extract(report, dc, t_obs)
                data[di] = val
                di += 1
        return data

    # -- internal helpers -------------------------------------------------

    def _get_param_values(self, pc: ParamConfig, rock: RockProperties) -> np.ndarray:
        if pc.ptype == "permeability":
            perm = rock.permeability
            if perm.ndim == 1:
                return perm[pc.indices]
            # flatten in C order (same as cell index convention)
            return perm.ravel()[pc.indices]
        elif pc.ptype == "porosity":
            return rock.porosity.ravel()[pc.indices]
        else:
            raise ValueError(f"Unknown param type: {pc.ptype}")

    def _build_rock(self, model: np.ndarray) -> RockProperties:
        """Construct a RockProperties from the model vector."""
        # start from template
        poro = self._rock_template.porosity.copy()
        perm = self._rock_template.permeability.copy()

        i = 0
        for pc in self.param_configs:
            vals = model[i:i + pc.size]
            if pc.log:
                vals = np.exp(vals)
            vals = np.clip(vals, pc.lower, pc.upper)
            if pc.ptype == "permeability":
                if perm.ndim == 1:
                    perm[pc.indices] = vals
                else:
                    perm_flat = perm.ravel()
                    perm_flat[pc.indices] = vals
                    perm = perm_flat.reshape(perm.shape)
            elif pc.ptype == "porosity":
                poro_flat = poro.ravel()
                poro_flat[pc.indices] = vals
                poro = poro_flat.reshape(poro.shape)
            i += pc.size

        return RockProperties(porosity=poro, permeability=perm)

    def _extract(self, report, dc: DataConfig, t_obs: float) -> float:
        """Extract a single data value from the simulation report."""
        times = np.array(report.times)
        # find closest time
        idx = int(np.argmin(np.abs(times - t_obs)))
        st = report.states[idx]
        if dc.quantity == "oil_rate":
            return st.well_rates.get(dc.well_name, {}).get("oil", 0.0)
        elif dc.quantity == "water_rate":
            return st.well_rates.get(dc.well_name, {}).get("water", 0.0)
        elif dc.quantity == "gas_rate":
            return st.well_rates.get(dc.well_name, {}).get("gas", 0.0)
        elif dc.quantity == "wct":
            r = st.well_rates.get(dc.well_name, {})
            oil = r.get("oil", 0.0)
            water = r.get("water", 0.0)
            tot = abs(oil) + abs(water)
            return water / tot if tot > 1e-30 else 0.0
        elif dc.quantity == "bhp":
            return st.well_bhp.get(dc.well_name, 0.0)
        elif dc.quantity == "pressure":
            return float(np.mean(st.pressure))
        else:
            raise ValueError(f"Unknown data quantity: {dc.quantity}")
