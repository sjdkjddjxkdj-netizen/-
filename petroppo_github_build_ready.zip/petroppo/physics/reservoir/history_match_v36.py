"""petroppo V36-2d/2e — Uncertainty-aware history matching harness.

This module provides the high-level API that ties together the V36
optimizers (:mod:`optim`) and ensemble methods (:mod:`esmda`) into a
unified history-matching workflow that:

1. **V36-2d**: Produces posterior P10/P50/P90 on both reservoir
   parameters and production forecasts, not just a single best-fit
   model.  This is the key differentiator vs. traditional
   deterministic history matching.

2. **V36-2e**: Assimilates **multiple data sources** simultaneously:
   - Production rates (oil, water, gas)
   - Bottom-hole pressure (BHP)
   - Well log data (porosity, saturation)
   - RFT/MDT pressure measurements
   - 4D seismic time-lapse (optional, via attribute changes)

Each data source has its own uncertainty (measurement error +
modeling error), which is accounted for in the data covariance.

Two workflows are provided:

* :class:`DeterministicHistoryMatch` — finds a single best-fit model
  using one of the gradient-free optimizers (CMA-ES, DE, NM, BO) or
  the V20 gradient-based methods (GN, LM).  Fast but gives no
  uncertainty estimate.

* :class:`UncertaintyHistoryMatch` — the V36 flagship: runs ES-MDA
  to produce a posterior ensemble, then propagates it through the
  simulator to get P10/P50/P90 production forecasts.  Also supports
  hybrid mode (optimizer to find the mode, ES-MDA for the spread).

The :class:`MultiSourceData` container handles the assembly of
heterogeneous data sources into a single observation vector and
covariance matrix, with proper scaling and weighting.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Union, Callable, Tuple

import numpy as np

from ..forward import ForwardModel
from ..regularization import RegularizationOperator, Tikhonov
from ..convergence import ConvergenceDiag
from .optim import CMAES, DifferentialEvolution, NelderMead, BayesianOptimization
from .esmda import ESMDA, ESMDAResult


__all__ = [
    "DataSource",
    "MultiSourceData",
    "MultiSourceForwardModel",
    "DeterministicHistoryMatch",
    "UncertaintyHistoryMatch",
    "HistoryMatchResultV36",
    "ForecastResult",
]


# -----------------------------------------------------------------------
# Data source definition
# -----------------------------------------------------------------------

@dataclass
class DataSource:
    """A single data source for history matching.

    Attributes
    ----------
    name : str
        Identifier (e.g. "producer_oil_rate", "inj_bhp").
    quantity : str
        What is being measured: "oil_rate", "water_rate", "gas_rate",
        "wct", "gor", "bhp", "pressure", "porosity", "saturation".
    times : list of float
        Observation times (seconds).
    values : ndarray
        Observed values (len = len(times)).
    uncertainty : ndarray or float
        Measurement uncertainty (std dev).  Can be a scalar (same for
        all) or per-observation array.
    well_name : str or None
        Well identifier (for well-specific data).
    cell_index : int or None
        Cell index (for grid-based data like logs, RFT).
    relative_weight : float
        Additional relative weight for this source (1.0 = default).
        Use < 1 to down-weight less reliable sources.
    """

    name: str
    quantity: str
    times: List[float]
    values: np.ndarray
    uncertainty: Union[np.ndarray, float] = 0.1
    well_name: Optional[str] = None
    cell_index: Optional[int] = None
    relative_weight: float = 1.0

    def __post_init__(self):
        self.values = np.asarray(self.values, dtype=float)
        n = len(self.times)
        if len(self.values) != n:
            raise ValueError(f"values length {len(self.values)} != times length {n}")
        if np.isscalar(self.uncertainty):
            self.uncertainty = np.full(n, float(self.uncertainty))
        else:
            self.uncertainty = np.asarray(self.uncertainty, dtype=float)
            if len(self.uncertainty) != n:
                raise ValueError("uncertainty length mismatch")

    @property
    def n_obs(self) -> int:
        return len(self.times)


# -----------------------------------------------------------------------
# Multi-source data container
# -----------------------------------------------------------------------

class MultiSourceData:
    """Assemble multiple :class:`DataSource` objects into a single
    observation vector and covariance matrix.

    The assembled observation vector is the concatenation of all
    source values (in the order sources were added).  The covariance
    is diagonal (sources are assumed independent) with entries
    sigma^2 / relative_weight.

    Provides mapping from the flat index back to (source, time) for
    diagnostics.
    """

    def __init__(self, sources: List[DataSource]):
        self.sources = sources
        self._build()

    def _build(self):
        values = []
        variances = []
        self.index_map = []  # (source_idx, time_idx)
        for s_idx, src in enumerate(self.sources):
            for t_idx in range(src.n_obs):
                values.append(src.values[t_idx])
                variances.append((src.uncertainty[t_idx] / np.sqrt(src.relative_weight)) ** 2)
                self.index_map.append((s_idx, t_idx))

        self.observed = np.array(values)
        self.cov_diag = np.array(variances)
        self.n_total = len(values)

    @property
    def data_cov(self) -> np.ndarray:
        """Diagonal data covariance matrix."""
        return self.cov_diag

    def decompose(self, flat_pred: np.ndarray) -> Dict[str, np.ndarray]:
        """Split a flat prediction vector back into per-source arrays."""
        result = {}
        for s_idx, src in enumerate(self.sources):
            mask = np.array([m[0] == s_idx for m in self.index_map])
            result[src.name] = flat_pred[mask]
        return result

    def summary(self) -> str:
        lines = [f"MultiSourceData: {self.n_total} observations from {len(self.sources)} sources"]
        for src in self.sources:
            lines.append(f"  {src.name}: {src.n_obs} obs, quantity={src.quantity}, "
                        f"uncertainty={src.uncertainty.mean():.4g}, weight={src.relative_weight}")
        return "\n".join(lines)


# -----------------------------------------------------------------------
# Multi-source forward model wrapper
# -----------------------------------------------------------------------

class MultiSourceForwardModel(ForwardModel):
    """Wrap a reservoir simulator to extract multi-source predictions.

    This wraps a :class:`ReservoirForwardModel` (or any ForwardModel)
    and maps its output to the multi-source observation layout defined
    by a :class:`MultiSourceData` container.

    For the V36 implementation, the underlying forward model is
    expected to produce a flat prediction vector that is already in
    the multi-source layout (i.e. the :class:`ReservoirForwardModel`
    data_configs should match the :class:`MultiSourceData` sources).
    This wrapper simply passes through, but provides a clean interface
    and handles simulation failures gracefully.

    Parameters
    ----------
    base_forward : ForwardModel
        The underlying forward model (e.g. ReservoirForwardModel).
    data : MultiSourceData
        The multi-source data layout.
    """

    def __init__(self, base_forward: ForwardModel, data: MultiSourceData):
        self.base = base_forward
        self.data = data
        if base_forward.n_data != data.n_total:
            raise ValueError(
                f"Base forward n_data={base_forward.n_data} != "
                f"MultiSourceData n_total={data.n_total}")

    @property
    def n_params(self) -> int:
        return self.base.n_params

    @property
    def n_data(self) -> int:
        return self.data.n_total

    @property
    def params_units(self) -> str:
        return self.base.params_units

    @property
    def data_units(self) -> str:
        return "multi-source"

    def predict(self, model: np.ndarray) -> np.ndarray:
        try:
            pred = self.base.predict(model)
        except Exception:
            return np.full(self.n_data, 1e30)
        return pred

    def default_model(self) -> np.ndarray:
        return self.base.default_model()


# -----------------------------------------------------------------------
# Result containers
# -----------------------------------------------------------------------

@dataclass
class ForecastResult:
    """P10/P50/P90 production forecast from a posterior ensemble.

    Attributes
    ----------
    times : ndarray
        Forecast times.
    p10, p50, p90 : ndarray
        Percentile curves (each shape = (n_times,) for a single
        quantity, or (n_quantities, n_times) for multiple).
    ensemble : ndarray
        Full ensemble of forecast trajectories (Ne, n_times) or
        (Ne, n_quantities, n_times).
    quantity : str
        What is being forecast (e.g. "oil_rate", "cum_oil").
    """

    times: np.ndarray
    p10: np.ndarray
    p50: np.ndarray
    p90: np.ndarray
    ensemble: np.ndarray
    quantity: str = ""

    @property
    def uncertainty_band(self) -> np.ndarray:
        """P90 - P10 spread at each time."""
        return self.p90 - self.p10


@dataclass
class HistoryMatchResultV36:
    """Complete result of a V36 history-matching run.

    Attributes
    ----------
    method : str
        "deterministic" or "uncertainty".
    best_model : ndarray or None
        Best-fit model (deterministic mode).
    posterior : ndarray or None
        Posterior ensemble (uncertainty mode, shape Ne x n_params).
    prior : ndarray or None
        Prior ensemble (uncertainty mode).
    misfit : float
        Final misfit of best model (deterministic) or mean misfit
        (uncertainty).
    converged : bool
    n_evaluations : int
        Number of forward model evaluations.
    diagnostics : ConvergenceDiag or ESMDAResult
        Optimization diagnostics.
    param_p10/p50/p90 : ndarray or None
        Parameter percentiles (uncertainty mode).
    """

    method: str
    best_model: Optional[np.ndarray] = None
    posterior: Optional[np.ndarray] = None
    prior: Optional[np.ndarray] = None
    misfit: float = 0.0
    converged: bool = False
    n_evaluations: int = 0
    diagnostics: Any = None
    param_p10: Optional[np.ndarray] = None
    param_p50: Optional[np.ndarray] = None
    param_p90: Optional[np.ndarray] = None
    forecast: Optional[ForecastResult] = None


# -----------------------------------------------------------------------
# Deterministic history match
# -----------------------------------------------------------------------

class DeterministicHistoryMatch:
    """Single best-fit model via gradient-free optimization.

    Parameters
    ----------
    forward : ForwardModel
        The forward model (typically wrapped in MultiSourceForwardModel).
    data : MultiSourceData
        Observed data + uncertainties.
    optimizer : str
        "cmaes", "de", "nelder_mead", "bayesian", "gauss_newton",
        " levenberg_marquardt".
    bounds : tuple(lower, upper) or None
        Parameter bounds (required for DE and BO).
    reg : RegularizationOperator or None
        Regularization (default: Tikhonov with small alpha).
    optimizer_kwargs : dict
        Additional kwargs passed to the optimizer constructor.
    """

    def __init__(self,
                 forward: ForwardModel,
                 data: MultiSourceData,
                 optimizer: str = "cmaes",
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 reg: Optional[RegularizationOperator] = None,
                 optimizer_kwargs: Optional[dict] = None):
        self.forward = forward
        self.data = data
        self.optimizer_name = optimizer
        self.bounds = bounds
        self.reg = reg or Tikhonov(forward.n_params, alpha=1e-4,
                                    m_ref=forward.default_model())
        self.optimizer_kwargs = optimizer_kwargs or {}

    def _build_optimizer(self):
        name = self.optimizer_name.lower()
        kwargs = self.optimizer_kwargs.copy()
        if name == "cmaes":
            return CMAES(bounds=self.bounds, **kwargs)
        elif name == "de":
            if self.bounds is None:
                raise ValueError("DE requires bounds")
            return DifferentialEvolution(bounds=self.bounds, **kwargs)
        elif name in ("nelder_mead", "nm", "nelder-mead"):
            return NelderMead(bounds=self.bounds, **kwargs)
        elif name in ("bayesian", "bo", "bayesopt"):
            if self.bounds is None:
                raise ValueError("Bayesian optimization requires bounds")
            return BayesianOptimization(bounds=self.bounds, **kwargs)
        elif name in ("gauss_newton", "gn", "gauss-newton"):
            from ..optimization import GaussNewton
            return GaussNewton(**kwargs)
        elif name in ("levenberg_marquardt", "lm", "levenberg-marquardt"):
            from ..optimization import LevenbergMarquardt
            return LevenbergMarquardt(**kwargs)
        else:
            raise ValueError(f"Unknown optimizer: {name}")

    def run(self, initial_model: Optional[np.ndarray] = None,
            max_iter: int = 100, tolerance: float = 1e-6,
            seed: Optional[int] = None) -> HistoryMatchResultV36:
        """Run the deterministic history match."""
        if initial_model is None:
            initial_model = self.forward.default_model()

        if seed is not None:
            self.optimizer_kwargs["seed"] = seed

        opt = self._build_optimizer()
        weights = 1.0 / self.data.cov_diag  # 1/sigma^2

        best_model, diag = opt.optimize(
            self.forward, self.data.observed, self.reg,
            initial_model, weights=weights,
            max_iter=max_iter, tolerance=tolerance)

        pred = self.forward.predict(best_model)
        residual = self.data.observed - pred
        misfit = 0.5 * float(np.dot(weights * residual, residual))

        n_eval = getattr(self.forward, '_n_eval', diag.n_iter)

        return HistoryMatchResultV36(
            method="deterministic",
            best_model=best_model,
            misfit=misfit,
            converged=diag.converged() if hasattr(diag, 'converged') else False,
            n_evaluations=n_eval,
            diagnostics=diag,
        )


# -----------------------------------------------------------------------
# Uncertainty-aware history match (V36 flagship)
# -----------------------------------------------------------------------

class UncertaintyHistoryMatch:
    """Posterior ensemble via ES-MDA, with P10/P50/P90 production forecasts.

    This is the V36 flagship history-matching method.  It:

    1. Generates a prior ensemble (Gaussian or lognormal).
    2. Runs ES-MDA to assimilate all data sources.
    3. Computes P10/P50/P90 on parameters.
    4. Optionally propagates the posterior ensemble through the
       forward model to get P10/P50/P90 production forecasts.

    Parameters
    ----------
    forward : ForwardModel
        The multi-source forward model.
    data : MultiSourceData
        Observed data + uncertainties.
    n_ensemble : int
        Ensemble size (50–200 typical; more = better stats but slower).
    n_assim : int
        Number of ES-MDA assimilation iterations.
    prior_mean : ndarray
        Prior mean parameter vector.
    prior_std : ndarray
        Prior standard deviation per parameter.
    prior_dist : "normal" or "lognormal"
        Prior distribution.  Lognormal recommended for permeability.
    bounds : tuple(lower, upper) or None
        Prior bounds (for clipping).
    localization_radius : float or None
        ES-MDA localization radius (requires param_coords).
    param_coords : ndarray or None
        Spatial coordinates of parameters (for localization).
    inflation : float
        Ensemble inflation factor (1.0 = off, 1.01–1.05 moderate).
    hybrid_optimizer : str or None
        If set, first run a deterministic optimizer to find the mode,
        then center the prior ensemble around it before ES-MDA.
    seed : int or None
    """

    def __init__(self,
                 forward: ForwardModel,
                 data: MultiSourceData,
                 n_ensemble: int = 50,
                 n_assim: int = 4,
                 prior_mean: Optional[np.ndarray] = None,
                 prior_std: Optional[np.ndarray] = None,
                 prior_dist: str = "normal",
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 localization_radius: Optional[float] = None,
                 param_coords: Optional[np.ndarray] = None,
                 inflation: float = 1.0,
                 hybrid_optimizer: Optional[str] = None,
                 seed: Optional[int] = None):
        self.forward = forward
        self.data = data
        self.n_ensemble = n_ensemble
        self.n_assim = n_assim
        self.prior_mean = prior_mean if prior_mean is not None else forward.default_model()
        self.prior_std = prior_std if prior_std is not None else 0.5 * np.abs(self.prior_mean) + 0.1
        self.prior_dist = prior_dist
        self.bounds = bounds
        self.localization_radius = localization_radius
        self.param_coords = param_coords
        self.inflation = inflation
        self.hybrid_optimizer = hybrid_optimizer
        self.seed = seed

    def _generate_prior(self, center: Optional[np.ndarray] = None) -> np.ndarray:
        mean = center if center is not None else self.prior_mean
        lower = self.bounds[0] if self.bounds is not None else None
        upper = self.bounds[1] if self.bounds is not None else None
        return ESMDA.generate_prior(
            mean, self.prior_std, n_ensemble=self.n_ensemble,
            dist=self.prior_dist, lower=lower, upper=upper, seed=self.seed)

    def run(self, max_iter: int = 100, tolerance: float = 1e-6,
            forecast_forward: Optional[ForwardModel] = None,
            forecast_times: Optional[np.ndarray] = None,
            forecast_quantity: str = "oil_rate",
            verbose: bool = False) -> HistoryMatchResultV36:
        """Run the uncertainty-aware history match.

        Parameters
        ----------
        max_iter : int
            Max iterations for the hybrid optimizer (if used).
        tolerance : float
            Convergence tolerance.
        forecast_forward : ForwardModel or None
            If provided, run this forward model on the posterior
            ensemble to produce production forecasts.  This is
            typically a reservoir simulator configured for the
            forecast period (not the history period).
        forecast_times : ndarray or None
            Times at which to extract forecasts (for labeling).
        forecast_quantity : str
            Label for the forecast result.
        verbose : bool

        Returns
        -------
        result : HistoryMatchResultV36
        """
        center = None

        # Hybrid mode: find the mode first, center the prior around it
        if self.hybrid_optimizer is not None:
            if verbose:
                print("V36 HM: Hybrid mode — running optimizer to find mode...")
            dhm = DeterministicHistoryMatch(
                self.forward, self.data, optimizer=self.hybrid_optimizer,
                bounds=self.bounds)
            det_result = dhm.run(max_iter=max_iter, tolerance=tolerance, seed=self.seed)
            center = det_result.best_model
            if verbose:
                print(f"V36 HM: Optimizer mode found, misfit={det_result.misfit:.4e}")

        # Generate prior
        prior = self._generate_prior(center=center)
        if verbose:
            print(f"V36 HM: Generated prior ensemble: {prior.shape}")
            print(f"V36 HM: Prior mean: {prior.mean(axis=0)[:5]}...")

        # Run ES-MDA
        esmda = ESMDA(
            self.forward, self.data.observed, self.data.data_cov,
            n_assim=self.n_assim,
            localization_radius=self.localization_radius,
            param_coords=self.param_coords,
            inflation=self.inflation,
            seed=self.seed)
        esmda_result = esmda.run(prior, verbose=verbose)

        # Compute parameter percentiles (SPE convention:
        # P10 = 90th pct = optimistic/high-side, P90 = 10th pct = pessimistic/low-side)
        p90_low, p50, p10_high = np.percentile(esmda_result.posterior, [10, 50, 90], axis=0)
        p10, p90 = p10_high, p90_low

        # Production forecast (optional)
        forecast = None
        if forecast_forward is not None:
            if verbose:
                print("V36 HM: Propagating posterior ensemble for forecasts...")
            Ne = esmda_result.posterior.shape[0]
            forecast_ensemble = []
            for i in range(Ne):
                try:
                    fp = forecast_forward.predict(esmda_result.posterior[i])
                    forecast_ensemble.append(fp)
                except Exception:
                    forecast_ensemble.append(np.full(forecast_forward.n_data, np.nan))
            forecast_ensemble = np.array(forecast_ensemble)

            # Handle NaNs
            valid = ~np.isnan(forecast_ensemble).any(axis=1)
            if valid.sum() < 3:
                if verbose:
                    print("V36 HM: WARNING — too many failed forecasts")
            else:
                forecast_ensemble = forecast_ensemble[valid]

            fp90_low, fp50, fp10_high = np.percentile(forecast_ensemble, [10, 50, 90], axis=0)
            fp10, fp90 = fp10_high, fp90_low
            times = forecast_times if forecast_times is not None else np.arange(forecast_ensemble.shape[1])
            forecast = ForecastResult(
                times=times, p10=fp10, p50=fp50, p90=fp90,
                ensemble=forecast_ensemble, quantity=forecast_quantity)

        final_misfit = float(np.mean(esmda_result.misfit_history[-1]))

        return HistoryMatchResultV36(
            method="uncertainty",
            posterior=esmda_result.posterior,
            prior=esmda_result.prior,
            misfit=final_misfit,
            converged=esmda_result.converged,
            n_evaluations=self.n_ensemble * (self.n_assim + 1) * 2,  # approx
            diagnostics=esmda_result,
            param_p10=p10,
            param_p50=p50,
            param_p90=p90,
            forecast=forecast,
        )
