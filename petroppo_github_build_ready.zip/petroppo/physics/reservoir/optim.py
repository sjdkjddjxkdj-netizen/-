"""petroppo V36-2a — Gradient-free optimizers for reservoir history matching.

These optimizers complement the V20 gradient-based solvers
(GaussNewton, LevenbergMarquardt, Occam, IRLS) in
:mod:`petroppo.physics.optimization` with **derivative-free** methods
that are essential for reservoir history matching because:

1. The forward map F(m) involves a full reservoir simulation that is
   expensive and noisy (adaptive time-stepping, CFL sub-cycling, flash
   non-linearities).  Finite-difference Jacobians are unreliable and
   costly (2*n_params simulations per iteration).

2. The misfit landscape is multi-modal — different permeability
   fields can reproduce the same production history.  Gradient methods
   converge to the nearest local minimum; population-based methods
   explore the space globally.

3. Reservoir parameters (permeability) span orders of magnitude, so
   log-space optimization with bounds is required.  All optimizers here
   support box constraints via clip-and-evaluate.

Optimizers
----------
* :class:`CMAES` — Covariance Matrix Adaptation Evolution Strategy
  (Hansen & Ostermeier 2001).  State-of-the-art for continuous
  black-box optimization with 3–100 parameters.  Adapts a full
  covariance matrix, so it learns parameter correlations.

* :class:`DifferentialEvolution` — Storn & Price (1997).  Population-based
  with mutation/crossover.  Robust on rugged landscapes, parallel-friendly.

* :class:`NelderMead` — Classic simplex (Nelder & Mead 1965).  Good for
  low-dimensional (n ≤ 10) smooth problems; no population needed.

All three follow the V20 :class:`Optimizer` contract::

    optimize(forward, observed, reg, initial_model, weights=None,
             max_iter=..., tolerance=...) -> (model, ConvergenceDiag)

The objective is::

    Phi(m) = 0.5 * ||W^{1/2} (d_obs - F(m))||^2 + R(m)

where ``W = 1/sigma^2`` (data weights) and ``R`` is the regularization
operator (use :class:`Tikhonov` or :class:`Smoothness` from
:mod:`petroppo.physics.regularization`).
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple, List

import numpy as np

from ..forward import ForwardModel
from ..regularization import RegularizationOperator
from ..convergence import ConvergenceDiag
from ..optimization import Optimizer


__all__ = [
    "CMAES",
    "DifferentialEvolution",
    "NelderMead",
    "BayesianOptimization",
]


# -----------------------------------------------------------------------
# Helper: objective evaluation
# -----------------------------------------------------------------------

def _objective(forward: ForwardModel, observed: np.ndarray,
                reg: RegularizationOperator, model: np.ndarray,
                W: np.ndarray) -> Tuple[float, float, float]:
    """Return (total, data_misfit, reg_value) for a single model.

    Handles simulation failures gracefully — if ``predict`` raises
    (e.g. Newton non-convergence, negative saturations), return +inf
    so the optimizer steers away from that region.
    """
    try:
        pred = forward.predict(np.asarray(model, dtype=float))
    except Exception:
        return 1e30, 1e30, 0.0
    r = observed - pred
    data_misfit = 0.5 * float(np.dot(W * r, r))
    reg_val = float(reg.value(np.asarray(model, dtype=float)))
    total = data_misfit + reg_val
    if not np.isfinite(total):
        total = 1e30
    return total, data_misfit, reg_val


def _clip_to_bounds(model: np.ndarray, lower: np.ndarray,
                    upper: np.ndarray) -> np.ndarray:
    return np.clip(model, lower, upper)


# =====================================================================
# CMA-ES (Covariance Matrix Adaptation Evolution Strategy)
# =====================================================================

class CMAES(Optimizer):
    """Covariance Matrix Adaptation Evolution Strategy.

    Implements the rank-μ update with cumulative step-size adaptation
    (CSA) following Hansen & Ostermeier (2001) and the summary in
    Hansen (2016) "The CMA Evolution Strategy: A Tutorial".

    The algorithm maintains a search distribution N(m, sigma^2 * C):
      - m: mean (current best estimate)
      - sigma: step-size
      - C: covariance matrix (learns parameter correlations)

    At each generation:
      1. Sample lambda offspring: x_i ~ N(m, sigma^2 * C)
      2. Evaluate and rank by fitness (lower misfit = better)
      3. Update m as weighted mean of the mu best
      4. Update evolution paths (p_sigma, p_c) for step-size & rank-1
      5. Update C with rank-1 (path) + rank-mu (weighted outer products)
      6. Adapt sigma via CSA

    Parameters
    ----------
    sigma0 : float
        Initial step-size (relative to parameter scale).  Default 0.3
        means the initial search covers ~1 sigma in 30% of the range.
    population : int or None
        Override the default population size (default: 4 + floor(3*ln(n))).
    elite_frac : float
        Fraction of population used as parents (mu/lambda).  Default 0.25.
    bounds : tuple(array, array) or None
        (lower, upper) box constraints.  Offspring are clipped.
    restart : bool
        If True, restart with doubled population when the distribution
        collapses (IPOP-CMA-ES).  Up to ``max_restarts`` restarts.
    seed : int or None
        Random seed for reproducibility.
    """

    name = "CMA-ES"

    def __init__(self,
                 sigma0: float = 0.3,
                 population: Optional[int] = None,
                 elite_frac: float = 0.25,
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 restart: bool = False,
                 max_restarts: int = 3,
                 seed: Optional[int] = None,
                 jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6):
        super().__init__(jacobian_strategy, eps)
        self.sigma0 = sigma0
        self._pop_override = population
        self.elite_frac = elite_frac
        self.bounds = bounds
        self.restart = restart
        self.max_restarts = max_restarts
        self.rng = np.random.default_rng(seed)
        self._seed = seed

    def _default_population(self, n: int) -> int:
        if self._pop_override is not None:
            return self._pop_override
        return 4 + int(np.floor(3 * np.log(n)))

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 100, tolerance: float = 1e-6
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        n = forward.n_params
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        m = np.asarray(initial_model, dtype=float).copy()
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)

        lower = self.bounds[0] if self.bounds is not None else np.full(n, -np.inf)
        upper = self.bounds[1] if self.bounds is not None else np.full(n, +np.inf)

        best_model = m.copy()
        best_obj, _, _ = _objective(forward, observed, reg, m, W)

        restart_count = 0
        gen = 0
        while gen < max_iter:
            lam = self._default_population(n)
            if self.restart and restart_count > 0:
                lam *= (2 ** restart_count)
            mu = max(1, int(np.floor(lam * self.elite_frac)))
            weights_pos = np.log(mu + 0.5) - np.log(np.arange(1, mu + 1))
            weights_pos /= weights_pos.sum()
            mueff = 1.0 / (weights_pos ** 2).sum()

            # Strategy parameters
            cc = (4 + mueff / n) / (n + 4 + 2 * mueff / n)
            cs = (mueff + 2) / (n + mueff + 5)
            c1 = 2.0 / ((n + 1.3) ** 2 + mueff)
            cmu = min(1 - c1, 2 * (mueff - 2 + 1 / mueff) / ((n + 2) ** 2 + mueff))
            damps = 1 + 2 * max(0, np.sqrt((mueff - 1) / (n + 1)) - 1) + cs

            sigma = self.sigma0 * (2.0 ** restart_count)
            C = np.eye(n)
            p_sigma = np.zeros(n)
            p_c = np.zeros(n)
            chiN = np.sqrt(n) * (1 - 1.0 / (4 * n) + 1.0 / (21 * n ** 2))

            stagnant_count = 0
            prev_best = best_obj

            while gen < max_iter:
                # Sample offspring
                try:
                    L = np.linalg.cholesky(C)
                except np.linalg.LinAlgError:
                    C = C + 1e-10 * np.eye(n)
                    L = np.linalg.cholesky(C)

                z = self.rng.standard_normal((lam, n))
                x = m + sigma * (z @ L.T)
                x = _clip_to_bounds(x, lower, upper)

                # Evaluate
                fitness = np.empty(lam)
                for i in range(lam):
                    fitness[i], _, _ = _objective(forward, observed, reg, x[i], W)

                # Sort by fitness (ascending = best first)
                idx = np.argsort(fitness)
                x_sorted = x[idx]
                f_sorted = fitness[idx]

                if f_sorted[0] < best_obj:
                    best_obj = f_sorted[0]
                    best_model = x_sorted[0].copy()

                # Update mean
                xelite = x_sorted[:mu]
                m_new = np.sum(weights_pos[:, None] * xelite, axis=0)
                dm = m_new - m  # weighted shift

                # Cumulation (evolution paths)
                C_inv_sqrt = np.linalg.inv(L)  # C^{-1/2} = L^{-T} but L is lower; use solve
                # C^{-1/2}: solve via eigendecomposition for robustness
                eigvals, eigvecs = np.linalg.eigh(C)
                eigvals = np.maximum(eigvals, 1e-20)
                C_inv_sqrt = eigvecs @ np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T

                p_sigma = (1 - cs) * p_sigma + np.sqrt(cs * (2 - cs) * mueff) * (C_inv_sqrt @ dm) / sigma
                p_c = (1 - cc) * p_c + np.sqrt(cc * (2 - cc) * mueff) * dm / sigma

                # Step-size adaptation
                sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(p_sigma) / chiN - 1))
                sigma = max(sigma, 1e-16)

                # Covariance update (rank-1 + rank-mu)
                term_rank1 = np.outer(p_c, p_c)
                # rank-mu: weighted sum of (x_i - m) outer products
                y_w = (xelite - m) / sigma  # (mu, n)
                term_rankmu = (weights_pos[:, None] * y_w).T @ y_w
                C = (1 - c1 - cmu) * C + c1 * term_rank1 + cmu * term_rankmu
                # Enforce symmetry
                C = (C + C.T) / 2

                m = m_new

                # Diagnostics
                data_misfit = 0.5 * float(np.dot(W * (observed - forward.predict(best_model)), (observed - forward.predict(best_model)))) if gen % 5 == 0 else f_sorted[0]
                reg_val = float(reg.value(best_model))
                diag.append(
                    data_misfit=f_sorted[0],
                    reg_term=reg_val,
                    total_objective=best_obj,
                    grad_norm=float(np.linalg.norm(p_sigma)),
                    step_norm=float(sigma * np.linalg.norm(dm)),
                    param_rms=float(np.sqrt(np.mean(best_model ** 2))),
                    label=f"CMAES-gen{gen}-σ={sigma:.2e}",
                )

                # Convergence checks
                if sigma < tolerance:
                    break
                if abs(prev_best - best_obj) < tolerance * max(1, abs(prev_best)):
                    stagnant_count += 1
                else:
                    stagnant_count = 0
                prev_best = best_obj

                if sigma < 1e-12 * self.sigma0 or stagnant_count > 10 + n:
                    break

                gen += 1

            # Check for restart
            if not self.restart or restart_count >= self.max_restarts or gen >= max_iter:
                break
            restart_count += 1
            # Re-seed for diversity
            if self._seed is not None:
                self.rng = np.random.default_rng(self._seed + restart_count)
            m = best_model + self.sigma0 * self.rng.standard_normal(n) * 0.5

        return best_model, diag


# =====================================================================
# Differential Evolution
# =====================================================================

class DifferentialEvolution(Optimizer):
    """Differential Evolution (Storn & Price 1997).

    A population-based optimizer that mutates candidate solutions by
    adding weighted differences between population members.

    **Strategy (DE/rand/1/bin):**
      For each target vector x_i in the population:
        1. Pick 3 distinct random members a, b, c (≠ i).
        2. Mutant: v = a + F * (b - c)
        3. Crossover: trial u = binomial crossover of x_i and v
        4. Selection: if f(u) ≤ f(x_i), replace x_i with u.

    Parameters
    ----------
    population : int or None
        Population size.  Default: max(15, 5 * n_params).
    F : float or tuple
        Mutation scale factor.  Can be a fixed value (0.5) or a
        (min, max) range for dithering (jitter per generation).
    CR : float
        Crossover probability (0–1).  Default 0.7.
    bounds : tuple(array, array)
        (lower, upper) box constraints.  Required for DE (the
        population is initialized uniformly within bounds).
    max_gen : int
        Maximum generations (used if max_iter is very large).
    seed : int or None
        Random seed.
    """

    name = "DifferentialEvolution"

    def __init__(self,
                 population: Optional[int] = None,
                 F: float = 0.5,
                 CR: float = 0.7,
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 seed: Optional[int] = None,
                 jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6):
        super().__init__(jacobian_strategy, eps)
        self._pop_override = population
        self.F = F
        self.CR = CR
        self.bounds = bounds
        self.rng = np.random.default_rng(seed)

    def _default_population(self, n: int) -> int:
        if self._pop_override is not None:
            return self._pop_override
        return max(15, 5 * n)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 200, tolerance: float = 1e-6
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        n = forward.n_params
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)

        # Bounds: if not provided, infer from initial_model ± 2 orders of magnitude
        if self.bounds is not None:
            lower = np.asarray(self.bounds[0], dtype=float)
            upper = np.asarray(self.bounds[1], dtype=float)
        else:
            spread = np.abs(initial_model) * 10 + 1.0
            lower = initial_model - spread
            upper = initial_model + spread

        pop_size = self._default_population(n)
        max_gen = max_iter // pop_size + 1

        # Initialize population
        pop = np.empty((pop_size, n))
        pop[0] = np.clip(initial_model.copy(), lower, upper)
        for i in range(1, pop_size):
            pop[i] = lower + self.rng.random(n) * (upper - lower)

        # Evaluate initial population
        fitness = np.empty(pop_size)
        for i in range(pop_size):
            fitness[i], _, _ = _objective(forward, observed, reg, pop[i], W)

        best_idx = int(np.argmin(fitness))
        best_model = pop[best_idx].copy()
        best_obj = fitness[best_idx]

        gen = 0
        evaluations = pop_size
        while gen < max_gen and evaluations < max_iter:
            # Mutation factor (dithering if F is a range)
            if isinstance(self.F, (tuple, list)):
                F = self.rng.uniform(self.F[0], self.F[1])
            else:
                F = self.F

            improved = False
            for i in range(pop_size):
                # Pick 3 distinct random indices ≠ i
                candidates = list(range(pop_size))
                candidates.remove(i)
                a, b, c = self.rng.choice(candidates, 3, replace=False)

                # Mutant
                mutant = pop[a] + F * (pop[b] - pop[c])
                mutant = _clip_to_bounds(mutant, lower, upper)

                # Crossover (binomial)
                cross_mask = self.rng.random(n) < self.CR
                # Ensure at least one component comes from mutant
                rand_dim = self.rng.integers(n)
                cross_mask[rand_dim] = True
                trial = np.where(cross_mask, mutant, pop[i])

                # Selection
                f_trial, _, _ = _objective(forward, observed, reg, trial, W)
                evaluations += 1
                if f_trial <= fitness[i]:
                    pop[i] = trial
                    fitness[i] = f_trial
                    if f_trial < best_obj:
                        best_obj = f_trial
                        best_model = trial.copy()
                        improved = True

            gen += 1

            # Diagnostics (record per generation)
            reg_val = float(reg.value(best_model))
            diag.append(
                data_misfit=best_obj - reg_val,
                reg_term=reg_val,
                total_objective=best_obj,
                grad_norm=0.0,
                step_norm=float(np.std(pop, axis=0).mean()),
                param_rms=float(np.sqrt(np.mean(best_model ** 2))),
                label=f"DE-gen{gen}",
            )

            # Convergence: population converged
            pop_std = float(np.std(fitness))
            if pop_std < tolerance:
                break
            if evaluations >= max_iter:
                break

        return best_model, diag


# =====================================================================
# Nelder-Mead
# =====================================================================

class NelderMead(Optimizer):
    """Nelder-Mead simplex algorithm (Nelder & Mead 1965).

    Maintains a simplex of n+1 vertices in n-dimensional parameter
    space.  At each iteration:
      1. Reflect the worst vertex through the centroid.
      2. If the reflected point is better than the best, expand.
      3. If it's better than the worst but not the best, accept.
      4. If worse, contract (inside or outside).
      5. If contraction fails, shrink the whole simplex toward the best.

    Well-suited for low-dimensional (n ≤ 10) smooth misfit surfaces.

    Parameters
    ----------
    initial_simplex_size : float
        Relative size of the initial simplex (fraction of the
        initial_model magnitude).  Default 0.05 (5%).
    bounds : tuple(array, array) or None
        Optional box constraints.
    alpha, gamma, rho, sigma : float
        Reflection, expansion, contraction, shrink coefficients.
        Defaults: 1.0, 2.0, 0.5, 0.5 (standard Nelder-Mead).
    seed : int or None
        Random seed (used only for initial simplex perturbation
        direction).
    """

    name = "NelderMead"

    def __init__(self,
                 initial_simplex_size: float = 0.05,
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 alpha: float = 1.0,
                 gamma: float = 2.0,
                 rho: float = 0.5,
                 sigma: float = 0.5,
                 seed: Optional[int] = None,
                 jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6):
        super().__init__(jacobian_strategy, eps)
        self.simplex_size = initial_simplex_size
        self.bounds = bounds
        self.alpha = alpha
        self.gamma = gamma
        self.rho = rho
        self.sigma = sigma
        self.rng = np.random.default_rng(seed)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 200, tolerance: float = 1e-6
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        n = forward.n_params
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)

        lower = self.bounds[0] if self.bounds is not None else np.full(n, -np.inf)
        upper = self.bounds[1] if self.bounds is not None else np.full(n, +np.inf)

        # Build initial simplex
        x0 = np.clip(np.asarray(initial_model, dtype=float).copy(), lower, upper)
        simplex = np.zeros((n + 1, n))
        simplex[0] = x0
        for i in range(n):
            vertex = x0.copy()
            step = self.simplex_size * (abs(x0[i]) + 1.0)
            vertex[i] += step
            simplex[i + 1] = _clip_to_bounds(vertex, lower, upper)

        # Evaluate simplex
        fvals = np.empty(n + 1)
        for i in range(n + 1):
            fvals[i], _, _ = _objective(forward, observed, reg, simplex[i], W)

        iteration = 0
        while iteration < max_iter:
            # Sort vertices by fitness (ascending)
            order = np.argsort(fvals)
            simplex = simplex[order]
            fvals = fvals[order]

            best = simplex[0]
            best_obj = fvals[0]

            # Convergence check: simplex size
            simplex_size = float(np.max(np.linalg.norm(simplex[1:] - simplex[0], axis=1)))
            f_range = float(np.max(fvals) - np.min(fvals))

            reg_val = float(reg.value(best))
            diag.append(
                data_misfit=best_obj - reg_val,
                reg_term=reg_val,
                total_objective=best_obj,
                grad_norm=f_range,
                step_norm=simplex_size,
                param_rms=float(np.sqrt(np.mean(best ** 2))),
                label=f"NM-iter{iteration}",
            )

            if simplex_size < tolerance and f_range < tolerance:
                break

            # Centroid of all but the worst
            centroid = np.mean(simplex[:-1], axis=0)

            # Reflection
            xr = centroid + self.alpha * (centroid - simplex[-1])
            xr = _clip_to_bounds(xr, lower, upper)
            fr, _, _ = _objective(forward, observed, reg, xr, W)

            if fvals[0] <= fr < fvals[-2]:
                # Accept reflection
                simplex[-1] = xr
                fvals[-1] = fr
            elif fr < fvals[0]:
                # Expansion
                xe = centroid + self.gamma * (xr - centroid)
                xe = _clip_to_bounds(xe, lower, upper)
                fe, _, _ = _objective(forward, observed, reg, xe, W)
                if fe < fr:
                    simplex[-1] = xe
                    fvals[-1] = fe
                else:
                    simplex[-1] = xr
                    fvals[-1] = fr
            else:
                # Contraction
                if fr < fvals[-1]:
                    # Outside contraction
                    xc = centroid + self.rho * (xr - centroid)
                    fc, _, _ = _objective(forward, observed, reg, xc, W)
                    if fc <= fr:
                        simplex[-1] = xc
                        fvals[-1] = fc
                    else:
                        # Shrink
                        for i in range(1, n + 1):
                            simplex[i] = simplex[0] + self.sigma * (simplex[i] - simplex[0])
                            simplex[i] = _clip_to_bounds(simplex[i], lower, upper)
                            fvals[i], _, _ = _objective(forward, observed, reg, simplex[i], W)
                else:
                    # Inside contraction
                    xcc = centroid - self.rho * (centroid - simplex[-1])
                    xcc = _clip_to_bounds(xcc, lower, upper)
                    fcc, _, _ = _objective(forward, observed, reg, xcc, W)
                    if fcc < fvals[-1]:
                        simplex[-1] = xcc
                        fvals[-1] = fcc
                    else:
                        # Shrink
                        for i in range(1, n + 1):
                            simplex[i] = simplex[0] + self.sigma * (simplex[i] - simplex[0])
                            simplex[i] = _clip_to_bounds(simplex[i], lower, upper)
                            fvals[i], _, _ = _objective(forward, observed, reg, simplex[i], W)

            iteration += 1

        # Return best vertex
        order = np.argsort(fvals)
        return simplex[order[0]], diag


# =====================================================================
# Bayesian Optimization (Gaussian Process surrogate of the misfit)
# =====================================================================

class _GaussianProcess:
    """Minimal GP regression with squared-exponential kernel.

    Predicts f(x) ~ GP(m(x), k(x, x')).  Used as a surrogate of the
    expensive reservoir misfit function.  This is a from-scratch
    implementation (no scikit-learn dependency) using numpy.

    Uses a squared-exponential (RBF) kernel::

        k(x, x') = sigma_f^2 * exp(-||x - x'||^2 / (2 * l^2))

    with noise variance sigma_n^2.  Hyperparameters (l, sigma_f,
    sigma_n) are set at construction; a simple leave-one-out tune
    can be added later.
    """

    def __init__(self, length_scale: float = 1.0,
                 signal_var: float = 1.0,
                 noise_var: float = 1e-6):
        self.l = length_scale
        self.sf2 = signal_var
        self.sn2 = noise_var
        self.X = None  # (N, d) training inputs
        self.y = None  # (N,) training targets
        self._K_inv = None
        self._alpha = None

    def _kernel(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """Squared-exponential kernel matrix between A (N,d) and B (M,d)."""
        sq_dist = (np.sum(A ** 2, axis=1)[:, None]
                   + np.sum(B ** 2, axis=1)[None, :]
                   - 2 * A @ B.T)
        return self.sf2 * np.exp(-0.5 * sq_dist / (self.l ** 2))

    def fit(self, X: np.ndarray, y: np.ndarray) -> None:
        self.X = np.asarray(X, dtype=float)
        self.y = np.asarray(y, dtype=float)
        K = self._kernel(self.X, self.X) + self.sn2 * np.eye(len(self.X))
        # Cholesky for stable inversion
        try:
            L = np.linalg.cholesky(K)
            self._alpha = np.linalg.solve(L.T, np.linalg.solve(L, self.y))
            self._L = L
        except np.linalg.LinAlgError:
            K += 1e-8 * np.eye(len(self.X))
            L = np.linalg.cholesky(K)
            self._alpha = np.linalg.solve(L.T, np.linalg.solve(L, self.y))
            self._L = L

    def predict(self, X_test: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Return (mean, variance) predictions at X_test."""
        if self.X is None:
            raise RuntimeError("GP not fitted")
        X_test = np.asarray(X_test, dtype=float)
        K_s = self._kernel(self.X, X_test)  # (N, M)
        mean = K_s.T @ self._alpha
        # Variance: k(x*, x*) - k_s^T K^{-1} k_s
        K_ss = self._kernel(X_test, X_test)
        v = np.linalg.solve(self._L, K_s)
        var = np.diag(K_ss) - np.sum(v ** 2, axis=0)
        var = np.maximum(var, 0.0)
        return mean, var


class BayesianOptimization(Optimizer):
    """Bayesian optimization with a Gaussian-Process surrogate.

    Builds a GP surrogate of the objective Phi(m) and uses an
    acquisition function to decide where to evaluate the true
    (expensive) simulator next.  This is sample-efficient — typically
    needs 10–50 simulator runs for 2–10 parameters.

    **Acquisition functions:**
      - "EI": Expected Improvement (default).  Robust, no tuning needed.
      - "UCB": Upper Confidence Bound (for minimization: LCB).  Needs
        exploration parameter beta.

    **Workflow:**
      1. Initialize with a small Latin-hypercube design (2*(n+1) points).
      2. Fit GP to evaluated points.
      3. Optimize acquisition function (grid + local refinement).
      4. Evaluate the true objective at the selected point.
      5. Update GP, repeat.

    Parameters
    ----------
    bounds : tuple(array, array)
        (lower, upper) — required.  BO needs a bounded search domain.
    n_initial : int
        Number of initial Latin-hypercube samples.  Default 2*(n+1).
    acquisition : str
        "EI" or "UCB".
    length_scale : float
        GP kernel length scale (in normalized [0,1] space).
    beta : float
        UCB exploration parameter.  Default 2.0.
    n_candidates : int
        Number of candidate points for acquisition optimization.
    seed : int or None
    """

    name = "BayesianOptimization"

    def __init__(self,
                 bounds: Tuple[np.ndarray, np.ndarray],
                 n_initial: Optional[int] = None,
                 acquisition: str = "EI",
                 length_scale: float = 0.5,
                 signal_var: float = 1.0,
                 noise_var: float = 1e-6,
                 beta: float = 2.0,
                 n_candidates: int = 2000,
                 seed: Optional[int] = None,
                 jacobian_strategy: Optional[Callable] = None,
                 eps: float = 1e-6):
        super().__init__(jacobian_strategy, eps)
        self.bounds = bounds
        self._n_init_override = n_initial
        self.acquisition = acquisition
        self.length_scale = length_scale
        self.signal_var = signal_var
        self.noise_var = noise_var
        self.beta = beta
        self.n_candidates = n_candidates
        self.rng = np.random.default_rng(seed)

    def _latin_hypercube(self, n: int, d: int) -> np.ndarray:
        """Latin hypercube sampling in [0, 1]^d."""
        result = np.empty((n, d))
        for j in range(d):
            perm = self.rng.permutation(n)
            result[:, j] = (perm + self.rng.random(n)) / n
        return result

    def _expected_improvement(self, X: np.ndarray, gp: _GaussianProcess,
                              f_best: float, xi: float = 0.01) -> np.ndarray:
        """EI acquisition for minimization."""
        mean, var = gp.predict(X)
        std = np.sqrt(var + 1e-12)
        improvement = f_best - mean - xi
        Z = improvement / std
        from scipy.stats import norm
        ei = improvement * norm.cdf(Z) + std * norm.pdf(Z)
        ei[std < 1e-10] = 0.0  # no uncertainty → no improvement expected
        return ei

    def _lcb(self, X: np.ndarray, gp: _GaussianProcess) -> np.ndarray:
        """Lower Confidence Bound for minimization."""
        mean, var = gp.predict(X)
        return mean - self.beta * np.sqrt(var)

    def optimize(self, forward: ForwardModel, observed: np.ndarray,
                 reg: RegularizationOperator, initial_model: np.ndarray,
                 weights: Optional[np.ndarray] = None,
                 max_iter: int = 50, tolerance: float = 1e-6
                 ) -> Tuple[np.ndarray, ConvergenceDiag]:
        from scipy.stats import norm

        n = forward.n_params
        W = np.ones(forward.n_data) if weights is None else np.asarray(weights, dtype=float)
        diag = ConvergenceDiag(tolerance=tolerance, max_iter=max_iter)

        lower = np.asarray(self.bounds[0], dtype=float)
        upper = np.asarray(self.bounds[1], dtype=float)
        # Normalize to [0, 1]
        scale = upper - lower
        scale[scale == 0] = 1.0

        def to_real(x_norm: np.ndarray) -> np.ndarray:
            return lower + x_norm * scale

        def obj_real(m: np.ndarray) -> float:
            total, _, _ = _objective(forward, observed, reg, m, W)
            return total

        # Initial design
        n_initial = self._n_init_override or max(2 * (n + 1), 6)
        X_init = self._latin_hypercube(n_initial, n)

        # Include the initial_model in the initial design
        x0_norm = (np.clip(initial_model, lower, upper) - lower) / scale
        X_init[0] = x0_norm

        # Evaluate initial points
        X_eval = []
        y_eval = []
        for i in range(n_initial):
            m_real = to_real(X_init[i])
            f = obj_real(m_real)
            X_eval.append(X_init[i])
            y_eval.append(f)

        X_eval = np.array(X_eval)
        y_eval = np.array(y_eval)

        best_idx = int(np.argmin(y_eval))
        best_model = to_real(X_eval[best_idx])
        best_obj = y_eval[best_idx]

        reg_val = float(reg.value(best_model))
        diag.append(
            data_misfit=best_obj - reg_val,
            reg_term=reg_val,
            total_objective=best_obj,
            grad_norm=0.0,
            step_norm=0.0,
            param_rms=float(np.sqrt(np.mean(best_model ** 2))),
            label=f"BO-init-{n_initial}pts",
        )

        # BO iterations
        iteration = 0
        total_budget = n_initial + max_iter
        while n_initial + iteration < total_budget:
            # Fit GP (normalize y for numerical stability)
            y_mean = y_eval.mean()
            y_std = y_eval.std() + 1e-10
            y_norm = (y_eval - y_mean) / y_std

            gp = _GaussianProcess(
                length_scale=self.length_scale,
                signal_var=self.signal_var,
                noise_var=self.noise_var,
            )
            gp.fit(X_eval, y_norm)

            # Generate candidates: random + local around best + near existing points
            n_rand = self.n_candidates // 2
            X_cand_rand = self.rng.random((n_rand, n))
            # Local candidates around current best (exploitation)
            local_radius = max(0.05, 0.2 / np.sqrt(iteration + 1))
            n_local = self.n_candidates - n_rand
            X_cand_local = X_eval[best_idx] + local_radius * self.rng.standard_normal(
                (n_local, n))
            X_cand_local = np.clip(X_cand_local, 0, 1)
            X_cand = np.vstack([X_cand_rand, X_cand_local])

            # Acquisition
            if self.acquisition == "EI":
                f_best_norm = (best_obj - y_mean) / y_std
                acq = self._expected_improvement(X_cand, gp, f_best_norm)
            else:
                acq = -self._lcb(X_cand, gp)  # maximize LCB → minimize -LCB

            # Select best candidate
            next_idx = int(np.argmax(acq))
            x_next = X_cand[next_idx]
            m_next = to_real(x_next)

            # Evaluate
            f_next = obj_real(m_next)
            X_eval = np.vstack([X_eval, x_next])
            y_eval = np.append(y_eval, f_next)

            if f_next < best_obj:
                best_obj = f_next
                best_model = m_next.copy()
                best_idx = len(y_eval) - 1

            iteration += 1
            reg_val = float(reg.value(best_model))
            diag.append(
                data_misfit=best_obj - reg_val,
                reg_term=reg_val,
                total_objective=best_obj,
                grad_norm=float(np.std(y_eval)),
                step_norm=float(np.linalg.norm(m_next - best_model)),
                param_rms=float(np.sqrt(np.mean(best_model ** 2))),
                label=f"BO-iter{iteration}-EI={float(acq[next_idx]):.4f}",
            )

            # Convergence: improvement stalled
            if len(y_eval) > 10:
                recent = y_eval[-10:]
                if float(np.max(recent) - np.min(recent)) < tolerance:
                    break

        return best_model, diag
