"""
Pressure-Volume-Temperature (PVT) fluid properties.

Two tiers are provided:

1. **Single-phase** water/oil properties (compressible, slightly compressible)
   used for the verification-grade single-phase simulator.
2. **Black-oil** PVT: formation volume factors (Bo, Bg, Bw), solution
   gas-oil ratio Rs, viscosities, and densities as functions of pressure.

All functions are vectorised and physically consistent (units documented
per function).  Default constants follow standard reservoir-engineering
references (McCain, Ahmed).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

__all__ = [
    "SinglePhaseFluid",
    "SlightlyCompressibleFluid",
    "WaterFluid",
    "BlackOilPVT",
    "BlackOilFluid",
]


# ---------------------------------------------------------------------------
# Single-phase fluid models
# ---------------------------------------------------------------------------

@dataclass
class SinglePhaseFluid:
    """Base class for a single-phase fluid.

    Subclasses implement :meth:`density`, :meth:`viscosity`,
    :meth:`formation_volume_factor`, and :meth:`compressibility` as
    functions of pressure ``p`` (Pa).
    """

    ref_pressure: float = 1.0e5        # Pa (1 atm)
    ref_density: float = 1000.0        # kg/m3
    ref_viscosity: float = 1.0e-3      # Pa.s
    compressibility: float = 0.0       # 1/Pa

    def density(self, p: np.ndarray) -> np.ndarray:
        p = np.asarray(p, float)
        return self.ref_density * np.exp(self.compressibility * (p - self.ref_pressure))

    def viscosity(self, p: np.ndarray) -> np.ndarray:
        return np.full_like(np.asarray(p, float), self.ref_viscosity)

    def formation_volume_factor(self, p: np.ndarray) -> np.ndarray:
        """B = rho_ref / rho(p) = exp(-c*(p - p_ref))."""
        p = np.asarray(p, float)
        return np.exp(-self.compressibility * (p - self.ref_pressure))

    def mobility(self, p: np.ndarray) -> np.ndarray:
        """k * rho / (mu * B) reduces to rho/mu for single phase (k applied outside)."""
        return self.density(p) / self.viscosity(p)


@dataclass
class SlightlyCompressibleFluid(SinglePhaseFluid):
    """Slightly compressible fluid (e.g. undersaturated oil, water).

    Uses the exponential relation ``rho = rho_ref * exp(c (p - p_ref))``.
    """

    def __post_init__(self) -> None:
        if self.compressibility < 0:
            raise ValueError("compressibility must be >= 0")


@dataclass
class WaterFluid(SlightlyCompressibleFluid):
    """Water with typical reservoir defaults."""

    ref_density: float = 1000.0
    ref_viscosity: float = 0.5e-3
    compressibility: float = 4.5e-10     # 1/Pa


# ---------------------------------------------------------------------------
# Black-oil PVT
# ---------------------------------------------------------------------------

@dataclass
class BlackOilPVT:
    """Black-oil PVT tables / correlations.

    All pressures in Pa.  Saturated (below bubble point) and undersaturated
    (above bubble point) branches are handled.

    Parameters
    ----------
    p_ref, p_bub : float
        Reference and bubble-point pressures (Pa).
    rho_o_surf, rho_w_surf, rho_g_surf : float
        Surface (standard-condition) densities (kg/m3).
    bo_ref, bw_ref, bg_ref : float
        Formation volume factors at ``p_ref``.
    co, cw, cg : float
        Compressibilities above the bubble point (1/Pa).
    mu_o_ref, mu_w_ref, mu_g_ref : float
        Reference viscosities (Pa.s).
    rsb : float
        Solution GOR at bubble point (sm3/sm3).
    rs_exp : float
        Exponent for Rs vs p below bubble point: Rs = Rsb (p/pb)^n.
    """

    p_ref: float = 1.0e5
    p_bub: float = 2.0e7
    rho_o_surf: float = 850.0
    rho_w_surf: float = 1025.0
    rho_g_surf: float = 0.9
    bo_ref: float = 1.0
    bw_ref: float = 1.0
    bg_ref: float = 1.0e-3
    co: float = 1.0e-9
    cw: float = 4.5e-10
    cg: float = 1.0e-7
    mu_o_ref: float = 2.0e-3
    mu_w_ref: float = 0.5e-3
    mu_g_ref: float = 2.0e-5
    rsb: float = 100.0
    rs_exp: float = 1.0

    # ------------------------------------------------------------------
    # Solution gas-oil ratio
    # ------------------------------------------------------------------
    def rs(self, p: np.ndarray) -> np.ndarray:
        """Rs(p): solution gas-oil ratio (sm3/sm3)."""
        p = np.asarray(p, float)
        rs = np.where(
            p >= self.p_bub,
            self.rsb,
            self.rsb * np.clip(p / self.p_bub, 0.0, 1.0) ** self.rs_exp,
        )
        return rs

    # ------------------------------------------------------------------
    # Formation volume factors
    # ------------------------------------------------------------------
    def bo(self, p: np.ndarray) -> np.ndarray:
        """Oil FVF (rm3/sm3)."""
        p = np.asarray(p, float)
        # Below bubble point: Bo increases as p decreases (gas comes out)
        bo_sat = self.bo_ref * (1.0 + self.co * (self.p_bub - p))
        bo_sat = np.where(p < self.p_bub, bo_sat, self.bo_ref)
        # Above bubble point: Bo decreases with p (oil compresses)
        bo_unsat = self.bo_ref * np.exp(-self.co * (p - self.p_bub))
        return np.where(p >= self.p_bub, bo_unsat, bo_sat)

    def bw(self, p: np.ndarray) -> np.ndarray:
        """Water FVF."""
        p = np.asarray(p, float)
        return self.bw_ref * np.exp(-self.cw * (p - self.p_ref))

    def bg(self, p: np.ndarray) -> np.ndarray:
        """Gas FVF (rm3/sm3) — ideal gas approximation."""
        p = np.asarray(p, float)
        return self.bg_ref * (self.p_ref / np.maximum(p, 1.0))

    # ------------------------------------------------------------------
    # Viscosities
    # ------------------------------------------------------------------
    def mu_o(self, p: np.ndarray) -> np.ndarray:
        p = np.asarray(p, float)
        return self.mu_o_ref * np.exp(self.co * (self.p_bub - np.minimum(p, self.p_bub)) * 0.5)

    def mu_w(self, p: np.ndarray) -> np.ndarray:
        return np.full_like(np.asarray(p, float), self.mu_w_ref)

    def mu_g(self, p: np.ndarray) -> np.ndarray:
        p = np.asarray(p, float)
        return self.mu_g_ref * (self.p_ref / np.maximum(p, 1.0)) ** 0.25

    # ------------------------------------------------------------------
    # Densities at reservoir conditions
    # ------------------------------------------------------------------
    def rho_o(self, p: np.ndarray) -> np.ndarray:
        """Oil density at reservoir conditions (kg/m3)."""
        p = np.asarray(p, float)
        rs = self.rs(p)
        bo = self.bo(p)
        # mass = rho_o_surf + rho_g_surf * Rs (per sm3 oil), volume = Bo rm3
        return (self.rho_o_surf + self.rho_g_surf * rs) / bo

    def rho_w(self, p: np.ndarray) -> np.ndarray:
        return self.rho_w_surf / self.bw(p)

    def rho_g(self, p: np.ndarray) -> np.ndarray:
        return self.rho_g_surf / self.bg(p)


# ---------------------------------------------------------------------------
# Convenience container used by the simulator
# ---------------------------------------------------------------------------

@dataclass
class BlackOilFluid:
    """Bundles a BlackOilPVT with rock-independent fluid metadata."""

    pvt: BlackOilPVT = None

    def __post_init__(self) -> None:
        if self.pvt is None:
            self.pvt = BlackOilPVT()

    @property
    def n_phases(self) -> int:
        return 3

    @property
    def phases(self) -> tuple[str, ...]:
        return ("water", "oil", "gas")

    def density(self, phase: str, p: np.ndarray) -> np.ndarray:
        return {"water": self.pvt.rho_w, "oil": self.pvt.rho_o,
                "gas": self.pvt.rho_g}[phase](p)

    def viscosity(self, phase: str, p: np.ndarray) -> np.ndarray:
        return {"water": self.pvt.mu_w, "oil": self.pvt.mu_o,
                "gas": self.pvt.mu_g}[phase](p)

    def fvf(self, phase: str, p: np.ndarray) -> np.ndarray:
        return {"water": self.pvt.bw, "oil": self.pvt.bo,
                "gas": self.pvt.bg}[phase](p)
