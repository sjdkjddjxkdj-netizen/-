"""
Region model, equilibration, and fluid-contact initialization.

A reservoir model is partitioned into **regions** (equilibration regions,
PVT regions, rock regions) so that each can have its own contacts, pressure
datum, and fluid properties.  This module provides:

* :class:`RegionModel` — a region label grid + metadata.
* :func:`assign_regions` — map ``(x, y, z)`` to a region id via a callable
  or a polygon list.
* :func:`hydrostatic_pressure` — hydrostatic (linear) pressure gradient.
* :func:`equilibration_region` — pressure and saturation vs depth for a
  single equilibration region given datum depth/pressure and contacts
  (OWC, GOC).
* :func:`contact_initialization` — initialize pressure and saturation for
  every active cell of a grid.

The pressure model is the standard hydrostatic (constant density) one used
by ECLIPSE's EQUIL keyword::

    P(z) = P_datum + ρ g (z - z_datum)

with separate densities for oil, water, and gas.  Between the GOC and OWC
the cell is oil-saturated; above the GOC gas-saturated; below the OWC
water-saturated.

All functions use only numpy + scipy.

References
----------
* Schlumberger, "ECLIPSE Reference Manual", EQUIL keyword (equilibration).
* Eclipse Technical Description, "Initialisation and Equilibration".
* Cosentino, "Integrated Reservoir Studies", ch. 4 (contacts & regions).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence, Union

import numpy as np

__all__ = [
    "RegionModel",
    "Contact",
    "assign_regions",
    "hydrostatic_pressure",
    "equilibration_region",
    "contact_initialization",
]


# gravity (m/s^2) — exposed so tests can use consistent units
G = 9.80665


# --------------------------------------------------------------------------- #
# Region model
# --------------------------------------------------------------------------- #
@dataclass
class RegionModel:
    """A region label grid with metadata.

    Attributes
    ----------
    regions : np.ndarray, int
        Region id per cell (same shape as the grid's actnum).  Region ids
        are 0-based contiguous integers.
    names : list of str
        Human-readable name per region id.
    """

    regions: np.ndarray
    names: Optional[list] = None

    def __post_init__(self) -> None:
        self.regions = np.asarray(self.regions, dtype=int)
        self.n_regions = int(self.regions.max()) + 1 if self.regions.size else 0
        if self.names is None:
            self.names = [f"region_{i}" for i in range(self.n_regions)]
        elif len(self.names) < self.n_regions:
            self.names = list(self.names) + [
                f"region_{i}" for i in range(len(self.names), self.n_regions)
            ]

    def cell_region(self, i: int, j: int, k: int) -> int:
        return int(self.regions[i, j, k])

    def mask(self, region_id: int) -> np.ndarray:
        return self.regions == region_id


def assign_regions(
    shape: tuple,
    region_function: Union[Callable, np.ndarray],
) -> RegionModel:
    """Assign a region id to every cell of a grid.

    Parameters
    ----------
    shape : (nx, ny, nz)
        Grid shape.
    region_function : callable or array
        * callable: ``f(x, y, z) -> int`` evaluated at each cell centre.
          Cell centres are ``(i, j, k)`` index tuples by default; pass a
          callable that accepts ``(i, j, k)``.
        * array: a pre-computed region id grid of the same shape.

    Returns
    -------
    RegionModel
    """
    nx, ny, nz = shape
    if callable(region_function):
        regions = np.zeros((nx, ny, nz), dtype=int)
        for k in range(nz):
            for j in range(ny):
                for i in range(nx):
                    regions[i, j, k] = int(region_function(i, j, k))
    else:
        arr = np.asarray(region_function, dtype=int)
        if arr.shape != (nx, ny, nz):
            raise ValueError("region array shape mismatch")
        regions = arr
    return RegionModel(regions=regions)


# --------------------------------------------------------------------------- #
# Contact
# --------------------------------------------------------------------------- #
@dataclass
class Contact:
    """A fluid contact (OWC / GOC / FWL).

    Attributes
    ----------
    contact_type : str
        ``'OWC'``, ``'GOC'``, ``'FWL'``, ``'GWC'`` etc.
    depth : float
        Contact depth (positive downward).
    region : int
        Region id this contact applies to.
    """

    contact_type: str
    depth: float
    region: int = 0


# --------------------------------------------------------------------------- #
# Hydrostatic pressure
# --------------------------------------------------------------------------- #
def hydrostatic_pressure(
    depth: Union[float, np.ndarray],
    datum_depth: float,
    datum_pressure: float,
    rho: float,
    g: float = G,
) -> Union[float, np.ndarray]:
    """Hydrostatic (linear) pressure at ``depth``.

    ``P(z) = P_datum + ρ g (z - z_datum)``

    Depth is positive downward, so deeper → higher pressure for ρ > 0.

    Parameters
    ----------
    depth : float or ndarray
        Depths at which to evaluate pressure.
    datum_depth : float
        Datum depth.
    datum_pressure : float
        Pressure at the datum.
    rho : float
        Fluid density (mass/volume).
    g : float
        Gravity (default 9.80665 m/s²).
    """
    z = np.asarray(depth, dtype=float)
    p = datum_pressure + rho * g * (z - datum_depth)
    if p.ndim == 0:
        return float(p)
    return p


# --------------------------------------------------------------------------- #
# Equilibration region
# --------------------------------------------------------------------------- #
@dataclass
class EquilResult:
    """Pressure and saturation vs depth for one equilibration region.

    Attributes
    ----------
    depth : np.ndarray
    pressure : np.ndarray
    so, sw, sg : np.ndarray
        Oil / water / gas saturation at each depth.
    """

    depth: np.ndarray
    pressure: np.ndarray
    so: np.ndarray
    sw: np.ndarray
    sg: np.ndarray


def equilibration_region(
    depths: np.ndarray,
    datum_depth: float,
    datum_pressure: float,
    rho_o: float,
    rho_w: float,
    rho_g: float,
    owc: Optional[float] = None,
    goc: Optional[float] = None,
    g: float = G,
) -> EquilResult:
    """Pressure and saturation vs depth for a single equilibration region.

    The pressure is piecewise-hydrostatic: above the GOC the gas gradient
    applies, between GOC and OWC the oil gradient, below the OWC the water
    gradient.  If a contact is absent the corresponding segment is omitted.

    Saturation is set to 1.0 for the phase that dominates each depth
    interval (sharp-contact, no transition zone — matching ECLIPSE's
    EQUIL with zero capillary transition):

    * above GOC → gas (sg = 1)
    * GOC → OWC → oil (so = 1)
    * below OWC → water (sw = 1)

    Parameters
    ----------
    depths : np.ndarray
        Depths to evaluate (positive downward).
    datum_depth, datum_pressure : float
        Datum for pressure reference.  The datum is taken to be in the oil
        zone (the standard ECLIPSE convention).
    rho_o, rho_w, rho_g : float
        Phase densities.
    owc, goc : float, optional
        Oil-water and gas-oil contact depths (positive downward).

    Returns
    -------
    EquilResult
    """
    z = np.asarray(depths, dtype=float).ravel()
    n = z.size
    pressure = np.empty(n)
    so = np.zeros(n)
    sw = np.zeros(n)
    sg = np.zeros(n)

    # default contacts: if none, treat whole column as oil
    if goc is None:
        goc = -np.inf   # gas never appears
    if owc is None:
        owc = np.inf    # water never appears

    # piecewise pressure anchored at datum (oil zone) with continuity at contacts
    for i in range(n):
        zi = z[i]
        if zi >= owc:
            # water zone: P = P_owc + rho_w g (z - owc)
            # P_owc from oil gradient: P_datum + rho_o g (owc - datum)
            p_owc = datum_pressure + rho_o * g * (owc - datum_depth)
            pressure[i] = p_owc + rho_w * g * (zi - owc)
            sw[i] = 1.0
        elif zi <= goc:
            # gas zone: P = P_goc + rho_g g (z - goc)
            p_goc = datum_pressure + rho_o * g * (goc - datum_depth)
            pressure[i] = p_goc + rho_g * g * (zi - goc)
            sg[i] = 1.0
        else:
            # oil zone
            pressure[i] = datum_pressure + rho_o * g * (zi - datum_depth)
            so[i] = 1.0

    return EquilResult(depth=z, pressure=pressure, so=so, sw=sw, sg=sg)


# --------------------------------------------------------------------------- #
# Full contact initialization on a grid
# --------------------------------------------------------------------------- #
@dataclass
class InitialState:
    """Initial pressure and saturation for every grid cell.

    Attributes
    ----------
    pressure : np.ndarray, shape (nx, ny, nz)
    sw, so, sg : np.ndarray, shape (nx, ny, nz)
    regions : np.ndarray, int
    """

    pressure: np.ndarray
    sw: np.ndarray
    so: np.ndarray
    sg: np.ndarray
    regions: np.ndarray


def contact_initialization(
    cell_centres: np.ndarray,
    regions: np.ndarray,
    equil: Sequence[dict],
    actnum: Optional[np.ndarray] = None,
    g: float = G,
) -> InitialState:
    """Initialize pressure and saturation for every grid cell.

    Parameters
    ----------
    cell_centres : np.ndarray, shape (nx, ny, nz, 3)
        Cell centre coordinates (x, y, z).  z positive downward.
    regions : np.ndarray, int, shape (nx, ny, nz)
        Region id per cell.
    equil : sequence of dict
        One dict per region with keys::

            datum_depth, datum_pressure, rho_o, rho_w, rho_g,
            owc (optional), goc (optional)
    actnum : np.ndarray, bool, optional
        Active-cell mask.  Inactive cells get zero saturation.

    Returns
    -------
    InitialState
    """
    cc = np.asarray(cell_centres, dtype=float)
    nx, ny, nz = cc.shape[:3]
    reg = np.asarray(regions, dtype=int)
    if reg.shape != (nx, ny, nz):
        raise ValueError("regions shape mismatch")
    depth = cc[..., 2]  # (nx, ny, nz)

    pressure = np.zeros((nx, ny, nz))
    sw = np.zeros((nx, ny, nz))
    so = np.zeros((nx, ny, nz))
    sg = np.zeros((nx, ny, nz))

    n_reg = len(equil)
    for r in range(n_reg):
        mask = reg == r
        if not np.any(mask):
            continue
        e = equil[r]
        res = equilibration_region(
            depth[mask],
            datum_depth=float(e["datum_depth"]),
            datum_pressure=float(e["datum_pressure"]),
            rho_o=float(e["rho_o"]),
            rho_w=float(e["rho_w"]),
            rho_g=float(e["rho_g"]),
            owc=e.get("owc"),
            goc=e.get("goc"),
            g=g,
        )
        pressure[mask] = res.pressure
        sw[mask] = res.sw
        so[mask] = res.so
        sg[mask] = res.sg

    if actnum is not None:
        act = np.asarray(actnum, dtype=bool)
        inactive = ~act
        pressure[inactive] = 0.0
        sw[inactive] = 0.0
        so[inactive] = 0.0
        sg[inactive] = 0.0

    return InitialState(pressure=pressure, sw=sw, so=so, sg=sg, regions=reg)
