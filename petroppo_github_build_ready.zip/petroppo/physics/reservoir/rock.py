"""
Rock and fluid-flow properties for reservoir simulation.

Covers:
* Porosity and (diagonal / full-tensor) permeability.
* Relative permeability models: Corey (2-phase), Brooks-Corey, Stone II
  (three-phase oil relative permeability).
* Capillary pressure: Brooks-Corey and J-function scaling.

All functions are vectorised over numpy arrays so they can be evaluated
cell-by-cell without Python loops in the simulator hot path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

__all__ = [
    "RockProperties",
    "corey_water_relperm",
    "corey_gas_relperm",
    "brooks_corey_oil_water",
    "stone2_oil_relperm",
    "brooks_corey_capillary",
    "j_function_capillary",
]


# ---------------------------------------------------------------------------
# Rock property container
# ---------------------------------------------------------------------------

@dataclass
class RockProperties:
    """Per-cell rock properties.

    Attributes
    ----------
    porosity : array (nx, ny, nz)
        Cell porosity (fraction).
    permeability : array
        * shape (nx, ny, nz)        -> isotropic scalar perm,
        * shape (nx, ny, nz, 3)     -> diagonal tensor (kx, ky, kz),
        * shape (nx, ny, nz, 3, 3)  -> full symmetric tensor.
    initial_water_sat : array, optional
        Connate (irreducible) water saturation per cell.
    """

    porosity: np.ndarray
    permeability: np.ndarray
    initial_water_sat: Optional[np.ndarray] = None

    def __post_init__(self) -> None:
        grid_shape = self.porosity.shape
        if self.porosity.ndim != 3:
            raise ValueError("porosity must be 3-D (nx, ny, nz)")
        k = np.asarray(self.permeability, float)
        if k.shape == grid_shape:
            self._k_form = "scalar"
        elif k.shape == (*grid_shape, 3):
            self._k_form = "diagonal"
        elif k.shape == (*grid_shape, 3, 3):
            self._k_form = "tensor"
        else:
            raise ValueError(
                f"permeability shape {k.shape} incompatible with porosity {grid_shape}"
            )
        self.permeability = k

    # ------------------------------------------------------------------
    @property
    def shape(self) -> tuple[int, int, int]:
        return self.porosity.shape

    @property
    def nx(self) -> int:
        return self.porosity.shape[0]

    @property
    def ny(self) -> int:
        return self.porosity.shape[1]

    @property
    def nz(self) -> int:
        return self.porosity.shape[2]

    def kx(self) -> np.ndarray:
        """Permeability in the x-direction (for transmissibility)."""
        if self._k_form == "scalar":
            return self.permeability
        if self._k_form == "diagonal":
            return self.permeability[..., 0]
        return self.permeability[..., 0, 0]

    def ky(self) -> np.ndarray:
        if self._k_form == "scalar":
            return self.permeability
        if self._k_form == "diagonal":
            return self.permeability[..., 1]
        return self.permeability[..., 1, 1]

    def kz(self) -> np.ndarray:
        if self._k_form == "scalar":
            return self.permeability
        if self._k_form == "diagonal":
            return self.permeability[..., 2]
        return self.permeability[..., 2, 2]


# ---------------------------------------------------------------------------
# Relative permeability models
# ---------------------------------------------------------------------------

def corey_water_relperm(
    sw: np.ndarray, swr: float = 0.1, sw_max: float = 1.0, nw: float = 2.0
) -> np.ndarray:
    """Corey water relative permeability.

    .. math:: k_{rw} = (S_w^*)^{n_w}

    with :math:`S_w^* = (S_w - S_{wr}) / (1 - S_{wr})`.
    """
    sw = np.asarray(sw, float)
    s_star = np.clip((sw - swr) / (sw_max - swr), 0.0, 1.0)
    return s_star ** nw


def corey_gas_relperm(
    sg: np.ndarray, sgr: float = 0.0, sg_max: float = 1.0, ng: float = 2.0
) -> np.ndarray:
    """Corey gas relative permeability (analogous to water)."""
    sg = np.asarray(sg, float)
    s_star = np.clip((sg - sgr) / (sg_max - sgr), 0.0, 1.0)
    return s_star ** ng


def brooks_corey_oil_water(
    sw: np.ndarray,
    swr: float = 0.1,
    sor: float = 0.2,
    no: float = 2.0,
    kro_max: float = 1.0,
) -> np.ndarray:
    """Brooks-Corey oil relative permeability in an oil-water system.

    .. math:: k_{ro} = k_{ro,max} (1 - S_w^*)^{n_o}

    with :math:`S_w^* = (S_w - S_{wr}) / (1 - S_{wr} - S_{or})`.
    """
    sw = np.asarray(sw, float)
    denom = 1.0 - swr - sor
    if denom <= 0:
        raise ValueError("swr + sor must be < 1")
    s_star = np.clip((sw - swr) / denom, 0.0, 1.0)
    return kro_max * (1.0 - s_star) ** no


def stone2_oil_relperm(
    sw: np.ndarray,
    sg: np.ndarray,
    swr: float = 0.1,
    sor: float = 0.2,
    sgr: float = 0.0,
    no: float = 2.0,
    nw: float = 2.0,
    ng: float = 2.0,
    kro_max_ow: float = 1.0,
    kro_max_og: float = 1.0,
) -> np.ndarray:
    """Stone II three-phase oil relative permeability.

    Uses the normalised-interpolation form:

    .. math::

        k_{ro} = k_{ro}^{OW}(S_w) \\,
                 \\frac{k_{ro}^{OG}(S_g)}{k_{ro}^{OW}(S_{w,max})}
                 \\big/ \\text{(normalisation)}

    Implementation follows the standard Aziz-Settari / Chen formulation.
    """
    sw = np.asarray(sw, float)
    sg = np.asarray(sg, float)
    so = 1.0 - sw - sg  # oil saturation

    # two-phase endpoints
    kro_ow = brooks_corey_oil_water(sw, swr, sor, no, kro_max_ow)

    # oil-gas system: treat (1 - sg - swr) as the "oil" saturation in OG
    so_og = 1.0 - sg - swr
    s_og_star = np.clip(so_og / (1.0 - sgr - swr), 0.0, 1.0)
    kro_og = kro_max_og * s_og_star ** no

    # Stone II normalisation
    kro_at_swc = brooks_corey_oil_water(np.full_like(sw, swr), swr, sor, no, kro_max_ow)
    kro_at_swc = np.where(kro_at_swc <= 0, 1.0, kro_at_swc)

    kro = kro_ow * kro_og / kro_at_swc
    # zero out only where oil saturation is at or below residual
    so = 1.0 - sw - sg
    kro = np.where(so > sor, kro, 0.0)
    return np.clip(kro, 0.0, kro_max_ow)


# ---------------------------------------------------------------------------
# Capillary pressure
# ---------------------------------------------------------------------------

def brooks_corey_capillary(
    sw: np.ndarray,
    swr: float = 0.1,
    pe: float = 1.0,
    lam: float = 2.0,
    pmax: float = 1e6,
) -> np.ndarray:
    """Brooks-Corey capillary pressure (oil-water).

    .. math:: P_c = P_e (S_w^*)^{-1/\\lambda}

    Clipped at ``pmax`` for saturations below ``swr``.
    """
    sw = np.asarray(sw, float)
    s_star = np.clip((sw - swr) / (1.0 - swr), 1e-6, 1.0)
    pc = pe * s_star ** (-1.0 / lam)
    return np.clip(pc, 0.0, pmax)


def j_function_capillary(
    sw: np.ndarray,
    k: np.ndarray,
    phi: np.ndarray,
    sigma_cos: float = 30.0,
    a: float = 0.1,
    b: float = -0.5,
    swr: float = 0.1,
) -> np.ndarray:
    """Leverett J-function capillary pressure.

    .. math:: P_c = \\frac{\\sigma \\cos\\theta}{\\sqrt{k/\\phi}} J(S_w)

    with :math:`J = a (S_w^*)^b`.
    """
    sw = np.asarray(sw, float)
    k = np.asarray(k, float)
    phi = np.asarray(phi, float)
    s_star = np.clip((sw - swr) / (1.0 - swr), 1e-6, 1.0)
    j_val = a * s_star ** b
    pc = sigma_cos / np.sqrt(k / np.clip(phi, 1e-6, None)) * j_val
    return np.where(sw > swr, pc, 1e6)
