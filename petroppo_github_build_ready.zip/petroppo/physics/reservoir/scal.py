"""
SCAL data: special core analysis — relative permeability and capillary
pressure curves from laboratory measurements.

Laboratory SCAL (Special Core Analysis) produces discrete measurements of
relative permeability and capillary pressure as functions of saturation.
This module fits those measurements to the standard parametric models used
in reservoir simulation and provides table look-ups:

* **Corey / Burdine** relative permeability::

      krw = krw_max * Snw^Nw
      krow = kro_max * Sno^No          (two-phase oil-water)
      krg = krg_max * Sng^Ng
      krog = kro_max * Sno^Nog         (two-phase gas-oil)

  where ``Sn`` is the normalized saturation::

      Snw = (Sw - Swc) / (1 - Swc - Sor)
      Sno = (1 - Sw - Sor) / (1 - Swc - Sor)

* **Brooks-Corey** capillary pressure::

      Pcow = Pentry * Snw^(-1/lambda)

The fit recovers the exponent and endpoints from the measured points and
reports the coefficient of determination R² so the quality of the fit can
be QC'd — the same workflow as Petrel's SCAL fitting tool.

All functions use only numpy + scipy.

References
----------
* Corey, "The Interrelation Between Gas and Oil Relative Permeabilities",
  Producers Monthly 1954.
* Burdine, "Relative Permeability Calculations From Pore Size Distribution
  Data", Trans. AIME 1953.
* Brooks & Corey, "Hydraulic Properties of Porous Media", Colorado State
  Univ. Hydrology Paper 3, 1964.
* Honarpour et al., "Relative Permeability of Petroleum Reservoirs", CRC
  Press 1986.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.interpolate import PchipInterpolator

__all__ = [
    "SCALCurve",
    "SCALFit",
    "normalize_saturation",
    "fit_corey_relperm",
    "fit_brooks_corey_pc",
    "corey_relperm",
    "brooks_corey_pc",
    "relperm_table",
    "pc_table",
    "two_point_pc_fit",
]


# --------------------------------------------------------------------------- #
# Data containers
# --------------------------------------------------------------------------- #
@dataclass
class SCALCurve:
    """A laboratory SCAL curve set.

    Attributes
    ----------
    sw : np.ndarray
        Water saturation (must be monotonic increasing).
    krw : np.ndarray or None
        Water relative permeability.
    krow : np.ndarray or None
        Oil relative permeability in the oil-water system.
    krg : np.ndarray or None
        Gas relative permeability.
    krog : np.ndarray or None
        Oil relative permeability in the gas-oil system.
    pc_ow : np.ndarray or None
        Oil-water capillary pressure.
    pc_og : np.ndarray or None
        Oil-gas capillary pressure.
    """

    sw: np.ndarray
    krw: Optional[np.ndarray] = None
    krow: Optional[np.ndarray] = None
    krg: Optional[np.ndarray] = None
    krog: Optional[np.ndarray] = None
    pc_ow: Optional[np.ndarray] = None
    pc_og: Optional[np.ndarray] = None

    def __post_init__(self) -> None:
        self.sw = np.asarray(self.sw, dtype=float)
        for name in ("krw", "krow", "krg", "krog", "pc_ow", "pc_og"):
            v = getattr(self, name)
            if v is not None:
                setattr(self, name, np.asarray(v, dtype=float))
                if getattr(self, name).shape != self.sw.shape:
                    raise ValueError(f"{name} shape mismatch with sw")


@dataclass
class SCALFit:
    """Result of fitting a SCAL curve to a parametric model.

    Attributes
    ----------
    kind : str
        ``'krw'``, ``'krow'``, ``'krg'``, ``'krog'``, or ``'pc'``.
    exponent : float
        Corey exponent ``N`` (relperm) or Brooks-Corey ``lambda`` (pc).
    krr_max : float
        Endpoint relative permeability (relperm fits).
    swc : float
        Connate water saturation.
    sor : float
        Residual oil saturation.
    pc_entry : float
        Brooks-Corey entry pressure (pc fits).
    r2 : float
        Coefficient of determination of the fit.
    n_points : int
        Number of data points fit.
    """

    kind: str
    exponent: float
    krr_max: float = float("nan")
    swc: float = float("nan")
    sor: float = float("nan")
    pc_entry: float = float("nan")
    r2: float = float("nan")
    n_points: int = 0


# --------------------------------------------------------------------------- #
# Normalized saturation
# --------------------------------------------------------------------------- #
def normalize_saturation(
    sw: np.ndarray,
    swc: float,
    sor: float,
) -> np.ndarray:
    """Normalize water saturation to ``[0, 1]``.

    ``Snw = (Sw - Swc) / (1 - Swc - Sor)``

    The movable saturation range is ``[Swc, 1 - Sor]``.
    """
    sw = np.asarray(sw, dtype=float)
    denom = 1.0 - swc - sor
    if denom <= 0:
        raise ValueError("1 - Swc - Sor must be positive")
    snw = (sw - swc) / denom
    return np.clip(snw, 0.0, 1.0)


# --------------------------------------------------------------------------- #
# Corey / Burdine relative permeability
# --------------------------------------------------------------------------- #
def corey_relperm(
    sw: np.ndarray,
    n: float,
    krr_max: float,
    swc: float,
    sor: float,
    phase: str = "water",
) -> np.ndarray:
    """Evaluate a Corey relative-permeability curve.

    Parameters
    ----------
    sw : np.ndarray
        Water saturation.
    n : float
        Corey exponent.
    krr_max : float
        Endpoint relative permeability.
    swc, sor : float
        Connate water and residual oil saturations.
    phase : str
        ``'water'`` → krw = krr_max * Snw^n
        ``'oil_ow'`` → krow = krr_max * Sno^n  (oil-water system)
        ``'gas'`` → krg = krr_max * Sng^n
        ``'oil_og'`` → krog = krr_max * Sno^n  (gas-oil system)
    """
    sw = np.asarray(sw, dtype=float)
    if phase == "water":
        snw = normalize_saturation(sw, swc, sor)
        return krr_max * np.power(snw, n)
    elif phase in ("oil_ow", "oil_og"):
        snw = normalize_saturation(sw, swc, sor)
        sno = 1.0 - snw
        return krr_max * np.power(sno, n)
    elif phase == "gas":
        # gas relative perm is a function of gas saturation
        # Sg = 1 - Sw - Sor (assuming no mobile oil in the gas system)
        sg = 1.0 - sw - sor
        sg = np.clip(sg, 0.0, None)
        denom = 1.0 - swc - sor
        sng = sg / denom if denom > 0 else sg
        return krr_max * np.power(np.clip(sng, 0.0, 1.0), n)
    else:
        raise ValueError(f"unknown phase '{phase}'")


def fit_corey_relperm(
    sw: np.ndarray,
    kr: np.ndarray,
    swc: float,
    sor: float,
    krr_max: Optional[float] = None,
    phase: str = "water",
) -> SCALFit:
    """Fit a Corey relative-permeability curve to lab data.

    Recovers the exponent ``N`` (and optionally ``krr_max``) by linear
    regression in log-log space::

        ln(kr) = ln(krr_max) + N * ln(Sn)

    Parameters
    ----------
    sw, kr : np.ndarray
        Lab saturation / relative permeability points.
    swc, sor : float
        Connate water and residual oil saturations.
    krr_max : float, optional
        If given, held fixed; otherwise fitted as the intercept.
    phase : str
        See :func:`corey_relperm`.
    """
    sw = np.asarray(sw, dtype=float)
    kr = np.asarray(kr, dtype=float)
    if sw.shape != kr.shape:
        raise ValueError("sw and kr shape mismatch")
    if phase == "water":
        sn = normalize_saturation(sw, swc, sor)
    elif phase in ("oil_ow", "oil_og"):
        sn = 1.0 - normalize_saturation(sw, swc, sor)
    else:
        raise ValueError(f"fit_corey_relperm supports water/oil_ow/oil_og, got '{phase}'")

    # use only points with kr > 0 and 0 < Sn < 1
    valid = (kr > 0) & (sn > 0) & (sn < 1)
    if valid.sum() < 2:
        raise ValueError("need at least 2 valid points with kr>0 and 0<Sn<1")
    sn_v = sn[valid]
    kr_v = kr[valid]
    ln_sn = np.log(sn_v)
    ln_kr = np.log(kr_v)

    if krr_max is None:
        # linear fit ln(kr) = a + N ln(Sn); krr_max = exp(a) at Sn=1
        A = np.vstack([np.ones_like(ln_sn), ln_sn]).T
        coef, *_ = np.linalg.lstsq(A, ln_kr, rcond=None)
        a, n = coef
        krr_max_fit = float(np.exp(a))
    else:
        # fixed endpoint: ln(kr/krr_max) = N ln(Sn)
        krr_max_fit = float(krr_max)
        n = float(np.sum(ln_sn * (ln_kr - np.log(krr_max_fit))) /
                  np.sum(ln_sn * ln_sn))

    # R² of the fit in kr-space
    kr_pred = corey_relperm(sw, n, krr_max_fit, swc, sor, phase=phase)
    ss_res = np.sum((kr - kr_pred) ** 2)
    ss_tot = np.sum((kr - kr.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0

    return SCALFit(kind=phase, exponent=float(n), krr_max=krr_max_fit,
                   swc=float(swc), sor=float(sor), r2=float(r2),
                   n_points=int(valid.sum()))


# --------------------------------------------------------------------------- #
# Brooks-Corey capillary pressure
# --------------------------------------------------------------------------- #
def brooks_corey_pc(
    sw: np.ndarray,
    pc_entry: float,
    lam: float,
    swc: float,
    sor: float = 0.0,
) -> np.ndarray:
    """Evaluate a Brooks-Corey capillary-pressure curve.

    ``Pcow = Pentry * Snw^(-1/lambda)`` for ``Sw > Swc``, else ``Pentry`` at
    ``Sw = Swc`` (the entry pressure).
    """
    sw = np.asarray(sw, dtype=float)
    snw = normalize_saturation(sw, swc, sor)
    # avoid log(0) at Snw=0
    eps = 1e-12
    pc = pc_entry * np.power(np.clip(snw, eps, 1.0), -1.0 / lam)
    # at/above max saturation → 0
    pc = np.where(snw >= 1.0, 0.0, pc)
    return pc


def fit_brooks_corey_pc(
    sw: np.ndarray,
    pc: np.ndarray,
    swc: float,
    sor: float = 0.0,
    pc_entry: Optional[float] = None,
) -> SCALFit:
    """Fit a Brooks-Corey capillary-pressure curve to lab data.

    Recovers ``lambda`` (and optionally ``Pentry``) by linear regression in
    log-log space::

        ln(Pc) = ln(Pentry) - (1/lambda) * ln(Snw)

    Parameters
    ----------
    sw, pc : np.ndarray
        Lab saturation / capillary-pressure points.
    swc, sor : float
    pc_entry : float, optional
        If given, held fixed.
    """
    sw = np.asarray(sw, dtype=float)
    pc = np.asarray(pc, dtype=float)
    if sw.shape != pc.shape:
        raise ValueError("sw and pc shape mismatch")
    snw = normalize_saturation(sw, swc, sor)
    valid = (pc > 0) & (snw > 0) & (snw < 1)
    if valid.sum() < 2:
        raise ValueError("need at least 2 valid points with pc>0 and 0<Snw<1")
    sn_v = snw[valid]
    pc_v = pc[valid]
    ln_sn = np.log(sn_v)
    ln_pc = np.log(pc_v)

    if pc_entry is None:
        A = np.vstack([np.ones_like(ln_sn), ln_sn]).T
        coef, *_ = np.linalg.lstsq(A, ln_pc, rcond=None)
        a, slope = coef
        pc_entry_fit = float(np.exp(a))
        lam = -1.0 / slope
    else:
        pc_entry_fit = float(pc_entry)
        slope = float(np.sum(ln_sn * (ln_pc - np.log(pc_entry_fit))) /
                      np.sum(ln_sn * ln_sn))
        lam = -1.0 / slope

    pc_pred = brooks_corey_pc(sw, pc_entry_fit, lam, swc, sor)
    ss_res = np.sum((pc - pc_pred) ** 2)
    ss_tot = np.sum((pc - pc.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0

    return SCALFit(kind="pc", exponent=float(lam), pc_entry=pc_entry_fit,
                   swc=float(swc), sor=float(sor), r2=float(r2),
                   n_points=int(valid.sum()))


def two_point_pc_fit(
    swc: float,
    pc_entry: float,
    lam: float,
    sor: float = 0.0,
) -> SCALFit:
    """Build a Brooks-Corey fit from two known parameters (no fitting).

    Useful when the entry pressure and lambda are known from a
    drainage/imbibition endpoint analysis.
    """
    return SCALFit(kind="pc", exponent=float(lam), pc_entry=float(pc_entry),
                   swc=float(swc), sor=float(sor), r2=1.0, n_points=2)


# --------------------------------------------------------------------------- #
# Table look-up
# --------------------------------------------------------------------------- #
def relperm_table(
    curve: SCALCurve,
    sw: np.ndarray,
    phase: str = "water",
) -> np.ndarray:
    """Interpolate a relperm curve at ``sw`` using PCHIP (monotonic).

    Falls back to zero outside the data range.
    """
    src = {"water": curve.krw, "oil_ow": curve.krow,
           "gas": curve.krg, "oil_og": curve.krog}.get(phase)
    if src is None:
        raise ValueError(f"curve has no data for phase '{phase}'")
    f = PchipInterpolator(curve.sw, src, extrapolate=False)
    out = f(np.clip(sw, curve.sw.min(), curve.sw.max()))
    out = np.where(np.isnan(out), 0.0, out)
    return np.maximum(out, 0.0)


def pc_table(
    curve: SCALCurve,
    sw: np.ndarray,
    system: str = "ow",
) -> np.ndarray:
    """Interpolate a capillary-pressure curve at ``sw`` using PCHIP."""
    src = curve.pc_ow if system == "ow" else curve.pc_og
    if src is None:
        raise ValueError(f"curve has no {system} capillary pressure")
    f = PchipInterpolator(curve.sw, src, extrapolate=False)
    out = f(np.clip(sw, curve.sw.min(), curve.sw.max()))
    out = np.where(np.isnan(out), 0.0, out)
    return out
