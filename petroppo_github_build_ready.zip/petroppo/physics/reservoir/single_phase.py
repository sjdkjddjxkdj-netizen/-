"""
Single-phase Darcy flow solver (finite-volume, implicit).

Solves the pressure-diffusion equation

.. math::

    \\nabla \\cdot \\left( \\frac{k}{\\mu B} \\nabla p \\right)
    + q = \\frac{\\partial}{\\partial t}\\left( \\frac{\\phi}{B} \\right)

discretised with a two-point flux approximation (TPFA) on a structured
grid, backward Euler in time.  The system is linear (single phase) so a
single linear solve per timestep suffices.

This module is the *verification grade* simulator: it is the substrate
on which the Method-of-Manufactured-Solutions test and the analytical
radial-flow comparison are built.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .grid import ReservoirGrid
from .rock import RockProperties
from .pvt import SinglePhaseFluid
from .wells import Well, InjectorWell

__all__ = ["SinglePhaseSimulator", "SimulationState", "SimulationReport"]


# ---------------------------------------------------------------------------
# State and report
# ---------------------------------------------------------------------------

@dataclass
class SimulationState:
    """Snapshot of the simulation at one time."""

    time: float
    pressure: np.ndarray
    well_rates: dict[str, float] = field(default_factory=dict)
    well_bhp: dict[str, float] = field(default_factory=dict)


@dataclass
class SimulationReport:
    """Time-series container for a completed run."""

    times: list[float] = field(default_factory=list)
    states: list[SimulationState] = field(default_factory=list)
    dt_history: list[float] = field(default_factory=list)
    mass_balance_error: list[float] = field(default_factory=list)
    n_linear_solves: int = 0
    total_time: float = 0.0


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

class SinglePhaseSimulator:
    """Finite-volume single-phase Darcy flow on a structured grid.

    Parameters
    ----------
    grid : ReservoirGrid
    rock : RockProperties
    fluid : SinglePhaseFluid
    wells : list[Well]
    initial_pressure : array or float
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        rock: RockProperties,
        fluid: SinglePhaseFluid,
        wells: Optional[list[Well]] = None,
        initial_pressure: float | np.ndarray = 1.0e7,
        source_term: Optional[np.ndarray] = None,
    ) -> None:
        if rock.shape != grid.shape:
            raise ValueError("rock shape must match grid shape")
        self.grid = grid
        self.rock = rock
        self.fluid = fluid
        self.wells = wells or []

        nx, ny, nz = grid.shape
        self.n = nx * ny * nz

        if np.isscalar(initial_pressure):
            self.pressure = np.full(self.n, float(initial_pressure))
        else:
            self.pressure = np.asarray(initial_pressure, float).ravel()

        # optional per-cell source term (m3/s, reservoir conditions)
        if source_term is not None:
            self.source = np.asarray(source_term, float).ravel()
            if self.source.shape != (self.n,):
                raise ValueError("source_term must have shape (n_cells,)")
        else:
            self.source = None

        self.time = 0.0
        # Pre-compute geometric transmissibility factors (one half per face).
        self._tx, self._ty, self._tz = self._build_transmissibility()
        # Cell pore volumes
        self._pv = rock.porosity.ravel() * grid.cell_volumes().ravel()

    # ------------------------------------------------------------------
    # Transmissibility
    # ------------------------------------------------------------------
    def _build_transmissibility(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Half-transmissibilities T = k * A / (mu * B * d).

        Returns arrays for the +x, +y, +z faces.  Single-phase uses the
        harmonic average of the two half-transmissibilities.
        """
        g = self.grid
        k = self.rock
        # Use ref viscosity / B (constant for incompressible / slightly
        # compressible single phase).  The full p-dependence is in the
        # accumulation term via B(p).
        mu = self.fluid.ref_viscosity
        b_ref = 1.0 / self.fluid.formation_volume_factor(self.fluid.ref_pressure)

        # x-direction
        ax = g.face_area_x()              # (nx-1, ny, nz)
        dx = g.neighbour_distances()[0]
        kx_half = k.kx()
        t_x_left = kx_half[:-1] * ax / (0.5 * dx)
        t_x_right = kx_half[1:] * ax / (0.5 * dx)
        # series combination of two half-transmissibilities:
        # T_total = 1/(1/T_left + 1/T_right) = T_left*T_right/(T_left+T_right)
        tx = t_x_left * t_x_right / (t_x_left + t_x_right + 1e-30)
        tx = tx * b_ref / mu

        # y-direction
        ay = g.face_area_y()
        dy = g.neighbour_distances()[1]
        ky_half = k.ky()
        t_y_left = ky_half[:, :-1] * ay / (0.5 * dy)
        t_y_right = ky_half[:, 1:] * ay / (0.5 * dy)
        ty = t_y_left * t_y_right / (t_y_left + t_y_right + 1e-30)
        ty = ty * b_ref / mu

        # z-direction
        az = g.face_area_z()
        dz = g.neighbour_distances()[2]
        kz_half = k.kz()
        t_z_left = kz_half[:, :, :-1] * az / (0.5 * dz)
        t_z_right = kz_half[:, :, 1:] * az / (0.5 * dz)
        tz = t_z_left * t_z_right / (t_z_left + t_z_right + 1e-30)
        tz = tz * b_ref / mu

        return tx, ty, tz

    # ------------------------------------------------------------------
    # Assembly
    # ------------------------------------------------------------------
    def _assemble(self, p_old: np.ndarray, dt: float) -> tuple[sp.csr_matrix, np.ndarray]:
        """Assemble the linear system A p = b for one implicit step.

        Equation per cell:

            V_i * (phi/B)_i' * (p_i - p_old_i)/dt
            - sum_faces T (p_j - p_i) = q_i

        For single phase ``(phi/B)' = phi * c / B_ref`` approximately.
        """
        n = self.n
        nx, ny, nz = self.grid.shape

        rows: list[int] = []
        cols: list[int] = []
        data: list[float] = []

        tx, ty, tz = self._tx, self._ty, self._tz
        # accumulation coefficient
        c = self.fluid.compressibility
        b_ref = 1.0 / self.fluid.formation_volume_factor(self.fluid.ref_pressure)
        acc = self._pv * c * b_ref / dt     # per cell

        def add(r, cidx, val):
            rows.append(r); cols.append(cidx); data.append(val)

        idx = lambda i, j, k: i + j * nx + k * nx * ny

        # x-fluxes
        for i in range(nx - 1):
            for j in range(ny):
                for k in range(nz):
                    T = tx[i, j, k]
                    a, b = idx(i, j, k), idx(i + 1, j, k)
                    add(a, a, T);  add(a, b, -T)
                    add(b, b, T);  add(b, a, -T)

        # y-fluxes
        for i in range(nx):
            for j in range(ny - 1):
                for k in range(nz):
                    T = ty[i, j, k]
                    a, b = idx(i, j, k), idx(i, j + 1, k)
                    add(a, a, T);  add(a, b, -T)
                    add(b, b, T);  add(b, a, -T)

        # z-fluxes
        for i in range(nx):
            for j in range(ny):
                for k in range(nz - 1):
                    T = tz[i, j, k]
                    a, b = idx(i, j, k), idx(i, j, k + 1)
                    add(a, a, T);  add(a, b, -T)
                    add(b, b, T);  add(b, a, -T)

        A = sp.coo_matrix((data, (rows, cols)), shape=(n, n)).tocsr()
        # add accumulation diagonal
        A = A + sp.diags(acc, 0, shape=(n, n))

        # RHS = accumulation * p_old + well sources
        rhs = acc * p_old
        # add per-cell source term if present
        if self.source is not None:
            rhs = rhs + self.source
        return A, rhs

    # ------------------------------------------------------------------
    # Wells
    # ------------------------------------------------------------------
    def _apply_wells(
        self, A: sp.csr_matrix, rhs: np.ndarray, p: np.ndarray
    ) -> tuple[sp.csr_matrix, np.ndarray, dict[str, float], dict[str, float]]:
        """Apply well constraints; returns modified A, rhs, rates, bhps.

        The well source term is ``q = WI * (mobility) * (BHP - P_cell)``
        where mobility = 1/(mu * B) to match the transmissibility scaling
        used in the flux terms.  This keeps wells and inter-cell fluxes
        on the same physical footing.
        """
        nx, ny, nz = self.grid.shape
        well_rates: dict[str, float] = {}
        well_bhp: dict[str, float] = {}

        mu = self.fluid.ref_viscosity
        b_ref = 1.0 / self.fluid.formation_volume_factor(self.fluid.ref_pressure)
        mobility = b_ref / mu  # consistent with transmissibility scaling

        diag = A.diagonal().copy()
        for w in self.wells:
            total_wi = 0.0
            for perf in w.perforations:
                wi = perf.well_index * perf.multiplier
                total_wi += wi

            if w.control == "bhp":
                for perf in w.perforations:
                    ci = perf.i + perf.j * nx + perf.k * nx * ny
                    wi = perf.well_index * perf.multiplier * mobility
                    diag[ci] += wi
                    rhs[ci] += wi * w.target
                well_bhp[w.name] = w.target
                rate = sum(
                    perf.well_index * perf.multiplier * mobility *
                    (w.target - p[perf.i + perf.j * nx + perf.k * nx * ny])
                    for perf in w.perforations
                )
                well_rates[w.name] = rate
            elif w.control == "rate":
                if total_wi <= 0:
                    continue
                for perf in w.perforations:
                    ci = perf.i + perf.j * nx + perf.k * nx * ny
                    frac = perf.well_index * perf.multiplier / total_wi
                    sign = +1.0 if isinstance(w, InjectorWell) else -1.0
                    rhs[ci] += sign * frac * w.target
                well_rates[w.name] = w.target
                if w.perforations:
                    perf = w.perforations[0]
                    ci = perf.i + perf.j * nx + perf.k * nx * ny
                    sign = +1.0 if isinstance(w, InjectorWell) else -1.0
                    if perf.well_index > 0:
                        well_bhp[w.name] = p[ci] + sign * w.target / (total_wi * mobility)

        A = A.copy()
        A.setdiag(diag)
        return A, rhs, well_rates, well_bhp

    # ------------------------------------------------------------------
    # Time stepping
    # ------------------------------------------------------------------
    def step(self, dt: float) -> SimulationState:
        """Advance the simulation by ``dt`` seconds (one implicit step)."""
        p_old = self.pressure.copy()
        A, rhs = self._assemble(p_old, dt)
        A, rhs, rates, bhps = self._apply_wells(A, rhs, p_old)
        # solve
        p_new = spla.spsolve(A.tocsc(), rhs)
        self.pressure = p_new
        self.time += dt
        return SimulationState(self.time, p_new.copy(), rates, bhps)

    def run(
        self,
        total_time: float,
        dt: float,
        save_every: int = 1,
        report: Optional[SimulationReport] = None,
    ) -> SimulationReport:
        """Run the simulator for ``total_time`` seconds with fixed ``dt``."""
        import time as _time
        if report is None:
            report = SimulationReport()
        t0 = _time.perf_counter()
        nsteps = int(round(total_time / dt))
        state0 = SimulationState(self.time, self.pressure.copy())
        report.times.append(state0.time)
        report.states.append(state0)
        mass0 = self._mass()
        for s in range(nsteps):
            state = self.step(dt)
            report.n_linear_solves += 1
            report.dt_history.append(dt)
            mass_now = self._mass()
            err = (mass_now - mass0 - self._cumulative_injection(state)) / max(abs(mass0), 1.0)
            report.mass_balance_error.append(float(err))
            if (s + 1) % save_every == 0 or s == nsteps - 1:
                report.times.append(state.time)
                report.states.append(state)
        report.total_time = _time.perf_counter() - t0
        return report

    # ------------------------------------------------------------------
    # diagnostics
    # ------------------------------------------------------------------
    def _mass(self) -> float:
        """Total mass in place (kg)."""
        rho = self.fluid.density(self.pressure)
        return float(np.sum(rho * self._pv))

    def _cumulative_injection(self, state: SimulationState) -> float:
        """Approximate net mass injected since t=0 (kg)."""
        # crude: sum of well rates * time (assumes roughly constant)
        total = 0.0
        for w in self.wells:
            r = state.well_rates.get(w.name, 0.0)
            rho = self.fluid.ref_density
            total += r * rho * state.time
        return total
