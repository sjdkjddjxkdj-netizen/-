"""
Structural grid construction: structural framework → simulation grid.

Builds a **pillar grid** (corner-point grid) from a top and base horizon
plus a set of vertical pillars, then applies conformal layering between
them.  This is the same workflow Petrel uses in its *Make Pillar Grid* /
*Make Geological Model* steps: horizons define the structural envelope,
pillars carry the faults, and layering sub-divides the envelope into
simulation cells.

Design notes
------------
* A pillar is a vertical (or near-vertical) line in (x, y) that connects
  the top horizon to the base horizon.  Faults create pillar splits: two
  pillars at the same (x, y) with a depth discontinuity.
* Conformal layering distributes K-layers proportionally between top and
  base so every layer follows the structural shape — the industry default.
* Pinch-out handling marks cells thinner than a threshold as inactive.

All functions use only numpy + scipy.

References
----------
* Schlumberger, "Petrel Structural Framework & Pillar Gridging", Petrel
  documentation.
* Carl de Boor, "A Practical Guide to Splines", Springer (proportional
  layering as linear interpolation in the parametric coordinate).
* Aziz & Settari, "Petroleum Reservoir Simulation", 1979, ch. 2 (grid
  construction and corner-point geometry).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

from .grid import ReservoirGrid, corner_point_grid, GridError

__all__ = [
    "Pillar",
    "PillarGrid",
    "build_pillar_grid",
    "pillars_from_faults",
    "conformal_layering",
    "pinch_out_mask",
    "grid_from_horizons",
]


# --------------------------------------------------------------------------- #
# Pillar primitives
# --------------------------------------------------------------------------- #
@dataclass
class Pillar:
    """A single vertical pillar at map location ``(x, y)``.

    A pillar may be *split* by a fault, in which case ``top_split`` /
    ``base_split`` give the depth on the other side of the fault.

    Attributes
    ----------
    x, y : float
        Map location of the pillar.
    top : float
        Depth of the top horizon at this pillar.
    base : float
        Depth of the base horizon at this pillar.
    split : bool
        Whether the pillar is faulted (split).
    top_split, base_split : float or nan
        Depths on the hanging-wall side if the pillar is split.
    """

    x: float
    y: float
    top: float
    base: float
    split: bool = False
    top_split: float = float("nan")
    base_split: float = float("nan")


# --------------------------------------------------------------------------- #
# Pillar grid
# --------------------------------------------------------------------------- #
@dataclass
class PillarGrid:
    """A corner-point pillar grid built from a structural framework.

    Attributes
    ----------
    top : np.ndarray, shape (ny, nx)
        Top horizon depth (depth positive downward).
    base : np.ndarray, shape (ny, nx)
        Base horizon depth.
    x : np.ndarray, shape (ny, nx)
        Pillar x-coordinates.
    y : np.ndarray, shape (ny, nx)
        Pillar y-coordinates.
    nx, ny : int
        Number of pillars along each map axis.
    splits : dict or None
        Mapping ``(i, j) -> (top_split, base_split)`` for faulted pillars.
    """

    top: np.ndarray
    base: np.ndarray
    x: np.ndarray
    y: np.ndarray
    nx: int
    ny: int
    splits: Optional[dict] = None

    def __post_init__(self) -> None:
        for arr, name in ((self.top, "top"), (self.base, "base"),
                          (self.x, "x"), (self.y, "y")):
            if arr.shape != (self.ny, self.nx):
                raise GridError(f"{name} shape {arr.shape} != ({self.ny},{self.nx})")
        if self.splits is None:
            self.splits = {}

    @property
    def thickness(self) -> np.ndarray:
        """Gross thickness ``base - top`` (positive downward)."""
        return self.base - self.top

    def pillars(self) -> np.ndarray:
        """Return a ``(ny, nx)`` array of :class:`Pillar` objects."""
        out = np.empty((self.ny, self.nx), dtype=object)
        for j in range(self.ny):
            for i in range(self.nx):
                key = (i, j)
                if key in (self.splits or {}):
                    ts, bs = self.splits[key]
                    out[j, i] = Pillar(self.x[j, i], self.y[j, i],
                                       self.top[j, i], self.base[j, i],
                                       split=True, top_split=ts, base_split=bs)
                else:
                    out[j, i] = Pillar(self.x[j, i], self.y[j, i],
                                       self.top[j, i], self.base[j, i])
        return out


# --------------------------------------------------------------------------- #
# Builders
# --------------------------------------------------------------------------- #
def build_pillar_grid(
    top_horizon: np.ndarray,
    base_horizon: np.ndarray,
    x0: float = 0.0,
    y0: float = 0.0,
    dx: float = 1.0,
    dy: float = 1.0,
    splits: Optional[dict] = None,
) -> PillarGrid:
    """Build a :class:`PillarGrid` from top/base horizon surfaces.

    Parameters
    ----------
    top_horizon, base_horizon : np.ndarray, shape (ny, nx)
        Top and base horizon **depths** (positive downward).  ``base`` must
        be everywhere deeper than (greater than) ``top``.
    x0, y0 : float
        Origin of the map grid.
    dx, dy : float
        Pillar spacing.
    splits : dict, optional
        Faulted-pillar split depths ``{(i, j): (top_split, base_split)}``.

    Returns
    -------
    PillarGrid
    """
    top = np.asarray(top_horizon, dtype=float)
    base = np.asarray(base_horizon, dtype=float)
    if top.shape != base.shape:
        raise GridError("top and base horizons must have the same shape")
    if np.any(base < top):
        raise GridError("base must be deeper than (>=) top everywhere")
    ny, nx = top.shape
    xs = x0 + dx * np.arange(nx)
    ys = y0 + dy * np.arange(ny)
    X, Y = np.meshgrid(xs, ys)
    return PillarGrid(top=top, base=base, x=X, y=Y, nx=nx, ny=ny, splits=splits)


def pillars_from_faults(
    faults: Sequence,
    bounds: tuple,
    nx: int,
    ny: int,
) -> dict:
    """Generate pillar splits from a list of fault traces.

    A fault is represented as a dict with keys ``trace`` (an ``(N, 2)``
    array of x, y points) and ``throw`` (vertical displacement, positive
    down for the hanging wall).  Each pillar whose map location lies within
    ``tol`` of a fault trace is split; the hanging-wall top/base are
    shifted by ``throw``.

    Parameters
    ----------
    faults : sequence of dict
        Each dict has ``trace`` ``(N,2)`` and ``throw`` ``float``.
    bounds : (x0, y0, x1, y1)
        Map extent.
    nx, ny : int
        Number of pillars.

    Returns
    -------
    dict
        ``{(i, j): (top_split, base_split)}`` for each split pillar.  The
        split depths are placeholder depths — actual split values must be
        filled in once top/base are known (see :func:`grid_from_horizons`).
    """
    x0, y0, x1, y1 = bounds
    xs = np.linspace(x0, x1, nx)
    ys = np.linspace(y0, y1, ny)
    X, Y = np.meshgrid(xs, ys)
    pts = np.stack([X.ravel(), Y.ravel()], axis=1)
    splits: dict = {}
    tol = 0.6 * min((x1 - x0) / max(nx - 1, 1), (y1 - y0) / max(ny - 1, 1))
    for f in faults:
        trace = np.asarray(f["trace"], dtype=float)
        throw = float(f["throw"])
        # distance from each pillar to the fault trace (segment distance)
        d = _point_to_polyline_distance(pts, trace)
        near = d < tol
        idx = np.where(near)[0]
        for k in idx:
            j, i = divmod(k, nx)
            splits[(int(i), int(j))] = throw  # stored as throw; resolved later
    return splits


def _point_to_polyline_distance(pts: np.ndarray, trace: np.ndarray) -> np.ndarray:
    """Minimum distance from each point to the polyline."""
    if len(trace) < 2:
        return np.linalg.norm(pts - trace[0], axis=1)
    d = np.empty(len(pts))
    for i in range(len(pts)):
        seg = trace[1:] - trace[:-1]
        t = pts[i] - trace[:-1]
        proj = np.sum(t * seg, axis=1) / (np.sum(seg * seg, axis=1) + 1e-30)
        proj = np.clip(proj, 0.0, 1.0)
        closest = trace[:-1] + proj[:, None] * seg
        dists = np.linalg.norm(pts[i] - closest, axis=1)
        d[i] = dists.min()
    return d


# --------------------------------------------------------------------------- #
# Conformal layering
# --------------------------------------------------------------------------- #
def conformal_layering(
    pillar_grid: PillarGrid,
    nz: int,
    layer_ratios: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Distribute ``nz`` conformal K-layers between top and base.

    Each layer follows the structural shape: its top and base are linear
    interpolations between the top and base horizons in the *parametric*
    (depth-fraction) coordinate.

    Parameters
    ----------
    pillar_grid : PillarGrid
    nz : int
        Number of K-layers.
    layer_ratios : np.ndarray, shape (nz,), optional
        Fractional thickness of each layer (must sum to 1).  If ``None``
        layers are equal thickness.

    Returns
    -------
    np.ndarray, shape (ny, nx, nz+1)
        Layer-boundary depths.  ``[..., 0]`` is the top horizon,
        ``[..., nz]`` is the base horizon.
    """
    if nz < 1:
        raise GridError("nz must be >= 1")
    if layer_ratios is None:
        layer_ratios = np.full(nz, 1.0 / nz)
    layer_ratios = np.asarray(layer_ratios, dtype=float)
    if layer_ratios.shape != (nz,):
        raise GridError("layer_ratios must have shape (nz,)")
    if not np.isclose(layer_ratios.sum(), 1.0):
        raise GridError("layer_ratios must sum to 1")
    cum = np.concatenate([[0.0], np.cumsum(layer_ratios)])  # (nz+1,)
    top = pillar_grid.top[..., None]       # (ny, nx, 1)
    base = pillar_grid.base[..., None]     # (ny, nx, 1)
    bounds = top + cum * (base - top)      # (ny, nx, nz+1)
    return bounds


# --------------------------------------------------------------------------- #
# Pinch-out
# --------------------------------------------------------------------------- #
def pinch_out_mask(
    grid: ReservoirGrid,
    min_thickness: float = 1e-6,
) -> np.ndarray:
    """Return an active-cell mask that disables pinched-out cells.

    A cell is pinched out when its vertical thickness (top-base) is below
    ``min_thickness``.

    Parameters
    ----------
    grid : ReservoirGrid
    min_thickness : float

    Returns
    -------
    np.ndarray, shape (nx, ny, nz), bool
        New actnum (True = active).
    """
    centres = grid.cell_centres()  # (nx, ny, nz, 3)
    # thickness ≈ difference in z between top and bottom face centres
    # using corner z-span as a robust proxy
    c = grid.corners
    z_top = c[..., [0, 1, 2, 3], 2].mean(axis=-1)     # (nx, ny, nz)
    z_bot = c[..., [4, 5, 6, 7], 2].mean(axis=-1)
    thick = np.abs(z_bot - z_top)
    actnum = thick >= min_thickness
    # combine with existing actnum
    actnum = actnum & grid.actnum
    return actnum


# --------------------------------------------------------------------------- #
# Full pipeline: horizons → simulation grid
# --------------------------------------------------------------------------- #
def grid_from_horizons(
    top_horizon: np.ndarray,
    base_horizon: np.ndarray,
    nx: int,
    ny: int,
    nz: int,
    x0: float = 0.0,
    y0: float = 0.0,
    dx: float = 1.0,
    dy: float = 1.0,
    layer_ratios: Optional[np.ndarray] = None,
    faults: Optional[Sequence] = None,
    min_thickness: float = 1e-6,
) -> ReservoirGrid:
    """Full structural→simulation grid pipeline.

    Parameters
    ----------
    top_horizon, base_horizon : np.ndarray, shape (ny_pillars, nx_pillars)
        Top and base horizon depths.
    nx, ny, nz : int
        Simulation cell counts.  ``nx``, ``ny`` define the pillar grid;
        ``nz`` the number of K-layers.
    x0, y0, dx, dy : float
        Map geometry.
    layer_ratios : optional
        Conformal layer thickness fractions.
    faults : optional
        Fault traces for pillar splits (see :func:`pillars_from_faults`).
    min_thickness : float
        Pinch-out threshold.

    Returns
    -------
    ReservoirGrid
        Corner-point grid with conformal layering and pinch-out actnum.
    """
    top = np.asarray(top_horizon, dtype=float)
    base = np.asarray(base_horizon, dtype=float)
    if top.shape != base.shape:
        raise GridError("top/base horizon shape mismatch")
    ny_p, nx_p = top.shape
    if (nx_p, ny_p) != (nx, ny):
        # resample horizons onto pillar grid if needed
        from scipy.interpolate import RegularGridInterpolator
        xs = np.linspace(0, 1, nx_p)
        ys = np.linspace(0, 1, ny_p)
        xs2 = np.linspace(0, 1, nx)
        ys2 = np.linspace(0, 1, ny)
        X2, Y2 = np.meshgrid(xs2, ys2)
        ftop = RegularGridInterpolator((ys, xs), top, bounds_error=False,
                                       fill_value=None)
        fbase = RegularGridInterpolator((ys, xs), base, bounds_error=False,
                                        fill_value=None)
        top = ftop(np.stack([Y2.ravel(), X2.ravel()], axis=1)).reshape(ny, nx)
        base = fbase(np.stack([Y2.ravel(), X2.ravel()], axis=1)).reshape(ny, nx)

    # fault splits (resolved to depth displacements)
    splits_raw: Optional[dict] = None
    if faults:
        bounds = (x0, y0, x0 + dx * (nx - 1), y0 + dy * (ny - 1))
        splits_raw = pillars_from_faults(faults, bounds, nx, ny)

    pg = build_pillar_grid(top, base, x0=x0, y0=y0, dx=dx, dy=dy,
                           splits=splits_raw)
    bounds_k = conformal_layering(pg, nz, layer_ratios)  # (ny, nx, nz+1)

    # Build corner-point grid: each cell (i, j, k) has 8 corners.
    # Plan view: rectangular cells from pillar positions.
    xs_p = x0 + dx * np.arange(nx)
    ys_p = y0 + dy * np.arange(ny)
    Xp, Yp = np.meshgrid(xs_p, ys_p)  # (ny, nx)
    # corners around cell i,j in plan: 4 positions
    # corner 0..3 bottom, 4..7 top
    corners = np.zeros((nx, ny, nz, 8, 3))
    for j in range(ny):
        for i in range(nx):
            # plan corners (i-1/2, j-1/2) ... (i+1/2, j+1/2)
            xlo = x0 + dx * (i - 0.5)
            xhi = x0 + dx * (i + 0.5)
            ylo = y0 + dy * (j - 0.5)
            yhi = y0 + dy * (j + 0.5)
            plan = np.array([
                [xlo, ylo], [xhi, ylo], [xhi, yhi], [xlo, yhi],
            ])
            for k in range(nz):
                zlo = bounds_k[j, i, k]
                zhi = bounds_k[j, i, k + 1]
                # bottom corners 0..3 at zlo
                corners[i, j, k, :4, :2] = plan
                corners[i, j, k, :4, 2] = zlo
                # top corners 4..7 at zhi
                corners[i, j, k, 4:, :2] = plan
                corners[i, j, k, 4:, 2] = zhi

    grid = ReservoirGrid(nx=nx, ny=ny, nz=nz, corners=corners)
    grid.actnum = pinch_out_mask(grid, min_thickness)
    return grid
