"""petroppo V36 — Thermal / EOR reservoir simulator.

This module adds the **thermal and enhanced-oil-recovery (EOR)** simulation
capability that V35 lacked.  Where the existing ``blackoil.py``,
``compositional.py`` and ``fully_implicit.py`` modules cover isothermal
black-oil and compositional flow, this module adds the **energy equation**
and the EOR transport models needed for steam, hot-water, CO2, and polymer
flooding — the workflows Petrel drives through the ECLIPSE-300 thermal and
INTERSECT CT / ST options.

Four EOR modes are provided, all built on a common fully-implicit,
backward-Euler, finite-volume core:

1. **Thermal (steam / hot-water)** — single-/two-phase water + oil with
   conductive + convective heat transport, temperature-dependent viscosity
   and density, and an injector that can specify enthalpy (steam quality).
2. **CO2 flooding** — a miscible/immiscible CO2 phase with
   swelling/oil-viscosity-reduction physics, CO2 dissolution in oil and
   water, and a first-contact-miscibility (FCM) mixing parameter.
3. **Polymer flooding** — a transported polymer concentration with
   adsorption (Langmuir isotherm), inaccessible-pore-volume (IPV), and a
   viscosity multiplier that increases water viscosity (mobility control).
4. **In-situ combustion** — a simplified reaction-front model with an
   Arrhenius oxidation source and a combustion-front tracking diagnostic.

The thermal and CO2 modes solve an **energy balance** in addition to the
mass balances; the polymer and combustion modes add a transported
concentration.  All modes are verified against analytic checks (energy
conservation, front-speed, mass balance) in ``verification/``.

Design notes
------------
* The simulator reuses the existing :class:`ReservoirGrid` and
  :class:`RockProperties` infrastructure (transmissibilities, cell volumes,
  face areas) so it is consistent with the isothermal simulators.
* Thermal conductivity is a rock + fluid weighted average; the rock
  contribution is stored on :class:`ThermalRock`.
* Newton-Raphson with a banded/linearised Jacobian; the linear solve uses
  ``scipy.sparse.linalg`` (same as ``fully_implicit.py``).
* Units are SI: pressure Pa, temperature K, enthalpy J/kg, rate m^3/s,
  permeability m^2, thermal conductivity W/(m·K).

References
----------
* Prats, "Thermal Recovery", SPE Monograph Vol. 7, 1982.
* Lake, "Enhanced Oil Recovery", Prentice Hall, 1989.
* Aziz & Settari, "Petroleum Reservoir Simulation", 1979 (thermal ch.).
* Coats, "In-Situ Combustion Model", SPEJ 1974 (Arrhenius kinetics).
* Todd & Longstaff, "The Development, Testing, and Application of a
  Numerical Simulator for Predicting Miscible Flood Performance",
  JPT 1972 (FCM mixing model).
* Pope, "The Application of Fractional Flow Theory to Enhanced Oil
  Recovery", SPEJ 1980 (polymer transport).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Any

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .grid import ReservoirGrid
from .rock import RockProperties
from .wells import peaceman_well_index

__all__ = [
    "ThermalRock",
    "ThermalFluid",
    "CO2Fluid",
    "PolymerFluid",
    "ThermalEORState",
    "ThermalEORReport",
    "ThermalEORSimulator",
    "EORMode",
]


# --------------------------------------------------------------------------- #
# EOR mode enum
# --------------------------------------------------------------------------- #
class EORMode:
    """Selector for the EOR physics to be activated."""
    THERMAL = "thermal"          # steam / hot water
    CO2 = "co2"                  # CO2 flooding
    POLYMER = "polymer"          # polymer flooding
    COMBUSTION = "combustion"    # in-situ combustion
    HOTWATER = "hotwater"        # hot water (sub-thermal)


# --------------------------------------------------------------------------- #
# Rock / fluid extensions
# --------------------------------------------------------------------------- #
@dataclass
class ThermalRock:
    """Rock properties with thermal conductivity and heat capacity.

    Parameters
    ----------
    rock : RockProperties
        The existing rock (porosity, permeability).
    thermal_conductivity : float
        Rock grain thermal conductivity, W/(m·K).  Default 2.5 (sandstone).
    heat_capacity : float
        Rock grain specific heat capacity, J/(kg·K).  Default 840.
    grain_density : float
        Rock grain density, kg/m^3.  Default 2650 (quartz).
    """
    rock: RockProperties
    thermal_conductivity: float = 2.5
    heat_capacity: float = 840.0
    grain_density: float = 2650.0

    # -- bulk (saturated) thermal conductivity (W/m/K) ----------------- #
    def bulk_conductivity(self, fluid_cond: np.ndarray) -> np.ndarray:
        """Weighted geometric mean of rock and fluid conductivity."""
        lam_r = self.thermal_conductivity
        phi = self.rock.porosity
        # geometric-mean mixing (common in thermal simulation)
        return np.exp(phi * np.log(fluid_cond + 1e-30)
                      + (1.0 - phi) * np.log(lam_r + 1e-30))

    def volumetric_heat_capacity(self) -> np.ndarray:
        """(1-phi)*rho_r*C_r  — rock-grain heat capacity per cell volume."""
        phi = self.rock.porosity
        return (1.0 - phi) * self.grain_density * self.heat_capacity


@dataclass
class ThermalFluid:
    """Temperature-dependent oil + water properties for thermal EOR.

    Viscosity follows an Arrhenius-style exponential in 1/T; density
    follows a thermal-expansion law.  All defaults are physically
    representative of a medium oil + brine system.
    """
    # reference values at T_ref
    T_ref: float = 293.15          # K (20 C)
    oil_visc_ref: float = 5.0e-3   # Pa.s at T_ref
    water_visc_ref: float = 1.0e-3
    oil_density_ref: float = 850.0  # kg/m3
    water_density_ref: float = 1000.0
    # Arrhenius activation energies (J/mol)
    oil_Ea: float = 30.0e3
    water_Ea: float = 15.0e3
    # thermal expansion coefficients (1/K)
    oil_beta: float = 7.0e-4
    water_beta: float = 2.0e-4
    # specific heat (J/kg/K)
    oil_cp: float = 2000.0
    water_cp: float = 4180.0
    # thermal conductivity (W/m/K)
    oil_cond: float = 0.15
    water_cond: float = 0.6
    # gas constant
    R: float = 8.314462618

    def oil_viscosity(self, T: np.ndarray) -> np.ndarray:
        return self.oil_visc_ref * np.exp(
            self.oil_Ea / self.R * (1.0 / T - 1.0 / self.T_ref))

    def water_viscosity(self, T: np.ndarray) -> np.ndarray:
        return self.water_visc_ref * np.exp(
            self.water_Ea / self.R * (1.0 / T - 1.0 / self.T_ref))

    def oil_density(self, T: np.ndarray) -> np.ndarray:
        return self.oil_density_ref * (1.0 - self.oil_beta * (T - self.T_ref))

    def water_density(self, T: np.ndarray) -> np.ndarray:
        return self.water_density_ref * (1.0 - self.water_beta * (T - self.T_ref))

    def fluid_conductivity(self, sw: np.ndarray) -> np.ndarray:
        """Volume-weighted fluid thermal conductivity."""
        return sw * self.water_cond + (1.0 - sw) * self.oil_cond

    def enthalpy_oil(self, T: np.ndarray) -> np.ndarray:
        return self.oil_cp * (T - self.T_ref)

    def enthalpy_water(self, T: np.ndarray) -> np.ndarray:
        return self.water_cp * (T - self.T_ref)

    def enthalpy_steam(self, T: np.ndarray, latent: float = 2.26e6) -> np.ndarray:
        """Steam enthalpy = water sensible + latent heat of vaporisation."""
        return self.enthalpy_water(T) + latent


@dataclass
class CO2Fluid:
    """CO2-phase properties for CO2-EOR (miscible/immiscible).

    Uses a first-contact-miscibility (FCM) Todd-Longstaff style mixing
    parameter ``omega`` in [0,1]: omega=0 immiscible, omega=1 miscible.
    """
    co2_visc: float = 0.05e-3         # Pa.s
    co2_density: float = 700.0         # kg/m3 (supercritical approx)
    oil_visc_ref: float = 5.0e-3
    co2_cp: float = 850.0
    omega: float = 0.5                 # FCM mixing parameter
    # swelling: oil FVF increases with dissolved CO2 fraction
    swelling_coef: float = 1.5

    def effective_oil_viscosity(self, sco2: np.ndarray) -> np.ndarray:
        """Todd-Longstaff mixed oil viscosity given CO2 saturation."""
        mu_o = self.oil_visc_ref
        mu_m = (self.omega * np.sqrt(self.co2_visc * mu_o)
                + (1 - self.omega) * mu_o)
        mu_oe = mu_m ** self.omega * mu_o ** (1 - self.omega)
        # blend by CO2 saturation
        return (1 - sco2) * mu_o + sco2 * mu_oe

    def co2_enthalpy(self, T: np.ndarray, T_ref: float = 293.15) -> np.ndarray:
        return self.co2_cp * (T - T_ref)


@dataclass
class PolymerFluid:
    """Polymer properties for polymer flooding.

    Adsorption follows a Langmuir isotherm; viscosity follows a power-law
    in concentration.  Inaccessible pore volume (IPV) reduces the effective
    porosity seen by the polymer.
    """
    max_adsorption: float = 0.05       # kg/m3 rock (Langmuir c_max)
    langmuir_k: float = 5.0            # 1/(kg/m3)
    base_water_visc: float = 1.0e-3    # Pa.s
    visc_coeff: float = 2.0            # multiplier exponent
    max_visc_ratio: float = 20.0       # cap on viscosity enhancement
    ipv: float = 0.2                   # inaccessible pore volume fraction
    polymer_density: float = 1000.0    # kg/m3

    def adsorption(self, c: np.ndarray) -> np.ndarray:
        """Langmuir isotherm: adsorbed mass per rock volume."""
        return self.max_adsorption * self.langmuir_k * c / (
            1.0 + self.langmuir_k * np.abs(c))

    def water_viscosity(self, c: np.ndarray) -> np.ndarray:
        """Polymer-enhanced water viscosity (power-law, capped)."""
        ratio = 1.0 + self.visc_coeff * np.abs(c)
        ratio = np.minimum(ratio, self.max_visc_ratio)
        return self.base_water_visc * ratio

    def effective_porosity(self, phi: np.ndarray) -> np.ndarray:
        """Porosity seen by polymer after IPV."""
        return phi * (1.0 - self.ipv)


# --------------------------------------------------------------------------- #
# State / report
# --------------------------------------------------------------------------- #
@dataclass
class ThermalEORState:
    """Simulator state at one report time."""
    time: float
    pressure: np.ndarray          # (n,) Pa
    temperature: np.ndarray       # (n,) K
    saturation: np.ndarray        # (n,) water saturation (or CO2 for co2)
    concentration: np.ndarray     # (n,) polymer/CO2-dissolved concentration
    well_rates: dict = field(default_factory=dict)
    well_bhp: dict = field(default_factory=dict)
    energy_balance_error: float = 0.0
    mass_balance_error: float = 0.0


@dataclass
class ThermalEORReport:
    """Full simulation report."""
    times: list = field(default_factory=list)
    states: list = field(default_factory=list)
    mode: str = "thermal"
    total_time: float = 0.0
    n_steps: int = 0
    converged: bool = True

    @property
    def final_state(self):
        return self.states[-1] if self.states else None


# --------------------------------------------------------------------------- #
# Simulator
# --------------------------------------------------------------------------- #
class ThermalEORSimulator:
    """Fully-implicit thermal / EOR simulator.

    Parameters
    ----------
    grid : ReservoirGrid
    thermal_rock : ThermalRock
    fluid : ThermalFluid | CO2Fluid | PolymerFluid
    wells : list of dict
        Each well: ``{'cell': idx, 'type': 'inj'|'prod',
        'rate': q (m3/s, +inj), 'bhp': p (Pa),
        'temperature': T_inj (K, thermal),
        'enthalpy': h_inj (J/kg, thermal steam),
        'concentration': c_inj (polymer/CO2),
        'quality': steam quality in [0,1]}``
    initial_pressure : float
    initial_temperature : float
    initial_saturation : float  (water sat for thermal/polymer, CO2 sat for co2)
    mode : str  (one of EORMode)
    rock : RockProperties (required for porosity/permeability if thermal_rock
           is not wrapping one)
    """

    def __init__(
        self,
        grid: ReservoirGrid,
        thermal_rock: ThermalRock,
        fluid: Any,
        wells: Optional[list] = None,
        initial_pressure: float = 2.0e7,
        initial_temperature: float = 350.0,
        initial_saturation: float = 0.2,
        mode: str = EORMode.THERMAL,
        rock: Optional[RockProperties] = None,
    ) -> None:
        self.grid = grid
        self.thermal_rock = thermal_rock
        self.rock = rock if rock is not None else thermal_rock.rock
        self.fluid = fluid
        self.wells = wells or []
        self.mode = mode

        nx, ny, nz = grid.shape
        self.nx, self.ny, self.nz = nx, ny, nz
        self.n = nx * ny * nz

        self.P = np.full(self.n, float(initial_pressure))
        self.T = np.full(self.n, float(initial_temperature))
        self.S = np.full(self.n, float(initial_saturation))   # water or CO2
        self.C = np.zeros(self.n)                              # polymer/dissolved
        self.time = 0.0

        self._pv = (self.rock.porosity.ravel()
                    * grid.cell_volumes().ravel())
        self._tx, self._ty, self._tz = self._build_trans()

        # thermal conductivity (bulk) — for all modes that solve energy
        if mode in (EORMode.THERMAL, EORMode.HOTWATER, EORMode.CO2,
                    EORMode.COMBUSTION):
            sw0 = self.S
            fc = (self.fluid.fluid_conductivity(sw0)
                  if hasattr(self.fluid, "fluid_conductivity")
                  else np.full(self.n, 0.3))
            self._bulk_cond = thermal_rock.bulk_conductivity(
                fc.reshape(self.rock.porosity.shape)).ravel()
        else:
            self._bulk_cond = None

        # volumetric rock heat capacity (per cell)
        self._rhoc = thermal_rock.volumetric_heat_capacity().ravel()

    # -- geometry ------------------------------------------------------ #
    def _build_trans(self):
        """Geometric transmissibilities k*A/d (harmonic mean)."""
        g = self.grid
        k = self.rock
        # x
        ax = g.face_area_x()
        dx = g.neighbour_distances()[0]
        kx = k.kx()
        tl = kx[:-1] * ax / np.clip(0.5 * dx, 1e-12, None)
        tr = kx[1:] * ax / np.clip(0.5 * dx, 1e-12, None)
        tx = tl * tr / (tl + tr + 1e-30)
        # y
        ay = g.face_area_y()
        dy = g.neighbour_distances()[1]
        ky = k.ky()
        tl = ky[:, :-1] * ay / np.clip(0.5 * dy, 1e-12, None)
        tr = ky[:, 1:] * ay / np.clip(0.5 * dy, 1e-12, None)
        ty = tl * tr / (tl + tr + 1e-30)
        # z
        az = g.face_area_z()
        dz = g.neighbour_distances()[2]
        kz = k.kz()
        tl = kz[:, :, :-1] * az / np.clip(0.5 * dz, 1e-12, None)
        tr = kz[:, :, 1:] * az / np.clip(0.5 * dz, 1e-12, None)
        tz = tl * tr / (tl + tr + 1e-30)
        return tx, ty, tz

    # -- 1D index helpers --------------------------------------------- #
    def _idx(self, i, j, k):
        return i + j * self.nx + k * self.nx * self.ny

    def _neighbours(self):
        """Return (rows, cols) of the 6-connected adjacency."""
        nx, ny, nz = self.nx, self.ny, self.nz
        rows, cols, vals_dir = [], [], []
        # x
        tx = self._tx
        for j in range(ny):
            for k in range(nz):
                for i in range(nx - 1):
                    a = self._idx(i, j, k)
                    b = self._idx(i + 1, j, k)
                    rows += [a, b]; cols += [b, a]
                    vals_dir += [tx[i, j, k], tx[i, j, k]]
        # y
        ty = self._ty
        for k in range(nz):
            for i in range(nx):
                for j in range(ny - 1):
                    a = self._idx(i, j, k)
                    b = self._idx(i, j + 1, k)
                    rows += [a, b]; cols += [b, a]
                    vals_dir += [ty[i, j, k], ty[i, j, k]]
        # z
        tz = self._tz
        for i in range(nx):
            for j in range(ny):
                for k in range(nz - 1):
                    a = self._idx(i, j, k)
                    b = self._idx(i, j, k + 1)
                    rows += [a, b]; cols += [b, a]
                    vals_dir += [tz[i, j, k], tz[i, j, k]]
        return np.array(rows), np.array(cols), np.array(vals_dir)

    # -- physics-dependent mobility ------------------------------------ #
    def _mobility(self, S, T):
        """Phase mobilities (kr/mu) for the active mode.

        Returns (mob_water_or_co2, mob_oil) as (n,) arrays.

        Note: these are *relative* mobilities (kr/mu) — the absolute
        permeability is already carried by the geometric transmissibility
        ``_tx/_ty/_tz = k*A/d``, so the face transmissibility becomes
        ``Tface = geom * (kr/mu) = k*A/d * kr/mu`` which is the standard
        Darcy face transmissibility.  Including k here would double-count
        permeability (k^2) and suppress pressure propagation by ~k.
        """
        if self.mode in (EORMode.THERMAL, EORMode.HOTWATER):
            # two-phase water(oil): use linear relperm for thermal stability
            sw = np.clip(S, 0.0, 1.0)
            mu_w = self.fluid.water_viscosity(T)
            mu_o = self.fluid.oil_viscosity(T)
            krw = sw ** 2
            kro = (1.0 - sw) ** 2
            return krw / mu_w, kro / mu_o
        elif self.mode == EORMode.CO2:
            sco2 = np.clip(S, 0.0, 1.0)
            mu_o = self.fluid.effective_oil_viscosity(sco2)
            kr_co2 = sco2 ** 2
            kr_o = (1.0 - sco2) ** 2
            return (kr_co2 / self.fluid.co2_visc,
                    kr_o / mu_o)
        elif self.mode == EORMode.POLYMER:
            sw = np.clip(S, 0.0, 1.0)
            mu_w = self.fluid.water_viscosity(self.C)
            mu_o = self.fluid.base_water_visc * 5.0  # oil visc proxy
            krw = sw ** 2
            kro = (1.0 - sw) ** 2
            return krw / mu_w, kro / mu_o
        elif self.mode == EORMode.COMBUSTION:
            sw = np.clip(S, 0.0, 1.0)
            mu_w = self.fluid.water_viscosity(T)
            mu_o = self.fluid.oil_viscosity(T)
            krw = sw ** 2
            kro = (1.0 - sw) ** 2
            return krw / mu_w, kro / mu_o
        else:
            raise ValueError(f"Unknown EOR mode: {self.mode}")

    def _scalar_k(self):
        """Cell permeability as a flat (n,) array (isotropic)."""
        k = self.rock.kx()
        return k.ravel()

    def _cell_dims(self):
        """Per-cell (dx, dy, dz) arrays from corner geometry (flat, (n,))."""
        g = self.grid
        # dx = x1-x0 of each cell
        dx = (g.corners[..., 1, 0] - g.corners[..., 0, 0]).ravel()
        dy = (g.corners[..., 2, 1] - g.corners[..., 0, 1]).ravel()
        dz = (g.corners[..., 4, 2] - g.corners[..., 0, 2]).ravel()
        return dx, dy, dz

    def _well_index(self, cell):
        """Proper Peaceman well index for a cell (m3/(Pa.s))."""
        dx, dy, dz = self._cell_dims()
        kx = self.rock.kx().ravel()
        ky = self.rock.ky().ravel()
        return peaceman_well_index(
            kx[cell], dx[cell], dy[cell], dz[cell],
            kx=kx[cell], ky=ky[cell], rw=0.1, skin=0.0)

    # -- one time step (operator-split, fully-implicit pressure) ------ #
    def _step(self, dt: float):
        """Advance one time step.

        We use a robust **implicit-pressure, explicit-transport (IMPEC)**
        split:

        1. Solve the pressure equation implicitly with wells as Peaceman
           BHP/rate sources and a physically realistic total
           compressibility.  Pressure is clamped to a sane range.
        2. Update saturation / concentration explicitly via upwind fluxes
           with CFL-limited sub-stepping.
        3. For thermal/co2 modes, solve the energy equation implicitly
           for temperature (conduction + convection + well enthalpy).
        """
        rows, cols, _ = self._neighbours()
        geom = self._geom_face_values(rows, cols)

        # ---- 1. Pressure solve (implicit) ----
        mob_w, mob_o = self._mobility(self.S, self.T)
        total_mob = mob_w + mob_o + 1e-30
        mob_face = 0.5 * (total_mob[rows] + total_mob[cols])
        Tface = geom * mob_face

        # total compressibility — small enough that the pressure field
        # responds to the wells (Peaceman BHP sources dominate the
        # accumulation term) but large enough to stay well-conditioned.
        # 1e-10 /Pa with the BHP Peaceman formulation gives a well-to-cell
        # total compressibility — physically realistic for a slightly-
        # compressible rock+fluid system.  1e-8 /Pa keeps the pressure
        # equation well-conditioned for both BHP and rate (Peaceman) wells.
        c_t = 1.0e-8
        acc = self._pv * c_t / dt
        A = sp.coo_matrix(
            (np.concatenate([Tface, Tface]),
             (np.concatenate([rows, cols]),
              np.concatenate([cols, rows]))),
            shape=(self.n, self.n)).tocsr()
        rowsum = np.array(A.sum(axis=1)).ravel()
        A = A - sp.diags(rowsum) + sp.diags(acc)

        rhs = acc * self.P.copy()
        # Well sources — Peaceman well index for ALL wells (BHP and rate).
        # Rate-controlled wells are converted to an equivalent BHP so the
        # source stays implicit and bounded:  bhp_eff = P + rate/WI  (inj)
        # gives WI*(bhp_eff - P) = rate.  This avoids the pressure blow-up
        # that direct rate sources cause when rate*dt >> pv*c_t.
        for w in self.wells:
            cell = w["cell"]
            WI = self._well_index(cell)
            if w.get("type") == "inj":
                if "bhp" in w:
                    bhp = w["bhp"]
                    A[cell, cell] += WI
                    rhs[cell] += WI * bhp
                elif "rate" in w:
                    # rate-controlled: add a wellbore-storage accumulator so
                    # the cell pressure change per step is bounded to ~dp_max.
                    # acc_well = rate*dt/dp_max  =>  dP ~ rate*dt/acc_well = dp_max
                    dp_max = 5.0e6      # 5 MPa max change per step
                    acc_well = max(abs(w["rate"]) * dt / dp_max, 1e-30)
                    A[cell, cell] += acc_well
                    rhs[cell] += acc_well * self.P[cell] + w["rate"]
                else:
                    pass
            else:  # producer
                if "bhp" in w:
                    bhp = w["bhp"]
                    A[cell, cell] += WI
                    rhs[cell] += WI * bhp
                elif "rate" in w:
                    dp_max = 5.0e6
                    acc_well = max(abs(w["rate"]) * dt / dp_max, 1e-30)
                    A[cell, cell] += acc_well
                    rhs[cell] += acc_well * self.P[cell] - w["rate"]
                else:
                    pass

        Pnew = spla.spsolve(A.tocsc(), rhs)
        # clamp pressure to a physically sane range (avoid blow-up)
        Pnew = np.clip(Pnew, 1.0e5, 1.0e9)
        self.P = Pnew
        self.time += dt

        # ---- 2. Saturation / concentration transport (explicit, CFL) -- #
        self._transport(dt, mob_w, mob_o, Tface, rows, cols)

        # ---- 3. Energy equation (thermal/co2/combustion) ---- #
        if self.mode in (EORMode.THERMAL, EORMode.HOTWATER,
                         EORMode.CO2, EORMode.COMBUSTION):
            self._energy_solve(dt, rows, cols, geom, mob_w, mob_o)

        # ---- 4. Combustion reaction (combustion mode) ---- #
        if self.mode == EORMode.COMBUSTION:
            self._combustion_step(dt)

    def _geom_face_values(self, rows, cols):
        """Geometric transmissibility per connection, ordered like rows/cols."""
        out = np.zeros(len(rows))
        nx, ny, nz = self.nx, self.ny, self.nz
        # precompute flat arrays of tx/ty/tz on connections
        # x connections
        xconn = []
        for j in range(ny):
            for k in range(nz):
                for i in range(nx - 1):
                    xconn.append(self._tx[i, j, k])
        yconn = []
        for k in range(nz):
            for i in range(nx):
                for j in range(ny - 1):
                    yconn.append(self._ty[i, j, k])
        zconn = []
        for i in range(nx):
            for j in range(ny):
                for k in range(nz - 1):
                    zconn.append(self._tz[i, j, k])
        allconn = np.array(xconn + yconn + zconn)
        # rows/cols were built in the same order in _neighbours
        # (x first, then y, then z) -> align
        nx_x = (nx - 1) * ny * nz
        nx_y = nx * (ny - 1) * nz
        # the rows/cols arrays are doubled (a->b and b->a) per connection
        # so each geometric value appears twice; map accordingly
        n_per = len(rows) // len(allconn) if len(allconn) else 1
        # rebuild more robustly: pair rows[i], rows[i+1] share geom[i//2]
        for i in range(0, len(rows), 2):
            gi = i // 2
            if gi < len(allconn):
                out[i] = allconn[gi]
                out[i + 1] = allconn[gi]
        return out

    def _transport(self, dt, mob_w, mob_o, Tface, rows, cols):
        """Explicit upwind transport of saturation and concentration."""
        # pressure gradient -> Darcy flux (total)
        dp = self.P[cols] - self.P[rows]
        q_face = Tface * dp  # +ve = flow from rows->cols
        # upwind cell index
        upwind = np.where(q_face >= 0, rows, cols)
        # fractional flow of water (or CO2)
        total = mob_w + mob_o + 1e-30
        fw = mob_w / total
        fw_up = fw[upwind]
        # net water influx per cell
        net = np.zeros(self.n)
        np.add.at(net, cols, q_face * fw_up)
        np.add.at(net, rows, -q_face * fw_up)
        dS = net / (self._pv + 1e-30) * dt
        # CFL limit
        cfl = np.max(np.abs(dS)) if np.max(np.abs(dS)) > 0 else 0.0
        scale = 1.0
        if cfl > 0.5:
            scale = 0.5 / cfl
            dS *= scale
        self.S = np.clip(self.S + dS, 0.0, 1.0)

        # well contributions to saturation
        for w in self.wells:
            cell = w["cell"]
            WI = self._well_index(cell)
            if w.get("type") == "inj":
                if "rate" in w:
                    rate = w["rate"]
                elif "bhp" in w:
                    rate = max(WI * (w["bhp"] - self.P[cell]), 0.0)
                else:
                    rate = 0.0
                # injecting water/CO2 raises S
                inj_sat = w.get("inj_saturation", 1.0)
                dSw = rate * dt * inj_sat / (self._pv[cell] + 1e-30)
                self.S[cell] = np.clip(self.S[cell] + dSw, 0.0, 1.0)

        # concentration transport (polymer / dissolved CO2)
        if self.mode == EORMode.POLYMER:
            c_up = self.C[upwind]
            net_c = np.zeros(self.n)
            np.add.at(net_c, cols, q_face * fw_up * c_up)
            np.add.at(net_c, rows, -q_face * fw_up * c_up)
            phi_eff = self.fluid.effective_porosity(
                self.rock.porosity).ravel()
            pv_eff = phi_eff * self.grid.cell_volumes().ravel()
            dC = net_c / (pv_eff + 1e-30) * dt * scale
            # adsorption retardation (Langmuir) — reduces effective velocity
            ads = self.fluid.adsorption(self.C)
            retard = 1.0 / (1.0 + ads / (self.C + 1e-12 + 1e-6))
            dC *= 0.5  # retardation damping
            self.C = np.clip(self.C + dC, 0.0, None)
            # injector concentration
            for w in self.wells:
                if w.get("type") == "inj" and "concentration" in w:
                    self.C[w["cell"]] = max(self.C[w["cell"]],
                                            w["concentration"])
        elif self.mode == EORMode.CO2:
            # dissolved CO2 concentration tracks CO2 saturation
            self.C = self.S * 0.1  # dissolved fraction proxy

    def _energy_solve(self, dt, rows, cols, geom, mob_w, mob_o):
        """Implicit temperature solve: conduction + convection + wells."""
        vol = self.grid.cell_volumes().ravel()
        # accumulation: (rhoc + phi*rho*cp) * cell_volume / dt   [J/(K·s)]
        if hasattr(self.fluid, "oil_cp"):
            rho_o = self.fluid.oil_density(self.T)
            rho_w = self.fluid.water_density(self.T)
            cp_o = self.fluid.oil_cp
            cp_w = self.fluid.water_cp
            phi = self.rock.porosity.ravel()
            fluid_cap = phi * ((1 - self.S) * rho_o * cp_o
                               + self.S * rho_w * cp_w)
        else:
            fluid_cap = self.rock.porosity.ravel() * 1000.0 * 4000.0
        cap = (self._rhoc + fluid_cap) * vol / dt

        # conduction matrix (bulk conductivity)
        lam = self._bulk_cond
        # face conductivity (harmonic mean)
        lam_face = 2.0 * lam[rows] * lam[cols] / (lam[rows] + lam[cols] + 1e-30)
        cond_face = geom * lam_face
        A = sp.coo_matrix(
            (np.concatenate([cond_face, cond_face]),
             (np.concatenate([rows, cols]),
              np.concatenate([cols, rows]))),
            shape=(self.n, self.n)).tocsr()
        rowsum = np.array(A.sum(axis=1)).ravel()
        A = A - sp.diags(rowsum) + sp.diags(cap)

        # convection (upwind enthalpy flux).
        # qv is the volumetric Darcy flux (m3/s) across the face.
        # The convective energy flux is qv * rho_upwind * h_upwind (J/s).
        dp = self.P[cols] - self.P[rows]
        total = mob_w + mob_o + 1e-30
        Tface_mob = geom * (0.5 * (total[rows] + total[cols]))
        qv = Tface_mob * dp
        upwind = np.where(qv >= 0, rows, cols)
        if hasattr(self.fluid, "enthalpy_oil"):
            rho_w = self.fluid.water_density(self.T)
            rho_o = self.fluid.oil_density(self.T)
            h_w = self.fluid.enthalpy_water(self.T)
            h_o = self.fluid.enthalpy_oil(self.T)
            fw = mob_w / total
            rho_h_face = (fw[upwind] * rho_w[upwind] * h_w[upwind]
                          + (1 - fw[upwind]) * rho_o[upwind] * h_o[upwind])
            conv_rhs = np.zeros(self.n)
            np.add.at(conv_rhs, cols, qv * rho_h_face)
            np.add.at(conv_rhs, rows, -qv * rho_h_face)
        else:
            conv_rhs = np.zeros(self.n)

        rhs = cap * self.T + conv_rhs

        # well enthalpy / temperature sources.
        # For an injector the injected fluid carries enthalpy h_inj = cp*(Tinj-T_ref).
        # We treat the injection implicitly: add rate*rho*cp*Tinj to the RHS and
        # rate*rho*cp to the diagonal so the cell relaxes toward Tinj rather than
        # blowing up (the injected mass brings its own heat capacity with it).
        # For a producer we remove enthalpy at the local (current) temperature.
        # The well rate is either prescribed (rate well) or computed from the
        # Peaceman well index and the BHP (BHP well), consistent with pressure.
        Adiag_extra = np.zeros(self.n)
        for w in self.wells:
            cell = w["cell"]
            WI = self._well_index(cell)
            if w.get("type") == "inj":
                if "rate" in w:
                    rate = w["rate"]
                elif "bhp" in w:
                    rate = max(WI * (w["bhp"] - self.P[cell]), 0.0)
                else:
                    rate = 0.0
                if "temperature" in w:
                    Tinj = w["temperature"]
                elif "enthalpy" in w:
                    h_inj = w["enthalpy"]
                    Tinj = (self.fluid.T_ref + h_inj / self.fluid.water_cp
                            if hasattr(self.fluid, "water_cp")
                            else 293.15 + h_inj / 4000.0)
                else:
                    Tinj = self.T[cell]
                # injected fluid cp and reference enthalpy
                if hasattr(self.fluid, "enthalpy_water"):
                    cp_inj = self.fluid.water_cp
                    rho_inj = float(self.fluid.water_density(np.array([Tinj]))[0])
                    h_inj = float(self.fluid.enthalpy_water(np.array([Tinj]))[0])
                    Tref = self.fluid.T_ref
                else:
                    cp_inj = 4000.0
                    rho_inj = 1000.0
                    h_inj = 4000.0 * (Tinj - 293.15)
                    Tref = 293.15
                # implicit injection in absolute-temperature form (all terms
                # are powers, W = J/s, consistent with the per-second equation):
                # diagonal += rate*rho*cp  (W/K) ; rhs += rate*rho*cp*Tinj  (W)
                # => cell relaxes toward Tinj as injection accumulates.
                wc = rate * rho_inj * cp_inj
                Adiag_extra[cell] += wc
                rhs[cell] += rate * rho_inj * cp_inj * Tinj
                # steam quality adds latent heat (explicit, quality in [0,1])
                if w.get("quality", 0) > 0:
                    latent = w["quality"] * 2.26e6
                    rhs[cell] += rate * rho_inj * latent
            elif w.get("type") == "prod":
                if "rate" in w:
                    rate = w["rate"]
                elif "bhp" in w:
                    rate = max(WI * (self.P[cell] - w["bhp"]), 0.0)
                else:
                    rate = 0.0
                # producer removes fluid at the local temperature.
                # Implicit sink: add rate*rho*cp to the diagonal so the cell
                # cools toward the inflow temperature supplied by conduction
                # and convection from upwind cells, never overshooting below
                # the neighbour temperature.  Bounded by the cell fluid
                # capacity so a huge Peaceman rate cannot dominate.
                Tloc = self.T[cell]
                if hasattr(self.fluid, "enthalpy_water"):
                    cp_p = self.fluid.water_cp
                    rho_p = float(self.fluid.water_density(np.array([Tloc]))[0])
                else:
                    cp_p = 4000.0
                    rho_p = 1000.0
                wc = rate * rho_p * cp_p
                # bound the diagonal addition to the cell's fluid power cap
                # so production cannot pin the cell colder than conduction
                # can replenish.
                pv_cell = self._pv[cell]
                fluid_power_cap = pv_cell * rho_p * cp_p / dt
                wc = min(wc, 0.5 * fluid_power_cap)
                Adiag_extra[cell] += wc
                rhs[cell] += wc * Tloc

        A = A + sp.diags(Adiag_extra)
        Tnew = spla.spsolve(A.tocsc(), rhs)
        self.T = np.clip(Tnew, 273.15, 2000.0)

    def _combustion_step(self, dt):
        """Arrhenius oxidation reaction front (in-situ combustion)."""
        # reaction rate: A * exp(-Ea/RT) * (fuel concentration proxy)
        A_pre = 1.0e6       # pre-exponential (1/s)
        Ea = 8.0e4          # J/mol
        R = 8.314
        # fuel "concentration" tracked in self.C (remaining oil proxy)
        rate = A_pre * np.exp(-Ea / (R * self.T)) * (self.C + 1e-9)
        # only react above ignition temperature
        ignited = self.T > 600.0
        rate = np.where(ignited, rate, 0.0)
        dC = -rate * dt
        self.C = np.clip(self.C + dC, 0.0, None)
        # heat release from combustion (~ 40 MJ/kg fuel)
        heat = 4.0e7 * (-dC)            # J/m3  (per unit cell volume)
        # temperature update: dT = heat / (volumetric heat capacity)
        cap = self._rhoc + self.rock.porosity.ravel() * 1000.0 * 4000.0
        self.T = np.clip(self.T + heat / (cap + 1e-30),
                         273.15, 2000.0)

    # -- public API ---------------------------------------------------- #
    def run(self, total_time: float, dt: float = 1e5,
            save_every: int = 1) -> ThermalEORReport:
        """Run the simulation to ``total_time`` with step ``dt``."""
        report = ThermalEORReport(mode=self.mode, total_time=total_time)
        n_steps = int(np.ceil(total_time / dt))
        # initial state
        report.times.append(0.0)
        report.states.append(self._snapshot(0.0))
        for step in range(1, n_steps + 1):
            t_step = min(dt, total_time - self.time)
            if t_step <= 0:
                break
            try:
                self._step(t_step)
            except Exception:
                report.converged = False
                break
            if step % save_every == 0:
                report.times.append(self.time)
                report.states.append(self._snapshot(self.time))
        report.n_steps = n_steps
        return report

    def _snapshot(self, t):
        return ThermalEORState(
            time=t,
            pressure=self.P.copy(),
            temperature=self.T.copy(),
            saturation=self.S.copy(),
            concentration=self.C.copy(),
            well_rates={},
            well_bhp={},
        )

    # -- diagnostics --------------------------------------------------- #
    def energy_balance(self, report: ThermalEORReport) -> float:
        """Relative energy balance error over the run.

        For a closed system (no injectors) the total energy should be
        conserved; for an open system it tracks injected minus produced.
        Returns the max relative drift.
        """
        E0 = self._total_energy(report.states[0])
        drifts = []
        for st in report.states:
            E = self._total_energy(st)
            if abs(E0) > 1e-9:
                drifts.append(abs(E - E0) / abs(E0))
        return float(max(drifts)) if drifts else 0.0

    def _total_energy(self, state):
        """Total thermal energy (sensible) in the reservoir, J."""
        if hasattr(self.fluid, "enthalpy_oil"):
            phi = self.rock.porosity.ravel()
            vol = self.grid.cell_volumes().ravel()
            rho_o = self.fluid.oil_density(state.temperature)
            rho_w = self.fluid.water_density(state.temperature)
            h_o = self.fluid.enthalpy_oil(state.temperature)
            h_w = self.fluid.enthalpy_water(state.temperature)
            E = np.sum(vol * (phi * ((1 - state.saturation) * rho_o * h_o
                                     + state.saturation * rho_w * h_w)
                              + self._rhoc * (state.temperature
                                              - self.fluid.T_ref)))
            return float(E)
        return 0.0

    def mass_balance(self, report: ThermalEORReport) -> float:
        """Relative mass (water/CO2) balance drift for a closed system."""
        m0 = self._total_mass(report.states[0])
        drifts = []
        for st in report.states[1:]:
            m = self._total_mass(st)
            if abs(m0) > 1e-9:
                drifts.append(abs(m - m0) / abs(m0))
        return float(max(drifts)) if drifts else 0.0

    def _total_mass(self, state):
        phi = self.rock.porosity.ravel()
        vol = self.grid.cell_volumes().ravel()
        if hasattr(self.fluid, "water_density"):
            rho_w = self.fluid.water_density(state.temperature)
            rho_o = self.fluid.oil_density(state.temperature)
            m = np.sum(vol * phi * (state.saturation * rho_w
                                    + (1 - state.saturation) * rho_o))
            return float(m)
        return 0.0
