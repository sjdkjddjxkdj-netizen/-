"""V36-4 — End-to-end P10/P50/P90 uncertainty propagation.

This module chains uncertainty from the earliest geophysical measurement
all the way through to the final production forecast:

    seismic → geology → petrophysics → reservoir → production

Each stage in the chain receives an **ensemble** of plausible input
realizations (drawn from that stage's own uncertainty distribution),
transforms them through the relevant physics model, and passes the
resulting ensemble downstream.  The final stage (reservoir simulation)
produces an ensemble of production time-series, from which the
P10/P50/P90 probabilistic production forecast is extracted.

This is the key capability that distinguishes a "reservoir-dominance"
platform from a feature-counting one: instead of a single deterministic
best-guess answer, the user receives a **calibrated probabilistic
forecast** with quantified confidence at every stage of the workflow.

Design principles
-----------------
1. **Monte Carlo backbone.**  Every stage is an ensemble transform.  The
   chain width (number of realizations) is set once at the top and
   preserved (or sub-sampled) through every stage.

2. **Decorrelated stages.**  Each stage declares its own parameters and
   uncertainty model.  Downstream stages see the *output* ensemble of
   upstream stages, not their internal parameters — so the chain is
   composable and testable in isolation.

3. **P10/P50/P90 at every node.**  Every stage can report its own
   P10/P50/P90, so the user can inspect where uncertainty grows or
   shrinks along the chain (uncertainty budgeting).

4. **Reproducibility.**  A single master seed propagates to all stages.

P10/P50/P90 convention (SPE / petroleum industry standard)
----------------------------------------------------------
* **P10** = 90th percentile (optimistic, 10 % chance of being exceeded)
* **P50** = 50th percentile (median, best estimate)
* **P90** = 10th percentile (pessimistic, 90 % chance of being exceeded)

For production rates and cumulative volumes, higher is better, so
P10 > P50 > P90.

References
----------
* Caers, J. (2011). *Modeling Uncertainty in the Earth Sciences*. Wiley.
* Pyrcz & Deutsch (2014). *Geostatistical Reservoir Modeling*. OUP.
* Emerick, A. A. & Reynolds, A. C. (2013). "Ensemble smoother with
  multiple data assimilation." *Computational Geosciences* 17(3).
* SPE/WPC/AAPG/SPEE Petroleum Resources Management System (2007).
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Callable, Any

__all__ = [
    "StageResult",
    "PropagationChain",
    "PropagationResult",
    "ProductionForecast",
    "SeismicStage",
    "GeologyStage",
    "PetrophysicsStage",
    "ReservoirStage",
    "UncertaintyBudget",
    "run_end_to_end_propagation",
]


# ── helpers ──────────────────────────────────────────────────────────────

def _p10p50p90(samples: np.ndarray, axis: int = 0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """P10/P50/P90 along *axis* (SPE convention: P10 = 90th pct)."""
    p10 = np.percentile(samples, 90, axis=axis)
    p50 = np.percentile(samples, 50, axis=axis)
    p90 = np.percentile(samples, 10, axis=axis)
    return p10, p50, p90


# ── stage result container ───────────────────────────────────────────────

@dataclass
class StageResult:
    """Holds the output ensemble of a single propagation stage.

    Attributes
    ----------
    name : str
        Stage identifier (e.g. "seismic", "reservoir").
    ensemble : np.ndarray, shape (n_real, ...)
        The ensemble of realizations produced by this stage.
    p10, p50, p90 : np.ndarray
        P10/P50/P90 of the ensemble (SPE convention).
    std : np.ndarray
        Per-element standard deviation across the ensemble.
    n_real : int
        Number of realizations in the ensemble.
    metadata : dict
        Stage-specific bookkeeping (parameter names, units, …).
    """
    name: str
    ensemble: np.ndarray
    p10: np.ndarray
    p50: np.ndarray
    p90: np.ndarray
    std: np.ndarray
    n_real: int
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_ensemble(cls, name: str, ensemble: np.ndarray, metadata: dict | None = None) -> "StageResult":
        p10, p50, p90 = _p10p50p90(ensemble, axis=0)
        std = np.std(ensemble, axis=0)
        return cls(
            name=name,
            ensemble=ensemble,
            p10=p10, p50=p50, p90=p90,
            std=std,
            n_real=ensemble.shape[0],
            metadata=metadata or {},
        )

    def summary(self) -> dict:
        """Compact summary for the uncertainty budget."""
        return {
            "stage": self.name,
            "n_real": self.n_real,
            "shape": tuple(self.ensemble.shape[1:]),
            "mean_std": float(np.mean(self.std)),
            "max_std": float(np.max(self.std)),
            "metadata": self.metadata,
        }


# ── production forecast ──────────────────────────────────────────────────

@dataclass
class ProductionForecast:
    """Probabilistic production forecast (P10/P50/P90) for one phase.

    Attributes
    ----------
    times : np.ndarray
        Time points (days).
    p10, p50, p90 : np.ndarray
        P10/P50/P90 rate (or cumulative) at each time.
    ensemble : np.ndarray, shape (n_real, n_times)
        The full ensemble of production time-series.
    phase : str
        "oil", "water", "gas", or "liquid".
    cumulative : bool
        If True, values are cumulative volumes; if False, instantaneous rates.
    n_real : int
        Number of realizations.
    """
    times: np.ndarray
    p10: np.ndarray
    p50: np.ndarray
    p90: np.ndarray
    ensemble: np.ndarray
    phase: str = "oil"
    cumulative: bool = False
    n_real: int = 0

    @classmethod
    def from_ensemble(cls, times: np.ndarray, ensemble: np.ndarray,
                      phase: str = "oil", cumulative: bool = False) -> "ProductionForecast":
        """Build a ProductionForecast from an ensemble of time-series.

        Parameters
        ----------
        times : (n_times,)
        ensemble : (n_real, n_times)
        phase : str
        cumulative : bool
        """
        p10, p50, p90 = _p10p50p90(ensemble, axis=0)
        return cls(
            times=times, p10=p10, p50=p50, p90=p90,
            ensemble=ensemble, phase=phase, cumulative=cumulative,
            n_real=ensemble.shape[0],
        )

    def ultimate_recovery(self) -> tuple[float, float, float]:
        """P10/P50/P90 ultimate recovery (last value of the cumulative curve).

        If *cumulative* is False, integrate the rate ensemble first.
        """
        if self.cumulative:
            ur = self.ensemble[:, -1]
        else:
            dt = np.diff(self.times, prepend=self.times[0])
            ur = np.sum(self.ensemble * dt[np.newaxis, :], axis=1)
        p10 = float(np.percentile(ur, 90))
        p50 = float(np.percentile(ur, 50))
        p90 = float(np.percentile(ur, 10))
        return p10, p50, p90


# ── uncertainty budget ───────────────────────────────────────────────────

@dataclass
class UncertaintyBudget:
    """Tracks how uncertainty evolves (or is introduced) at each stage.

    Attributes
    ----------
    stages : list[dict]
        One entry per stage with name, mean_std, max_std, n_real.
    """
    stages: list[dict] = field(default_factory=list)

    def add(self, stage_result: StageResult) -> None:
        self.stages.append(stage_result.summary())

    def table(self) -> str:
        """Render the uncertainty budget as a readable table."""
        lines = []
        lines.append(f"{'Stage':<20} {'N_real':>8} {'Mean_std':>12} {'Max_std':>12} {'Shape'}")
        lines.append("-" * 70)
        for s in self.stages:
            shape = "×".join(str(d) for d in s["shape"]) if s["shape"] else "scalar"
            lines.append(
                f"{s['stage']:<20} {s['n_real']:>8d} {s['mean_std']:>12.4g} "
                f"{s['max_std']:>12.4g} {shape}"
            )
        return "\n".join(lines)


# ── propagation result ───────────────────────────────────────────────────

@dataclass
class PropagationResult:
    """Final result of the end-to-end uncertainty propagation.

    Attributes
    ----------
    stage_results : dict[str, StageResult]
        Per-stage ensembles and P10/P50/P90.
    forecasts : dict[str, ProductionForecast]
        Production forecasts keyed by phase ("oil", "water", "gas").
    budget : UncertaintyBudget
        Uncertainty budget table across all stages.
    n_real : int
        Chain width (ensemble size).
    master_seed : int
        Reproducibility seed.
    """
    stage_results: dict = field(default_factory=dict)
    forecasts: dict = field(default_factory=dict)
    budget: UncertaintyBudget = field(default_factory=UncertaintyBudget)
    n_real: int = 0
    master_seed: int = 0

    def ultimate_recovery(self, phase: str = "oil") -> tuple[float, float, float]:
        """P10/P50/P90 ultimate recovery for *phase*."""
        if phase not in self.forecasts:
            raise KeyError(f"No forecast for phase '{phase}'. Available: {list(self.forecasts)}")
        return self.forecasts[phase].ultimate_recovery()


# ── stage base class ─────────────────────────────────────────────────────

class PropagationStage:
    """Base class for a single stage in the uncertainty propagation chain.

    Sub-classes implement :meth:`sample` (draw the input ensemble) and
    :meth:`transform` (map the input ensemble to the output ensemble).
    """

    name: str = "base"

    def sample(self, n_real: int, rng: np.random.Generator) -> np.ndarray:
        """Draw *n_real* input realizations.  Return shape (n_real, ...)."""
        raise NotImplementedError

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        """Map the input ensemble to the output ensemble.  Return (n_real, ...)."""
        raise NotImplementedError

    def run(self, n_real: int, rng: np.random.Generator, inputs: np.ndarray | None = None) -> StageResult:
        """Execute the stage: sample (if *inputs* is None) then transform."""
        if inputs is None:
            inp = self.sample(n_real, rng)
        else:
            inp = inputs
        out = self.transform(inp)
        return StageResult.from_ensemble(self.name, out, metadata=self._metadata())

    def _metadata(self) -> dict:
        return {}


# ── concrete stages ──────────────────────────────────────────────────────

class SeismicStage(PropagationStage):
    """Stage 1 — Seismic: impedance / horizon-depth uncertainty.

    Draws an ensemble of acoustic-impedance values by perturbing a base
    impedance with Gaussian noise whose standard deviation is tied to
    the seismic signal-to-noise ratio (SNR).  A lower SNR means higher
    impedance uncertainty, which propagates into porosity and everything
    downstream.

    Parameters
    ----------
    base_impedance : array
        Best-estimate acoustic impedance (kg/m²·s).
    snr : float
        Signal-to-noise ratio (linear).  Higher = less uncertainty.
    relative : bool
        If True, noise std = base / snr (relative); else absolute.
    """

    name = "seismic"

    def __init__(self, base_impedance: np.ndarray, snr: float = 20.0, relative: bool = True):
        self.base = np.asarray(base_impedance, float)
        self.snr = float(snr)
        self.relative = relative
        if self.relative:
            self._noise_std = self.base / self.snr
        else:
            self._noise_std = np.full_like(self.base, 1.0 / self.snr)

    def sample(self, n_real: int, rng: np.random.Generator) -> np.ndarray:
        # (n_real, *base.shape)
        noise = rng.normal(0.0, 1.0, size=(n_real,) + self.base.shape)
        return self.base[np.newaxis] + noise * self._noise_std[np.newaxis]

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        # Seismic stage is a measurement stage — output = input ensemble.
        return inputs

    def _metadata(self) -> dict:
        return {"unit": "kg/(m2.s)", "snr": self.snr, "relative": self.relative}


class GeologyStage(PropagationStage):
    """Stage 2 — Geology: impedance → porosity (rock-physics transform).

    Converts each seismic-impedance realization into a porosity
    realization via a calibrated linear (or power-law) rock-physics
    transform, then adds a small geologic scatter to represent
    lateral facies variability not captured by the seismic.

    The default transform is the linear Gardner-style relation

        phi = a - b * (I / I_ref)

    Parameters
    ----------
    a, b : float
        Linear transform coefficients.
    i_ref : float
        Reference impedance for normalization.
    phi_min, phi_max : float
        Physical porosity bounds (clipped).
    geologic_scatter : float
        Additional Gaussian scatter (in porosity units) representing
        sub-seismic facies variability.
    """

    name = "geology"

    def __init__(self, a: float = 0.35, b: float = 0.15, i_ref: float = 1.0e7,
                 phi_min: float = 0.02, phi_max: float = 0.45,
                 geologic_scatter: float = 0.01):
        self.a = float(a)
        self.b = float(b)
        self.i_ref = float(i_ref)
        self.phi_min = float(phi_min)
        self.phi_max = float(phi_max)
        self.scatter = float(geologic_scatter)

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        phi = self.a - self.b * (inputs / self.i_ref)
        phi = np.clip(phi, self.phi_min, self.phi_max)
        # add geologic scatter (per-realization, per-element)
        rng = np.random.default_rng(0)  # deterministic scatter seed
        noise = rng.normal(0.0, self.scatter, size=phi.shape)
        phi = np.clip(phi + noise, self.phi_min, self.phi_max)
        return phi

    def _metadata(self) -> dict:
        return {"unit": "fraction", "transform": "linear", "scatter": self.scatter}


class PetrophysicsStage(PropagationStage):
    """Stage 3 — Petrophysics: porosity → permeability (Kozeny-Carman).

    Converts porosity realizations into permeability realizations using
    the Kozeny-Carman relation

        k = C * phi^n / (1 - phi)^2

    and then draws a water-saturation ensemble from a porosity-dependent
    saturation-height function (capillary-entry model).

    Parameters
    ----------
    kc_c, kc_n : float
        Kozeny-Carman coefficient and exponent.
    sw_base, sw_phi_slope : float
        Linear saturation-height: Sw = sw_base + sw_phi_slope * (phi_ref - phi).
    k_min, k_max : float
        Permeability bounds (mD).
    """

    name = "petrophysics"

    def __init__(self, kc_c: float = 5.0e3, kc_n: float = 3.0,
                 sw_base: float = 0.25, sw_phi_slope: float = 0.5,
                 phi_ref: float = 0.25,
                 k_min: float = 0.1, k_max: float = 5.0e3):
        self.kc_c = float(kc_c)
        self.kc_n = float(kc_n)
        self.sw_base = float(sw_base)
        self.sw_phi_slope = float(sw_phi_slope)
        self.phi_ref = float(phi_ref)
        self.k_min = float(k_min)
        self.k_max = float(k_max)

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        """inputs: porosity ensemble (n_real, ...).  Returns permeability (mD)."""
        phi = np.clip(inputs, 0.01, 0.50)
        denom = (1.0 - phi) ** 2
        denom = np.where(denom < 1e-6, 1e-6, denom)
        k = self.kc_c * (phi ** self.kc_n) / denom
        k = np.clip(k, self.k_min, self.k_max)
        return k

    def water_saturation(self, porosity_ensemble: np.ndarray) -> np.ndarray:
        """Derive an Sw ensemble from the porosity ensemble."""
        sw = self.sw_base + self.sw_phi_slope * (self.phi_ref - porosity_ensemble)
        return np.clip(sw, 0.05, 0.95)

    def _metadata(self) -> dict:
        return {"unit": "mD", "transform": "kozeny-carman",
                "kc_c": self.kc_c, "kc_n": self.kc_n}


class ReservoirStage(PropagationStage):
    """Stage 4 — Reservoir: permeability → production (simulation).

    Runs a reservoir simulation for each permeability realization and
    collects the production time-series.  The simulation callable must
    accept a permeability array and return a (n_times, n_phases) array
    of production rates (or cumulative).

    Parameters
    ----------
    simulate : callable
        ``simulate(permeability: np.ndarray) -> np.ndarray``
        where the returned array has shape (n_times,) for a single phase
        or (n_times, n_phases) for multiple phases.
    phase_names : list[str]
        Names of the phases in the output (e.g. ["oil", "water", "gas"]).
    cumulative : bool
        Whether the simulation returns cumulative volumes.
    times : np.ndarray
        Time points (days) at which production is reported.
    """

    name = "reservoir"

    def __init__(self, simulate: Callable[[np.ndarray], np.ndarray],
                 phase_names: list[str] | None = None,
                 cumulative: bool = False,
                 times: np.ndarray | None = None):
        self.simulate = simulate
        self.phase_names = phase_names or ["oil"]
        self.cumulative = cumulative
        self.times = np.asarray(times, float) if times is not None else None

    def transform(self, inputs: np.ndarray) -> np.ndarray:
        """inputs: permeability ensemble (n_real, ...).

        Returns
        -------
        np.ndarray, shape (n_real, n_times, n_phases)
            Production ensemble.
        """
        n_real = inputs.shape[0]
        results = []
        for i in range(n_real):
            k = inputs[i]
            try:
                prod = np.asarray(self.simulate(k), float)
            except Exception:
                # On failure, return zeros so the ensemble survives.
                if self.times is not None:
                    nt = len(self.times)
                else:
                    nt = 1
                prod = np.zeros((nt, len(self.phase_names)))
            results.append(prod)
        arr = np.array(results)  # (n_real, n_times, n_phases)
        return arr

    def to_forecasts(self, production_ensemble: np.ndarray) -> dict[str, ProductionForecast]:
        """Convert the (n_real, n_times, n_phases) ensemble to per-phase forecasts."""
        if production_ensemble.ndim != 3:
            raise ValueError(f"Expected (n_real, n_times, n_phases); got {production_ensemble.shape}")
        n_real, nt, nph = production_ensemble.shape
        times = self.times if self.times is not None else np.arange(nt, dtype=float)
        forecasts = {}
        for j, phase in enumerate(self.phase_names):
            ens = production_ensemble[:, :, j]  # (n_real, n_times)
            forecasts[phase] = ProductionForecast.from_ensemble(
                times, ens, phase=phase, cumulative=self.cumulative
            )
        return forecasts

    def _metadata(self) -> dict:
        return {"phases": self.phase_names, "cumulative": self.cumulative,
                "n_times": len(self.times) if self.times is not None else 0}


# ── propagation chain ────────────────────────────────────────────────────

class PropagationChain:
    """Orchestrates the end-to-end uncertainty propagation.

    Stages are added in order; each stage receives the output ensemble
    of the previous stage (or samples its own if it is the first stage).

    Parameters
    ----------
    stages : list[PropagationStage]
        Ordered list of stages (seismic → … → reservoir).
    n_real : int
        Chain width (ensemble size).
    seed : int
        Master RNG seed for reproducibility.
    """

    def __init__(self, stages: list[PropagationStage], n_real: int = 100, seed: int = 42):
        if not stages:
            raise ValueError("At least one stage is required.")
        self.stages = stages
        self.n_real = int(n_real)
        self.seed = int(seed)

    def run(self, verbose: bool = False) -> PropagationResult:
        """Execute the full chain and return the propagation result."""
        rng = np.random.default_rng(self.seed)
        result = PropagationResult(n_real=self.n_real, master_seed=self.seed)
        prev_ensemble = None

        for stage in self.stages:
            if verbose:
                print(f"  [propagation] running stage '{stage.name}' ...")
            sr = stage.run(self.n_real, rng, inputs=prev_ensemble)
            result.stage_results[stage.name] = sr
            result.budget.add(sr)
            prev_ensemble = sr.ensemble
            if verbose:
                print(f"    → ensemble shape {sr.ensemble.shape}, "
                      f"mean_std={float(np.mean(sr.std)):.4g}")

        # If the last stage is a ReservoirStage, build production forecasts.
        last = self.stages[-1]
        if isinstance(last, ReservoirStage) and last.name in result.stage_results:
            prod_ens = result.stage_results[last.name].ensemble
            result.forecasts = last.to_forecasts(prod_ens)

        return result


# ── convenience: run_end_to_end_propagation ──────────────────────────────

def run_end_to_end_propagation(
    base_impedance: np.ndarray,
    simulate: Callable[[np.ndarray], np.ndarray],
    *,
    n_real: int = 100,
    seed: int = 42,
    snr: float = 20.0,
    geo_a: float = 0.35,
    geo_b: float = 0.15,
    i_ref: float = 1.0e7,
    geologic_scatter: float = 0.01,
    kc_c: float = 5.0e3,
    kc_n: float = 3.0,
    sw_base: float = 0.25,
    sw_phi_slope: float = 0.5,
    phi_ref: float = 0.25,
    phase_names: list[str] | None = None,
    cumulative: bool = False,
    times: np.ndarray | None = None,
    verbose: bool = False,
) -> PropagationResult:
    """One-call end-to-end seismic → production uncertainty propagation.

    Builds the four-stage chain (seismic → geology → petrophysics →
    reservoir) with sensible defaults and runs it.

    Parameters
    ----------
    base_impedance : np.ndarray
        Best-estimate acoustic impedance volume (or scalar / 1-D array).
    simulate : callable
        ``simulate(permeability: np.ndarray) -> np.ndarray``
        Must return (n_times,) or (n_times, n_phases).
    n_real : int
        Ensemble size (chain width).
    seed : int
        Master seed.
    snr : float
        Seismic signal-to-noise ratio.
    geo_a, geo_b, i_ref : float
        Geology-stage impedance → porosity coefficients.
    geologic_scatter : float
        Sub-seismic geologic scatter (porosity units).
    kc_c, kc_n : float
        Kozeny-Carman permeability transform coefficients.
    sw_base, sw_phi_slope, phi_ref : float
        Petrophysics saturation-height parameters.
    phase_names : list[str]
        Names of the production phases.
    cumulative : bool
        Whether *simulate* returns cumulative volumes.
    times : np.ndarray
        Time points (days).
    verbose : bool

    Returns
    -------
    PropagationResult
    """
    stages = [
        SeismicStage(base_impedance, snr=snr),
        GeologyStage(a=geo_a, b=geo_b, i_ref=i_ref, geologic_scatter=geologic_scatter),
        PetrophysicsStage(kc_c=kc_c, kc_n=kc_n,
                          sw_base=sw_base, sw_phi_slope=sw_phi_slope, phi_ref=phi_ref),
        ReservoirStage(simulate, phase_names=phase_names, cumulative=cumulative, times=times),
    ]
    chain = PropagationChain(stages, n_real=n_real, seed=seed)
    return chain.run(verbose=verbose)


# ── self-test ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 70)
    print("V36-4 Uncertainty Propagation — self-test")
    print("=" * 70)

    # Build a simple synthetic reservoir: 1-D, 10 cells.
    n_cells = 10
    base_imp = np.full(n_cells, 1.0e7)  # 10e6 kg/(m2.s) base impedance

    # A toy reservoir simulator: given permeability (n_cells,), produce
    # a cumulative-oil production curve (n_times,) using a simple
    # exponential-depletion model.  Higher k → faster depletion → more
    # early production but same ultimate.
    n_times = 20
    times = np.linspace(0.0, 365.0, n_times)  # 1 year

    def toy_simulate(k):
        k_mean = float(np.mean(k))
        # time constant inversely related to k (faster drain for high k)
        tau = 200.0 / (1.0 + k_mean / 500.0)  # days
        ur = 1.0e5 * (0.5 + 0.5 * np.tanh((k_mean - 200.0) / 300.0))  # m3
        cum = ur * (1.0 - np.exp(-times / tau))
        return cum[:, np.newaxis]  # (n_times, 1) single phase

    # Run the chain with a modest ensemble.
    result = run_end_to_end_propagation(
        base_impedance=base_imp,
        simulate=toy_simulate,
        n_real=64,
        seed=42,
        snr=15.0,
        phase_names=["oil"],
        cumulative=True,
        times=times,
        verbose=True,
    )

    print()
    print("── Uncertainty budget ──")
    print(result.budget.table())

    print()
    print("── Stage P10/P50/P90 summaries ──")
    for name, sr in result.stage_results.items():
        p10, p50, p90 = sr.p10, sr.p50, sr.p90
        if p10.ndim == 0:
            print(f"  {name:14s}  P10={p10:.4g}  P50={p50:.4g}  P90={p90:.4g}")
        else:
            print(f"  {name:14s}  shape={p10.shape}  "
                  f"P50 range=[{p50.min():.4g}, {p50.max():.4g}]  "
                  f"std range=[{sr.std.min():.4g}, {sr.std.max():.4g}]")

    print()
    print("── Production forecast (oil, cumulative) ──")
    fc = result.forecasts["oil"]
    print(f"  n_real = {fc.n_real}")
    print(f"  times  = {fc.times[0]:.0f} … {fc.times[-1]:.0f} days ({len(fc.times)} pts)")
    print(f"  P10 final = {fc.p10[-1]:.1f} m3")
    print(f"  P50 final = {fc.p50[-1]:.1f} m3")
    print(f"  P90 final = {fc.p90[-1]:.1f} m3")
    ur_p10, ur_p50, ur_p90 = result.ultimate_recovery("oil")
    print(f"  Ultimate recovery  P10={ur_p10:.1f}  P50={ur_p50:.1f}  P90={ur_p90:.1f} m3")

    # Sanity: P10 > P50 > P90 for production (higher = better).
    assert fc.p10[-1] >= fc.p50[-1] >= fc.p90[-1], "P10/P50/P90 ordering violated!"
    assert ur_p10 >= ur_p50 >= ur_p90, "UR ordering violated!"
    # Ensemble spread should be positive (uncertainty is real).
    assert fc.ensemble.std() > 0.0, "No spread in production ensemble!"
    # P50 should be finite and reasonable.
    assert 0.0 < ur_p50 < 2.0e5, f"UR P50 {ur_p50} out of expected range"

    print()
    print("── Validation checks ──")
    print(f"  P10 >= P50 >= P90 at all times: {np.all(fc.p10 >= fc.p50 - 1e-10) and np.all(fc.p50 >= fc.p90 - 1e-10)}")
    print(f"  Ensemble has spread: {fc.ensemble.std() > 0.0}")
    print(f"  All stages present: {list(result.stage_results.keys()) == ['seismic', 'geology', 'petrophysics', 'reservoir']}")
    print(f"  4 stages chained: {len(result.stage_results) == 4}")
    print()
    print("ALL CHECKS PASSED ✓")
