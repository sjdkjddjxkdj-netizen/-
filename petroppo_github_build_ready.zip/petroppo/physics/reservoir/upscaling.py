"""
Upscaling: fine-grid → coarse-grid property averaging.

In reservoir modeling the geological (fine) grid is often 10^6+ cells —
too many to simulate directly.  Upscaling computes equivalent coarse-grid
properties that reproduce the fine-grid flow behaviour.  The choice of
averaging rule depends on the property and the flow direction:

* **Porosity** → always arithmetic (volume-weighted mean).
* **Permeability, horizontal (Kx, Ky)** → arithmetic for flow parallel to
  layering; harmonic for flow perpendicular.  For a layered package the
  *effective* horizontal perm is the arithmetic mean and the *effective*
  vertical perm is the harmonic mean (Bear 1972, Cardwell & Parsons 1945).
* **Power-law** → a tunable blend (α=1 arithmetic, α=-1 harmonic, α=0
  geometric); useful for intermediate anisotropy.
* **Flow-based** → solve a single-phase steady-state pressure problem on
  the fine block with unit pressure gradient, then back out the equivalent
  perm from Darcy's law.  This is the most accurate method and the one
  Petrel uses for "flow-based upscaling".

All functions use only numpy + scipy.

References
----------
* Bear, "Dynamics of Fluids in Porous Media", 1972, §5.7 (averaging).
* Cardwell & Parsons, "Average Permeabilities of Heterogeneous Oil Sands",
  Trans. AIME 1945.
* Pickup et al., "A Method for Calculating Permeability Tensors using
  Pore-Scale Models", Transport in Porous Media 1995.
* Wen & Gómez-Hernández, "Upscaling Hydraulic Conductivities", Math.
  Geol. 1996 (review of methods).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

__all__ = [
    "UpscaleResult",
    "upscale_arithmetic",
    "upscale_harmonic",
    "upscale_power_law",
    "upscale_geometric",
    "upscale_porosity",
    "upscale_permeability",
    "upscale_flow_based",
]


@dataclass
class UpscaleResult:
    """Result of an upscaling operation.

    Attributes
    ----------
    value : float
        Upscaled (coarse) value.
    method : str
        Name of the upscaling method used.
    scale_ratio : float
        Ratio of fine to coarse cell count along the upscaled axis.
    n_fine : int
        Number of fine cells averaged.
    """

    value: float
    method: str
    scale_ratio: float
    n_fine: int

    def __float__(self) -> float:
        return float(self.value)


# --------------------------------------------------------------------------- #
# Basic averages
# --------------------------------------------------------------------------- #
def upscale_arithmetic(
    values: np.ndarray,
    weights: Optional[np.ndarray] = None,
) -> UpscaleResult:
    """Volume-weighted arithmetic mean: ``sum(w·v) / sum(w)``.

    The correct average for porosity and for permeability parallel to
    layering.
    """
    v = np.asarray(values, dtype=float).ravel()
    if v.size == 0:
        raise ValueError("empty values")
    if weights is None:
        w = np.ones_like(v)
    else:
        w = np.asarray(weights, dtype=float).ravel()
        if w.shape != v.shape:
            raise ValueError("weights shape mismatch")
    if np.any(w < 0):
        raise ValueError("weights must be non-negative")
    sw = w.sum()
    if sw <= 0:
        raise ValueError("total weight must be positive")
    val = float(np.sum(w * v) / sw)
    return UpscaleResult(value=val, method="arithmetic",
                         scale_ratio=float(v.size), n_fine=int(v.size))


def upscale_harmonic(
    values: np.ndarray,
    weights: Optional[np.ndarray] = None,
) -> UpscaleResult:
    """Volume-weighted harmonic mean: ``sum(w) / sum(w/v)``.

    The correct average for permeability perpendicular to layering.  Any
    zero value yields zero (a perfect seal).
    """
    v = np.asarray(values, dtype=float).ravel()
    if v.size == 0:
        raise ValueError("empty values")
    if weights is None:
        w = np.ones_like(v)
    else:
        w = np.asarray(weights, dtype=float).ravel()
        if w.shape != v.shape:
            raise ValueError("weights shape mismatch")
    if np.any(w < 0):
        raise ValueError("weights must be non-negative")
    sw = w.sum()
    if sw <= 0:
        raise ValueError("total weight must be positive")
    # zero perm → harmonic = 0 (seal)
    if np.any(v == 0):
        return UpscaleResult(value=0.0, method="harmonic",
                             scale_ratio=float(v.size), n_fine=int(v.size))
    val = float(sw / np.sum(w / v))
    return UpscaleResult(value=val, method="harmonic",
                         scale_ratio=float(v.size), n_fine=int(v.size))


def upscale_geometric(
    values: np.ndarray,
    weights: Optional[np.ndarray] = None,
) -> UpscaleResult:
    """Volume-weighted geometric mean: ``exp(sum(w·ln v) / sum(w))``.

    Often used for permeability in 2-D areal upscaling.  Any zero value
    yields zero.
    """
    v = np.asarray(values, dtype=float).ravel()
    if v.size == 0:
        raise ValueError("empty values")
    if np.any(v < 0):
        raise ValueError("values must be non-negative for geometric mean")
    if weights is None:
        w = np.ones_like(v)
    else:
        w = np.asarray(weights, dtype=float).ravel()
        if w.shape != v.shape:
            raise ValueError("weights shape mismatch")
    sw = w.sum()
    if sw <= 0:
        raise ValueError("total weight must be positive")
    if np.any(v == 0):
        return UpscaleResult(value=0.0, method="geometric",
                             scale_ratio=float(v.size), n_fine=int(v.size))
    val = float(np.exp(np.sum(w * np.log(v)) / sw))
    return UpscaleResult(value=val, method="geometric",
                         scale_ratio=float(v.size), n_fine=int(v.size))


def upscale_power_law(
    values: np.ndarray,
    weights: Optional[np.ndarray] = None,
    alpha: float = 1.0,
) -> UpscaleResult:
    """Power-law average: ``(sum(w·v^α)/sum(w))^(1/α)``.

    ``α=1`` arithmetic, ``α=-1`` harmonic, ``α=0`` geometric (limit),
    ``α→∞`` maximum.
    """
    v = np.asarray(values, dtype=float).ravel()
    if v.size == 0:
        raise ValueError("empty values")
    if np.any(v < 0):
        raise ValueError("values must be non-negative for power-law")
    if weights is None:
        w = np.ones_like(v)
    else:
        w = np.asarray(weights, dtype=float).ravel()
        if w.shape != v.shape:
            raise ValueError("weights shape mismatch")
    sw = w.sum()
    if sw <= 0:
        raise ValueError("total weight must be positive")
    if np.isclose(alpha, 0.0):
        return upscale_geometric(v, w)
    if np.any(v == 0):
        if alpha < 0:
            # negative power of zero → harmonic-like seal
            return UpscaleResult(value=0.0, method=f"power-law(α={alpha})",
                                 scale_ratio=float(v.size), n_fine=int(v.size))
    val = float((np.sum(w * np.power(v, alpha)) / sw) ** (1.0 / alpha))
    return UpscaleResult(value=val, method=f"power-law(α={alpha})",
                         scale_ratio=float(v.size), n_fine=int(v.size))


def upscale_porosity(
    porosity: np.ndarray,
    volumes: Optional[np.ndarray] = None,
) -> UpscaleResult:
    """Upscale porosity — always arithmetic (pore-volume weighted)."""
    return upscale_arithmetic(porosity, volumes)


# --------------------------------------------------------------------------- #
# Direction-aware permeability upscaling
# --------------------------------------------------------------------------- #
def upscale_permeability(
    perm: np.ndarray,
    volumes: Optional[np.ndarray] = None,
    direction: str = "x",
) -> UpscaleResult:
    """Direction-aware permeability upscaling for a layered block.

    For a stack of layers with perm ``perm[k]`` and volume ``volumes[k]``,
    the effective permeability is:

    * arithmetic for flow **parallel** to the layering (``direction`` in
      ``{'x', 'y', 'horizontal', 'h'}``).
    * harmonic for flow **perpendicular** to the layering
      (``direction`` in ``{'z', 'vertical', 'v'}``).

    This is the Cardwell-Parsons / Bear result for 1-D stratified media.

    Parameters
    ----------
    perm : np.ndarray
        Fine permeabilities.
    volumes : np.ndarray, optional
        Cell volumes (or thicknesses) for weighting.
    direction : str
        ``'x'``, ``'y'``, ``'horizontal'`` → arithmetic; ``'z'``,
        ``'vertical'`` → harmonic.

    Returns
    -------
    UpscaleResult
    """
    d = direction.lower()
    if d in ("x", "y", "horizontal", "h", "areal"):
        return upscale_arithmetic(perm, volumes)
    elif d in ("z", "vertical", "v"):
        return upscale_harmonic(perm, volumes)
    else:
        raise ValueError(f"unknown direction '{direction}'")


# --------------------------------------------------------------------------- #
# Flow-based upscaling
# --------------------------------------------------------------------------- #
def upscale_flow_based(
    perm: np.ndarray,
    direction: str = "x",
    porosity: Optional[np.ndarray] = None,
    pressure_gradient: float = 1.0,
) -> UpscaleResult:
    """Single-phase steady-state flow-based upscaling.

    Solves the pressure equation on the fine block with a unit pressure
    gradient imposed across the block in ``direction``, no-flow on the
    other faces, then computes the equivalent perm from Darcy's law::

        k_eq = - q * L / (A * ΔP)

    where ``q`` is the total outflow, ``L`` the block length in the flow
    direction, ``A`` the cross-sectional area, and ``ΔP`` the imposed
    pressure drop.  For a homogeneous block ``k_eq`` equals the input perm
    exactly.

    Parameters
    ----------
    perm : np.ndarray, shape (nx, ny, nz)
        Fine permeability field (isotropic).
    direction : str
        ``'x'``, ``'y'``, or ``'z'``.
    porosity : optional
        Unused for single-phase steady state (kept for API symmetry).
    pressure_gradient : float
        Imposed pressure gradient (Pa/m or any consistent unit).

    Returns
    -------
    UpscaleResult
    """
    perm = np.asarray(perm, dtype=float)
    if perm.ndim != 3:
        raise ValueError("perm must be 3-D (nx, ny, nz)")
    nx, ny, nz = perm.shape
    d = direction.lower()
    axis = {"x": 0, "y": 1, "z": 2}.get(d)
    if axis is None:
        raise ValueError(f"direction must be x, y, or z; got '{direction}'")

    dims = [nx, ny, nz]
    L = dims[axis]               # length (in cell units)
    A = 1.0
    for a in range(3):
        if a != axis:
            A *= dims[a]
    dP = pressure_gradient * L

    # Build and solve the steady-state pressure system.
    # 7-point finite difference on the fine grid, no-flow on the four side
    # faces, and Dirichlet pressure on the inlet & outlet faces (imposed
    # directly on the boundary cells).
    n_cell = nx * ny * nz

    def idx(i, j, k):
        return i + j * nx + k * nx * ny

    # transmissibility between neighbouring cells (harmonic mean of perm)
    def T(k1, k2):
        if k1 <= 0 or k2 <= 0:
            return 0.0
        return 2.0 * k1 * k2 / (k1 + k2)

    rows = []
    cols = []
    data = []
    rhs = np.zeros(n_cell)

    p_inlet = dP       # high pressure on inlet face
    p_outlet = 0.0     # zero on outlet face

    # identify inlet/outlet cell index ranges along the flow axis
    def is_inlet(i, j, k):
        return (i == 0) if axis == 0 else ((j == 0) if axis == 1 else (k == 0))
    def is_outlet(i, j, k):
        return (i == nx-1) if axis == 0 else ((j == ny-1) if axis == 1 else (k == nz-1))

    dirichlet = np.zeros(n_cell, dtype=bool)
    dir_val = np.zeros(n_cell)
    for k in range(nz):
        for j in range(ny):
            for i in range(nx):
                n = idx(i, j, k)
                if is_inlet(i, j, k):
                    dirichlet[n] = True
                    dir_val[n] = p_inlet
                elif is_outlet(i, j, k):
                    dirichlet[n] = True
                    dir_val[n] = p_outlet

    for k in range(nz):
        for j in range(ny):
            for i in range(nx):
                n = idx(i, j, k)
                if dirichlet[n]:
                    # Dirichlet row: p = dir_val
                    rows.append(n); cols.append(n); data.append(1.0)
                    rhs[n] = dir_val[n]
                    continue
                diag = 0.0
                p = perm[i, j, k]
                for a, (di, dj, dk) in enumerate(
                    [(1, 0, 0), (-1, 0, 0),
                     (0, 1, 0), (0, -1, 0),
                     (0, 0, 1), (0, 0, -1)]):
                    ii, jj, kk = i + di, j + dj, k + dk
                    if 0 <= ii < nx and 0 <= jj < ny and 0 <= kk < nz:
                        tt = T(p, perm[ii, jj, kk])
                        nb = idx(ii, jj, kk)
                        rows.append(n); cols.append(nb); data.append(-tt)
                        diag += tt
                    # side faces → no-flow (nothing added)
                rows.append(n); cols.append(n); data.append(diag)

    from scipy.sparse import csr_matrix
    from scipy.sparse.linalg import spsolve
    M = csr_matrix((data, (rows, cols)), shape=(n_cell, n_cell))
    pvec = spsolve(M, rhs)

    # total flux through the outlet face (sum of inter-cell fluxes into the
    # outlet cells)
    flux = 0.0
    if axis == 0:
        for k in range(nz):
            for j in range(ny):
                i = nx - 1
                nb_i = nx - 2
                tt = T(perm[i, j, k], perm[nb_i, j, k])
                flux += tt * (pvec[idx(nb_i, j, k)] - pvec[idx(i, j, k)])
    elif axis == 1:
        for k in range(nz):
            for i in range(nx):
                j = ny - 1
                nb_j = ny - 2
                tt = T(perm[i, j, k], perm[i, nb_j, k])
                flux += tt * (pvec[idx(i, nb_j, k)] - pvec[idx(i, j, k)])
    else:
        for j in range(ny):
            for i in range(nx):
                k = nz - 1
                nb_k = nz - 2
                tt = T(perm[i, j, k], perm[i, j, nb_k])
                flux += tt * (pvec[idx(i, j, nb_k)] - pvec[idx(i, j, k)])

    # k_eq from Darcy: q = k_eq * A * dP / L  (flux is positive, dP>0)
    k_eq = float(abs(flux) * L / (A * dP))
    return UpscaleResult(value=k_eq, method=f"flow-based-{direction}",
                         scale_ratio=float(n_cell), n_fine=int(n_cell))
