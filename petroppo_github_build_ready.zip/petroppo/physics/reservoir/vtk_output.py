"""
VTK output for reservoir simulation results.

Writes unstructured-grid (.vtu) files that ParaView can open directly,
giving petroppo a visualisation path comparable to Petrel's 3D viewer
(via the free, open-source ParaView).

Two writers are provided:

* ``write_vtu`` — cell-centred data on the reservoir grid (pressure,
  saturation, porosity, permeability, etc.) as a VTK unstructured grid
  of hexahedra built from the corner-point geometry.
* ``write_time_series`` — a .pvd collection file referencing a sequence
  of .vtu snapshots so ParaView can animate the simulation over time.

The XML is hand-written (no vtk dependency) so the module works in any
environment with only numpy.
"""

from __future__ import annotations

import os
from typing import Iterable, Optional

import numpy as np

from .grid import ReservoirGrid

__all__ = ["write_vtu", "write_time_series", "write_wells_pvd"]


# ---------------------------------------------------------------------------
# VTU writer
# ---------------------------------------------------------------------------

def write_vtu(
    grid: ReservoirGrid,
    filename: str,
    cell_data: Optional[dict[str, np.ndarray]] = None,
    point_data: Optional[dict[str, np.ndarray]] = None,
) -> str:
    """Write a VTK unstructured-grid (.vtu) file.

    Parameters
    ----------
    grid : ReservoirGrid
        Corner-point grid; inactive cells (actnum=False) are written but
        flagged via an ``actnum`` cell array.
    filename : str
        Output path.  ``.vtu`` extension appended if missing.
    cell_data : dict
        Maps field name -> array of shape ``(nx, ny, nz)`` or flattened
        ``(n_cells,)``.
    point_data : dict
        Maps field name -> array at the grid nodes.

    Returns
    -------
    str
        The absolute path written.
    """
    if not filename.endswith(".vtu"):
        filename += ".vtu"

    nx, ny, nz = grid.shape
    corners = grid.corners  # (nx, ny, nz, 8, 3)

    # Build unique node list.  Each cell has 8 corners but adjacent cells
    # share nodes.  We build node coordinates from the (nx+1, ny+1, nz+1)
    # grid of corner points by extracting the 8 corners of each cell.
    # For corner-point grids corners may not coincide exactly, so we
    # use per-cell unique nodes (less compact but always correct).
    n_cells = nx * ny * nz
    n_nodes = n_cells * 8
    nodes = corners.reshape(n_nodes, 3)

    # connectivity: cell c uses nodes [8c .. 8c+7]
    # VTK hexahedron node ordering (different from our internal one):
    #   VTK:  4---5    ours:  6---7
    #         |   |           |   |
    #         6---7    (top)  4---5
    #         |   |           |   |
    #         0---1    (bot)  0---1
    #   VTK expects (0,1,2,3) bottom CCW then (4,5,6,7) top CCW.
    #   Our order: 0=(x0,y0,z0),1=(x1,y0,z0),2=(x0,y1,z0),3=(x1,y1,z0),
    #              4=(x0,y0,z1),5=(x1,y0,z1),6=(x0,y1,z1),7=(x1,y1,z1)
    #   VTK wants bottom: (0,1,3,2) and top: (4,5,7,6)
    vtk_order = np.array([0, 1, 3, 2, 4, 5, 7, 6])

    cells_conn = np.empty((n_cells, 8), dtype=np.int64)
    for c in range(n_cells):
        base = c * 8
        cells_conn[c] = base + vtk_order

    # cell types: 12 = VTK_HEXAHEDRON
    cell_types = np.full(n_cells, 12, dtype=np.uint8)

    # ----- serialise to XML -----
    header = (
        '<?xml version="1.0"?>\n'
        '<VTKFile type="UnstructuredGrid" version="0.1" '
        'byte_order="LittleEndian">\n'
        '  <UnstructuredGrid>\n'
        f'    <Piece NumberOfPoints="{n_nodes}" NumberOfCells="{n_cells}">\n'
    )

    # points
    pts_xml = (
        '      <Points>\n'
        '        <DataArray type="Float64" NumberOfComponents="3" '
        f'format="ascii">\n'
        + _fmt_array(nodes, 3)
        + '\n        </DataArray>\n'
        '      </Points>\n'
    )

    # cells
    conn_flat = cells_conn.ravel()
    offsets = np.arange(8, 8 * n_cells + 1, 8, dtype=np.int64)
    cells_xml = (
        '      <Cells>\n'
        '        <DataArray type="Int64" Name="connectivity" '
        f'format="ascii">\n          '
        + ' '.join(str(x) for x in conn_flat)
        + '\n        </DataArray>\n'
        '        <DataArray type="Int64" Name="offsets" '
        f'format="ascii">\n          '
        + ' '.join(str(x) for x in offsets)
        + '\n        </DataArray>\n'
        '        <DataArray type="UInt8" Name="types" '
        f'format="ascii">\n          '
        + ' '.join(str(int(x)) for x in cell_types)
        + '\n        </DataArray>\n'
        '      </Cells>\n'
    )

    # cell data
    cd = {"actnum": grid.actnum.astype(np.float64).ravel()}
    if cell_data:
        for name, arr in cell_data.items():
            cd[name] = np.asarray(arr, float).ravel()
    cell_data_xml = '      <CellData>\n'
    for name, arr in cd.items():
        cell_data_xml += (
            f'        <DataArray type="Float64" Name="{name}" '
            f'format="ascii">\n          '
            + ' '.join(f"{x:.6g}" for x in arr)
            + '\n        </DataArray>\n'
        )
    cell_data_xml += '      </CellData>\n'

    # point data
    point_data_xml = ''
    if point_data:
        point_data_xml = '      <PointData>\n'
        for name, arr in point_data.items():
            a = np.asarray(arr, float)
            point_data_xml += (
                f'        <DataArray type="Float64" Name="{name}" '
                f'format="ascii">\n'
                + _fmt_array(a, 1)
                + '\n        </DataArray>\n'
            )
        point_data_xml += '      </PointData>\n'

    footer = (
        '    </Piece>\n'
        '  </UnstructuredGrid>\n'
        '</VTKFile>\n'
    )

    xml = header + point_data_xml + pts_xml + cells_xml + cell_data_xml + footer
    abspath = os.path.abspath(filename)
    with open(abspath, "w") as f:
        f.write(xml)
    return abspath


# ---------------------------------------------------------------------------
# Time-series (.pvd) writer
# ---------------------------------------------------------------------------

def write_time_series(
    vtu_files: Iterable[str],
    times: Iterable[float],
    pvd_filename: str,
) -> str:
    """Write a .pvd collection referencing a sequence of .vtu files.

    Parameters
    ----------
    vtu_files : iterable of str
        Paths (relative to the .pvd file's directory) to each .vtu snapshot.
    times : iterable of float
        Simulation time for each snapshot (seconds).
    pvd_filename : str
        Output .pvd path.
    """
    if not pvd_filename.endswith(".pvd"):
        pvd_filename += ".pvd"
    vtu_list = list(vtu_files)
    t_list = list(times)
    if len(vtu_list) != len(t_list):
        raise ValueError("vtu_files and times must have equal length")

    xml = (
        '<?xml version="1.0"?>\n'
        '<VTKFile type="Collection" version="0.1" '
        'byte_order="LittleEndian">\n'
        '  <Collection>\n'
    )
    for f, t in zip(vtu_list, t_list):
        xml += f'    <DataSet timestep="{t:.6g}" file="{f}"/>\n'
    xml += '  </Collection>\n</VTKFile>\n'

    abspath = os.path.abspath(pvd_filename)
    with open(abspath, "w") as fh:
        fh.write(xml)
    return abspath


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _fmt_array(arr: np.ndarray, ncomp: int) -> str:
    """Format a 2-D array (n_rows, ncomp) into VTK ascii lines."""
    a = np.asarray(arr).reshape(-1, ncomp)
    lines = []
    for row in a:
        lines.append("          " + " ".join(f"{x:.6g}" for x in row))
    return "\n".join(lines)


def write_wells_pvd(
    well_positions: Iterable[tuple[float, float, float]],
    well_names: Iterable[str],
    filename: str,
) -> str:
    """Write well locations as a simple VTK polydata (.vtp) file.

    Useful for overlaying wells on the grid in ParaView.
    """
    if not filename.endswith(".vtp"):
        filename += ".vtp"
    pts = list(well_positions)
    names = list(well_names)
    n = len(pts)
    pts_xml = (
        '<?xml version="1.0"?>\n'
        '<VTKFile type="PolyData" version="0.1" byte_order="LittleEndian">\n'
        f'  <PolyData>\n    <Piece NumberOfPoints="{n}" NumberOfVerts="{n}" '
        f'NumberOfLines="0" NumberOfStrips="0" NumberOfPolys="0">\n'
        '      <Points>\n'
        '        <DataArray type="Float64" NumberOfComponents="3" '
        'format="ascii">\n'
    )
    for x, y, z in pts:
        pts_xml += f"          {x:.6g} {y:.6g} {z:.6g}\n"
    pts_xml += (
        '        </DataArray>\n      </Points>\n'
        '      <Verts>\n'
        f'        <DataArray type="Int32" Name="connectivity" '
        f'format="ascii">\n          {" ".join(str(i) for i in range(n))}\n'
        '        </DataArray>\n'
        f'        <DataArray type="Int32" Name="offsets" '
        f'format="ascii">\n          {" ".join(str(i+1) for i in range(n))}\n'
        '        </DataArray>\n      </Verts>\n'
        '      <PointData>\n'
        '        <DataArray type="Float64" Name="well_names" '
        'format="ascii">\n'
    )
    # write names as integer codes (ParaView can't display strings easily)
    name_map = {nm: i for i, nm in enumerate(sorted(set(names)))}
    pts_xml += "          " + " ".join(str(name_map[nm]) for nm in names) + "\n"
    pts_xml += (
        '        </DataArray>\n      </PointData>\n'
        '    </Piece>\n  </PolyData>\n</VTKFile>\n'
    )
    abspath = os.path.abspath(filename)
    with open(abspath, "w") as f:
        f.write(pts_xml)
    return abspath
