"""
Well-flow dynamics for reservoir simulation.

Extends the basic Peaceman well model (``wells.py``) with:

* **Layered well-index computation** directly from a :class:`ReservoirGrid`
  using the Peaceman (1983) equivalent-radius formula.
* **Multi-rate commingled flow** — a well completed across several layers
  with a prescribed per-layer rate, producing cumulative production and a
  bottom-hole pressure consistent with the layer pressures.
* **Crossflow detection** — flagging layers where the wellbore pressure
  lies below the layer pressure (inflow into the wellbore from a layer
  that is nominally injecting, or outflow from the wellbore into a layer
  that is nominally producing).

The Peaceman well index for a Cartesian block is

.. math::

    WI = \\frac{2\\pi k h}{\\ln(r_e/r_w) + S}

with the equivalent block radius

.. math::

    r_e = 0.28\\,
          \\frac{\\sqrt{\\sqrt{k_x/k_y}\\,\\Delta x^2
                       + \\sqrt{k_y/k_x}\\,\\Delta y^2}}
               {\\tfrac12\\bigl[(k_x/k_y)^{1/4}+(k_y/k_x)^{1/4}\\bigr]}.

All quantities are SI: permeability in m^2, length in m, pressure in Pa,
rate in m^3/s (reservoir conditions).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "PeacemanWell",
    "LayerConnection",
    "well_index",
    "WellFlowResult",
    "multi_rate_well",
    "detect_crossflow",
    "commingled_bhp",
]


# --------------------------------------------------------------------------- #
# Layer connection (one per perforated cell)
# --------------------------------------------------------------------------- #
@dataclass
class LayerConnection:
    """A single cell-to-wellbore connection.

    Attributes
    ----------
    i, j, k : int
        Cell indices in the grid.
    wi : float
        Well index for this connection (m^3/(Pa.s)).
    dz : float
        Net pay (cell thickness) used for the index (m).
    k_eff : float
        Effective permeability of the connection (m^2).
    """

    i: int
    j: int
    k: int
    wi: float
    dz: float
    k_eff: float


# --------------------------------------------------------------------------- #
# Peaceman well
# --------------------------------------------------------------------------- #
@dataclass
class PeacemanWell:
    """A vertical well completed in one or more cells of a grid.

    Parameters
    ----------
    name : str
        Well identifier.
    i, j : int
        Surface location (constant I, J column); the well is vertical so
        all perforations share the same (i, j).
    k_range : tuple[int, int]
        Inclusive layer range ``[k_top, k_bot]`` to perforate.
    rw : float
        Wellbore radius (m).
    skin : float
        Dimensionless skin factor.
    control : str
        ``"bhp"`` (pressure-constrained) or ``"rate"`` (rate-constrained).
    target : float
        BHP in Pa (control="bhp") or total rate in m^3/s (control="rate").
    phase : str
        Producing/injecting phase label.
    """

    name: str
    i: int
    j: int
    k_range: tuple[int, int]
    rw: float = 0.1
    skin: float = 0.0
    control: str = "bhp"
    target: float = 1.0e7
    phase: str = "oil"
    connections: list[LayerConnection] = field(default_factory=list)

    # ----- helpers --------------------------------------------------------
    def total_wi(self) -> float:
        """Sum of connection well indices (m^3/(Pa.s))."""
        return sum(c.wi for c in self.connections)

    def perforated_layers(self) -> list[int]:
        return [c.k for c in self.connections]


# --------------------------------------------------------------------------- #
# Equivalent block radius (Peaceman 1983)
# --------------------------------------------------------------------------- #
def _equivalent_radius(dx: float, dy: float, kx: float, ky: float) -> float:
    """Peaceman equivalent grid-block radius ``r_e``.

    For anisotropic grids (:math:`k_x \\neq k_y`) the anisotropic correction
    is applied.  Falls back to the isotropic ``r_e = 0.2 * sqrt(dx*dy)``
    when either permeability is zero.
    """
    if kx <= 0.0 or ky <= 0.0:
        return 0.2 * np.sqrt(dx * dy)
    rx = np.sqrt(kx / ky)
    ry = np.sqrt(ky / kx)
    num = np.sqrt(rx * dx ** 2 + ry * dy ** 2)
    den = 0.5 * ((kx / ky) ** 0.25 + (ky / kx) ** 0.25)
    re = 0.28 * num / den
    return re


# --------------------------------------------------------------------------- #
# Well index from a grid
# --------------------------------------------------------------------------- #
def well_index(
    grid,
    well: PeacemanWell,
    perm: np.ndarray,
    skin: Optional[float] = None,
) -> np.ndarray:
    """Compute the Peaceman well index for every perforated layer.

    Parameters
    ----------
    grid : ReservoirGrid
        The simulation grid.
    well : PeacemanWell
        The well description (column ``(i, j)`` and layer range).
    perm : np.ndarray, shape (nx, ny, nz, 3)
        Permeability field with ``perm[..., 0] = kx``, ``[...,1] = ky``,
        ``[...,2] = kz`` (m^2).
    skin : float, optional
        Override the well's skin factor.

    Returns
    -------
    wi : np.ndarray, shape (n_layers,)
        Well index per perforated layer (m^3/(Pa.s)).
    """
    skin = well.skin if skin is None else skin
    dx, dy, dz = grid.cell_dxyz()
    k_top, k_bot = well.k_range
    i, j = well.i, well.j

    wi_list = []
    for k in range(k_top, k_bot + 1):
        kx = float(perm[i, j, k, 0])
        ky = float(perm[i, j, k, 1])
        h = float(dz[i, j, k])
        re = _equivalent_radius(float(dx[i, j, k]), float(dy[i, j, k]), kx, ky)
        re = max(re, well.rw * 1.01)
        k_eff = np.sqrt(max(kx * ky, 0.0))
        denom = np.log(re / well.rw) + skin
        if denom <= 0.0:
            denom = 1.0
        wi = 2.0 * np.pi * k_eff * h / denom
        wi_list.append(wi)
        # register the connection on the well object
        well.connections.append(
            LayerConnection(i=i, j=j, k=k, wi=wi, dz=h, k_eff=k_eff)
        )
    return np.asarray(wi_list)


# --------------------------------------------------------------------------- #
# Well flow result
# --------------------------------------------------------------------------- #
@dataclass
class WellFlowResult:
    """Outcome of a multi-layer well calculation.

    Attributes
    ----------
    layer_rates : np.ndarray
        Rate per layer (m^3/s, reservoir conditions).  Positive = production
        into the wellbore.
    cumulative : float
        Total rate across all layers (m^3/s).
    bhp : float
        Bottom-hole pressure used / computed (Pa).
    layer_pressures : np.ndarray
        Cell pressure per layer (Pa).
    crossflow : np.ndarray, bool
        Per-layer crossflow flag.
    """

    layer_rates: np.ndarray
    cumulative: float
    bhp: float
    layer_pressures: np.ndarray
    crossflow: np.ndarray


# --------------------------------------------------------------------------- #
# Crossflow detection
# --------------------------------------------------------------------------- #
def detect_crossflow(
    layer_pressures: np.ndarray,
    well_bhp: float,
    producing: bool = True,
) -> np.ndarray:
    """Flag layers where flow reverses relative to the well's intent.

    For a **producer** the wellbore pressure is below the reservoir pressure,
    so each layer should flow *into* the well (``P_layer > BHP``).  A layer
    with ``P_layer < BHP`` is crossflowing (the wellbore injects into it).

    For an **injector** the opposite holds: ``P_layer < BHP`` is normal,
    ``P_layer > BHP`` is crossflow.

    Parameters
    ----------
    layer_pressures : np.ndarray
        Reservoir (cell) pressure per layer (Pa).
    well_bhp : float
        Well bottom-hole pressure (Pa).
    producing : bool
        ``True`` for a producing well, ``False`` for an injector.

    Returns
    -------
    crossflow : np.ndarray, bool
        ``True`` where the layer is crossflowing.
    """
    lp = np.asarray(layer_pressures, dtype=float)
    if producing:
        return lp < well_bhp
    return lp > well_bhp


# --------------------------------------------------------------------------- #
# Commingled BHP from a prescribed total rate
# --------------------------------------------------------------------------- #
def commingled_bhp(
    layer_pressures: np.ndarray,
    well_indices: np.ndarray,
    total_rate: float,
) -> float:
    """Bottom-hole pressure for a commingled well at a prescribed total rate.

    For a producer with total reservoir rate :math:`Q`:

    .. math::

        Q = \\sum_l WI_l (P_l - BHP)
          \\;\\Longrightarrow\\;
        BHP = \\frac{\\sum_l WI_l P_l - Q}{\\sum_l WI_l}.

    Parameters
    ----------
    layer_pressures : np.ndarray
        Cell pressure per layer (Pa).
    well_indices : np.ndarray
        Well index per layer (m^3/(Pa.s)).
    total_rate : float
        Prescribed total (reservoir) rate (m^3/s).  Positive = production.

    Returns
    -------
    bhp : float
        Bottom-hole pressure (Pa).
    """
    lp = np.asarray(layer_pressures, dtype=float)
    wi = np.asarray(well_indices, dtype=float)
    if wi.sum() == 0.0:
        return float(np.mean(lp))
    bhp = (np.dot(wi, lp) - total_rate) / wi.sum()
    return float(bhp)


# --------------------------------------------------------------------------- #
# Multi-rate well
# --------------------------------------------------------------------------- #
def multi_rate_well(
    layer_pressures: np.ndarray,
    well_indices: np.ndarray,
    bhp: float,
    producing: bool = True,
) -> WellFlowResult:
    """Compute per-layer rates for a BHP-constrained multi-layer well.

    Each layer produces/injects at

    .. math:: q_l = WI_l (P_l - BHP).

    The sign convention is: **positive rate = production into the wellbore**
    regardless of ``producing``; the flag only governs crossflow semantics.

    Parameters
    ----------
    layer_pressures : np.ndarray
        Cell pressure per layer (Pa).
    well_indices : np.ndarray
        Well index per layer (m^3/(Pa.s)).
    bhp : float
        Imposed bottom-hole pressure (Pa).
    producing : bool
        Whether the well is a producer (controls crossflow logic).

    Returns
    -------
    result : WellFlowResult
    """
    lp = np.asarray(layer_pressures, dtype=float)
    wi = np.asarray(well_indices, dtype=float)
    layer_rates = wi * (lp - bhp)
    cumulative = float(layer_rates.sum())
    crossflow = detect_crossflow(lp, bhp, producing=producing)
    return WellFlowResult(
        layer_rates=layer_rates,
        cumulative=cumulative,
        bhp=float(bhp),
        layer_pressures=lp,
        crossflow=crossflow,
    )
