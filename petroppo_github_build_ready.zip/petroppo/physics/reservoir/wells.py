"""
Well models for reservoir simulation.

Implements the Peaceman well index for Cartesian grids and supports
rate- and pressure-constrained wells (BHP / WCONPROD / WCONINJE style).

A well is a list of perforations; each perforation contributes a source
term to one cell.  The well index (WI) couples the cell pressure to the
well bottom-hole pressure (BHP) via

.. math::

    q = WI (P_{well} - P_{cell})

with :math:`WI = \\frac{2\\pi k h}{\\ln(r_e/r_w) + S}`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "Perforation",
    "Well",
    "ProducerWell",
    "InjectorWell",
    "peaceman_well_index",
]


# ---------------------------------------------------------------------------
# Peaceman well index
# ---------------------------------------------------------------------------

def peaceman_well_index(
    k_cell: float,
    dx: float,
    dy: float,
    dz: float,
    kx: Optional[float] = None,
    ky: Optional[float] = None,
    rw: float = 0.1,
    skin: float = 0.0,
) -> float:
    """Peaceman well index for a single cell.

    Parameters
    ----------
    k_cell : float
        Effective (geometric-mean) permeability at the well, m2.
        If ``kx``/``ky`` given they override.
    dx, dy, dz : float
        Cell dimensions (m).
    rw : float
        Wellbore radius (m).
    skin : float
        Dimensionless skin factor.

    Returns
    -------
    wi : float
        Well index (m3/(Pa.s)).
    """
    if kx is None or ky is None:
        kx = ky = k_cell
    # equivalent grid-block radius (Peaceman 1983)
    re = 0.28 * np.sqrt(np.sqrt(kx / ky) * dx ** 2 + np.sqrt(ky / kx) * dy ** 2) \
         / (0.5 * ((kx / ky) ** 0.25 + (ky / kx) ** 0.25))
    re = max(re, rw * 1.01)
    wi = 2.0 * np.pi * np.sqrt(kx * ky) * dz / (np.log(re / rw) + skin)
    return wi


# ---------------------------------------------------------------------------
# Perforations and wells
# ---------------------------------------------------------------------------

@dataclass
class Perforation:
    """A single well-cell connection."""

    i: int
    j: int
    k: int
    well_index: float
    multiplier: float = 1.0


@dataclass
class Well:
    """Base well: a list of perforations plus a control."""

    name: str
    perforations: list[Perforation] = field(default_factory=list)
    control: str = "bhp"          # "bhp" or "rate"
    target: float = 0.0           # Pa (bhp) or m3/s (rate, reservoir conditions)
    phase: str = "oil"            # which phase this well produces/injects
    rw: float = 0.1
    skin: float = 0.0

    def add_perforation(
        self,
        i: int,
        j: int,
        k: int,
        k_cell: float,
        dx: float,
        dy: float,
        dz: float,
        kx: Optional[float] = None,
        ky: Optional[float] = None,
        multiplier: float = 1.0,
        rw: Optional[float] = None,
        skin: Optional[float] = None,
    ) -> None:
        rw = self.rw if rw is None else rw
        skin = self.skin if skin is None else skin
        wi = peaceman_well_index(k_cell, dx, dy, dz, kx, ky, rw, skin)
        self.perforations.append(Perforation(i, j, k, wi, multiplier))

    def total_wi(self) -> float:
        return sum(p.well_index * p.multiplier for p in self.perforations)


@dataclass
class ProducerWell(Well):
    """A production well."""

    control: str = "bhp"
    target: float = 1.0e7         # 100 bar BHP default
    phase: str = "oil"


@dataclass
class InjectorWell(Well):
    """An injection well."""

    control: str = "rate"
    target: float = 0.0           # m3/s reservoir conditions
    phase: str = "water"
