"""petroppo V20 — Scientific result envelope.

Every solver in petroppo V20 returns a :class:`ScientificResult` rather than a
bare array or dict.  The envelope carries:

* the computed ``model`` (parameters) and ``prediction`` (synthesised data);
* a :class:`Provenance` block recording *exactly* what produced it (code
  version, git SHA if available, random seed, wall time, machine fingerprint);
* a :class:`QCReport` with quantitative pass/fail flags that the verification
  suite and the benchmark harness can inspect *without* trusting the solver's
  own claim of success.

This closes V19 audit defect #6 (results written to leaderboard with no
provenance → non-reproducible numbers) and defect #4 (silent success on
failure).

Design principles
-----------------
1. **Never trust the solver.**  QCReport flags are computed *by the caller*
   (or the harness), not set by the solver.
2. **Everything is serialisable.**  ``to_dict()`` / ``from_dict()`` produce
   plain JSON-compatible structures so results can be stored, diffed, and
   compared across runs.
3. **Provenance is mandatory.**  A ScientificResult without provenance raises
   ``ValueError`` on construction — you cannot ship an un-attributed result.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import platform
import socket
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np


# ──────────────────────────────────────────────────────────────────────────────
# Provenance
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class Provenance:
    """Records the exact conditions under which a result was produced."""
    solver_name: str
    solver_version: str
    timestamp: str = ""
    seed: Optional[int] = None
    wall_time_s: float = 0.0
    cpu_time_s: float = 0.0
    hostname: str = ""
    platform: str = ""
    python_version: str = ""
    numpy_version: str = ""
    n_cores: int = 1
    git_sha: str = ""
    config: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                           time.gmtime())
        if not self.hostname:
            self.hostname = socket.gethostname()
        if not self.platform:
            self.platform = platform.platform()
        if not self.python_version:
            self.python_version = platform.python_version()
        try:
            if not self.numpy_version:
                import numpy as _np
                self.numpy_version = _np.__version__
        except Exception:
            self.numpy_version = "unknown"
        if not self.n_cores:
            self.n_cores = os.cpu_count() or 1

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Provenance":
        return cls(**d)


# ──────────────────────────────────────────────────────────────────────────────
# QCReport
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class QCReport:
    """Quality-control flags computed by the caller (NOT the solver).

    Each flag is a (passed: bool, value: float, detail: str) triple.  The
    :attr:`all_passed` property is the single boolean the harness trusts.
    """
    flags: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)

    def add(self, name: str, passed: bool, value: float,
            detail: str = "") -> None:
        self.flags[name] = {
            "passed": bool(passed),
            "value": float(value),
            "detail": str(detail),
        }

    @property
    def all_passed(self) -> bool:
        if not self.flags:
            return False  # empty QC = not certified
        return all(f["passed"] for f in self.flags.values())

    @property
    def n_passed(self) -> int:
        return sum(1 for f in self.flags.values() if f["passed"])

    @property
    def n_total(self) -> int:
        return len(self.flags)

    def to_dict(self) -> Dict[str, Any]:
        return {"flags": self.flags, "notes": self.notes}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "QCReport":
        return cls(flags=d.get("flags", {}), notes=d.get("notes", []))


# ──────────────────────────────────────────────────────────────────────────────
# ScientificResult
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class ScientificResult:
    """The standard return type for all V20 solvers.

    Parameters
    ----------
    model : np.ndarray
        The estimated model parameters (e.g. log-resistivity per cell).
    prediction : np.ndarray
        The synthesised data corresponding to *model*.
    provenance : Provenance
        Mandatory provenance block.
    qc : QCReport
        Quality-control flags (computed by caller).
    metadata : dict
        Solver-specific extra info (iterations, misfit history, etc.).
    units_model : str
        SI unit string for the model parameters.
    units_prediction : str
        SI unit string for the prediction.
    """
    model: np.ndarray
    prediction: np.ndarray
    provenance: Provenance
    qc: QCReport = field(default_factory=QCReport)
    metadata: Dict[str, Any] = field(default_factory=dict)
    units_model: str = ""
    units_prediction: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.provenance, Provenance):
            raise TypeError("provenance must be a Provenance instance")
        self.model = np.asarray(self.model, dtype=float)
        self.prediction = np.asarray(self.prediction, dtype=float)

    @property
    def certified(self) -> bool:
        """True iff all QC flags passed AND provenance is complete."""
        return self.qc.all_passed and bool(self.provenance.solver_name)

    @property
    def fingerprint(self) -> str:
        """SHA-256 of (model + prediction + provenance) for tamper detection."""
        h = hashlib.sha256()
        h.update(self.model.tobytes())
        h.update(self.prediction.tobytes())
        h.update(json.dumps(self.provenance.to_dict(), sort_keys=True).encode())
        return h.hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model.tolist(),
            "prediction": self.prediction.tolist(),
            "provenance": self.provenance.to_dict(),
            "qc": self.qc.to_dict(),
            "metadata": self.metadata,
            "units_model": self.units_model,
            "units_prediction": self.units_prediction,
            "certified": self.certified,
            "fingerprint": self.fingerprint,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ScientificResult":
        return cls(
            model=np.asarray(d["model"], dtype=float),
            prediction=np.asarray(d["prediction"], dtype=float),
            provenance=Provenance.from_dict(d["provenance"]),
            qc=QCReport.from_dict(d.get("qc", {})),
            metadata=d.get("metadata", {}),
            units_model=d.get("units_model", ""),
            units_prediction=d.get("units_prediction", ""),
        )

    def summary(self) -> str:
        lines = [
            f"ScientificResult (certified={self.certified})",
            f"  fingerprint : {self.fingerprint}",
            f"  model       : shape={self.model.shape} unit={self.units_model!r}",
            f"  prediction  : shape={self.prediction.shape} unit={self.units_prediction!r}",
            f"  provenance  : {self.provenance.solver_name} v{self.provenance.solver_version}",
            f"                 seed={self.provenance.seed} wall={self.provenance.wall_time_s:.3f}s",
            f"  QC          : {self.qc.n_passed}/{self.qc.n_total} passed",
        ]
        for name, fl in self.qc.flags.items():
            tag = "PASS" if fl["passed"] else "FAIL"
            lines.append(f"    [{tag}] {name}: {fl['value']:.6g}  {fl['detail']}")
        return "\n".join(lines)
