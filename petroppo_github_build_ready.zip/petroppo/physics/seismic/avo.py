"""petroppo V22 — AVO (Amplitude Variation with Offset) analysis.

Implements AVO analysis for hydrocarbon detection:

* **Zoeppritz equations** — exact plane-wave reflection coefficients
  at a solid-solid interface (P-P reflection).

* **Shuey approximation** — the most widely used AVO approximation:

    R(θ) = A + B·sin²(θ) + C·(tan²(θ) - sin²(θ))

  where:
    A = intercept (normal-incidence reflection coefficient)
    B = gradient (AVO slope)
    C = higher-order term (often neglected for θ < 30°)

  Two-term Shuey: R(θ) ≈ A + B·sin²(θ)

* **Aki-Richards approximation** — three-term approximation in terms
  of P-wave velocity, S-wave velocity, and density contrasts.

* **AVO classification** (Rutherford & Williams 1989, Castagna & Swan 1997):
    * Class 1: High impedance contrast — positive intercept, negative gradient
    * Class 2: Near-zero intercept — gradient dominates
    * Class 2p: Class 2 with polarity reversal
    * Class 3: Low impedance gas sand — negative intercept, negative gradient (bright spot)
    * Class 4: Negative intercept, positive gradient (rare)

* **AVO attributes**: intercept-gradient product (P·G), fluid factor,
  Poisson's ratio change.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.optimize import curve_fit

__all__ = [
    "zoeppritz_pp",
    "shuey_approximation",
    "aki_richards",
    "avo_intercept_gradient",
    "AVOClass",
    "classify_avo",
    "avo_attributes",
    "AVOAnalysis",
]


# -----------------------------------------------------------------------
# Zoeppritz equations (exact)
# -----------------------------------------------------------------------

def zoeppritz_pp(
    vp1: float, vs1: float, rho1: float,
    vp2: float, vs2: float, rho2: float,
    theta1: np.ndarray | float,
) -> np.ndarray | float:
    """Exact P-P reflection coefficient from the Zoeppritz equations.

    Solves the full 4×4 Zoeppritz system for the P-wave reflection
    coefficient at a solid-solid interface.

    Parameters
    ----------
    vp1, vs1, rho1 : float
        P-wave velocity (m/s), S-wave velocity (m/s), density (kg/m³)
        of the upper medium.
    vp2, vs2, rho2 : float
        Properties of the lower medium.
    theta1 : ndarray or float
        Incidence angles (radians).

    Returns
    -------
    Rpp : ndarray or float
        P-P reflection coefficient(s).
    """
    theta1 = np.asarray(theta1, dtype=float)
    scalar = theta1.ndim == 0
    theta1 = np.atleast_1d(theta1)
    Rpp = np.zeros_like(theta1)

    for i, t1 in enumerate(theta1):
        # Ray parameter p = sin(θ₁) / Vp₁ (Snell's law invariant)
        p = np.sin(t1) / vp1
        # Transmitted P-wave angle:  sin(θ₂) = p · Vp₂
        sin_t2 = p * vp2
        if abs(sin_t2) > 1.0:
            Rpp[i] = 0.0
            continue
        t2 = np.arcsin(sin_t2)
        # Reflected / transmitted S-wave angles:  sin(φ) = p · Vs
        sin_phi1 = p * vs1
        sin_phi2 = p * vs2
        if abs(sin_phi1) > 1.0 or abs(sin_phi2) > 1.0:
            Rpp[i] = 0.0
            continue
        phi1 = np.arcsin(sin_phi1)
        phi2 = np.arcsin(sin_phi2)

        # Zoeppritz 4x4 system (Aki & Richards, 2002, Box 5.2).
        # Columns: reflected P (Rpp), reflected S (Rps), transmitted P (Tpp), transmitted S (Tps).
        # Rows:    u-displacement, w-displacement, shear stress (σzx), normal stress (σzz).
        # Using the sin(2θ) / cos(2φ) form which is numerically well-conditioned
        # away from grazing angles and reduces exactly to R0 at normal incidence.
        M = np.array([
            [-np.sin(t1), -np.cos(phi1), np.sin(t2), np.cos(phi2)],
            [ np.cos(t1), -np.sin(phi1), np.cos(t2), -np.sin(phi2)],
            [ np.sin(2 * t1) * rho1 * vs1**2 / vp1**2,
             -rho1 * vs1 * np.cos(2 * phi1),
              np.sin(2 * t2) * rho2 * vs2**2 / vp2**2,
              rho2 * vs2 * np.cos(2 * phi2)],
            [-rho1 * vp1 * np.cos(2 * phi1),
              rho1 * vs1 * np.sin(2 * phi1),
              rho2 * vp2 * np.cos(2 * phi2),
              rho2 * vs2 * np.sin(2 * phi2)],
        ], dtype=float)

        rhs = np.array([
            np.sin(t1),
            np.cos(t1),
            np.sin(2 * t1) * rho1 * vs1**2 / vp1**2,
            rho1 * vp1 * np.cos(2 * phi1),
        ])

        try:
            sol = np.linalg.solve(M, rhs)
            Rpp[i] = sol[0]
        except np.linalg.LinAlgError:
            Rpp[i] = 0.0

    return Rpp[0] if scalar else Rpp


# -----------------------------------------------------------------------
# Shuey approximation
# -----------------------------------------------------------------------

def shuey_approximation(
    theta: np.ndarray | float,
    intercept: float,
    gradient: float,
    third_term: float = 0.0,
) -> np.ndarray | float:
    """Shuey AVO approximation.

    R(θ) = A + B·sin²(θ) + C·(tan²(θ) - sin²(θ))

    For θ < 30°, the third term is often negligible:
    R(θ) ≈ A + B·sin²(θ)

    Parameters
    ----------
    theta : ndarray or float
        Angles (radians).
    intercept : float
        A — normal-incidence reflection coefficient.
    gradient : float
        B — AVO gradient.
    third_term : float
        C — higher-order term (default 0).

    Returns
    -------
    R : ndarray or float
        Reflection coefficient at each angle.
    """
    theta = np.asarray(theta, dtype=float)
    s2 = np.sin(theta) ** 2
    t2 = np.tan(theta) ** 2
    return intercept + gradient * s2 + third_term * (t2 - s2)


def aki_richards(
    theta: np.ndarray | float,
    dvp_vp: float,
    dvs_vs: float,
    drho_rho: float,
    vp_vs: float = 2.0,
) -> np.ndarray | float:
    """Aki-Richards three-term AVO approximation.

    R(θ) = 0.5·(dVp/Vp) + 0.5·(dρ/ρ)·cos²(θ)·...
    
    Full form:
    R(θ) = 0.5·(dVp/Vp + dρ/ρ) + 0.5·(dVp/Vp - 2·(Vs/Vp)²·(dρ/ρ + 2·dVs/Vs))·sin²(θ)
           + 0.5·(dVp/Vp)·sin²(θ)·tan²(θ)

    Parameters
    ----------
    theta : ndarray or float
        Angles (radians).
    dvp_vp, dvs_vs, drho_rho : float
        Fractional contrasts: (Vp2-Vp1)/Vp_avg, etc.
    vp_vs : float
        Vp/Vs ratio (average).

    Returns
    -------
    R : ndarray or float
    """
    theta = np.asarray(theta, dtype=float)
    g = (vp_vs ** -2)  # (Vs/Vp)²
    s2 = np.sin(theta) ** 2
    t2s2 = np.sin(theta) ** 2 * np.tan(theta) ** 2
    R = (0.5 * (dvp_vp + drho_rho)
         + 0.5 * (dvp_vp - 2 * g * (drho_rho + 2 * dvs_vs)) * s2
         + 0.5 * dvp_vp * t2s2)
    return R


# -----------------------------------------------------------------------
# Intercept-Gradient fitting
# -----------------------------------------------------------------------

@dataclass
class AVOAnalysis:
    """Result of AVO intercept-gradient analysis."""
    intercept: float       # A
    gradient: float        # B
    third_term: float      # C (if fitted)
    r_squared: float       # goodness of fit
    avo_class: str         # classified AVO class
    angles: np.ndarray     # angles used (radians)
    amplitudes: np.ndarray  # observed amplitudes
    fitted: np.ndarray     # fitted Shuey curve


def avo_intercept_gradient(
    angles: np.ndarray,
    amplitudes: np.ndarray,
    fit_third_term: bool = False,
) -> AVOAnalysis:
    """Fit AVO intercept and gradient from angle-gather amplitudes.

    Uses least-squares to fit the Shuey approximation to observed
    amplitudes vs angle.

    Parameters
    ----------
    angles : ndarray
        Incidence angles (radians).
    amplitudes : ndarray
        Reflection amplitudes at each angle.
    fit_third_term : bool
        If True, fit the three-term Shuey; otherwise two-term.

    Returns
    -------
    AVOAnalysis
    """
    angles = np.asarray(angles, dtype=float)
    amps = np.asarray(amplitudes, dtype=float)

    if fit_third_term:
        def model(theta, A, B, C):
            return shuey_approximation(theta, A, B, C)
        p0 = [amps[0], 0.0, 0.0]
        try:
            popt, _ = curve_fit(model, angles, amps, p0=p0, maxfev=10000)
            A, B, C = popt
        except Exception:
            A, B, C = amps[0], 0.0, 0.0
    else:
        def model(theta, A, B):
            return shuey_approximation(theta, A, B, 0.0)
        p0 = [amps[0], 0.0]
        try:
            popt, _ = curve_fit(model, angles, amps, p0=p0, maxfev=10000)
            A, B = popt
            C = 0.0
        except Exception:
            A, B, C = amps[0], 0.0, 0.0

    fitted = shuey_approximation(angles, A, B, C)
    # R²
    ss_res = np.sum((amps - fitted) ** 2)
    ss_tot = np.sum((amps - np.mean(amps)) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-30 else 0.0

    avo_class = classify_avo(A, B)

    return AVOAnalysis(
        intercept=A, gradient=B, third_term=C,
        r_squared=r2, avo_class=avo_class,
        angles=angles, amplitudes=amps, fitted=fitted,
    )


# -----------------------------------------------------------------------
# AVO classification
# -----------------------------------------------------------------------

# AVO classes (Castagna & Swan 1997, extended)
AVOClass = {
    "Class 1": "High impedance contrast — positive intercept, negative gradient",
    "Class 2": "Near-zero intercept — gradient dominates",
    "Class 2p": "Class 2 with polarity reversal",
    "Class 3": "Low impedance gas sand — negative intercept, negative gradient",
    "Class 4": "Negative intercept, positive gradient",
    "No AVO": "No significant AVO effect",
}


def classify_avo(intercept: float, gradient: float) -> str:
    """Classify AVO response from intercept (A) and gradient (B).

    Classification scheme (Rutherford & Williams 1989, Castagna & Swan 1997):

    * Class 1: A > 0, B < 0 (high impedance, brightening with offset decreasing)
    * Class 2: A ≈ 0, B < 0 (near-zero intercept, negative gradient)
    * Class 2p: A > 0 small, B < 0 (polarity reversal at far offset)
    * Class 3: A < 0, B < 0 (low impedance gas sand, bright spot)
    * Class 4: A < 0, B > 0 (negative intercept, positive gradient)
    * No AVO: |A| and |B| both small

    Parameters
    ----------
    intercept : float
        A — normal-incidence reflection coefficient.
    gradient : float
        B — AVO gradient.

    Returns
    -------
    class_name : str
    """
    A = intercept
    B = gradient
    # thresholds
    a_thresh = 0.02
    b_thresh = 0.02

    if abs(A) < a_thresh and abs(B) < b_thresh:
        return "No AVO"
    if A > a_thresh and B < -b_thresh:
        # check for polarity reversal: does R cross zero?
        # R(θ) = A + B*sin²(θ) → zero at sin²(θ) = -A/B
        if B < 0 and A > 0:
            sin2_cross = -A / B
            if 0 < sin2_cross < 1:
                return "Class 2p"
        return "Class 1"
    if A < -a_thresh and B < -b_thresh:
        return "Class 3"
    if A < -a_thresh and B > b_thresh:
        return "Class 4"
    if abs(A) < a_thresh and B < -b_thresh:
        return "Class 2"
    # fallback
    if A > 0 and B < 0:
        return "Class 1"
    if A < 0 and B < 0:
        return "Class 3"
    if A < 0 and B > 0:
        return "Class 4"
    return "No AVO"


# -----------------------------------------------------------------------
# AVO attributes
# -----------------------------------------------------------------------

@dataclass
class AVOAttributes:
    """Derived AVO attributes."""
    intercept: float
    gradient: float
    product: float          # A × G (intercept-gradient product)
    fluid_factor: float     # Castagna's fluid factor
    poisson_change: float   # Δσ estimate
    class_name: str


def avo_attributes(
    intercept: float,
    gradient: float,
    vp_vs: float = 2.0,
) -> AVOAttributes:
    """Compute derived AVO attributes from intercept and gradient.

    Parameters
    ----------
    intercept, gradient : float
        AVO A and B.
    vp_vs : float
        Average Vp/Vs ratio for fluid factor calculation.

    Returns
    -------
    AVOAttributes
    """
    A = intercept
    B = gradient
    product = A * B
    # Fluid factor (Castagna & Smith): F = A + B * (1 + 2*sigma) / (1 - sigma)
    # Simplified: fluid factor deviation from mudrock line
    sigma = 0.25  # typical Poisson's ratio for brine-saturated sand
    fluid_factor = A + B * (1 + 2 * sigma) / (1 - sigma)
    # Poisson's ratio change estimate: Δσ ≈ -B * (Vp/Vs)² / 2
    poisson_change = -B * (vp_vs ** 2) / 2.0
    class_name = classify_avo(A, B)

    return AVOAttributes(
        intercept=A, gradient=B, product=product,
        fluid_factor=fluid_factor, poisson_change=poisson_change,
        class_name=class_name,
    )
