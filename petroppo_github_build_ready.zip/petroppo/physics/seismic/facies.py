"""petroppo V22 — Seismic facies classification.

Implements seismic facies classification from attribute volumes:

* **K-means clustering** — unsupervised classification of seismic
  traces into facies classes based on attribute vectors (amplitude,
  frequency, coherence, etc.).

* **Bayesian facies classification** — supervised classification using
  Gaussian mixture models (GMM) trained on well-tied facies labels.
  Returns both the most-likely facies and the posterior probability
  for each class.

* **Attribute-based rule classification** — simple rule-based
  classification using industry-standard heuristics:
  * High amplitude + low frequency → channel sand (potential reservoir)
  * Low amplitude + high frequency → shale
  * Medium amplitude + medium frequency → interbedded sand-shale
  * Low coherence → faulted / fractured

* **Facies map generation** — produce 2-D facies maps at a target
  horizon from 3-D attribute volumes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.stats import norm, multivariate_normal

__all__ = [
    "FaciesClassification",
    "kmeans_facies",
    "bayesian_facies",
    "rule_based_facies",
    "FACIES_NAMES",
]


# Standard facies names
FACIES_NAMES = {
    0: "Shale",
    1: "Interbedded Sand-Shale",
    2: "Channel Sand",
    3: "Carbonate",
    4: "Faulted/Fractured",
}


@dataclass
class FaciesClassification:
    """Result of facies classification."""
    facies: np.ndarray         # (nx, ny) or (nx, ny, nz) integer labels
    n_classes: int
    probabilities: Optional[np.ndarray] = None  # (nx, ny, n_classes) if Bayesian
    class_names: dict = field(default_factory=lambda: dict(FACIES_NAMES))
    method: str = "kmeans"


# -----------------------------------------------------------------------
# K-means clustering
# -----------------------------------------------------------------------

def kmeans_facies(
    attributes: np.ndarray,
    n_classes: int = 4,
    n_init: int = 10,
    max_iter: int = 300,
    seed: int = 42,
) -> FaciesClassification:
    """Unsupervised facies classification via K-means clustering.

    Parameters
    ----------
    attributes : ndarray (n_samples, n_features)
        Feature matrix: each row is a sample (trace or voxel), each
        column is an attribute (amplitude, frequency, coherence, etc.).
    n_classes : int
        Number of facies classes.
    n_init : int
        Number of K-means restarts.
    max_iter : int
        Maximum iterations per restart.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    FaciesClassification
    """
    X = np.asarray(attributes, dtype=float)
    n, d = X.shape
    rng = np.random.default_rng(seed)

    best_inertia = np.inf
    best_labels = None
    best_centroids = None

    for _ in range(n_init):
        # Initialise centroids via random selection
        idx = rng.choice(n, n_classes, replace=False)
        centroids = X[idx].copy()

        for _ in range(max_iter):
            # Assign
            dists = np.zeros((n, n_classes))
            for k in range(n_classes):
                dists[:, k] = np.sum((X - centroids[k]) ** 2, axis=1)
            labels = np.argmin(dists, axis=1)

            # Update
            new_centroids = np.zeros_like(centroids)
            for k in range(n_classes):
                mask = labels == k
                if np.sum(mask) > 0:
                    new_centroids[k] = np.mean(X[mask], axis=0)
                else:
                    new_centroids[k] = centroids[k]

            if np.allclose(new_centroids, centroids, atol=1e-8):
                break
            centroids = new_centroids

        inertia = np.sum(np.min(dists, axis=1))
        if inertia < best_inertia:
            best_inertia = inertia
            best_labels = labels
            best_centroids = centroids

    return FaciesClassification(
        facies=best_labels, n_classes=n_classes, method="kmeans",
    )


# -----------------------------------------------------------------------
# Bayesian (GMM) facies classification
# -----------------------------------------------------------------------

def bayesian_facies(
    attributes: np.ndarray,
    means: np.ndarray,
    covariances: np.ndarray,
    priors: Optional[np.ndarray] = None,
) -> FaciesClassification:
    """Supervised Bayesian facies classification via Gaussian mixture.

    Given training statistics (mean, covariance, prior for each class),
    classify each sample by maximum posterior probability.

    Parameters
    ----------
    attributes : ndarray (n_samples, n_features)
        Feature matrix.
    means : ndarray (n_classes, n_features)
        Mean vector for each class.
    covariances : ndarray (n_classes, n_features, n_features)
        Covariance matrix for each class.
    priors : ndarray (n_classes,), optional
        Class priors (default: uniform).

    Returns
    -------
    FaciesClassification
        Includes posterior probabilities.
    """
    X = np.asarray(attributes, dtype=float)
    n, d = X.shape
    n_classes = means.shape[0]
    if priors is None:
        priors = np.ones(n_classes) / n_classes

    # Compute log-posterior for each sample and class
    log_post = np.zeros((n, n_classes))
    for k in range(n_classes):
        try:
            rv = multivariate_normal(mean=means[k], cov=covariances[k],
                                     allow_singular=True)
            log_post[:, k] = np.log(priors[k] + 1e-30) + rv.logpdf(X)
        except Exception:
            log_post[:, k] = np.log(priors[k] + 1e-30) - 1e10

    # Normalise to probabilities
    log_post -= np.max(log_post, axis=1, keepdims=True)
    probs = np.exp(log_post)
    probs /= np.sum(probs, axis=1, keepdims=True)

    facies = np.argmax(probs, axis=1)

    return FaciesClassification(
        facies=facies, n_classes=n_classes,
        probabilities=probs, method="bayesian",
    )


# -----------------------------------------------------------------------
# Rule-based facies classification
# -----------------------------------------------------------------------

def rule_based_facies(
    amplitude: np.ndarray,
    frequency: np.ndarray,
    coherence: np.ndarray,
    amp_threshold: float = 0.5,
    freq_low: float = 20.0,
    freq_high: float = 40.0,
    coh_threshold: float = 0.5,
) -> FaciesClassification:
    """Rule-based seismic facies classification.

    Uses industry-standard heuristic rules:

    * Low coherence (< coh_threshold) → Faulted/Fractured (4)
    * High amplitude + low frequency → Channel Sand (2)
    * Low amplitude + high frequency → Shale (0)
    * Medium amplitude + medium frequency → Interbedded (1)
    * Otherwise → Carbonate (3)

    Parameters
    ----------
    amplitude : ndarray
        RMS or envelope amplitude (normalised 0–1).
    frequency : ndarray
        Instantaneous or dominant frequency (Hz).
    coherence : ndarray
        Coherence (0–1).
    amp_threshold, freq_low, freq_high, coh_threshold : float
        Classification thresholds.

    Returns
    -------
    FaciesClassification
    """
    amp = np.asarray(amplitude, dtype=float)
    freq = np.asarray(frequency, dtype=float)
    coh = np.asarray(coherence, dtype=float)

    facies = np.full(amp.shape, 3, dtype=int)  # default: Carbonate

    # Rule 1: low coherence → faulted
    facies[coh < coh_threshold] = 4

    # Rule 2: high amplitude + low freq → channel sand
    sand = (amp > amp_threshold) & (freq < freq_low) & (coh >= coh_threshold)
    facies[sand] = 2

    # Rule 3: low amplitude + high freq → shale
    shale = (amp < amp_threshold * 0.5) & (freq > freq_high) & (coh >= coh_threshold)
    facies[shale] = 0

    # Rule 4: medium amplitude + medium freq → interbedded
    inter = (amp >= amp_threshold * 0.5) & (amp <= amp_threshold) & \
            (freq >= freq_low) & (freq <= freq_high) & (coh >= coh_threshold)
    facies[inter] = 1

    return FaciesClassification(
        facies=facies, n_classes=5, method="rule_based",
    )
