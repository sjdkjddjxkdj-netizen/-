"""petroppo V22 — Fault detection from seismic.

Implements fault detection algorithms based on seismic coherence:

* **Coherence-edge detection** — identify fault planes as zones of
  low coherence.  A coherence threshold is applied, and connected
  regions of low coherence are labelled as fault segments.

* **Ant-tracking** (simplified) — a proprietary-style edge enhancement
  algorithm inspired by ant colony optimisation.  "Ants" preferentially
  follow low-coherence edges, enhancing fault-like linear features.
  Here we implement a simplified version using directional filtering
  and edge enhancement.

* **Fault plane extraction** — from the enhanced coherence cube,
  extract fault planes as surfaces.  Uses connected-component
  labelling and planar fitting.

* **Fault throw estimation** — estimate vertical throw across detected
  faults by comparing horizon picks on either side of the fault.

All algorithms operate on 3-D numpy arrays and are deterministic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.ndimage import label, gaussian_filter, sobel

__all__ = [
    "detect_faults_coherence",
    "ant_tracking",
    "extract_fault_planes",
    "estimate_fault_throw",
    "FaultDetectionResult",
]


# -----------------------------------------------------------------------
# Coherence-based fault detection
# -----------------------------------------------------------------------

@dataclass
class FaultSegment:
    """A single detected fault segment."""
    segment_id: int
    n_voxels: int
    centroid: tuple[float, float, float]
    mean_coherence: float
    indices: tuple  # (ix_indices, iy_indices, iz_indices)


@dataclass
class FaultDetectionResult:
    """Result of fault detection."""
    fault_mask: np.ndarray           # binary (1 = fault, 0 = none)
    fault_labels: np.ndarray         # labelled segments
    n_faults: int
    segments: list[FaultSegment]
    enhanced_coherence: np.ndarray   # ant-tracked coherence (optional)


def detect_faults_coherence(
    coherence: np.ndarray,
    threshold: float = 0.5,
    min_size: int = 10,
) -> FaultDetectionResult:
    """Detect faults from a coherence volume.

    Faults correspond to zones of low coherence (discontinuities).
    This function thresholds the coherence and labels connected
    regions of low coherence as fault segments.

    Parameters
    ----------
    coherence : ndarray (nx, ny, nz)
        Coherence cube (1 = coherent, 0 = discontinuous).
    threshold : float
        Coherence threshold; voxels with coherence < threshold are
        potential faults.
    min_size : int
        Minimum number of voxels for a valid fault segment.

    Returns
    -------
    FaultDetectionResult
    """
    coh = np.asarray(coherence, dtype=float)
    fault_mask = (coh < threshold).astype(int)

    # Label connected fault segments
    structure = np.ones((3, 3, 3), dtype=int)  # 26-connectivity
    labels, n_labels = label(fault_mask, structure=structure)

    segments = []
    valid_labels = []
    for i in range(1, n_labels + 1):
        mask_i = labels == i
        n_vox = int(np.sum(mask_i))
        if n_vox < min_size:
            continue
        ix, iy, iz = np.where(mask_i)
        cx, cy, cz = float(np.mean(ix)), float(np.mean(iy)), float(np.mean(iz))
        mean_coh = float(np.mean(coh[mask_i]))
        segments.append(FaultSegment(
            segment_id=i, n_voxels=n_vox,
            centroid=(cx, cy, cz), mean_coherence=mean_coh,
            indices=(ix, iy, iz),
        ))
        valid_labels.append(i)

    # Relabel to remove small segments
    new_labels = np.zeros_like(labels)
    for new_id, old_id in enumerate(valid_labels, 1):
        new_labels[labels == old_id] = new_id

    return FaultDetectionResult(
        fault_mask=fault_mask,
        fault_labels=new_labels,
        n_faults=len(segments),
        segments=segments,
        enhanced_coherence=coh.copy(),
    )


# -----------------------------------------------------------------------
# Ant-tracking (simplified)
# -----------------------------------------------------------------------

def ant_tracking(
    coherence: np.ndarray,
    n_iterations: int = 3,
    sigma: float = 1.0,
    edge_threshold: float = 0.3,
) -> np.ndarray:
    """Simplified ant-tracking edge enhancement.

    The ant-tracking algorithm enhances fault-like linear features in
    the coherence cube.  This simplified version:

    1. Computes the Sobel edge magnitude in each direction
    2. Applies Gaussian smoothing along potential fault orientations
    3. Iteratively enhances connected edge structures

    Parameters
    ----------
    coherence : ndarray (nx, ny, nz)
        Coherence cube (low = fault).
    n_iterations : int
        Number of enhancement iterations.
    sigma : float
        Gaussian smoothing sigma.
    edge_threshold : float
        Threshold for edge detection.

    Returns
    -------
    enhanced : ndarray
        Enhanced fault attribute (high = likely fault).
    """
    coh = np.asarray(coherence, dtype=float)
    # Invert: edges = 1 - coherence (high = discontinuity)
    edge = 1.0 - coh

    # Sobel edge detection in each direction
    ex = sobel(edge, axis=0)
    ey = sobel(edge, axis=1)
    ez = sobel(edge, axis=2)
    edge_mag = np.sqrt(ex**2 + ey**2 + ez**2)

    # Normalise
    edge_mag = edge_mag / (np.max(edge_mag) + 1e-30)

    # Iterative enhancement: smooth then threshold
    enhanced = edge_mag.copy()
    for _ in range(n_iterations):
        enhanced = gaussian_filter(enhanced, sigma=sigma)
        # Keep only strong edges, enhance them
        enhanced = np.where(enhanced > edge_threshold, enhanced * 1.5, enhanced * 0.5)

    # Normalise to [0, 1]
    enhanced = enhanced / (np.max(enhanced) + 1e-30)
    return enhanced


# -----------------------------------------------------------------------
# Fault plane extraction
# -----------------------------------------------------------------------

@dataclass
class FaultPlane:
    """An extracted fault plane."""
    plane_id: int
    n_points: int
    normal: np.ndarray       # normal vector (3,)
    dip: float               # dip angle (radians)
    azimuth: float           # azimuth (radians)
    centroid: np.ndarray     # centroid (3,)


def extract_fault_planes(
    fault_result: FaultDetectionResult,
    min_points: int = 50,
) -> list[FaultPlane]:
    """Extract planar fault surfaces from labelled fault segments.

    For each fault segment, fit a plane (via SVD) to the voxel
    coordinates and compute dip and azimuth.

    Parameters
    ----------
    fault_result : FaultDetectionResult
        Output of ``detect_faults_coherence``.
    min_points : int
        Minimum points to fit a plane.

    Returns
    -------
    planes : list[FaultPlane]
    """
    planes = []
    for seg in fault_result.segments:
        if seg.n_voxels < min_points:
            continue
        ix, iy, iz = seg.indices
        points = np.column_stack([ix, iy, iz]).astype(float)
        # Fit plane via SVD: normal = last right singular vector
        centroid = points.mean(axis=0)
        centered = points - centroid
        try:
            _, _, vt = np.linalg.svd(centered, full_matrices=False)
            normal = vt[-1]
            # Ensure normal points upward (positive z)
            if normal[2] < 0:
                normal = -normal
            # Dip = angle from horizontal
            dip = np.arccos(np.abs(normal[2]))
            # Azimuth = angle of horizontal projection from x-axis
            horiz = normal[:2]
            if np.linalg.norm(horiz) > 1e-10:
                azimuth = np.arctan2(horiz[1], horiz[0])
            else:
                azimuth = 0.0
            planes.append(FaultPlane(
                plane_id=seg.segment_id,
                n_points=seg.n_voxels,
                normal=normal, dip=dip, azimuth=azimuth,
                centroid=centroid,
            ))
        except np.linalg.LinAlgError:
            continue
    return planes


# -----------------------------------------------------------------------
# Fault throw estimation
# -----------------------------------------------------------------------

def estimate_fault_throw(
    horizon: np.ndarray,
    fault_mask: np.ndarray,
) -> dict:
    """Estimate vertical throw across detected faults.

    For each fault, compares horizon picks on either side (left vs right)
    to estimate the vertical displacement (throw).

    Parameters
    ----------
    horizon : ndarray (nx, ny)
        Horizon surface (time/depth picks), NaN where not tracked.
    fault_mask : ndarray (nx, ny, nz) or (nx, ny)
        Fault mask (1 = fault). If 3-D, projected to 2-D.

    Returns
    -------
    dict
        {"mean_throw": float, "max_throw": float, "n_estimates": int}
    """
    h = np.asarray(horizon, dtype=float)
    if fault_mask.ndim == 3:
        fm = np.any(fault_mask > 0, axis=-1).astype(int)
    else:
        fm = np.asarray(fault_mask, dtype=int)

    nx, ny = h.shape
    throws = []

    for ix in range(1, nx - 1):
        for iy in range(ny):
            if fm[ix, iy] != 1:
                continue
            # Look left and right for valid horizon picks
            left_val = None
            right_val = None
            for dx in range(1, min(5, nx)):
                if ix - dx >= 0 and not np.isnan(h[ix - dx, iy]) and fm[ix - dx, iy] == 0:
                    left_val = h[ix - dx, iy]
                    break
            for dx in range(1, min(5, nx)):
                if ix + dx < nx and not np.isnan(h[ix + dx, iy]) and fm[ix + dx, iy] == 0:
                    right_val = h[ix + dx, iy]
                    break
            if left_val is not None and right_val is not None:
                throws.append(abs(right_val - left_val))

    if len(throws) == 0:
        return {"mean_throw": 0.0, "max_throw": 0.0, "n_estimates": 0}

    throws = np.array(throws)
    return {
        "mean_throw": float(np.mean(throws)),
        "max_throw": float(np.max(throws)),
        "n_estimates": len(throws),
    }
