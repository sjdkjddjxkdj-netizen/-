"""petroppo V22 — Horizon autotracking.

Implements automatic horizon tracking from 3-D seismic volumes:

* **Seed-based tracking** — given a seed pick (x, y, t), propagate the
  horizon to neighbouring traces by finding the best-correlated time
  window.  Uses normalised cross-correlation as the similarity measure.

* **Correlation-based propagation** — for each neighbour trace, search
  a time window around the current pick and select the time shift that
  maximises the cross-correlation with the reference trace.

* **Phase-based tracking** — uses instantaneous phase correlation
  (more robust to amplitude variations) as an alternative similarity
  measure.

* **Confidence map** — each tracked pick has an associated confidence
  value (the cross-correlation coefficient at the picked location),
  allowing quality control of the autotracked surface.

* **Multi-seed merging** — multiple seeds can be tracked independently
  and merged, with conflict resolution based on confidence.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from scipy.signal import hilbert

__all__ = [
    "HorizonSurface",
    "track_horizon",
    "track_horizon_multiseed",
    "auto_pick_horizon",
]


@dataclass
class HorizonSurface:
    """A tracked horizon surface.

    Attributes
    ----------
    times : ndarray (nx, ny)
        Picked two-way time (or sample index) for each trace.
        NaN where not tracked.
    confidence : ndarray (nx, ny)
        Cross-correlation confidence at each pick (0–1).
    nx, ny : int
        Grid dimensions.
    """
    times: np.ndarray
    confidence: np.ndarray
    nx: int
    ny: int

    @property
    def coverage(self) -> float:
        """Fraction of grid cells with a valid pick."""
        return float(np.sum(~np.isnan(self.times)) / (self.nx * self.ny))

    @property
    def mean_confidence(self) -> float:
        valid = self.confidence[~np.isnan(self.times)]
        return float(np.mean(valid)) if len(valid) > 0 else 0.0


def _ncc(a: np.ndarray, b: np.ndarray) -> float:
    """Normalised cross-correlation between two equal-length arrays."""
    na = np.dot(a, a)
    nb = np.dot(b, b)
    if na < 1e-30 or nb < 1e-30:
        return 0.0
    return float(np.dot(a, b) / np.sqrt(na * nb))


def _ncc_phase(a: np.ndarray, b: np.ndarray) -> float:
    """Phase-based correlation (correlation of instantaneous phases)."""
    if len(a) < 4:
        return _ncc(a, b)
    ha = hilbert(a)
    hb = hilbert(b)
    pa = np.angle(ha)
    pb = np.angle(hb)
    # circular correlation: use cos of phase difference
    return float(np.mean(np.cos(pa - pb)))


def track_horizon(
    seismic: np.ndarray,
    seed: tuple[int, int, int],
    window: int = 11,
    search: int = 5,
    min_confidence: float = 0.3,
    method: str = "correlation",
) -> HorizonSurface:
    """Track a horizon from a single seed pick.

    Propagates from the seed to all reachable traces using a BFS-like
    approach: for each picked trace, examine its 4-neighbours and
    find the best correlated time window within the search range.

    Parameters
    ----------
    seismic : ndarray (nx, ny, nz)
        3-D seismic volume.
    seed : (ix, iy, iz)
        Seed pick location (grid indices).
    window : int
        Correlation window half-length (samples).
    search : int
        Maximum time shift to search (samples).
    min_confidence : float
        Minimum correlation to accept a pick.
    method : str
        "correlation" (amplitude NCC) or "phase" (instantaneous phase).

    Returns
    -------
    HorizonSurface
    """
    se = np.asarray(seismic, dtype=float)
    nx, ny, nz = se.shape
    times = np.full((nx, ny), np.nan)
    confidence = np.zeros((nx, ny))

    ix0, iy0, iz0 = seed
    if not (0 <= ix0 < nx and 0 <= iy0 < ny and 0 <= iz0 < nz):
        raise ValueError("Seed out of bounds")

    times[ix0, iy0] = float(iz0)
    confidence[ix0, iy0] = 1.0

    sim_fn = _ncc if method == "correlation" else _ncc_phase

    # BFS propagation
    from collections import deque
    queue = deque([(ix0, iy0)])
    visited = set([(ix0, iy0)])

    while queue:
        ix, iy = queue.popleft()
        iz_ref = int(times[ix, iy])
        if np.isnan(iz_ref):
            continue
        iz_ref = int(iz_ref)

        # reference trace window
        z0 = max(iz_ref - window, 0)
        z1 = min(iz_ref + window + 1, nz)
        ref = se[ix, iy, z0:z1]
        ref_len = len(ref)

        # examine 4-neighbours
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx_, ny_ = ix + dx, iy + dy
            if not (0 <= nx_ < nx and 0 <= ny_ < ny):
                continue
            if (nx_, ny_) in visited:
                continue
            visited.add((nx_, ny_))

            # search for best time shift
            best_conf = -1.0
            best_iz = iz_ref

            for shift in range(-search, search + 1):
                iz_try = iz_ref + shift
                z0t = max(iz_try - window, 0)
                z1t = min(iz_try + window + 1, nz)
                if z1t - z0t != ref_len:
                    continue
                test = se[nx_, ny_, z0t:z1t]
                conf = sim_fn(ref, test)
                if conf > best_conf:
                    best_conf = conf
                    best_iz = iz_try

            if best_conf >= min_confidence:
                times[nx_, ny_] = float(best_iz)
                confidence[nx_, ny_] = best_conf
                queue.append((nx_, ny_))

    return HorizonSurface(times=times, confidence=confidence, nx=nx, ny=ny)


def track_horizon_multiseed(
    seismic: np.ndarray,
    seeds: list[tuple[int, int, int]],
    window: int = 11,
    search: int = 5,
    min_confidence: float = 0.3,
    method: str = "correlation",
) -> HorizonSurface:
    """Track a horizon from multiple seeds, merging by confidence.

    Each seed is tracked independently, and results are merged:
    at conflicting picks, the one with higher confidence wins.

    Parameters
    ----------
    seismic : ndarray (nx, ny, nz)
    seeds : list of (ix, iy, iz)
    window, search, min_confidence, method : see ``track_horizon``.

    Returns
    -------
    HorizonSurface
    """
    se = np.asarray(seismic, dtype=float)
    nx, ny, nz = se.shape
    times = np.full((nx, ny), np.nan)
    confidence = np.zeros((nx, ny))

    for seed in seeds:
        h = track_horizon(se, seed, window, search, min_confidence, method)
        # merge: higher confidence wins
        for i in range(nx):
            for j in range(ny):
                if np.isnan(h.times[i, j]):
                    continue
                if np.isnan(times[i, j]) or h.confidence[i, j] > confidence[i, j]:
                    times[i, j] = h.times[i, j]
                    confidence[i, j] = h.confidence[i, j]

    return HorizonSurface(times=times, confidence=confidence, nx=nx, ny=ny)


def auto_pick_horizon(
    seismic: np.ndarray,
    target_time: int,
    search: int = 20,
) -> HorizonSurface:
    """Auto-pick a horizon by finding the maximum amplitude near a target time.

    For each trace, finds the sample with maximum absolute amplitude
    within ±search samples of target_time.  This is the simplest
    horizon picking method (peak amplitude tracking).

    **V33**: Vectorised — no Python loops over traces.

    Parameters
    ----------
    seismic : ndarray (nx, ny, nz)
    target_time : int
        Approximate time (sample index) of the horizon.
    search : int
        Search range (samples).

    Returns
    -------
    HorizonSurface
    """
    se = np.asarray(seismic, dtype=float)
    nx, ny, nz = se.shape
    times = np.full((nx, ny), np.nan)
    confidence = np.zeros((nx, ny))

    z0 = max(target_time - search, 0)
    z1 = min(target_time + search + 1, nz)
    if z1 <= z0:
        return HorizonSurface(times=times, confidence=confidence, nx=nx, ny=ny)

    # Vectorised: extract search window for all traces at once
    window = np.abs(se[:, :, z0:z1])  # (nx, ny, z1-z0)
    peak_idx = np.argmax(window, axis=-1)  # (nx, ny)
    peak_val = np.max(window, axis=-1)     # (nx, ny)

    times = (peak_idx + z0).astype(float)
    confidence = peak_val.astype(float)

    return HorizonSurface(times=times, confidence=confidence, nx=nx, ny=ny)
