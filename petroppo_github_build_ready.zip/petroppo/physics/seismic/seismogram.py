"""petroppo V22 — Synthetic seismogram generation.

Implements the standard convolutional model of seismic trace generation:

    s(t) = r(t) * w(t) + n(t)

where:
    * r(t) — reflectivity series (from acoustic impedance contrasts)
    * w(t) — source wavelet (Ricker, Ormsby, or user-supplied)
    * n(t) — optional random noise

The acoustic impedance is Z = ρ · v (density × velocity), and the
normal-incidence reflection coefficient at an interface is:

    R = (Z₂ - Z₁) / (Z₂ + Z₁)

This module is the foundation of seismic interpretation: it provides
the forward model from earth properties to seismic data, enabling
verification of interpretation algorithms (horizon tracking, fault
detection, AVO) against known ground truth.

All functions are pure-numpy and fully deterministic for reproducibility.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.signal import fftconvolve

__all__ = [
    "ricker_wavelet",
    "ormsby_wavelet",
    "reflection_coefficients",
    "synthetic_seismogram",
    "Seismogram",
    "compute_impedance",
]


# -----------------------------------------------------------------------
# Wavelets
# -----------------------------------------------------------------------

def ricker_wavelet(
    n_samples: int,
    dt: float,
    freq: float,
    delay: Optional[float] = None,
) -> np.ndarray:
    """Ricker (Mexican-hat) wavelet.

    Parameters
    ----------
    n_samples : int
        Number of time samples.
    dt : float
        Sample interval (s).
    freq : float
        Central frequency (Hz).
    delay : float, optional
        Time delay of wavelet centre (s).  Defaults to n_samples*dt/2.

    Returns
    -------
    w : ndarray (n_samples,)
        Ricker wavelet, normalised so max amplitude = 1.
    """
    if delay is None:
        delay = n_samples * dt / 2.0
    t = np.arange(n_samples) * dt - delay
    p = (np.pi * freq * t) ** 2
    w = (1.0 - 2.0 * p) * np.exp(-p)
    return w


def ormsby_wavelet(
    n_samples: int,
    dt: float,
    f1: float = 5.0,
    f2: float = 10.0,
    f3: float = 40.0,
    f4: float = 60.0,
    delay: Optional[float] = None,
) -> np.ndarray:
    """Ormsby band-pass wavelet defined by four corner frequencies.

    The Ormsby wavelet has a trapezoidal frequency spectrum with
    cut slopes [f1–f2] (low-pass ramp) and [f3–f4] (high-pass ramp).

    Parameters
    ----------
    f1, f2, f3, f4 : float
        Corner frequencies (Hz), with f1 < f2 < f3 < f4.
    """
    if not (f1 < f2 < f3 < f4):
        raise ValueError("Ormsby requires f1 < f2 < f3 < f4")
    if delay is None:
        delay = n_samples * dt / 2.0
    t = np.arange(n_samples) * dt - delay
    # Ormsby time-domain expression
    def term(fa, fb):
        num = (np.sin(np.pi * fb * t)) ** 2 - (np.sin(np.pi * fa * t)) ** 2
        den = (np.pi ** 2) * (fb - fa) * t ** 2
        den = np.where(np.abs(t) < 1e-12, 1.0, den)
        num = np.where(np.abs(t) < 1e-12, fb - fa, num)
        return num / den
    w = (f4**2 / (f4 - f3)) * term(f3, f4) - (f3**2 / (f4 - f3)) * term(f3, f4) \
        - (f2**2 / (f2 - f1)) * term(f1, f2) + (f1**2 / (f2 - f1)) * term(f1, f2)
    w *= (np.pi**2) / (f4 - f1) ** 2
    w = np.nan_to_num(w, nan=0.0, posinf=0.0, neginf=0.0)
    return w / np.max(np.abs(w) + 1e-30)


# -----------------------------------------------------------------------
# Reflectivity & impedance
# -----------------------------------------------------------------------

def compute_impedance(velocity: np.ndarray, density: np.ndarray) -> np.ndarray:
    """Acoustic impedance Z = ρ · v.

    Parameters
    ----------
    velocity : ndarray
        P-wave velocity (m/s), any shape.
    density : ndarray
        Bulk density (kg/m³), same shape as velocity.

    Returns
    -------
    Z : ndarray
        Acoustic impedance (kg·m⁻²·s⁻¹), same shape.
    """
    v = np.asarray(velocity, dtype=float)
    rho = np.asarray(density, dtype=float)
    if v.shape != rho.shape:
        raise ValueError(f"velocity shape {v.shape} != density shape {rho.shape}")
    return rho * v


def reflection_coefficients(impedance: np.ndarray, axis: int = -1) -> np.ndarray:
    """Normal-incidence reflection coefficients from impedance.

    For a 1-D layered medium (axis=-1 is depth), the reflection
    coefficient at the i-th interface is:

        R_i = (Z[i+1] - Z[i]) / (Z[i+1] + Z[i])

    Parameters
    ----------
    impedance : ndarray
        Acoustic impedance, shape (..., n_layers).
    axis : int
        Axis along which interfaces are computed (default: last).

    Returns
    -------
    rc : ndarray
        Reflection coefficients, shape (..., n_layers - 1).
    """
    Z = np.asarray(impedance, dtype=float)
    Z1 = np.take(Z, range(0, Z.shape[axis] - 1), axis=axis)
    Z2 = np.take(Z, range(1, Z.shape[axis]), axis=axis)
    denom = Z1 + Z2
    # avoid division by zero
    denom = np.where(np.abs(denom) < 1e-30, 1e-30, denom)
    rc = (Z2 - Z1) / denom
    return rc


# -----------------------------------------------------------------------
# Convolutional model
# -----------------------------------------------------------------------

@dataclass
class Seismogram:
    """Container for a synthetic seismic trace or volume.

    Attributes
    ----------
    data : ndarray
        Seismic amplitudes, shape (..., n_samples).
    dt : float
        Sample interval (s).
    times : ndarray
        Time axis (s), shape (n_samples,).
    wavelet : ndarray
        Source wavelet used.
    reflectivity : ndarray
        Reflectivity series used.
    """

    data: np.ndarray
    dt: float
    times: np.ndarray
    wavelet: np.ndarray
    reflectivity: np.ndarray


def synthetic_seismogram(
    reflectivity: np.ndarray,
    dt: float,
    wavelet_freq: float = 30.0,
    wavelet_type: str = "ricker",
    n_wavelet: Optional[int] = None,
    noise_std: float = 0.0,
    rng: Optional[np.random.Generator] = None,
) -> Seismogram:
    """Generate a synthetic seismogram via the convolutional model.

    s(t) = r(t) * w(t) + n(t)

    Parameters
    ----------
    reflectivity : ndarray
        Reflectivity series, shape (..., n_layers). The last axis
        is convolved with the wavelet.
    dt : float
        Sample interval (s).
    wavelet_freq : float
        Central frequency of the wavelet (Hz).
    wavelet_type : str
        "ricker" or "ormsby".
    n_wavelet : int, optional
        Wavelet length in samples. Defaults to ~2.0/freq/dt (2 periods).
    noise_std : float
        Standard deviation of additive Gaussian noise (0 = no noise).
    rng : np.random.Generator, optional
        Random generator for reproducible noise.

    Returns
    -------
    Seismogram
    """
    r = np.asarray(reflectivity, dtype=float)
    n = r.shape[-1]
    times = np.arange(n) * dt

    if n_wavelet is None:
        n_wavelet = max(int(2.0 / (wavelet_freq * dt)), 21)
        if n_wavelet % 2 == 0:
            n_wavelet += 1

    if wavelet_type == "ricker":
        w = ricker_wavelet(n_wavelet, dt, wavelet_freq)
    elif wavelet_type == "ormsby":
        f2 = wavelet_freq * 0.3
        f1 = f2 * 0.5
        f3 = wavelet_freq * 1.3
        f4 = wavelet_freq * 2.0
        w = ormsby_wavelet(n_wavelet, dt, f1, f2, f3, f4)
    else:
        raise ValueError(f"Unknown wavelet type: {wavelet_type}")

    # Convolve along last axis
    if r.ndim == 1:
        trace = fftconvolve(r, w, mode="same")
    else:
        # reshape to 2-D, convolve each row
        shape = r.shape
        r2d = r.reshape(-1, n)
        traces = np.zeros_like(r2d)
        for i in range(r2d.shape[0]):
            traces[i] = fftconvolve(r2d[i], w, mode="same")
        trace = traces.reshape(shape)

    if noise_std > 0:
        if rng is None:
            rng = np.random.default_rng(42)
        trace = trace + rng.normal(0, noise_std, trace.shape)

    return Seismogram(
        data=trace, dt=dt, times=times,
        wavelet=w, reflectivity=r,
    )
