"""petroppo V20 — Uncertainty quantification.

Provides *linearised* (Gaussian approximation) uncertainty estimates for
inverse-problem solutions.  This closes V19 gap G10 (no uncertainty reporting
anywhere — V19 returned a single "best" model with no confidence bounds).

Given a converged model m* with Jacobian J = dF/dm|m* and data noise covariance
C_d = diag(σ_i²), the posterior model covariance is:

    C_m = (J^T C_d^{-1} J + R'')^{-1}

From C_m we derive:

* per-parameter standard deviation:  σ_m[i] = sqrt(C_m[i,i])
* 95% confidence intervals:          m[i] ± 1.96 σ_m[i]
* correlation matrix:                ρ_ij = C_m[i,j] / (σ_i σ_j)
* parameter resolution matrix:       R = C_m J^T C_d^{-1} J
* data resolution (resolution) matrix: S = J C_m J^T C_d^{-1}

These are the standard linearised quantities (Tarantola 2005; Aster et al.
2018).  They are valid near the optimum and require the Jacobian + Hessian,
both of which V20 now provides via physics.jacobian and physics.regularization.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.linalg import inv, solve

from .forward import ForwardModel
from .regularization import RegularizationOperator


@dataclass
class UncertaintyEstimate:
    """Linearised uncertainty at a model point."""
    covariance: np.ndarray          # (n_params, n_params)
    std_dev: np.ndarray             # (n_params,)
    ci_lower: np.ndarray            # (n_params,)  95% CI lower
    ci_upper: np.ndarray            # (n_params,)  95% CI upper
    correlation: np.ndarray         # (n_params, n_params)
    param_resolution: np.ndarray    # (n_params, n_params)  model resolution matrix
    data_resolution: np.ndarray     # (n_data, n_data)      data resolution matrix
    z_score: float = 1.96           # 95% two-sided

    def to_dict(self) -> dict:
        return {
            "std_dev": self.std_dev.tolist(),
            "ci_lower": self.ci_lower.tolist(),
            "ci_upper": self.ci_upper.tolist(),
            "z_score": self.z_score,
            "covariance_cond": float(np.linalg.cond(self.covariance)),
            "param_resolution_diag_mean": float(np.mean(np.diag(self.param_resolution))),
            "data_resolution_diag_mean": float(np.mean(np.diag(self.data_resolution))),
        }

    def summary(self) -> str:
        lines = [
            "UncertaintyEstimate (linearised, 95% CI)",
            f"  z-score             : {self.z_score}",
            f"  covariance cond     : {np.linalg.cond(self.covariance):.2e}",
            f"  param resolution    : mean diag = {np.mean(np.diag(self.param_resolution)):.4f} (1=fully resolved)",
            f"  data resolution     : mean diag = {np.mean(np.diag(self.data_resolution)):.4f}",
            f"  max parameter σ     : {self.std_dev.max():.4e}",
            f"  min parameter σ     : {self.std_dev.min():.4e}",
        ]
        return "\n".join(lines)


def linearized_uncertainty(forward: ForwardModel, model: np.ndarray,
                           data_std: np.ndarray,
                           reg: Optional[RegularizationOperator] = None,
                           jacobian: Optional[np.ndarray] = None,
                           confidence: float = 0.95) -> UncertaintyEstimate:
    """Compute linearised posterior uncertainty at *model*.

    Parameters
    ----------
    forward : ForwardModel
    model : np.ndarray
        The (converged) model at which to evaluate uncertainty.
    data_std : np.ndarray, shape (n_data,)
        Per-datum standard deviation of the data noise.
    reg : RegularizationOperator, optional
        If provided, its Hessian is added as prior information.
    jacobian : np.ndarray, optional
        Pre-computed Jacobian.  If None, uses forward.jacobian or FD.
    confidence : float
        Confidence level for the interval (default 0.95 → z=1.96).

    Returns
    -------
    UncertaintyEstimate
    """
    m = np.asarray(model, dtype=float)
    sigma = np.asarray(data_std, dtype=float)
    if sigma.shape[0] != forward.n_data:
        raise ValueError("data_std length must equal n_data")
    if jacobian is not None:
        J = np.asarray(jacobian, dtype=float)
    else:
        try:
            J = forward.jacobian(m)
        except NotImplementedError:
            from .jacobian import FiniteDifference
            J = FiniteDifference(forward)(m)
    Cd_inv = np.diag(1.0 / sigma ** 2)
    JtCdJ = J.T @ Cd_inv @ J
    R_hess = reg.hessian(m) if reg is not None else 0.0
    A = JtCdJ + R_hess
    # Posterior covariance
    try:
        Cm = inv(A)
    except np.linalg.LinAlgError:
        # Add Tikhonov stabilisation if singular
        Cm = inv(A + 1e-10 * np.eye(forward.n_params))
    std = np.sqrt(np.maximum(np.diag(Cm), 0.0))
    # z-score for confidence level
    from scipy.stats import norm
    z = norm.ppf(0.5 + confidence / 2.0)
    ci_lower = m - z * std
    ci_upper = m + z * std
    # Correlation matrix
    outer = np.outer(std, std)
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(outer > 0, Cm / outer, 0.0)
    np.fill_diagonal(corr, 1.0)
    # Resolution matrices
    # Param resolution: R_m = Cm J^T Cd^{-1} J
    Rm = Cm @ JtCdJ
    # Data resolution: S = J Cm J^T Cd^{-1}
    S = J @ Cm @ J.T @ Cd_inv
    return UncertaintyEstimate(
        covariance=Cm, std_dev=std, ci_lower=ci_lower, ci_upper=ci_upper,
        correlation=corr, param_resolution=Rm, data_resolution=S, z_score=float(z),
    )
