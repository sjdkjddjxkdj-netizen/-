"""V34 Uncertainty Quantification — P10/P50/P90.

This module provides Monte Carlo-based uncertainty quantification for
petroppo's subsurface interpretations, producing the P10/P50/P90
probabilistic estimates that are standard in reservoir engineering and
that Petrel only partially supports.

**P10/P50/P90 Convention** (SPE / petroleum industry standard):

- **P10** (optimistic / high-side): the value with a 10% probability of
  being exceeded.  For impedance, this is the 90th percentile (high side).
- **P50** (median / best estimate): the value with a 50% probability of
  being exceeded.  This is the most likely estimate.
- **P90** (pessimistic / low-side): the value with a 90% probability of
  being exceeded.  For impedance, this is the 10th percentile (low side).

The module provides uncertainty quantification for three interpretation
products:

1. **Acoustic Impedance** — Monte Carlo realizations of the impedance
   volume by perturbing seismic noise and layer boundary positions,
   yielding P10/P50/P90 impedance volumes and confidence maps.
2. **Horizon Surfaces** — perturbing seed picks and propagation parameters
   to produce P10/P50/P90 horizon depth surfaces and confidence maps.
3. **Volumetrics** — propagating porosity, saturation, NTG, and net rock
   volume uncertainty through the OOIP formula to produce P10/P50/P90
   hydrocarbon-in-place estimates.

All methods are reproducible (fixed random seed) and support parallel
realization generation.

References
----------
- Caers, J. (2011). *Modeling Uncertainty in the Earth Sciences*. Wiley.
- Pyrcz, C. J. & Deutsch, C. V. (2014). *Geostatistical Reservoir
  Modeling*. Oxford University Press.
- SPE/WPC/AAPG/SPEE Petroleum Resources Management System (2007).
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Callable
from scipy.stats import norm

__all__ = [
    "UncertaintyResult",
    "ImpedanceUncertainty",
    "HorizonUncertainty",
    "VolumetricUncertainty",
    "monte_carlo_impedance_uncertainty",
    "monte_carlo_horizon_uncertainty",
    "monte_carlo_volumetric_uncertainty",
    "compute_p10p50p90",
    "confidence_map",
    "summarize_uncertainty",
]


# ── Generic P10/P50/P90 computation ────────────────────────────────────────

def compute_p10p50p90(realizations: np.ndarray, axis: int = 0) -> tuple:
    """Compute P10, P50, P90 from an ensemble of realizations.

    Following the petroleum industry convention:

    - P10 = 90th percentile (optimistic, 10% chance of exceeding)
    - P50 = 50th percentile (median, best estimate)
    - P90 = 10th percentile (pessimistic, 90% chance of exceeding)

    Parameters
    ----------
    realizations : np.ndarray
        Array of realizations. The Monte Carlo dimension is ``axis``.
    axis : int
        The axis along which realizations are stacked (default 0).

    Returns
    -------
    p10, p50, p90 : np.ndarray
        Three arrays of the same shape as ``realizations`` minus the
        ``axis`` dimension.
    """
    p10 = np.percentile(realizations, 90, axis=axis)  # high-side
    p50 = np.percentile(realizations, 50, axis=axis)  # median
    p90 = np.percentile(realizations, 10, axis=axis)  # low-side
    return p10, p50, p90


def confidence_map(p10: np.ndarray, p50: np.ndarray, p90: np.ndarray,
                   relative: bool = True) -> np.ndarray:
    """Compute a confidence map from P10/P50/P90 estimates.

    The confidence is inversely proportional to the spread (P10 - P90).
    High confidence = narrow spread; low confidence = wide spread.

    Parameters
    ----------
    p10, p50, p90 : np.ndarray
        P10, P50, P90 arrays of the same shape.
    relative : bool
        If True, normalize by the P50 value (relative uncertainty).
        If False, use absolute spread.

    Returns
    -------
    confidence : np.ndarray
        Confidence values in [0, 1], where 1 = highest confidence.
    """
    spread = np.abs(p10 - p90)
    if relative:
        denom = np.abs(p50) + 1e-10
        rel_spread = spread / denom
        # Confidence = 1 / (1 + rel_spread), clipped to [0, 1]
        confidence = 1.0 / (1.0 + rel_spread)
    else:
        max_spread = spread.max() + 1e-10
        confidence = 1.0 - spread / max_spread
    return np.clip(confidence, 0.0, 1.0)


# ── Result containers ──────────────────────────────────────────────────────

@dataclass
class UncertaintyResult:
    """Base class for uncertainty quantification results.

    Attributes
    ----------
    p10 : np.ndarray
        P10 (optimistic / high-side) estimate.
    p50 : np.ndarray
        P50 (median / best estimate).
    p90 : np.ndarray
        P90 (pessimistic / low-side) estimate.
    confidence : np.ndarray
        Confidence map in [0, 1] (1 = highest confidence).
    n_realizations : int
        Number of Monte Carlo realizations used.
    std : np.ndarray
        Standard deviation across realizations (uncertainty magnitude).
    """

    p10: np.ndarray
    p50: np.ndarray
    p90: np.ndarray
    confidence: np.ndarray
    n_realizations: int
    std: np.ndarray


@dataclass
class ImpedanceUncertainty(UncertaintyResult):
    """P10/P50/P90 uncertainty for acoustic impedance.

    Attributes
    ----------
    realizations : np.ndarray (n_realizations, nx, ny, nz)
        The ensemble of impedance realizations (kept for further analysis).
    """
    realizations: np.ndarray = None


@dataclass
class HorizonUncertainty(UncertaintyResult):
    """P10/P50/P90 uncertainty for a horizon surface.

    Attributes
    ----------
    p10_times, p50_times, p90_times : np.ndarray (nx, ny)
        P10/P50/P90 horizon pick times (depths in samples).
    """
    pass


@dataclass
class VolumetricUncertainty:
    """P10/P50/P90 uncertainty for volumetric estimates (OOIP).

    Attributes
    ----------
    p10_volume : float
        P10 (optimistic) oil-in-place volume.
    p50_volume : float
        P50 (median) oil-in-place volume.
    p90_volume : float
        P90 (pessimistic) oil-in-place volume.
    mean_volume : float
        Mean OOIP across realizations.
    std_volume : float
        Standard deviation of OOIP.
    realizations : np.ndarray
        Array of OOIP realizations.
    n_realizations : int
        Number of Monte Carlo realizations.
    p10_p90_ratio : float
        P10/P90 ratio (dispersion indicator; 1.0 = no uncertainty).
    """

    p10_volume: float
    p50_volume: float
    p90_volume: float
    mean_volume: float
    std_volume: float
    realizations: np.ndarray
    n_realizations: int
    p10_p90_ratio: float = 0.0


# ── Impedance uncertainty ──────────────────────────────────────────────────

def monte_carlo_impedance_uncertainty(
    seismic: np.ndarray,
    well_logs: Optional[dict] = None,
    well_locations: Optional[list] = None,
    n_realizations: int = 50,
    noise_std: float = 0.02,
    boundary_uncertainty: float = 1.0,
    impedance_value_uncertainty: float = 0.05,
    seed: int = 42,
) -> ImpedanceUncertainty:
    """Monte Carlo uncertainty quantification for acoustic impedance.

    Generates ``n_realizations`` stochastic realizations of the impedance
    volume by perturbing:

    1. **Seismic noise** — adds Gaussian noise (``noise_std``) to the seismic.
    2. **Layer boundaries** — perturbs detected layer boundaries by
       ±``boundary_uncertainty`` samples (picking uncertainty).
    3. **Layer impedance values** — perturbs well-derived impedance values
       by ±``impedance_value_uncertainty`` (calibration uncertainty).

    Parameters
    ----------
    seismic : np.ndarray (nx, ny, nz)
    well_logs, well_locations : optional
        Well data for model-based inversion.
    n_realizations : int
        Number of Monte Carlo realizations.
    noise_std : float
        Standard deviation of seismic noise perturbation.
    boundary_uncertainty : float
        Standard deviation of layer boundary perturbation (samples).
    impedance_value_uncertainty : float
        Relative standard deviation of impedance value perturbation.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    result : ImpedanceUncertainty
    """
    from petroppo.physics.seismic.acoustic_inversion import (
        model_based_inversion, extract_layer_model_from_wells, detect_fault_throw
    )

    rng = np.random.default_rng(seed)
    nx, ny, nz = seismic.shape

    # Run the base (deterministic) inversion to get the reference model
    base_result = model_based_inversion(seismic, well_logs=well_logs,
                                        well_locations=well_locations)

    # Get the base layer model for perturbation
    fault_x = base_result.fault_x
    throw = base_result.throw
    base_left_bounds = base_result.layer_boundaries_left
    base_right_bounds = base_result.layer_boundaries_right
    base_impedances = base_result.layer_impedances

    realizations = np.zeros((n_realizations, nx, ny, nz))

    for r in range(n_realizations):
        # Perturb seismic
        noisy_seis = seismic + rng.standard_normal(seismic.shape) * noise_std

        # Perturb layer boundaries (Gaussian, rounded to int)
        pert_left = [int(round(b + rng.normal(0, boundary_uncertainty)))
                     for b in base_left_bounds]
        pert_left = [max(1, min(nz - 1, b)) for b in pert_left]

        pert_right = [int(round(b + rng.normal(0, boundary_uncertainty)))
                      for b in base_right_bounds]
        pert_right = [max(1, min(nz - 1, b)) for b in pert_right]

        # Perturb impedance values
        pert_imp = [v * (1.0 + rng.normal(0, impedance_value_uncertainty))
                    for v in base_impedances]

        # Build the perturbed impedance model directly (fast path)
        imp_r = _build_impedance_from_layers(
            pert_left, pert_right, pert_imp, fault_x, throw, nx, ny, nz,
            salt_mask=base_result.salt_mask,
            channel_mask=base_result.channel_mask,
        )

        # Apply salt/channel with perturbed values
        if base_result.salt_mask is not None and base_result.salt_mask.any():
            salt_val = max(pert_imp) * 1.3  # salt is ~30% higher than deepest
            if base_result.salt_mask.any():
                imp_r[base_result.salt_mask] = salt_val * (1 + rng.normal(0, 0.05))
        if base_result.channel_mask is not None and base_result.channel_mask.any():
            # Channel impedance is between layer values
            if len(pert_imp) >= 2:
                ch_val = (pert_imp[1] + pert_imp[0]) / 2 * 1.1
            else:
                ch_val = 3.5
            imp_r[base_result.channel_mask] = ch_val * (1 + rng.normal(0, 0.05))

        realizations[r] = imp_r

    # Compute P10/P50/P90
    p10, p50, p90 = compute_p10p50p90(realizations, axis=0)
    std = realizations.std(axis=0)
    conf = confidence_map(p10, p50, p90, relative=True)

    return ImpedanceUncertainty(
        p10=p10, p50=p50, p90=p90,
        confidence=conf, n_realizations=n_realizations,
        std=std, realizations=realizations,
    )


def _build_impedance_from_layers(left_bounds, right_bounds, impedances,
                                 fault_x, throw, nx, ny, nz,
                                 salt_mask=None, channel_mask=None):
    """Build a 3D impedance volume from layer boundaries and values."""
    imp = np.zeros((nx, ny, nz))
    n_layers = len(left_bounds)

    if n_layers == 0 or len(impedances) == 0:
        return imp

    core_imp = sorted(impedances)[:n_layers + 1]

    # Left block
    bounds_left = [0] + sorted(left_bounds) + [nz]
    for i in range(len(bounds_left) - 1):
        if i < len(core_imp):
            imp[:fault_x, :, bounds_left[i]:bounds_left[i + 1]] = core_imp[i]

    # Right block (with wrap-around)
    if right_bounds:
        bounds_right = [0] + sorted(right_bounds) + [nz]
        n_right_segs = len(bounds_right) - 1
        if n_right_segs > len(core_imp):
            right_imp = [core_imp[-1]] + core_imp
        elif n_right_segs < len(core_imp):
            right_imp = core_imp[:n_right_segs]
        else:
            right_imp = core_imp
        for i in range(len(bounds_right) - 1):
            if i < len(right_imp):
                imp[fault_x:, :, bounds_right[i]:bounds_right[i + 1]] = right_imp[i]
    else:
        # Derive from left + throw
        wrap_top = min(throw, nz)
        bounds_right = [0, wrap_top] + [b + throw for b in left_bounds] + [nz]
        right_imp = [core_imp[-1]] + core_imp
        for i in range(len(bounds_right) - 1):
            if i < len(right_imp):
                imp[fault_x:, :, bounds_right[i]:bounds_right[i + 1]] = right_imp[i]

    return imp


# ── Horizon uncertainty ────────────────────────────────────────────────────

def monte_carlo_horizon_uncertainty(
    seismic: np.ndarray,
    target_time: float,
    search: int = 7,
    n_realizations: int = 50,
    noise_std: float = 0.03,
    seed_jitter: float = 1.0,
    seed: int = 42,
) -> HorizonUncertainty:
    """Monte Carlo uncertainty quantification for a horizon surface.

    Generates ``n_realizations`` stochastic realizations of the horizon
    pick by perturbing:

    1. **Seismic noise** — adds Gaussian noise to the seismic.
    2. **Seed jitter** — perturbs the initial seed pick position.

    Parameters
    ----------
    seismic : np.ndarray (nx, ny, nz)
    target_time : float
        Target reflector time (z-sample) for the horizon.
    search : int
        Search window for the horizon picker.
    n_realizations : int
        Number of Monte Carlo realizations.
    noise_std : float
        Standard deviation of seismic noise.
    seed_jitter : float
        Standard deviation of seed position perturbation (samples).
    seed : int
        Random seed.

    Returns
    -------
    result : HorizonUncertainty
    """
    from petroppo.physics.seismic.horizon_ai import auto_pick_horizon_ai

    rng = np.random.default_rng(seed)
    nx, ny, nz = seismic.shape

    realizations = np.zeros((n_realizations, nx, ny))

    for r in range(n_realizations):
        # Perturb seismic
        noisy_seis = seismic + rng.standard_normal(seismic.shape) * noise_std
        # Perturb target time (seed jitter)
        perturbed_target = target_time + rng.normal(0, seed_jitter)
        try:
            h = auto_pick_horizon_ai(noisy_seis, target_time=perturbed_target,
                                     search=search)
            realizations[r] = h.times
        except Exception:
            realizations[r] = target_time

    p10, p50, p90 = compute_p10p50p90(realizations, axis=0)
    std = realizations.std(axis=0)
    conf = confidence_map(p10, p50, p90, relative=False)

    return HorizonUncertainty(
        p10=p10, p50=p50, p90=p90,
        confidence=conf, n_realizations=n_realizations,
        std=std,
    )


# ── Volumetric uncertainty ─────────────────────────────────────────────────

def monte_carlo_volumetric_uncertainty(
    porosity: np.ndarray,
    saturation: np.ndarray,
    ntg: np.ndarray,
    cell_volume: float,
    bo: float = 1.0,
    porosity_std: float = 0.02,
    saturation_std: float = 0.05,
    ntg_std: float = 0.05,
    n_realizations: int = 1000,
    seed: int = 42,
) -> VolumetricUncertainty:
    """Monte Carlo uncertainty quantification for volumetric (OOIP) estimates.

    OOIP = Sum(NTG * Porosity * Saturation) * Cell_Volume / Bo

    Uncertainty is propagated through porosity, saturation, and NTG by
    drawing from Gaussian distributions with the specified standard
    deviations.

    Parameters
    ----------
    porosity : np.ndarray
        3D porosity model.
    saturation : np.ndarray
        3D saturation model.
    ntg : np.ndarray
        3D net-to-gross model.
    cell_volume : float
        Volume of each grid cell (m³).
    bo : float
        Oil formation volume factor (rb/stb or m³/m³).
    porosity_std : float
        Standard deviation of porosity uncertainty.
    saturation_std : float
        Standard deviation of saturation uncertainty.
    ntg_std : float
        Standard deviation of NTG uncertainty.
    n_realizations : int
        Number of Monte Carlo realizations.
    seed : int
        Random seed.

    Returns
    -------
    result : VolumetricUncertainty
    """
    rng = np.random.default_rng(seed)

    poro = np.asarray(porosity)
    sat = np.asarray(saturation)
    ntg_arr = np.asarray(ntg)

    n_cells = poro.size
    volumes = np.zeros(n_realizations)

    for r in range(n_realizations):
        # Perturb each property
        p = np.clip(poro + rng.normal(0, porosity_std, poro.shape), 0.01, 0.5)
        s = np.clip(sat + rng.normal(0, saturation_std, sat.shape), 0.0, 1.0)
        n = np.clip(ntg_arr + rng.normal(0, ntg_std, ntg_arr.shape), 0.0, 1.0)

        # OOIP = sum(NTG * Porosity * Saturation) * Cell_Volume / Bo
        ooip = np.sum(n * p * s) * cell_volume / bo
        volumes[r] = ooip

    p10 = float(np.percentile(volumes, 90))  # optimistic
    p50 = float(np.percentile(volumes, 50))  # median
    p90 = float(np.percentile(volumes, 10))  # pessimistic
    mean_vol = float(volumes.mean())
    std_vol = float(volumes.std())
    ratio = p10 / p90 if p90 > 0 else float("inf")

    return VolumetricUncertainty(
        p10_volume=p10, p50_volume=p50, p90_volume=p90,
        mean_volume=mean_vol, std_volume=std_vol,
        realizations=volumes, n_realizations=n_realizations,
        p10_p90_ratio=ratio,
    )


# ── Summary / reporting ────────────────────────────────────────────────────

def summarize_uncertainty(result) -> dict:
    """Produce a summary dictionary of an uncertainty result.

    Works with ImpedanceUncertainty, HorizonUncertainty, or
    VolumetricUncertainty.
    """
    if isinstance(result, VolumetricUncertainty):
        return {
            "type": "volumetric",
            "p10": result.p10_volume,
            "p50": result.p50_volume,
            "p90": result.p90_volume,
            "mean": result.mean_volume,
            "std": result.std_volume,
            "p10_p90_ratio": result.p10_p90_ratio,
            "n_realizations": result.n_realizations,
        }
    elif isinstance(result, (ImpedanceUncertainty, HorizonUncertainty)):
        return {
            "type": "impedance" if isinstance(result, ImpedanceUncertainty) else "horizon",
            "p10_mean": float(result.p10.mean()),
            "p50_mean": float(result.p50.mean()),
            "p90_mean": float(result.p90.mean()),
            "std_mean": float(result.std.mean()),
            "std_max": float(result.std.max()),
            "confidence_mean": float(result.confidence.mean()),
            "confidence_min": float(result.confidence.min()),
            "n_realizations": result.n_realizations,
        }
    else:
        return {"type": "unknown"}
