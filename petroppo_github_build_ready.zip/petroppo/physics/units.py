"""petroppo V20 — Strict physical unit system.

Replaces the permissive ``core/units.py`` (14 units, trusts the caller) with a
dimensioned-quantity system that enforces dimensional consistency at runtime.

Design
------
* :class:`Quantity` — a value paired with a unit; arithmetic rejects
  category-mismatched operations via :class:`DimensionError`.
* :data:`UNITS` — ~40 units across 9 categories (length, resistivity,
  frequency, voltage, current, gravity, magnetic, velocity, pressure,
  permeability, density, temperature, viscosity, modulus).
* SI base enforcement: every unit declares its SI conversion factor and
  base-dimensional exponent vector, so ``a + b`` is only legal when the two
  quantities share the same base dimensions.

This closes V19 audit gap G1 (units system is permissive) and is the foundation
every other V20 physics module builds on.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Iterable, Tuple

__all__ = [
    "Quantity",
    "Unit",
    "DimensionError",
    "UNITS",
    "convert",
    "to_si",
    "register_unit",
    "format_value",
]


# ---------------------------------------------------------------------------
# Base dimensions (SI) — the 7 we actually use in geophysics / reservoir eng.
# Exponent vector order: [L, M, T, I, K, N, J]
#   L=length, M=mass, T=time, I=current, K=temperature, N=amount, J=luminous
# ---------------------------------------------------------------------------
_BASE_NAMES = ("L", "M", "T", "I", "K", "N", "J")
_DIM_ZERO: Tuple[int, ...] = (0, 0, 0, 0, 0, 0, 0)


class DimensionError(ValueError):
    """Raised when an operation is attempted on dimensionally incompatible
    quantities (e.g. adding meters to ohms)."""


@dataclass(frozen=True)
class Unit:
    """A physical unit with SI conversion and base-dimensional exponents."""

    name: str
    symbol: str
    category: str
    to_si: float                      # multiply a value in this unit by to_si → SI
    si_name: str
    # base-dimensional exponent vector [L, M, T, I, K, N, J]
    dims: Tuple[int, ...] = _DIM_ZERO

    @property
    def is_dimensionless(self) -> bool:
        return all(d == 0 for d in self.dims)


# Convenience constructors for common dimension vectors.
def _d(**kw) -> Tuple[int, ...]:
    v = list(_DIM_ZERO)
    for k, exp in kw.items():
        v[_BASE_NAMES.index(k)] = exp
    return tuple(v)


# ---------------------------------------------------------------------------
# Unit registry (~40 units, 9 categories)
# ---------------------------------------------------------------------------
UNITS: Dict[str, Unit] = {}


def register_unit(u: Unit) -> Unit:
    """Register a unit (idempotent on symbol)."""
    UNITS[u.symbol] = u
    return u


# --- length (L) ---
register_unit(Unit("meter", "m", "length", 1.0, "m", _d(L=1)))
register_unit(Unit("kilometer", "km", "length", 1000.0, "m", _d(L=1)))
register_unit(Unit("centimeter", "cm", "length", 0.01, "m", _d(L=1)))
register_unit(Unit("millimeter", "mm", "length", 0.001, "m", _d(L=1)))
register_unit(Unit("foot", "ft", "length", 0.3048, "m", _d(L=1)))
register_unit(Unit("inch", "in", "length", 0.0254, "m", _d(L=1)))
register_unit(Unit("mile", "mi", "length", 1609.344, "m", _d(L=1)))

# --- resistivity (L^3 M T^-3 I^-2 = ohm·m) ---
_RHO_DIM = _d(L=3, M=1, T=-3, I=-2)
register_unit(Unit("ohm-meter", "ohm.m", "resistivity", 1.0, "ohm.m", _RHO_DIM))
register_unit(Unit("kilohm-meter", "kohm.m", "resistivity", 1000.0, "ohm.m", _RHO_DIM))

# --- conductivity (I^2 T^3 L^-3 M^-1 = S/m) ---
_COND_DIM = _d(L=-3, M=-1, T=3, I=2)
register_unit(Unit("siemens-per-meter", "S/m", "conductivity", 1.0, "S/m", _COND_DIM))
register_unit(Unit("millisiemens-per-meter", "mS/m", "conductivity", 0.001, "S/m", _COND_DIM))

# --- frequency (T^-1) ---
_FREQ_DIM = _d(T=-1)
register_unit(Unit("hertz", "Hz", "frequency", 1.0, "Hz", _FREQ_DIM))
register_unit(Unit("kilohertz", "kHz", "frequency", 1000.0, "Hz", _FREQ_DIM))
register_unit(Unit("megahertz", "MHz", "frequency", 1.0e6, "Hz", _FREQ_DIM))

# --- time (T) ---
register_unit(Unit("second", "s", "time", 1.0, "s", _d(T=1)))
register_unit(Unit("millisecond", "ms", "time", 0.001, "s", _d(T=1)))
register_unit(Unit("microsecond", "us", "time", 1.0e-6, "s", _d(T=1)))
register_unit(Unit("minute", "min", "time", 60.0, "s", _d(T=1)))
register_unit(Unit("hour", "h", "time", 3600.0, "s", _d(T=1)))
register_unit(Unit("day", "d", "time", 86400.0, "s", _d(T=1)))

# --- voltage (L^2 M T^-3 I^-1 = V) ---
_V_DIM = _d(L=2, M=1, T=-3, I=-1)
register_unit(Unit("volt", "V", "voltage", 1.0, "V", _V_DIM))
register_unit(Unit("millivolt", "mV", "voltage", 0.001, "V", _V_DIM))
register_unit(Unit("microvolt", "uV", "voltage", 1.0e-6, "V", _V_DIM))

# --- current (I) ---
register_unit(Unit("ampere", "A", "current", 1.0, "A", _d(I=1)))
register_unit(Unit("milliampere", "mA", "current", 0.001, "A", _d(I=1)))

# --- acceleration / gravity (L T^-2) ---
_G_DIM = _d(L=1, T=-2)
register_unit(Unit("meter-per-second-squared", "m/s2", "gravity", 1.0, "m/s2", _G_DIM))
register_unit(Unit("milligal", "mGal", "gravity", 1.0e-5, "m/s2", _G_DIM))
register_unit(Unit("gal", "Gal", "gravity", 1.0e-2, "m/s2", _G_DIM))

# --- magnetic field (M T^-2 I^-1 = T) ---
_B_DIM = _d(M=1, T=-2, I=-1)
register_unit(Unit("tesla", "T", "magnetic", 1.0, "T", _B_DIM))
register_unit(Unit("nanotesla", "nT", "magnetic", 1.0e-9, "T", _B_DIM))
register_unit(Unit("gammas", "gamma", "magnetic", 1.0e-9, "T", _B_DIM))

# --- velocity (L T^-1) ---
_VEL_DIM = _d(L=1, T=-1)
register_unit(Unit("meter-per-second", "m/s", "velocity", 1.0, "m/s", _VEL_DIM))
register_unit(Unit("kilometer-per-second", "km/s", "velocity", 1000.0, "m/s", _VEL_DIM))
register_unit(Unit("foot-per-second", "ft/s", "velocity", 0.3048, "m/s", _VEL_DIM))

# --- pressure (L^-1 M T^-2 = Pa) ---
_P_DIM = _d(L=-1, M=1, T=-2)
register_unit(Unit("pascal", "Pa", "pressure", 1.0, "Pa", _P_DIM))
register_unit(Unit("kilopascal", "kPa", "pressure", 1.0e3, "Pa", _P_DIM))
register_unit(Unit("megapascal", "MPa", "pressure", 1.0e6, "Pa", _P_DIM))
register_unit(Unit("bar", "bar", "pressure", 1.0e5, "Pa", _P_DIM))
register_unit(Unit("psi", "psi", "pressure", 6894.757, "Pa", _P_DIM))

# --- permeability (L^2 = m^2; reservoir eng uses Darcy) ---
_PERM_DIM = _d(L=2)
register_unit(Unit("square-meter", "m2", "permeability", 1.0, "m2", _PERM_DIM))
register_unit(Unit("darcy", "D", "permeability", 9.869233e-13, "m2", _PERM_DIM))
register_unit(Unit("millidarcy", "mD", "permeability", 9.869233e-16, "m2", _PERM_DIM))

# --- density (L^-3 M) ---
_RHO_MASS_DIM = _d(L=-3, M=1)
register_unit(Unit("kilogram-per-cubic-meter", "kg/m3", "density", 1.0, "kg/m3", _RHO_MASS_DIM))
register_unit(Unit("gram-per-cubic-centimeter", "g/cm3", "density", 1000.0, "kg/m3", _RHO_MASS_DIM))

# --- temperature (K) ---
register_unit(Unit("kelvin", "K", "temperature", 1.0, "K", _d(K=1)))
register_unit(Unit("celsius", "C", "temperature", 1.0, "K", _d(K=1)))  # offset handled in Quantity

# --- dynamic viscosity (L^-1 M T^-1 = Pa·s) ---
_VISC_DIM = _d(L=-1, M=1, T=-1)
register_unit(Unit("pascal-second", "Pa.s", "viscosity", 1.0, "Pa.s", _VISC_DIM))
register_unit(Unit("centipoise", "cP", "viscosity", 1.0e-3, "Pa.s", _VISC_DIM))

# --- modulus / pressure (same dims as pressure) ---
register_unit(Unit("gigapascal", "GPa", "modulus", 1.0e9, "Pa", _P_DIM))

# --- dimensionless ---
register_unit(Unit("dimensionless", "", "dimensionless", 1.0, "", _DIM_ZERO))


# ---------------------------------------------------------------------------
# Quantity
# ---------------------------------------------------------------------------
@dataclass
class Quantity:
    """A dimensioned scalar (or array-shaped) value.

    Arithmetic is dimension-aware:
      * ``a + b`` / ``a - b`` require same base dimensions.
      * ``a * b`` / ``a / b`` combine dimensions.
      * Comparisons compare in SI.

    For temperature, Celsius is affine (offset 273.15); add/subtract handle the
    offset correctly for absolute conversions.
    """
    value: float
    unit: str

    def __post_init__(self) -> None:
        if self.unit not in UNITS:
            raise DimensionError(f"Unknown unit symbol: {self.unit!r}")

    # --- unit introspection ---
    @property
    def _u(self) -> Unit:
        return UNITS[self.unit]

    @property
    def dims(self) -> Tuple[int, ...]:
        return self._u.dims

    @property
    def si_value(self) -> float:
        v = self.value * self._u.to_si
        if self.unit == "C":
            v += 273.15
        return v

    def to(self, other: str) -> "Quantity":
        """Convert to another unit in the same category."""
        if other not in UNITS:
            raise DimensionError(f"Unknown unit: {other!r}")
        u_to = UNITS[other]
        if u_to.dims != self.dims:
            raise DimensionError(
                f"Cannot convert {self.unit} → {other}: different dimensions "
                f"{self.dims} vs {u_to.dims}")
        si = self.si_value
        if other == "C":
            return Quantity(si - 273.15, "C")
        return Quantity(si / u_to.to_si, other)

    # --- arithmetic ---
    def _check_same_dim(self, other: "Quantity", op: str) -> None:
        if self.dims != other.dims:
            raise DimensionError(
                f"Cannot {op} {self.unit} and {other.unit}: dimensions "
                f"{self.dims} vs {other.dims}")

    def __add__(self, other: "Quantity") -> "Quantity":
        self._check_same_dim(other, "add")
        return Quantity(self.si_value + other.si_value, self._u.si_name or self.unit)

    def __sub__(self, other: "Quantity") -> "Quantity":
        self._check_same_dim(other, "subtract")
        return Quantity(self.si_value - other.si_value, self._u.si_name or self.unit)

    def __mul__(self, other) -> "Quantity":
        if isinstance(other, Quantity):
            new_dims = tuple(a + b for a, b in zip(self.dims, other.dims))
            return Quantity(self.si_value * other.si_value,
                            _symbol_for_dims(new_dims))
        return Quantity(self.si_value * float(other), self._u.si_name or self.unit)

    __rmul__ = __mul__

    def __truediv__(self, other) -> "Quantity":
        if isinstance(other, Quantity):
            new_dims = tuple(a - b for a, b in zip(self.dims, other.dims))
            return Quantity(self.si_value / other.si_value,
                            _symbol_for_dims(new_dims))
        return Quantity(self.si_value / float(other), self._u.si_name or self.unit)

    def __eq__(self, other: object) -> bool:
        return (isinstance(other, Quantity) and self.dims == other.dims
                and math.isclose(self.si_value, other.si_value, rel_tol=1e-12, abs_tol=1e-15))

    def __repr__(self) -> str:
        return f"Quantity({self.value!r} {self.unit!r})"


def _symbol_for_dims(dims: Tuple[int, ...]) -> str:
    """Best-effort SI symbol for a derived dimension vector; '' if unknown."""
    for u in UNITS.values():
        if u.dims == dims and u.category in ("dimensionless",):
            continue
        if u.dims == dims:
            return u.si_name
    # derived: build a readable product string
    parts = []
    for name, exp in zip(_BASE_NAMES, dims):
        if exp == 1:
            parts.append(name)
        elif exp != 0:
            parts.append(f"{name}^{exp}")
    return "·".join(parts) if parts else ""


# ---------------------------------------------------------------------------
# Free functions (backward-compatible with V19 core/units.py)
# ---------------------------------------------------------------------------
def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert a scalar between two units in the same category."""
    return Quantity(value, from_unit).to(to_unit).value


def to_si(value: float, from_unit: str) -> float:
    """Return the SI-equivalent scalar."""
    return Quantity(value, from_unit).si_value


def format_value(value: float, unit: str, precision: int = 2) -> str:
    """Format a value with its unit symbol."""
    u = UNITS.get(unit)
    sym = u.symbol if u else unit
    return f"{value:.{precision}f} {sym}".strip()
