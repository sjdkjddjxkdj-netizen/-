"""Physics verification sub-package (V28 — Scientific Basis Upgrade).

Analytical benchmark library and convergence-order database for petroppo
solvers.  Every benchmark is verified against a closed-form analytical
solution; every convergence study checks the observed order against the
theoretical order expected from the discretisation scheme.

Modules
-------
* :mod:`benchmark_suite` — analytical benchmarks (steady-state 1-D,
  transient diffusion erfc, radial Theis/Thiem, linear inversion).
* :mod:`convergence_database` — convergence-order computation, records,
  database, and pre-built MMS / temporal studies.
"""

from __future__ import annotations

__all__ = []

# Lazy imports — keeps the package importable even if an optional
# dependency path changes, and avoids heavy simulator import at
# package-import time.
try:  # pragma: no cover - import guard
    from .benchmark_suite import (
        BenchmarkResult,
        BenchmarkSuite,
        SteadyState1D,
        TransientDiffusion1D,
        RadialSteadyState,
        LinearInversionBenchmark,
        run_benchmark,
        run_all_benchmarks,
    )
    __all__ += [
        "BenchmarkResult",
        "BenchmarkSuite",
        "SteadyState1D",
        "TransientDiffusion1D",
        "RadialSteadyState",
        "LinearInversionBenchmark",
        "run_benchmark",
        "run_all_benchmarks",
    ]
except Exception:  # pragma: no cover
    pass

try:  # pragma: no cover - import guard
    from .convergence_database import (
        compute_observed_order,
        ConvergenceRecord,
        ConvergenceDatabase,
        mms_diffusion_study,
        transient_time_study,
        verify_order,
    )
    __all__ += [
        "compute_observed_order",
        "ConvergenceRecord",
        "ConvergenceDatabase",
        "mms_diffusion_study",
        "transient_time_study",
        "verify_order",
    ]
except Exception:  # pragma: no cover
    pass
