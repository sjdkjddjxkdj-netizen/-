"""Convergence-order database for petroppo solvers (V28 — Scientific Basis).

Code verification requires not only that a solver matches an analytical
solution on one grid, but that the **error decreases at the expected rate**
as the grid is refined.  The observed convergence order ``p`` is computed
from the ratio of errors on successive grids::

    p = log(e₁ / e₂) / log(h₁ / h₂)

where ``h`` is the grid spacing and ``e`` the error norm.  Comparing the
observed order against the theoretical order (expected from the
discretisation scheme) is the definitive verification that the solver is
*implemented correctly* — not just calibrated to one answer.

This module provides:

* :func:`compute_observed_order` — compute ``p`` from error/spacing arrays.
* :class:`ConvergenceRecord` — one convergence study (solver, problem,
  resolutions, errors, observed & theoretical orders, pass/fail).
* :class:`ConvergenceDatabase` — collection of records with query and
  summary methods.
* :func:`mms_diffusion_study` — pre-built Method-of-Manufactured-Solutions
  spatial convergence study for the pressure-diffusion solver
  (2nd-order TPFA finite volume, expected ``p ≈ 2``).
* :func:`transient_time_study` — pre-built temporal convergence study
  for the implicit time integrator (1st-order backward Euler, expected
  ``p ≈ 1``).

References
----------
* Roache, P. J. (1998). *Verification of Codes and Calculations*,
  AIAA Journal, 36(5), 696–702.
* Salari & Knupp (2000). *Code Verification by the Method of
  Manufactured Solutions*, SAND2000-1444.
* Oberkampf & Roy (2010). *Verification and Validation in Scientific
  Computing*, Cambridge, ch. 5 (convergence order, observed order).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "compute_observed_order",
    "ConvergenceRecord",
    "ConvergenceDatabase",
    "mms_diffusion_study",
    "transient_time_study",
    "verify_order",
]


# --------------------------------------------------------------------------- #
# Core utility
# --------------------------------------------------------------------------- #
def compute_observed_order(errors: list[float], h: list[float]) -> list[float]:
    """Compute observed convergence order between successive grid levels.

    For each pair of consecutive refinements::

        p_i = log(e_i / e_{i+1}) / log(h_i / h_{i+1})

    Parameters
    ----------
    errors : list of float
        Error norms on each grid level (decreasing expected).
    h : list of float
        Grid spacing (or time step) on each level (decreasing expected).

    Returns
    -------
    list of float
        Observed order between each consecutive pair
        (length ``len(errors) - 1``).

    Raises
    ------
    ValueError
        If ``len(errors) != len(h)`` or fewer than 2 levels.
    """
    if len(errors) != len(h):
        raise ValueError("errors and h must have the same length")
    if len(errors) < 2:
        raise ValueError("need at least 2 grid levels to compute order")

    orders = []
    for i in range(len(errors) - 1):
        e1, e2 = float(errors[i]), float(errors[i + 1])
        h1, h2 = float(h[i]), float(h[i + 1])
        if e2 <= 0 or e1 <= 0:
            orders.append(float("nan"))
            continue
        if h2 <= 0 or h1 <= 0:
            orders.append(float("nan"))
            continue
        p = np.log(e1 / e2) / np.log(h1 / h2)
        orders.append(float(p))
    return orders


# --------------------------------------------------------------------------- #
# Record
# --------------------------------------------------------------------------- #
@dataclass
class ConvergenceRecord:
    """One convergence study for a solver on a benchmark problem.

    Attributes
    ----------
    solver : str
        Solver name.
    problem : str
        Benchmark / problem name.
    resolutions : list of int
        Grid resolution (number of cells) per level.
    h : list of float
        Grid spacing (or dt) per level.
    errors : list of float
        Error norm per level.
    observed_order : list of float
        Observed convergence order between consecutive levels.
    theoretical_order : float
        Expected order from the discretisation theory.
    tolerance : float
        Allowance: observed must be >= theoretical - tolerance to pass.
    passed : bool
        ``True`` if the minimum observed order meets the criterion and
        errors decrease monotonically.
    """

    solver: str
    problem: str
    resolutions: list = field(default_factory=list)
    h: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    observed_order: list = field(default_factory=list)
    theoretical_order: float = 2.0
    tolerance: float = 0.5
    passed: bool = False

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        flag = "PASS" if self.passed else "FAIL"
        return (
            f"ConvergenceRecord({self.solver}/{self.problem} [{flag}] "
            f"orders={self.observed_order}, theo={self.theoretical_order})"
        )


def verify_order(
    record: ConvergenceRecord,
) -> bool:
    """Check that a convergence record meets its order criterion.

    Passes if:
    * errors decrease monotonically (each e_{i+1} < e_i), and
    * the minimum observed order >= theoretical_order - tolerance.
    """
    errs = record.errors
    monotone = all(errs[i + 1] < errs[i] for i in range(len(errs) - 1))
    valid_orders = [
        o for o in record.observed_order if not np.isnan(o)
    ]
    if not valid_orders:
        return False
    min_order = min(valid_orders)
    criterion = record.theoretical_order - record.tolerance
    return bool(monotone and min_order >= criterion)


# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
class ConvergenceDatabase:
    """Collection of :class:`ConvergenceRecord` with query helpers.

    Parameters
    ----------
    records : list, optional
        Pre-populated records.
    """

    def __init__(self, records: Optional[list[ConvergenceRecord]] = None) -> None:
        self.records: list[ConvergenceRecord] = list(records) if records else []

    def add(self, record: ConvergenceRecord) -> None:
        """Add a convergence record (auto-verifies pass/fail)."""
        if not record.observed_order and record.errors:
            record.observed_order = compute_observed_order(record.errors, record.h)
        record.passed = verify_order(record)
        self.records.append(record)

    def get(self, solver: str, problem: Optional[str] = None) -> list[ConvergenceRecord]:
        """Query records by solver (and optionally problem)."""
        out = []
        for r in self.records:
            if r.solver == solver and (problem is None or r.problem == problem):
                out.append(r)
        return out

    def by_solver(self) -> dict[str, list[ConvergenceRecord]]:
        """Group records by solver name."""
        groups: dict[str, list[ConvergenceRecord]] = {}
        for r in self.records:
            groups.setdefault(r.solver, []).append(r)
        return groups

    @property
    def n_records(self) -> int:
        return len(self.records)

    @property
    def n_passed(self) -> int:
        return sum(1 for r in self.records if r.passed)

    @property
    def all_passed(self) -> bool:
        return len(self.records) > 0 and self.n_passed == len(self.records)

    def summary(self) -> str:
        """Human-readable summary."""
        lines = ["Convergence Database Summary", "=" * 50]
        for r in self.records:
            flag = "PASS" if r.passed else "FAIL"
            orders_str = ", ".join(f"{o:.2f}" for o in r.observed_order)
            lines.append(
                f"  {r.solver:25s} / {r.problem:20s} {flag}  "
                f"p=[{orders_str}] theo={r.theoretical_order:.1f}"
            )
        lines.append("-" * 50)
        lines.append(f"  Passed: {self.n_passed}/{self.n_records}")
        return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Pre-built study: MMS spatial convergence for pressure diffusion
# --------------------------------------------------------------------------- #
def mms_diffusion_study(
    grids: Optional[list[int]] = None,
) -> ConvergenceRecord:
    """Method-of-Manufactured-Solutions spatial convergence study.

    Manufactured solution: ``P(x, y) = A sin(πx/L) sin(πy/L)`` on the unit
    square.  The source term ``f = −k ∇²P = 2kAπ²/L² sin(πx/L) sin(πy/L)``
    is injected so that the exact ``P`` is a solution of the steady
    diffusion equation.  Boundary cells are pinned to the exact solution
    via strong BHP wells.

    The TPFA finite-volume discretisation is 2nd-order in space, so the
    observed order ``p`` should approach 2 as the grid is refined.

    Parameters
    ----------
    grids : list of int, optional
        Grid resolutions to test (default ``[10, 20, 40]``).

    Returns
    -------
    ConvergenceRecord
        Record with errors, observed orders, and pass/fail.
    """
    if grids is None:
        grids = [10, 20, 40]

    from petroppo.physics.reservoir.grid import cartesian_grid
    from petroppo.physics.reservoir.rock import RockProperties
    from petroppo.physics.reservoir.pvt import WaterFluid
    from petroppo.physics.reservoir.single_phase import SinglePhaseSimulator
    from petroppo.physics.reservoir.wells import InjectorWell

    errors = []
    hs = []
    A = 1.0
    L = 1.0
    k_val = 1.0

    for nx in grids:
        dx = L / nx
        g = cartesian_grid(nx, nx, 1, dx=dx, dy=dx, dz=1.0)
        k = np.full((nx, nx, 1), k_val)
        rock = RockProperties(
            porosity=np.full((nx, nx, 1), 0.1), permeability=k
        )
        fluid = WaterFluid(
            compressibility=1e-16, ref_viscosity=1.0,
            ref_density=1.0, ref_pressure=0.0,
        )
        centres = g.cell_centres()
        xx, yy = centres[:, :, 0, 0], centres[:, :, 0, 1]
        f = (
            2.0 * k_val * A * (np.pi / L) ** 2
            * np.sin(np.pi * xx / L) * np.sin(np.pi * yy / L)
        )
        vol = g.cell_volumes()[:, :, 0]
        source = (f * vol).ravel()
        # zero source on boundary
        for i in range(nx):
            for j in range(nx):
                if i == 0 or i == nx - 1 or j == 0 or j == nx - 1:
                    source[i + j * nx] = 0.0
        wells = []
        for i in range(nx):
            for j in range(nx):
                if i == 0 or i == nx - 1 or j == 0 or j == nx - 1:
                    xc, yc = centres[i, j, 0, 0], centres[i, j, 0, 1]
                    p_bc = A * np.sin(np.pi * xc / L) * np.sin(np.pi * yc / L)
                    w = InjectorWell(
                        name=f"bc_{i}_{j}", target=p_bc,
                        control="bhp", phase="water",
                    )
                    w.add_perforation(i, j, 0, k_val, dx, dx, 1.0)
                    w.perforations[0].well_index = 1e8
                    wells.append(w)
        sim = SinglePhaseSimulator(
            g, rock, fluid, wells=wells,
            initial_pressure=0.0, source_term=source,
        )
        report = sim.run(total_time=1.0, dt=0.1)
        p = report.states[-1].pressure.reshape(nx, nx)
        xxg, yyg = np.meshgrid(
            np.arange(nx) * dx + dx / 2,
            np.arange(nx) * dx + dx / 2,
            indexing="ij",
        )
        p_exact = A * np.sin(np.pi * xxg / L) * np.sin(np.pi * yyg / L)
        interior = slice(2, -2)
        err = float(
            np.max(np.abs(p[interior, interior] - p_exact[interior, interior]))
        )
        errors.append(err)
        hs.append(dx)

    orders = compute_observed_order(errors, hs)
    record = ConvergenceRecord(
        solver="SinglePhaseSimulator",
        problem="MMS_diffusion_2D",
        resolutions=list(grids),
        h=hs,
        errors=errors,
        observed_order=orders,
        theoretical_order=2.0,
        tolerance=0.5,
    )
    record.passed = verify_order(record)
    return record


# --------------------------------------------------------------------------- #
# Pre-built study: temporal convergence for the implicit time integrator
# --------------------------------------------------------------------------- #
def transient_time_study(
    dts: Optional[list[float]] = None,
) -> ConvergenceRecord:
    """Temporal convergence study for the backward-Euler integrator.

    We solve a 1-D transient diffusion problem on a *fine, fixed* spatial
    grid and vary only the time step ``dt``.  To isolate the **temporal**
    error (which would otherwise be swamped by the fixed spatial error),
    we use a **Richardson pairwise-difference** approach: for a sequence
    of halving time steps ``dt, dt/2, dt/4, ...`` we compute::

        diff_i = ‖p(dt_i) − p(dt_{i+1})‖₂

    If the temporal error scales as ``E(dt) ≈ C·dt^p`` (backward Euler:
    ``p = 1``), then the ratio of successive differences satisfies::

        diff_i / diff_{i+1} = (dt^p − (dt/2)^p) / ((dt/2)^p − (dt/4)^p)
                            = 2^p

    so the observed order ``p = log(diff_i / diff_{i+1}) / log(2)``.

    Parameters
    ----------
    dts : list of float, optional
        Time steps to test, in **decreasing** order (each ~half the
        previous).  Default ``[1e5, 5e4, 2.5e4, 1.25e4]`` — at least 4
        levels needed for 2 pairwise orders.

    Returns
    -------
    ConvergenceRecord
    """
    if dts is None:
        dts = [1e5, 5e4, 2.5e4, 1.25e4]

    from petroppo.physics.reservoir.grid import cartesian_grid
    from petroppo.physics.reservoir.rock import RockProperties
    from petroppo.physics.reservoir.pvt import WaterFluid
    from petroppo.physics.reservoir.single_phase import SinglePhaseSimulator
    from petroppo.physics.reservoir.wells import InjectorWell

    # fixed fine spatial grid (fine enough that spatial error << temporal)
    nx = 400
    L = 4000.0
    dx = L / nx
    k = 1e-13
    phi = 0.2
    ct = 1e-9
    mu = 1e-3
    p_init = 2.0e7
    dp = 5.0e6
    t_compare = 3e5  # compare at this fixed time

    def _solve(dt: float) -> np.ndarray:
        g = cartesian_grid(nx, 1, 1, dx=dx, dy=100.0, dz=20.0)
        k_arr = np.full((nx, 1, 1), k)
        rock = RockProperties(
            porosity=np.full((nx, 1, 1), phi), permeability=k_arr
        )
        fluid = WaterFluid(
            compressibility=ct, ref_viscosity=mu,
            ref_density=1000.0, ref_pressure=p_init,
        )
        inj = InjectorWell(
            name="BC", target=p_init + dp, control="bhp", phase="water"
        )
        inj.add_perforation(0, 0, 0, k, dx, 100.0, 20.0)
        sim = SinglePhaseSimulator(
            g, rock, fluid, wells=[inj], initial_pressure=p_init
        )
        report = sim.run(total_time=t_compare, dt=dt, save_every=1000000)
        return report.states[-1].pressure

    # solve at each dt (decreasing)
    solutions = [_solve(dt) for dt in dts]

    # pairwise L2 differences between successive levels
    diffs = []
    for i in range(len(solutions) - 1):
        d = float(np.sqrt(np.mean((solutions[i] - solutions[i + 1]) ** 2)))
        diffs.append(d)

    # observed order from ratio of successive diffs:
    # p = log(diff_i / diff_{i+1}) / log(dt_i / dt_{i+1})
    # for halving dt, log(2) in denominator
    observed_orders = []
    for i in range(len(diffs) - 1):
        if diffs[i + 1] <= 0 or diffs[i] <= 0:
            observed_orders.append(float("nan"))
            continue
        ratio = diffs[i] / diffs[i + 1]
        dt_ratio = dts[i] / dts[i + 1]
        p = np.log(ratio) / np.log(dt_ratio)
        observed_orders.append(float(p))

    # for the record, store the diffs as "errors" (they decrease) and
    # the mid-point dts as "h".  The pass criterion checks monotone
    # decrease and min order >= theoretical - tolerance.
    record = ConvergenceRecord(
        solver="SinglePhaseSimulator",
        problem="transient_temporal_Richardson",
        resolutions=[int(t_compare / dt) for dt in dts],
        h=list(dts),
        errors=diffs + [0.0],  # pad to match len(dts); last diff is ~0
        observed_order=observed_orders,
        theoretical_order=1.0,
        tolerance=0.4,
    )
    # custom pass check: diffs decrease and observed orders >= 0.6
    monotone = all(diffs[i] > diffs[i + 1] for i in range(len(diffs) - 1))
    valid = [o for o in observed_orders if not np.isnan(o)]
    order_ok = all(o >= 1.0 - 0.4 for o in valid) if valid else False
    record.passed = bool(monotone and order_ok and len(valid) >= 1)
    return record
