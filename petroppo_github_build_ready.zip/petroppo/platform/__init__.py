"""petroppo V39 -- Platform integration package.

``petroppo.platform`` is the Breadth / platform-integration layer that
turns the discipline-specific physics modules (seismic, geology, reservoir
modelling, reservoir simulation, inversion, QC) into a single, scriptable
subsurface platform.

Modules
-------
* :mod:`data_exchange`      -- SEG-Y, LAS 2.0, and ECLIPSE-deck readers/writers
* :mod:`case_management`   -- Case / Ensemble / CaseManager + uncertainty sampling
* :mod:`workflow`          -- integrated seismic -> geology -> reservoir -> simulation pipeline
* :mod:`viz3d_engine`      -- 3D volume ray-casting, marching-cubes isosurfaces, VTK export
* :mod:`performance`       -- chunked/out-of-core volumes, mmap I/O, parallel map, GPU stubs
* :mod:`memory`            -- V37 memory budget governor, TB-scale streaming volumes, LRU cache
* :mod:`distributed`       -- V37 task-graph executor, fault-tolerant retry, scaling benchmark
* :mod:`checkpoint`        -- V37 incremental checkpointing, crash recovery, resume-from-step
* :mod:`scheduler`         -- V37 fair-share job scheduler, quotas, backfill, SLA, spot handling
* :mod:`versioning`        -- V37 content-addressed project versioning, branching, diff, merge
* :mod:`provenance`        -- V37 W3C-PROV provenance capture, environment pinning, reproducible pipelines
* :mod:`collaboration`     -- multi-user project store, versioning, locking, branching
* :mod:`security`          -- RBAC, PBKDF2 password hashing, JWT tokens, AES-CTR encryption
* :mod:`cloud`             -- REST API server, cloud job executor, HPC SLURM/PBS stubs
* :mod:`diagnostics`       -- health checks, self-healing, error taxonomy, auto API docs
* :mod:`multi_tenancy`     -- V38 multi-tenant isolation, per-tenant quotas & keys, tenant-scoped RBAC
* :mod:`sso`               -- V38 enterprise SSO: SAML 2.0 / OIDC, JIT provisioning, group->role mapping
* :mod:`compliance`        -- V38 compliance & audit: hash-chained tamper-evident log, PII redaction, SOC2/ISO27001/GDPR reports
* :mod:`api_gateway`       -- V38 API gateway: rate limiting, versioning, routing, circuit breaker, API keys
* :mod:`ha`                -- V38 high availability: Raft leader election, health checks, failover, service registry, deployment templates
* :mod:`config`            -- V38 enterprise config: hierarchical sources, encrypted secret vault, schema validation, hot-reload
* :mod:`licensing`         -- V39 commercial licensing: HMAC-SHA256 signed keys, feature gating, usage tracking, license server
* :mod:`packaging`         -- V39 packaging & distribution: version comparison, wheel spec, pyproject.toml, health checks, deployment configurator, update manager
* :mod:`demo`              -- V39 customer demo & evaluation: guided walkthroughs, evaluation harness, comparison report, ROI calculator, quick-start guide
"""

from __future__ import annotations

__all__: list = []

for _mod in (
    "data_exchange",
    "case_management",
    "workflow",
    "viz3d_engine",
    "performance",
    "memory",
    "distributed",
    "checkpoint",
    "scheduler",
    "versioning",
    "provenance",
    "collaboration",
    "security",
    "cloud",
    "diagnostics",
    "multi_tenancy",
    "sso",
    "compliance",
    "api_gateway",
    "ha",
    "config",
    # V39 -- Proof & Commercial Edition
    "licensing",
    "packaging",
    "demo",
):
    try:
        __import__(f"{__name__}.{_mod}")
        __all__.append(_mod)
    except Exception:  # pragma: no cover
        pass
