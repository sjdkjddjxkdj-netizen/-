"""petroppo V38 — API Gateway.

Provides the API management infrastructure for enterprise deployments:

* **Rate limiting** — token-bucket algorithm with per-tenant and
  per-user limits.  Supports burst capacity and configurable refill
  rates.  Returns ``Retry-After`` header value on rejection.
* **API versioning** — version negotiation via URL path
  (``/v1/...``, ``/v2/...``) and ``Accept`` header.  Supports
  deprecation notices and sunset headers.
* **Request routing** — route requests to backend services based on
  path patterns.  Supports weighted load balancing across multiple
  backend instances.
* **Circuit breaker** — protects backend services from cascading
  failures.  Tracks success/failure rates per backend; opens the
  circuit after a configurable failure threshold; allows half-open
  probing to test recovery.
* **API key management** — issue, validate, revoke, and rotate API
  keys.  Keys are scoped to tenants and have configurable permissions.
* **Request/response logging** — logs all API calls with timing,
  status, and tenant context (integrates with the compliance audit log).

This is a pure-Python implementation using only the standard library
(``hashlib``, ``hmac``, ``time``, ``json``, ``dataclasses``).

References
----------
* Netflix (2012). *Hystrix: Circuit Breaker Pattern*.
* Nginx (2014). *Rate Limiting with Token Bucket*.
* RFC 8594 — *The Sunset HTTP Header Field*.
* Google AIP — *API Versioning Best Practices*.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Deque

__all__ = [
    "RateLimitExceeded",
    "CircuitOpenError",
    "APIKeyError",
    "CircuitState",
    "TokenBucket",
    "RateLimiter",
    "APIVersion",
    "VersionNegotiator",
    "BackendInstance",
    "CircuitBreaker",
    "RequestRouter",
    "APIKey",
    "APIKeyManager",
    "RequestLog",
    "RequestLogger",
    "APIGateway",
    "GatewayResponse",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class RateLimitExceeded(Exception):
    """Raised when a request exceeds the rate limit."""

    def __init__(self, message: str, retry_after: float = 0.0):
        super().__init__(message)
        self.retry_after = retry_after


class CircuitOpenError(Exception):
    """Raised when the circuit breaker is open."""


class APIKeyError(Exception):
    """Raised for API key validation failures."""


# ---------------------------------------------------------------------------
# Circuit breaker state
# ---------------------------------------------------------------------------

class CircuitState(str, Enum):
    CLOSED = "closed"       # Normal operation, requests pass through
    OPEN = "open"           # Failing, requests are rejected immediately
    HALF_OPEN = "half_open" # Testing if the backend has recovered


# ---------------------------------------------------------------------------
# Token bucket rate limiter
# ---------------------------------------------------------------------------

class TokenBucket:
    """A token-bucket rate limiter.

    Parameters
    ----------
    capacity : float
        Maximum number of tokens (burst capacity).
    refill_rate : float
        Tokens added per second (sustained rate).
    """

    def __init__(self, capacity: float, refill_rate: float):
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        if refill_rate <= 0:
            raise ValueError("refill_rate must be positive")
        self.capacity = float(capacity)
        self.refill_rate = float(refill_rate)
        self._tokens: float = float(capacity)
        self._last_refill: float = time.time()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self._last_refill
        if elapsed > 0:
            self._tokens = min(self.capacity, self._tokens + elapsed * self.refill_rate)
            self._last_refill = now

    def try_consume(self, tokens: float = 1.0) -> bool:
        """Try to consume tokens. Returns True if allowed, False if rate-limited."""
        self._refill()
        if self._tokens >= tokens:
            self._tokens -= tokens
            return True
        return False

    def consume_or_wait(self, tokens: float = 1.0) -> Tuple[bool, float]:
        """Try to consume tokens.

        Returns
        -------
        (allowed, retry_after)
            If allowed, retry_after=0.  If not, retry_after is the
            seconds to wait before enough tokens are available.
        """
        self._refill()
        if self._tokens >= tokens:
            self._tokens -= tokens
            return True, 0.0
        needed = tokens - self._tokens
        retry_after = needed / self.refill_rate
        return False, retry_after

    @property
    def available_tokens(self) -> float:
        """Current available tokens (after refill)."""
        self._refill()
        return self._tokens


class RateLimiter:
    """Multi-level rate limiter with per-tenant and per-user buckets.

    Parameters
    ----------
    tenant_capacity : float
        Burst capacity per tenant.
    tenant_refill_rate : float
        Sustained rate per tenant (tokens/sec).
    user_capacity : float
        Burst capacity per user.
    user_refill_rate : float
        Sustained rate per user (tokens/sec).
    """

    def __init__(
        self,
        tenant_capacity: float = 1000,
        tenant_refill_rate: float = 100,   # 100 req/sec sustained
        user_capacity: float = 100,
        user_refill_rate: float = 10,       # 10 req/sec sustained
    ):
        self.tenant_capacity = tenant_capacity
        self.tenant_refill_rate = tenant_refill_rate
        self.user_capacity = user_capacity
        self.user_refill_rate = user_refill_rate
        self._tenant_buckets: Dict[str, TokenBucket] = {}
        self._user_buckets: Dict[str, TokenBucket] = {}  # key = "tenant:user"

    def _get_tenant_bucket(self, tenant_id: str) -> TokenBucket:
        if tenant_id not in self._tenant_buckets:
            self._tenant_buckets[tenant_id] = TokenBucket(
                self.tenant_capacity, self.tenant_refill_rate
            )
        return self._tenant_buckets[tenant_id]

    def _get_user_bucket(self, tenant_id: str, user: str) -> TokenBucket:
        key = f"{tenant_id}:{user}"
        if key not in self._user_buckets:
            self._user_buckets[key] = TokenBucket(
                self.user_capacity, self.user_refill_rate
            )
        return self._user_buckets[key]

    def check(self, tenant_id: str, user: str, tokens: float = 1.0) -> Tuple[bool, float]:
        """Check if a request is allowed under both tenant and user limits.

        Returns
        -------
        (allowed, retry_after)
        """
        tenant_bucket = self._get_tenant_bucket(tenant_id)
        user_bucket = self._get_user_bucket(tenant_id, user)

        # Check tenant limit first
        t_ok, t_retry = tenant_bucket.consume_or_wait(tokens)
        if not t_ok:
            return False, t_retry

        # Check user limit
        u_ok, u_retry = user_bucket.consume_or_wait(tokens)
        if not u_ok:
            # Refund the tenant token since we're rejecting
            tenant_bucket._tokens += tokens
            return False, u_retry

        return True, 0.0

    def allow(self, tenant_id: str, user: str, tokens: float = 1.0) -> bool:
        """Boolean check: is the request allowed?"""
        allowed, _ = self.check(tenant_id, user, tokens)
        return allowed

    def set_tenant_limits(self, tenant_id: str, capacity: float, refill_rate: float) -> None:
        """Set custom rate limits for a specific tenant."""
        self._tenant_buckets[tenant_id] = TokenBucket(capacity, refill_rate)

    def stats(self) -> dict:
        """Return rate limiter statistics."""
        return {
            "tenant_buckets": len(self._tenant_buckets),
            "user_buckets": len(self._user_buckets),
            "tenant_capacity": self.tenant_capacity,
            "tenant_refill_rate": self.tenant_refill_rate,
            "user_capacity": self.user_capacity,
            "user_refill_rate": self.user_refill_rate,
        }


# ---------------------------------------------------------------------------
# API versioning
# ---------------------------------------------------------------------------

@dataclass
class APIVersion:
    """An API version definition.

    Parameters
    ----------
    version : str
        Version identifier (e.g., "v1", "v2").
    status : str
        "active", "deprecated", "sunset".
    deprecated_at : float, optional
        When the version was deprecated.
    sunset_at : float, optional
        When the version will be removed.
    """

    version: str
    status: str = "active"
    deprecated_at: Optional[float] = None
    sunset_at: Optional[float] = None
    description: str = ""

    @property
    def is_deprecated(self) -> bool:
        return self.status == "deprecated"

    @property
    def is_sunset(self) -> bool:
        return self.status == "sunset"

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "status": self.status,
            "deprecated_at": self.deprecated_at,
            "sunset_at": self.sunset_at,
            "description": self.description,
        }


class VersionNegotiator:
    """API version negotiation and management.

    Supports version selection via:
    1. URL path prefix: ``/api/v1/projects``
    2. Accept header: ``Accept: application/vnd.petroppo.v1+json``
    """

    def __init__(self):
        self._versions: Dict[str, APIVersion] = {}
        self._default_version: Optional[str] = None

    def register_version(
        self,
        version: str,
        status: str = "active",
        description: str = "",
        is_default: bool = False,
    ) -> APIVersion:
        """Register a new API version."""
        v = APIVersion(version=version, status=status, description=description)
        self._versions[version] = v
        if is_default or self._default_version is None:
            self._default_version = version
        return v

    def deprecate(self, version: str, sunset_at: Optional[float] = None) -> None:
        """Mark a version as deprecated."""
        v = self._versions.get(version)
        if v is None:
            raise ValueError(f"version '{version}' not registered")
        v.status = "deprecated"
        v.deprecated_at = time.time()
        if sunset_at:
            v.sunset_at = sunset_at

    def sunset(self, version: str) -> None:
        """Mark a version as sunset (to be removed)."""
        v = self._versions.get(version)
        if v is None:
            raise ValueError(f"version '{version}' not registered")
        v.status = "sunset"

    def negotiate(self, path: str = "", accept_header: str = "") -> Tuple[Optional[APIVersion], Optional[str]]:
        """Negotiate the API version from a request.

        Parameters
        ----------
        path : str
            Request path (e.g., "/api/v1/projects").
        accept_header : str
            Accept header value.

        Returns
        -------
        (version, deprecation_warning)
            The negotiated version (or None if not found) and a
            deprecation warning message if applicable.
        """
        version_str = None

        # Try URL path first
        if path:
            parts = path.strip("/").split("/")
            if len(parts) >= 2 and parts[0] == "api":
                candidate = parts[1]
                if candidate in self._versions:
                    version_str = candidate

        # Try Accept header
        if version_str is None and accept_header:
            # Parse: application/vnd.petroppo.v1+json
            import re
            match = re.search(r"vnd\.petroppo\.(\w+)\+", accept_header)
            if match:
                candidate = match.group(1)
                if candidate in self._versions:
                    version_str = candidate

        # Fall back to default
        if version_str is None:
            version_str = self._default_version

        if version_str is None:
            return None, None

        version = self._versions.get(version_str)
        warning = None
        if version and version.is_deprecated:
            sunset_info = ""
            if version.sunset_at:
                from datetime import datetime, timezone
                sunset_info = f" Sunset: {datetime.fromtimestamp(version.sunset_at, tz=timezone.utc).isoformat()}"
            warning = f"Deprecation: API version '{version.version}' is deprecated.{sunset_info}"

        return version, warning

    def list_versions(self) -> List[APIVersion]:
        """List all registered versions."""
        return list(self._versions.values())

    @property
    def default_version(self) -> Optional[str]:
        return self._default_version


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

@dataclass
class BackendInstance:
    """A backend service instance."""

    name: str
    url: str
    weight: int = 1
    healthy: bool = True
    last_check: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "url": self.url,
            "weight": self.weight,
            "healthy": self.healthy,
        }


class CircuitBreaker:
    """Circuit breaker for a single backend.

    Parameters
    ----------
    failure_threshold : int
        Number of consecutive failures before opening the circuit.
    recovery_timeout : float
        Seconds to wait before transitioning from OPEN to HALF_OPEN.
    success_threshold : int
        Consecutive successes in HALF_OPEN before closing the circuit.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        success_threshold: int = 3,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.success_threshold = success_threshold
        self._state: CircuitState = CircuitState.CLOSED
        self._failure_count: int = 0
        self._success_count: int = 0
        self._opened_at: float = 0.0
        self._total_requests: int = 0
        self._total_failures: int = 0
        self._total_successes: int = 0

    @property
    def state(self) -> CircuitState:
        """Current circuit state (with automatic OPEN→HALF_OPEN transition)."""
        if self._state == CircuitState.OPEN:
            if time.time() - self._opened_at >= self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                self._success_count = 0
        return self._state

    def can_execute(self) -> bool:
        """Check if a request can be sent through the circuit."""
        state = self.state
        return state in (CircuitState.CLOSED, CircuitState.HALF_OPEN)

    def record_success(self) -> None:
        """Record a successful request."""
        self._total_requests += 1
        self._total_successes += 1

        if self._state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.success_threshold:
                self._state = CircuitState.CLOSED
                self._failure_count = 0
        elif self._state == CircuitState.CLOSED:
            self._failure_count = 0  # Reset on success

    def record_failure(self) -> None:
        """Record a failed request."""
        self._total_requests += 1
        self._total_failures += 1
        self._failure_count += 1

        if self._state == CircuitState.HALF_OPEN:
            # Failure during half-open → re-open
            self._state = CircuitState.OPEN
            self._opened_at = time.time()
        elif self._state == CircuitState.CLOSED:
            if self._failure_count >= self.failure_threshold:
                self._state = CircuitState.OPEN
                self._opened_at = time.time()

    def reset(self) -> None:
        """Reset the circuit breaker to closed state."""
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0

    def stats(self) -> dict:
        return {
            "state": self.state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "total_requests": self._total_requests,
            "total_failures": self._total_failures,
            "total_successes": self._total_successes,
            "failure_rate": (self._total_failures / self._total_requests)
            if self._total_requests > 0 else 0.0,
        }


# ---------------------------------------------------------------------------
# Request router
# ---------------------------------------------------------------------------

class RequestRouter:
    """Routes requests to backend services with load balancing.

    Supports path-pattern-based routing and weighted round-robin
    load balancing across multiple backend instances.
    """

    def __init__(self):
        # route_id -> {pattern, backends, circuit_breakers, current_index}
        self._routes: Dict[str, dict] = {}

    def add_route(
        self,
        route_id: str,
        path_pattern: str,
        backends: List[BackendInstance],
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
    ) -> None:
        """Add a routing rule.

        Parameters
        ----------
        route_id : str
            Unique route identifier.
        path_pattern : str
            Regex pattern to match request paths.
        backends : list of BackendInstance
            Backend instances for this route.
        """
        import re
        self._routes[route_id] = {
            "pattern": re.compile(path_pattern),
            "backends": backends,
            "circuit_breakers": {
                b.name: CircuitBreaker(failure_threshold, recovery_timeout)
                for b in backends
            },
            "current_index": 0,
        }

    def match_route(self, path: str) -> Optional[str]:
        """Find the route that matches the given path."""
        for route_id, route in self._routes.items():
            if route["pattern"].search(path):
                return route_id
        return None

    def select_backend(self, route_id: str) -> Optional[BackendInstance]:
        """Select a healthy backend using weighted round-robin.

        Skips backends with open circuit breakers.
        """
        route = self._routes.get(route_id)
        if route is None:
            return None

        backends = route["backends"]
        breakers = route["circuit_breakers"]

        # Filter to backends with closed/half-open circuits
        available = [
            (i, b) for i, b in enumerate(backends)
            if breakers[b.name].can_execute()
        ]
        if not available:
            return None

        # Weighted selection
        total_weight = sum(b.weight for _, b in available)
        if total_weight <= 0:
            return available[0][1]

        # Round-robin with weight
        idx = route["current_index"] % len(available)
        selected = available[idx][1]
        route["current_index"] = (route["current_index"] + 1) % len(available)
        return selected

    def record_result(self, route_id: str, backend_name: str, success: bool) -> None:
        """Record the result of a request to a backend."""
        route = self._routes.get(route_id)
        if route is None:
            return
        breaker = route["circuit_breakers"].get(backend_name)
        if breaker is None:
            return
        if success:
            breaker.record_success()
        else:
            breaker.record_failure()

    def get_circuit_breaker(self, route_id: str, backend_name: str) -> Optional[CircuitBreaker]:
        """Get the circuit breaker for a specific backend."""
        route = self._routes.get(route_id)
        if route is None:
            return None
        return route["circuit_breakers"].get(backend_name)

    def list_routes(self) -> List[dict]:
        """List all routes with their backend and circuit states."""
        result = []
        for route_id, route in self._routes.items():
            backends_info = []
            for b in route["backends"]:
                cb = route["circuit_breakers"][b.name]
                backends_info.append({
                    "name": b.name,
                    "url": b.url,
                    "circuit_state": cb.state.value,
                    "circuit_stats": cb.stats(),
                })
            result.append({
                "route_id": route_id,
                "pattern": route["pattern"].pattern,
                "backends": backends_info,
            })
        return result


# ---------------------------------------------------------------------------
# API key management
# ---------------------------------------------------------------------------

@dataclass
class APIKey:
    """An API key for programmatic access."""

    key_id: str
    key_hash: str                    # SHA-256 hash of the actual key
    tenant_id: str
    user: str
    name: str
    scopes: List[str] = field(default_factory=list)  # e.g., ["read", "write"]
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None
    last_used: float = 0.0
    revoked: bool = False
    revoked_at: Optional[float] = None
    # We store the raw key only in memory for display (never persisted)
    _raw_key: str = ""

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    @property
    def is_active(self) -> bool:
        return not self.revoked and not self.is_expired

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes

    def to_dict(self, include_raw: bool = False) -> dict:
        d = {
            "key_id": self.key_id,
            "key_hash": self.key_hash[:16] + "...",
            "tenant_id": self.tenant_id,
            "user": self.user,
            "name": self.name,
            "scopes": list(self.scopes),
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "last_used": self.last_used,
            "revoked": self.revoked,
            "is_active": self.is_active,
        }
        if include_raw and self._raw_key:
            d["raw_key"] = self._raw_key
        return d


class APIKeyManager:
    """Manages API key lifecycle: issue, validate, revoke, rotate."""

    def __init__(self):
        self._keys: Dict[str, APIKey] = {}  # key_id -> APIKey
        self._hash_index: Dict[str, str] = {}  # key_hash -> key_id

    def issue(
        self,
        tenant_id: str,
        user: str,
        name: str,
        scopes: Optional[List[str]] = None,
        expires_at: Optional[float] = None,
    ) -> Tuple[APIKey, str]:
        """Issue a new API key.

        Returns
        -------
        (APIKey, raw_key)
            The key metadata and the raw key string (only shown once).
        """
        key_id = "key_" + secrets.token_hex(12)
        raw_key = "psk_" + secrets.token_hex(32)
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        api_key = APIKey(
            key_id=key_id,
            key_hash=key_hash,
            tenant_id=tenant_id,
            user=user,
            name=name,
            scopes=scopes or ["read"],
            expires_at=expires_at,
            _raw_key=raw_key,
        )
        self._keys[key_id] = api_key
        self._hash_index[key_hash] = key_id
        return api_key, raw_key

    def validate(self, raw_key: str) -> Optional[APIKey]:
        """Validate an API key. Returns the key if valid, None if invalid.

        Updates the last_used timestamp.
        """
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        key_id = self._hash_index.get(key_hash)
        if key_id is None:
            return None
        api_key = self._keys.get(key_id)
        if api_key is None or not api_key.is_active:
            return None
        api_key.last_used = time.time()
        return api_key

    def revoke(self, key_id: str) -> bool:
        """Revoke an API key."""
        api_key = self._keys.get(key_id)
        if api_key is None:
            return False
        api_key.revoked = True
        api_key.revoked_at = time.time()
        # Remove from hash index
        self._hash_index.pop(api_key.key_hash, None)
        return True

    def rotate(self, key_id: str) -> Tuple[APIKey, str]:
        """Rotate an API key (revoke old, issue new with same metadata).

        Returns
        -------
        (new_APIKey, new_raw_key)
        """
        old = self._keys.get(key_id)
        if old is None:
            raise APIKeyError(f"key '{key_id}' not found")

        # Revoke old
        self.revoke(key_id)

        # Issue new with same metadata
        new_key, raw_key = self.issue(
            tenant_id=old.tenant_id,
            user=old.user,
            name=old.name,
            scopes=old.scopes,
            expires_at=old.expires_at,
        )
        return new_key, raw_key

    def list_keys(self, tenant_id: Optional[str] = None) -> List[APIKey]:
        """List API keys, optionally filtered by tenant."""
        if tenant_id is None:
            return list(self._keys.values())
        return [k for k in self._keys.values() if k.tenant_id == tenant_id]

    def get_key(self, key_id: str) -> Optional[APIKey]:
        return self._keys.get(key_id)

    def check_scope(self, raw_key: str, required_scope: str) -> bool:
        """Check if a key has a required scope."""
        api_key = self.validate(raw_key)
        if api_key is None:
            return False
        return api_key.has_scope(required_scope)


# ---------------------------------------------------------------------------
# Request logging
# ---------------------------------------------------------------------------

@dataclass
class RequestLog:
    """A single API request log entry."""

    request_id: str
    timestamp: float
    method: str
    path: str
    tenant_id: str
    user: str
    status_code: int = 0
    response_time_ms: float = 0.0
    api_version: str = ""
    rate_limited: bool = False
    circuit_open: bool = False
    backend: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


from dataclasses import asdict


class RequestLogger:
    """Logs API requests for observability and compliance."""

    def __init__(self, max_entries: int = 10000):
        self._entries: Deque[RequestLog] = deque(maxlen=max_entries)
        self._request_counter: int = 0

    def log_request(self, log: RequestLog) -> None:
        self._entries.append(log)

    def query(
        self,
        tenant_id: Optional[str] = None,
        status_code: Optional[int] = None,
        path: Optional[str] = None,
        limit: int = 100,
    ) -> List[RequestLog]:
        """Query request logs."""
        results = []
        for entry in reversed(self._entries):
            if tenant_id and entry.tenant_id != tenant_id:
                continue
            if status_code and entry.status_code != status_code:
                continue
            if path and entry.path != path:
                continue
            results.append(entry)
            if len(results) >= limit:
                break
        return results

    def stats(self) -> dict:
        """Return aggregate request statistics."""
        total = len(self._entries)
        if total == 0:
            return {"total": 0}

        status_counts: Dict[int, int] = defaultdict(int)
        rate_limited_count = 0
        circuit_open_count = 0
        total_response_time = 0.0
        response_times: List[float] = []

        for e in self._entries:
            status_counts[e.status_code] += 1
            if e.rate_limited:
                rate_limited_count += 1
            if e.circuit_open:
                circuit_open_count += 1
            total_response_time += e.response_time_ms
            response_times.append(e.response_time_ms)

        avg_response_time = total_response_time / total if total else 0
        sorted_times = sorted(response_times)
        p50 = sorted_times[len(sorted_times) // 2] if sorted_times else 0
        p99 = sorted_times[int(len(sorted_times) * 0.99)] if sorted_times else 0

        return {
            "total": total,
            "status_codes": dict(status_counts),
            "rate_limited": rate_limited_count,
            "circuit_open": circuit_open_count,
            "avg_response_time_ms": round(avg_response_time, 2),
            "p50_response_time_ms": round(p50, 2),
            "p99_response_time_ms": round(p99, 2),
        }


# ---------------------------------------------------------------------------
# Gateway response
# ---------------------------------------------------------------------------

@dataclass
class GatewayResponse:
    """Response from the API gateway."""

    status_code: int
    body: Any = None
    headers: dict = field(default_factory=dict)
    error: str = ""

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300


# ---------------------------------------------------------------------------
# API Gateway (combines all components)
# ---------------------------------------------------------------------------

class APIGateway:
    """The complete API gateway combining rate limiting, versioning,
    routing, circuit breaking, API keys, and request logging.

    This is the main entry point for processing API requests.
    """

    def __init__(
        self,
        rate_limiter: Optional[RateLimiter] = None,
        version_negotiator: Optional[VersionNegotiator] = None,
        router: Optional[RequestRouter] = None,
        key_manager: Optional[APIKeyManager] = None,
        logger: Optional[RequestLogger] = None,
    ):
        self.rate_limiter = rate_limiter or RateLimiter()
        self.versions = version_negotiator or VersionNegotiator()
        self.router = router or RequestRouter()
        self.keys = key_manager or APIKeyManager()
        self.logger = logger or RequestLogger()
        self._request_counter = 0

    def process(
        self,
        method: str,
        path: str,
        tenant_id: str = "",
        user: str = "",
        api_key: Optional[str] = None,
        accept_header: str = "",
        backend_handler: Optional[Callable] = None,
    ) -> GatewayResponse:
        """Process an API request through the full gateway pipeline.

        Pipeline:
        1. API key validation (if provided)
        2. Rate limiting
        3. Version negotiation
        4. Route matching + backend selection (with circuit breaker)
        5. Request logging

        Parameters
        ----------
        backend_handler : callable, optional
            If provided, called as ``backend_handler(path, method)``
            to simulate the backend.  If None, returns 200 OK.

        Returns
        -------
        GatewayResponse
        """
        self._request_counter += 1
        request_id = f"req_{self._request_counter}"
        now = time.time()
        response = GatewayResponse(status_code=200)
        log_entry = RequestLog(
            request_id=request_id,
            timestamp=now,
            method=method,
            path=path,
            tenant_id=tenant_id,
            user=user,
        )

        # 1. API key validation
        if api_key:
            key = self.keys.validate(api_key)
            if key is None:
                response.status_code = 401
                response.error = "Invalid or revoked API key"
                log_entry.status_code = 401
                log_entry.error = response.error
                self.logger.log_request(log_entry)
                return response
            # Use key's tenant/user if not explicitly provided
            if not tenant_id:
                tenant_id = key.tenant_id
                log_entry.tenant_id = tenant_id
            if not user:
                user = key.user
                log_entry.user = user

        # 2. Rate limiting
        if tenant_id and user:
            allowed, retry_after = self.rate_limiter.check(tenant_id, user)
            if not allowed:
                response.status_code = 429
                response.error = "Rate limit exceeded"
                response.headers["Retry-After"] = str(int(retry_after) + 1)
                log_entry.status_code = 429
                log_entry.rate_limited = True
                log_entry.error = response.error
                self.logger.log_request(log_entry)
                return response

        # 3. Version negotiation
        version, deprecation_warning = self.versions.negotiate(path, accept_header)
        if version is None:
            response.status_code = 404
            response.error = "No matching API version"
            log_entry.status_code = 404
            log_entry.error = response.error
            self.logger.log_request(log_entry)
            return response
        log_entry.api_version = version.version
        if deprecation_warning:
            response.headers["Deprecation"] = "true"
            if version.sunset_at:
                response.headers["Sunset"] = str(version.sunset_at)

        if version.is_sunset:
            response.status_code = 410
            response.error = "API version has been sunset"
            log_entry.status_code = 410
            log_entry.error = response.error
            self.logger.log_request(log_entry)
            return response

        # 4. Route matching + circuit breaker
        route_id = self.router.match_route(path)
        if route_id is None:
            response.status_code = 404
            response.error = "No route matches the request path"
            log_entry.status_code = 404
            log_entry.error = response.error
            self.logger.log_request(log_entry)
            return response

        backend = self.router.select_backend(route_id)
        if backend is None:
            response.status_code = 503
            response.error = "All backends unavailable (circuit open)"
            log_entry.status_code = 503
            log_entry.circuit_open = True
            log_entry.error = response.error
            self.logger.log_request(log_entry)
            return response

        log_entry.backend = backend.name

        # 5. Execute backend (simulated or real)
        t0 = time.perf_counter()
        success = True
        try:
            if backend_handler:
                result = backend_handler(path, method)
                response.body = result
                response.status_code = 200
            else:
                response.status_code = 200
                response.body = {"status": "ok", "path": path}
        except Exception as e:
            success = False
            response.status_code = 500
            response.error = str(e)
            log_entry.error = str(e)

        elapsed_ms = (time.perf_counter() - t0) * 1000
        log_entry.response_time_ms = round(elapsed_ms, 2)
        log_entry.status_code = response.status_code

        # Record result with circuit breaker
        self.router.record_result(route_id, backend.name, success)

        # Log the request
        self.logger.log_request(log_entry)

        return response

    def stats(self) -> dict:
        """Return gateway-wide statistics."""
        return {
            "rate_limiter": self.rate_limiter.stats(),
            "request_logger": self.logger.stats(),
            "routes": self.router.list_routes(),
            "versions": [v.to_dict() for v in self.versions.list_versions()],
        }
