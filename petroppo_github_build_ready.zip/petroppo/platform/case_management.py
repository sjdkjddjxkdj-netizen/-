"""petroppo V29 -- Case management & uncertainty ensembles.

``petroppo.platform.case_management`` provides the orchestration layer that
turns a single model definition into a *campaign* of related runs:

* :class:`Case`        -- one deterministic model + simulation schedule.
* :class:`Ensemble`    -- a collection of Cases (e.g. a parameter sweep or a
                          Monte-Carlo uncertainty ensemble), built from a
                          base Case plus a list of perturbations.
* :class:`CaseManager` -- runs an Ensemble (or a single Case) in sequence,
                          collects the reports, and exposes summary
                          statistics (P10/P50/P90, mean, std) over any
                          scalar response extracted from a report.

It is deliberately simulator-agnostic: the user supplies a *factory* callable
that builds the simulator from a Case, and a *response* callable that turns a
report into a dict of scalar responses.  This keeps the manager usable with
the single-phase, black-oil, and fully-implicit simulators alike.

Example
-------

>>> from petroppo.platform.case_management import (
...     Case, Ensemble, CaseManager)
>>> base = Case(name='base', params={'perm': 100.0, 'poro': 0.2})
>>> def factory(case):
...     # build & run a simulator from case.params, return report
...     return {'recovery': case.params['perm'] * 0.01}
>>> ens = Ensemble.from_sweep(base, {'perm': [50.0, 100.0, 200.0]})
>>> mgr = CaseManager(factory, response=lambda r: r)
>>> results = mgr.run_ensemble(ens)
>>> stats = mgr.summary(results, 'recovery')
>>> stats['mean']
1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np

__all__ = [
    "Case",
    "Ensemble",
    "CaseResult",
    "CaseManager",
    "monte_carlo_perturbations",
    "latin_hypercube_samples",
]


@dataclass
class Case:
    """A single deterministic model + its parameter set + schedule."""

    name: str
    params: dict = field(default_factory=dict)
    schedule: dict = field(default_factory=dict)   # e.g. {'total_time':..., 'dt':...}
    metadata: dict = field(default_factory=dict)

    def with_params(self, **overrides) -> "Case":
        """Return a copy of this Case with overridden parameters."""
        new = Case(
            name=self.name,
            params={**self.params, **overrides},
            schedule=dict(self.schedule),
            metadata=dict(self.metadata),
        )
        return new


@dataclass
class CaseResult:
    """The outcome of running a single Case."""

    case: Case
    report: Any            # whatever the factory returned
    responses: dict = field(default_factory=dict)
    status: str = "ok"     # "ok" | "failed"
    error: Optional[str] = None


@dataclass
class Ensemble:
    """A collection of Cases forming a campaign."""

    name: str
    cases: list = field(default_factory=list)  # list[Case]

    def __len__(self) -> int:
        return len(self.cases)

    def __iter__(self):
        return iter(self.cases)

    @classmethod
    def from_sweep(cls, base: Case, sweep: dict,
                   naming: str = "{base}_{key}_{val}") -> "Ensemble":
        """Build an ensemble from a Cartesian parameter sweep.

        ``sweep`` maps a parameter name to a list of values.  Every combination
        is produced (Cartesian product).  Each case is named uniquely.
        """
        keys = list(sweep.keys())
        value_lists = [list(sweep[k]) for k in keys]
        if not keys:
            return cls(name=base.name, cases=[base])
        # cartesian product
        cases: list = []
        # use index-based recursion to build combos
        idx = [0] * len(keys)
        n = [len(v) for v in value_lists]
        total = int(np.prod(n)) if n else 1
        for _ in range(total):
            overrides = {keys[t]: value_lists[t][idx[t]] for t in range(len(keys))}
            name_parts = []
            for k, v in overrides.items():
                name_parts.append(f"{k}_{v}")
            nm = f"{base.name}_" + "_".join(name_parts) if name_parts else base.name
            cases.append(base.with_params(**overrides).rename(nm))
            # increment odometer
            t = len(keys) - 1
            while t >= 0:
                idx[t] += 1
                if idx[t] < n[t]:
                    break
                idx[t] = 0
                t -= 1
        return cls(name=base.name, cases=cases)

    @classmethod
    def from_perturbations(cls, base: Case,
                           perturbations: list,
                           prefix: str = "p") -> "Ensemble":
        """Build an ensemble from an explicit list of param-override dicts.

        Each entry of ``perturbations`` is a dict of parameter overrides; a
        new Case is created from ``base`` for each.
        """
        cases = []
        for i, ov in enumerate(perturbations):
            nm = ov.pop("__name__", f"{base.name}_{prefix}{i}")
            cases.append(base.with_params(**ov).rename(nm))
        return cls(name=base.name, cases=cases)


def _case_rename(self, name: str) -> "Case":
    self.name = name
    return self


Case.rename = _case_rename  # type: ignore[attr-defined]


# --------------------------------------------------------------------------- #
# Sampling helpers
# --------------------------------------------------------------------------- #

def monte_carlo_perturbations(base_params: dict, distributions: dict,
                              n: int, seed: Optional[int] = None) -> list:
    """Generate ``n`` perturbation dicts via Monte-Carlo sampling.

    ``distributions`` maps a parameter name to a tuple
    ``(kind, *args)`` where ``kind`` is one of:

    * ``('uniform', low, high)``
    * ``('normal', mean, std)``
    * ``('lognormal', mean, std)``  (mean/std of the *log*)

    A fixed ``seed`` makes the ensemble reproducible.
    """
    rng = np.random.default_rng(seed)
    out = []
    for i in range(n):
        ov = {}
        for key, spec in distributions.items():
            kind = spec[0]
            if kind == "uniform":
                _, low, high = spec
                ov[key] = float(rng.uniform(low, high))
            elif kind == "normal":
                _, mean, std = spec
                ov[key] = float(rng.normal(mean, std))
            elif kind == "lognormal":
                _, mean, std = spec
                ov[key] = float(np.exp(rng.normal(mean, std)))
            else:
                raise ValueError(f"unknown distribution kind {kind!r}")
        ov["__name__"] = f"mc{i}"
        out.append(ov)
    return out


def latin_hypercube_samples(n_params: int, n_samples: int,
                            seed: Optional[int] = None,
                            bounds: Optional[list] = None) -> np.ndarray:
    """Latin-hypercube sample in the unit (or given) hyper-cube.

    Returns an array of shape ``(n_samples, n_params)`` with values in
    ``[0, 1]`` (or scaled to ``bounds`` if provided, where ``bounds`` is a
    list of ``(low, high)`` tuples).
    """
    rng = np.random.default_rng(seed)
    result = np.empty((n_samples, n_params))
    for j in range(n_params):
        # stratify the unit interval into n_samples equal cells
        perm = rng.permutation(n_samples)
        # random position within each cell
        result[:, j] = (perm + rng.random(n_samples)) / n_samples
    if bounds is not None:
        for j, (low, high) in enumerate(bounds):
            result[:, j] = low + result[:, j] * (high - low)
    return result


# --------------------------------------------------------------------------- #
# Case manager
# --------------------------------------------------------------------------- #


@dataclass
class CaseManager:
    """Runs Cases / Ensembles and collects summary statistics.

    Parameters
    ----------
    factory : callable(Case) -> report
        Builds and runs the simulator for a Case, returning a report object.
    response : callable(report) -> dict[str, float]
        Extracts named scalar responses from a report.
    """

    factory: Callable[[Case], Any]
    response: Callable[[Any], dict] = field(
        default_factory=lambda: (lambda r: r if isinstance(r, dict) else {})
    )

    def run_case(self, case: Case) -> CaseResult:
        """Run a single Case, capturing any exception as a failed result."""
        try:
            report = self.factory(case)
            responses = self.response(report)
            if not isinstance(responses, dict):
                responses = {"value": float(responses)}
            return CaseResult(case=case, report=report, responses=responses,
                              status="ok")
        except Exception as exc:  # noqa: BLE001 - record, don't crash campaign
            return CaseResult(case=case, report=None, responses={},
                              status="failed", error=str(exc))

    def run_ensemble(self, ensemble: Ensemble) -> list:
        """Run every Case in an Ensemble, returning a list of CaseResult."""
        return [self.run_case(c) for c in ensemble]

    @staticmethod
    def summary(results: list, response_name: str) -> dict:
        """Compute summary statistics for one response across results.

        Only successful results are included.  Returns P10/P50/P90, mean,
        std, min, max, and the count of ok/failed runs.
        """
        vals = np.array(
            [r.responses[response_name] for r in results
             if r.status == "ok" and response_name in r.responses],
            dtype=float,
        )
        n_ok = int(vals.size)
        n_fail = sum(1 for r in results if r.status != "ok")
        if n_ok == 0:
            return {"p10": None, "p50": None, "p90": None,
                    "mean": None, "std": None, "min": None, "max": None,
                    "n_ok": 0, "n_fail": n_fail}
        return {
            "p10": float(np.percentile(vals, 10)),
            "p50": float(np.percentile(vals, 50)),
            "p90": float(np.percentile(vals, 90)),
            "mean": float(vals.mean()),
            "std": float(vals.std(ddof=0)),
            "min": float(vals.min()),
            "max": float(vals.max()),
            "n_ok": n_ok,
            "n_fail": n_fail,
        }

    @staticmethod
    def response_matrix(results: list) -> tuple:
        """Return (case_names, response_names, matrix) for analysis/plotting.

        ``matrix`` has shape (n_ok_cases, n_responses) and rows are aligned
        with the returned ``case_names``.
        """
        ok = [r for r in results if r.status == "ok" and r.responses]
        if not ok:
            return [], [], np.empty((0, 0))
        # union of response keys, sorted for determinism
        keys = sorted({k for r in ok for k in r.responses})
        names = [r.case.name for r in ok]
        mat = np.array([[float(r.responses.get(k, np.nan)) for k in keys]
                        for r in ok])
        return names, keys, mat
