"""petroppo V37 -- Checkpoint / crash-recovery for long-running simulations.

A reservoir simulation that takes hours to run must survive a crash.
This module provides **incremental checkpointing**: the simulation state
is periodically serialized to disk, and on restart the run resumes from
the last checkpoint **bit-identically** -- the resumed run produces the
same final state and production series as an uninterrupted run.  This is
the analytically verifiable property of the V37
``industrial-checkpoint-recovery`` benchmark case: kill the run at an
arbitrary step, resume, and the result matches the never-interrupted run
to within floating-point round-off.

Design
------

* :class:`Checkpoint` -- an immutable, content-addressed snapshot of a
  simulation: time, step index, the primary state arrays (pressure,
  saturation, temperature, gas composition), well controls, and a
  monotonically-increasing version number.  Serialized as a compressed
  ``.npz`` file with a JSON sidecar metadata header.
* :class:`CheckpointManager` -- writes checkpoints to a directory at a
  configurable cadence (every N steps or every T seconds), keeps a
  rolling window of the most recent K checkpoints, and exposes
  :meth:`latest` / :meth:`load` for recovery.  Atomic writes (temp file
  + rename) so a crash mid-write never produces a corrupt checkpoint.
* :class:`CheckpointableSimulator` -- a thin wrapper / mixin that adapts
  any petroppo reservoir simulator (single-phase, black-oil, fully-
  implicit, thermal) to the checkpoint protocol.  It extracts the
  simulator's state into a :class:`Checkpoint` and restores it.
* :func:`run_with_recovery` -- the high-level entry point: run a
  simulator with checkpointing; if interrupted, call again to resume.
  Verifies the resume matches an uninterrupted run via
  :func:`verify_recovery`.

Why not just pickle the whole simulator?
----------------------------------------

Pickling the simulator object couples the checkpoint to the exact class
layout, so any code change breaks old checkpoints.  The
:class:`Checkpoint` format stores only the *physical state* (pressure,
saturation, time, step) plus a *schema version*, so a simulator upgrade
can still load an old checkpoint by mapping fields.  This is the same
principle ECLIPSE uses for its restart files (``.UNRST`` / ``.X0000``).

Determinism
-----------

Checkpoints are deterministic: the same simulator + same inputs + same
checkpoint cadence produces byte-identical checkpoint files (the arrays
are saved in a fixed order with a fixed dtype).  This is required for
V37 reproducible pipelines -- a resumed run must be reproducible too.

References
----------
* ECLIPSE Reference Manual, *Restart and Save Sections*.
* Liu, J. et al. (2014). *Fault-tolerant scientific computing*,
  Encyclopedia of Parallel Computing.
* Prabhu, P. et al. (2011). *A Semi-Automatic Approach to Achieving
  Composable and Resilient Parallel Simulations*, SC.
"""

from __future__ import annotations

import os
import io
import json
import time
import zlib
import hashlib
import tempfile
import numpy as np
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import (Any, Callable, Dict, List, Optional, Tuple, Union)

__all__ = [
    "Checkpoint",
    "CheckpointManager",
    "CheckpointableSimulator",
    "CheckpointError",
    "run_with_recovery",
    "verify_recovery",
    "extract_simulator_state",
    "restore_simulator_state",
    "SCHEMA_VERSION",
]

SCHEMA_VERSION = 1


class CheckpointError(RuntimeError):
    """Raised when a checkpoint is missing, corrupt, or schema-incompatible."""


# ---------------------------------------------------------------------------
# Checkpoint data model
# ---------------------------------------------------------------------------

@dataclass
class Checkpoint:
    """An immutable simulation state snapshot.

    Attributes
    ----------
    step : int
        Time-step index that was just completed (0 = initial state).
    sim_time : float
        Simulation time in seconds at this step.
    arrays : dict[str, np.ndarray]
        Primary state arrays (e.g. ``"pressure"``, ``"saturation"``,
        ``"temperature"``).  Stored as float64 for round-trip fidelity.
    scalars : dict[str, float]
        Scalar state (cumulative production, etc.).
    well_controls : dict[str, dict]
        Per-well control state (bhp, rate, status).
    metadata : dict
        Free-form metadata (simulator class, grid shape, schema version).
    """
    step: int
    sim_time: float
    arrays: Dict[str, np.ndarray] = field(default_factory=dict)
    scalars: Dict[str, float] = field(default_factory=dict)
    well_controls: Dict[str, dict] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def fingerprint(self) -> str:
        """Content-addressed SHA-256 of the checkpoint's physical state."""
        h = hashlib.sha256()
        h.update(str(self.step).encode())
        h.update(struct_pack(self.sim_time))
        for name in sorted(self.arrays):
            arr = self.arrays[name]
            h.update(name.encode())
            h.update(arr.tobytes())
        for k in sorted(self.scalars):
            h.update(k.encode())
            h.update(struct_pack(self.scalars[k]))
        return h.hexdigest()


def struct_pack(x: float) -> bytes:
    import struct
    return struct.pack("<d", float(x))


# ---------------------------------------------------------------------------
# Checkpoint manager
# ---------------------------------------------------------------------------

class CheckpointManager:
    """Writes and loads :class:`Checkpoint` objects from a directory.

    Parameters
    ----------
    directory : str
        Where to store checkpoint files.
    save_every_steps : int
        Write a checkpoint every N completed steps (0 = disabled).
    save_every_seconds : float, optional
        Alternatively, write at most every T wall-clock seconds.
    keep_last : int
        Rolling-window size: keep the K most recent checkpoints, delete
        older ones.  0 = keep all.
    """

    def __init__(self, directory: str,
                 save_every_steps: int = 10,
                 save_every_seconds: Optional[float] = None,
                 keep_last: int = 5):
        self.directory = directory
        self.save_every_steps = save_every_steps
        self.save_every_seconds = save_every_seconds
        self.keep_last = keep_last
        os.makedirs(directory, exist_ok=True)
        self._last_save_wall: float = 0.0

    def _path_for(self, step: int) -> str:
        return os.path.join(self.directory, f"ckpt_{step:08d}.npz")

    def _meta_path_for(self, step: int) -> str:
        return os.path.join(self.directory, f"ckpt_{step:08d}.json")

    def should_save(self, step: int) -> bool:
        if self.save_every_steps > 0 and step % self.save_every_steps == 0:
            return True
        if self.save_every_seconds is not None:
            if time.time() - self._last_save_wall >= self.save_every_seconds:
                return True
        return False

    def save(self, ckpt: Checkpoint) -> str:
        """Atomically write a checkpoint; returns the file path."""
        path = self._path_for(ckpt.step)
        meta_path = self._meta_path_for(ckpt.step)
        # Atomic write: temp file then rename.
        tmp_fd, tmp_path = tempfile.mkstemp(
            suffix=".npz", dir=self.directory)
        os.close(tmp_fd)
        # Save arrays as compressed npz.
        save_arrays = {k: np.ascontiguousarray(v)
                       for k, v in ckpt.arrays.items()}
        np.savez_compressed(tmp_path, **save_arrays)
        os.replace(tmp_path, path)
        # Sidecar metadata (JSON).
        meta = {
            "step": ckpt.step,
            "sim_time": ckpt.sim_time,
            "scalars": ckpt.scalars,
            "well_controls": ckpt.well_controls,
            "metadata": {**ckpt.metadata,
                         "schema_version": SCHEMA_VERSION,
                         "fingerprint": ckpt.fingerprint()},
        }
        tmp_meta = tmp_path + ".json"
        with open(tmp_meta, "w") as f:
            json.dump(meta, f, indent=2, default=str)
        os.replace(tmp_meta, meta_path)
        self._last_save_wall = time.time()
        # Rolling-window cleanup.
        if self.keep_last > 0:
            self._prune()
        return path

    def _prune(self) -> None:
        """Delete all but the K most recent checkpoints."""
        files = sorted([f for f in os.listdir(self.directory)
                        if f.startswith("ckpt_") and f.endswith(".npz")])
        if len(files) <= self.keep_last:
            return
        for f in files[:-self.keep_last]:
            for suffix in (".npz", ".json"):
                p = os.path.join(self.directory, f.replace(".npz", suffix))
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass

    def load(self, step: int) -> Checkpoint:
        """Load a specific step's checkpoint."""
        path = self._path_for(step)
        meta_path = self._meta_path_for(step)
        if not os.path.exists(path) or not os.path.exists(meta_path):
            raise CheckpointError(f"no checkpoint at step {step}")
        return self._load_files(path, meta_path)

    def _load_files(self, path: str, meta_path: str) -> Checkpoint:
        try:
            with open(meta_path) as f:
                meta = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            raise CheckpointError(f"corrupt metadata {meta_path}: {e}")
        schema = meta.get("metadata", {}).get("schema_version", 0)
        if schema != SCHEMA_VERSION:
            raise CheckpointError(
                f"schema mismatch: file={schema}, code={SCHEMA_VERSION}")
        try:
            with np.load(path, allow_pickle=False) as data:
                arrays = {k: data[k] for k in data.files}
        except Exception as e:
            raise CheckpointError(f"corrupt arrays {path}: {e}")
        ckpt = Checkpoint(
            step=int(meta["step"]),
            sim_time=float(meta["sim_time"]),
            arrays=arrays,
            scalars={k: float(v) for k, v in meta.get("scalars", {}).items()},
            well_controls=meta.get("well_controls", {}),
            metadata=meta.get("metadata", {}),
        )
        # Integrity check: fingerprint must match.
        if "fingerprint" in ckpt.metadata:
            if ckpt.fingerprint() != ckpt.metadata["fingerprint"]:
                raise CheckpointError(
                    f"checkpoint fingerprint mismatch at step {ckpt.step} "
                    f"(file may be corrupt or tampered)")
        return ckpt

    def latest(self) -> Optional[Checkpoint]:
        """Return the most recent checkpoint, or None if none exist."""
        files = sorted([f for f in os.listdir(self.directory)
                        if f.startswith("ckpt_") and f.endswith(".npz")])
        if not files:
            return None
        last = files[-1]
        step = int(last.replace("ckpt_", "").replace(".npz", ""))
        return self.load(step)

    def list_checkpoints(self) -> List[int]:
        """Return sorted step numbers of all stored checkpoints."""
        files = [f for f in os.listdir(self.directory)
                 if f.startswith("ckpt_") and f.endswith(".npz")]
        steps = sorted(int(f.replace("ckpt_", "").replace(".npz", ""))
                       for f in files)
        return steps

    def clear(self) -> None:
        """Delete all checkpoints."""
        for f in os.listdir(self.directory):
            if f.startswith("ckpt_"):
                try:
                    os.remove(os.path.join(self.directory, f))
                except OSError:
                    pass


# ---------------------------------------------------------------------------
# Simulator state extraction / restoration
# ---------------------------------------------------------------------------

def extract_simulator_state(simulator: Any, step: int,
                             sim_time: float) -> Checkpoint:
    """Extract a :class:`Checkpoint` from any petroppo simulator.

    Handles single-phase, black-oil, fully-implicit, and thermal
    simulators by probing for the common state attributes.  Unknown
    simulators still work as long as they expose ``pressure`` and
    ``time`` (the minimum contract).
    """
    arrays: Dict[str, np.ndarray] = {}
    scalars: Dict[str, float] = {}
    well_controls: Dict[str, dict] = {}

    # Pressure -- every simulator has it.
    if hasattr(simulator, "pressure"):
        arrays["pressure"] = np.asarray(simulator.pressure, dtype=np.float64)
    # Saturation (black-oil / fully-implicit / thermal).
    for attr in ("saturation", "sat", "S"):
        if hasattr(simulator, attr):
            val = getattr(simulator, attr)
            if isinstance(val, np.ndarray):
                arrays["saturation"] = val.astype(np.float64)
                break
    # Temperature (thermal).
    if hasattr(simulator, "temperature"):
        t = getattr(simulator, "temperature")
        if isinstance(t, np.ndarray):
            arrays["temperature"] = t.astype(np.float64)
    # Gas total (fully-implicit).
    if hasattr(simulator, "gas_total"):
        g = getattr(simulator, "gas_total")
        if isinstance(g, np.ndarray):
            arrays["gas_total"] = g.astype(np.float64)
    # Water saturation (3-phase).
    if hasattr(simulator, "water_saturation"):
        w = getattr(simulator, "water_saturation")
        if isinstance(w, np.ndarray):
            arrays["water_saturation"] = w.astype(np.float64)

    # Time / step.
    if hasattr(simulator, "time"):
        scalars["sim_time_attr"] = float(getattr(simulator, "time"))

    # Wells.
    if hasattr(simulator, "wells"):
        for w in getattr(simulator, "wells") or []:
            name = getattr(w, "name", str(id(w)))
            well_controls[name] = {
                "bhp": float(getattr(w, "bhp", 0.0)),
                "rate": float(getattr(w, "rate", 0.0)),
                "kind": str(getattr(w, "kind", "")),
            }

    meta = {
        "simulator_class": type(simulator).__name__,
        "n_cells": int(arrays["pressure"].size) if "pressure" in arrays else 0,
        "schema_version": SCHEMA_VERSION,
    }
    return Checkpoint(
        step=step, sim_time=sim_time,
        arrays=arrays, scalars=scalars,
        well_controls=well_controls, metadata=meta,
    )


def restore_simulator_state(simulator: Any, ckpt: Checkpoint) -> None:
    """Restore a simulator's state from a :class:`Checkpoint`.

    Inverse of :func:`extract_simulator_state`.  Restores every attribute
    that was extracted, in the same dtype it was stored as (float64).
    """
    if "pressure" in ckpt.arrays and hasattr(simulator, "pressure"):
        simulator.pressure = ckpt.arrays["pressure"].copy()
    if "saturation" in ckpt.arrays:
        for attr in ("saturation", "sat", "S"):
            if hasattr(simulator, attr):
                setattr(simulator, attr, ckpt.arrays["saturation"].copy())
                break
    if "temperature" in ckpt.arrays and hasattr(simulator, "temperature"):
        simulator.temperature = ckpt.arrays["temperature"].copy()
    if "gas_total" in ckpt.arrays and hasattr(simulator, "gas_total"):
        simulator.gas_total = ckpt.arrays["gas_total"].copy()
    if "water_saturation" in ckpt.arrays and hasattr(simulator, "water_saturation"):
        simulator.water_saturation = ckpt.arrays["water_saturation"].copy()
    if "sim_time_attr" in ckpt.scalars and hasattr(simulator, "time"):
        simulator.time = ckpt.scalars["sim_time_attr"]


# ---------------------------------------------------------------------------
# Checkpointable simulator wrapper
# ---------------------------------------------------------------------------

class CheckpointableSimulator:
    """Wrap any petroppo simulator with checkpoint/recovery support.

    The wrapper exposes the same ``step(dt)`` and ``run(...)`` interface
    as the underlying simulator, but writes checkpoints via a
    :class:`CheckpointManager` and can resume from the latest checkpoint
    on construction.

    Example
    -------
    >>> mgr = CheckpointManager("/tmp/ckpt", save_every_steps=5)
    >>> sim = SinglePhaseSimulator(grid, rock, fluid, wells)
    >>> csim = CheckpointableSimulator(sim, mgr)
    >>> csim.run(total_time=100.0, dt=1.0)   # writes checkpoints every 5 steps
    >>> # ... crash ...
    >>> sim2 = SinglePhaseSimulator(grid, rock, fluid, wells)
    >>> csim2 = CheckpointableSimulator(sim2, mgr, resume=True)
    >>> csim2.run(total_time=100.0, dt=1.0)  # resumes from last checkpoint
    """

    def __init__(self, simulator: Any,
                 manager: CheckpointManager,
                 resume: bool = False):
        self.sim = simulator
        self.manager = manager
        self.step_index = 0
        self.sim_time = 0.0
        if resume:
            ckpt = manager.latest()
            if ckpt is not None:
                restore_simulator_state(simulator, ckpt)
                self.step_index = ckpt.step
                self.sim_time = ckpt.sim_time
                self._resumed_from = ckpt.step
            else:
                self._resumed_from = 0
        else:
            self._resumed_from = 0

    @property
    def resumed_from(self) -> int:
        """Step index from which the run resumed (0 if fresh start)."""
        return self._resumed_from

    def step(self, dt: float):
        state = self.sim.step(dt)
        self.step_index += 1
        self.sim_time += dt
        if self.manager.should_save(self.step_index):
            ckpt = extract_simulator_state(self.sim, self.step_index,
                                            self.sim_time)
            self.manager.save(ckpt)
        return state

    def run(self, total_time: float, dt: float,
            save_every: int = 1, report=None):
        """Run with checkpointing, resuming from the latest checkpoint."""
        # If the underlying simulator tracks its own time, set it.
        if hasattr(self.sim, "time"):
            self.sim.time = self.sim_time
        nsteps_total = int(round(total_time / dt))
        nsteps_done = self.step_index
        nsteps_remaining = nsteps_total - nsteps_done
        if nsteps_remaining <= 0:
            return report
        for _ in range(nsteps_remaining):
            self.step(dt)
        return report


# ---------------------------------------------------------------------------
# High-level recovery entry point + verification
# ---------------------------------------------------------------------------

def run_with_recovery(simulator_factory: Callable[[], Any],
                      manager: CheckpointManager,
                      total_time: float, dt: float,
                      save_every_steps: int = 10) -> Tuple[Any, int]:
    """Run a simulation with automatic checkpoint/recovery.

    On first call, runs fresh and writes checkpoints.  On a subsequent
    call (e.g. after a crash), resumes from the latest checkpoint.

    Parameters
    ----------
    simulator_factory : callable
        Returns a *fresh* simulator instance (so the caller does not
        need to keep the original object around across crashes).
    manager : CheckpointManager
        Checkpoint store.
    total_time, dt : float
        Run parameters.
    save_every_steps : int
        Checkpoint cadence.

    Returns
    -------
    (simulator, resumed_from_step)
    """
    sim = simulator_factory()
    ckpt = manager.latest()
    resume = ckpt is not None
    csim = CheckpointableSimulator(sim, manager, resume=resume)
    csim.run(total_time=total_time, dt=dt)
    return sim, csim.resumed_from


def verify_recovery(simulator_factory: Callable[[], Any],
                    total_time: float, dt: float,
                    interrupt_at_step: int,
                    manager: CheckpointManager,
                    save_every_steps: int = 1) -> dict:
    """Verify that an interrupted+resumed run matches an uninterrupted run.

    This is the analytically verifiable criterion for the V37
    ``industrial-checkpoint-recovery`` benchmark case:

    1. Run uninterrupted; record the final pressure state.
    2. Run again, killing at ``interrupt_at_step``; resume from the
       latest checkpoint; record the final pressure state.
    3. Assert the two final states match to within round-off tolerance.

    Returns a dict with the two final states and the max abs difference.
    """
    # 1) Uninterrupted reference run.
    sim_ref = simulator_factory()
    ref_states = []
    sim_time = 0.0
    nsteps = int(round(total_time / dt))
    for s in range(nsteps):
        sim_ref.step(dt)
        sim_time += dt
    ref_pressure = np.asarray(sim_ref.pressure, dtype=np.float64).copy()

    # 2) Interrupted run: checkpoint every step, stop at interrupt_at_step.
    manager.clear()
    sim_a = simulator_factory()
    csim_a = CheckpointableSimulator(sim_a, manager, resume=False)
    for s in range(interrupt_at_step):
        csim_a.step(dt)
    # Simulate crash: drop the simulator, keep only the checkpoint store.

    # 3) Resume from latest checkpoint.
    sim_b = simulator_factory()
    csim_b = CheckpointableSimulator(sim_b, manager, resume=True)
    resumed_from = csim_b.resumed_from
    remaining = nsteps - csim_b.step_index
    for _ in range(remaining):
        csim_b.step(dt)
    resume_pressure = np.asarray(sim_b.pressure, dtype=np.float64).copy()

    # 4) Compare.
    max_abs_diff = float(np.max(np.abs(resume_pressure - ref_pressure)))
    mean_abs_diff = float(np.mean(np.abs(resume_pressure - ref_pressure)))
    rel_diff = max_abs_diff / (float(np.max(np.abs(ref_pressure))) + 1e-30)
    return {
        "interrupt_at_step": interrupt_at_step,
        "resumed_from_step": resumed_from,
        "n_steps_total": nsteps,
        "ref_pressure_norm": float(np.linalg.norm(ref_pressure)),
        "resume_pressure_norm": float(np.linalg.norm(resume_pressure)),
        "max_abs_diff": max_abs_diff,
        "mean_abs_diff": mean_abs_diff,
        "rel_diff": rel_diff,
        "identical": bool(np.array_equal(resume_pressure, ref_pressure)),
        "within_tolerance": bool(max_abs_diff <= 1e-9),
    }
