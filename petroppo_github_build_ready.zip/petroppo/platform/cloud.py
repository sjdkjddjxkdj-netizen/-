"""petroppo V35 — Cloud, HPC & REST API layer.

Closes the cloud/HPC gap with Petrel's Schlumberger DELFI platform by
providing:

* :class:`CloudExecutor` — submit compute jobs to a local or remote
  executor (supports local, SLURM, PBS job schedulers via stubs).
* :class:`RESTServer` — a lightweight REST API server for remote
  execution of petroppo workflows (seismic, inversion, simulation).
  Built on the standard library ``http.server`` so no external deps are
  required (upgrade to FastAPI for production).
* :class:`CloudStorage` — S3-compatible object storage adapter for
  reading/writing seismic volumes and project artifacts to cloud storage.
* :class:`JobStatus` — track job lifecycle (queued, running, completed,
  failed).

The REST API exposes endpoints:
* ``GET  /health`` — health check
* ``GET  /api/v1/jobs`` — list jobs
* ``POST /api/v1/jobs`` — submit a job
* ``GET  /api/v1/jobs/{id}`` — job status
* ``GET  /api/v1/results/{id}`` — fetch results
* ``POST /api/v1/auth/login`` — authenticate (returns token)
"""

from __future__ import annotations

import os
import json
import time
import uuid
import threading
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Callable
from queue import Queue
from urllib.parse import urlparse, parse_qs

__all__ = [
    "JobStatus",
    "Job",
    "CloudExecutor",
    "RESTServer",
    "CloudStorage",
    "SLURMSubmitter",
    "PBSSubmitter",
    "SLURMJobArray",
    "DAGSubmitter",
    "validate_sbatch_script",
    "validate_pbs_script",
]


# ---------------------------------------------------------------------------
# Job model
# ---------------------------------------------------------------------------

class JobStatus:
    """Job lifecycle states."""
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Job:
    """A compute job."""
    id: str
    name: str
    command: str
    status: str = JobStatus.QUEUED
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return self.completed_at - self.started_at
        return None

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


# ---------------------------------------------------------------------------
# Cloud executor
# ---------------------------------------------------------------------------

class CloudExecutor:
    """Execute compute jobs locally or via HPC schedulers.

    Parameters
    ----------
    backend : str
        ``"local"`` (default), ``"slurm"``, or ``"pbs"``.
    max_workers : int
        Maximum concurrent local jobs.
    """

    def __init__(self, backend: str = "local", max_workers: int = 4):
        self.backend = backend
        self.max_workers = max_workers
        self._jobs: Dict[str, Job] = {}
        self._queue: Queue = Queue()
        self._lock = threading.Lock()
        self._workers: List[threading.Thread] = []
        self._running = False

    def start(self) -> None:
        """Start the worker pool."""
        self._running = True
        for _ in range(self.max_workers):
            t = threading.Thread(target=self._worker_loop, daemon=True)
            t.start()
            self._workers.append(t)

    def stop(self) -> None:
        """Stop the worker pool."""
        self._running = False
        for _ in self._workers:
            self._queue.put(None)
        for t in self._workers:
            t.join(timeout=5)

    def submit(self, name: str, fn: Callable, *args, **kwargs) -> Job:
        """Submit a Python callable as a job."""
        job = Job(id=str(uuid.uuid4()), name=name,
                  command=f"{fn.__name__}({args}, {kwargs})")
        with self._lock:
            self._jobs[job.id] = job
        self._queue.put((job, fn, args, kwargs))
        return job

    def submit_command(self, name: str, command: str) -> Job:
        """Submit a shell command as a job."""
        job = Job(id=str(uuid.uuid4()), name=name, command=command)
        with self._lock:
            self._jobs[job.id] = job
        self._queue.put((job, "shell", command, {}))
        return job

    def _worker_loop(self):
        while self._running:
            item = self._queue.get()
            if item is None:
                break
            job, fn, args, kwargs = item
            job.status = JobStatus.RUNNING
            job.started_at = time.time()
            try:
                if fn == "shell":
                    result = subprocess.run(
                        args[0], shell=True, capture_output=True, text=True,
                        timeout=300,
                    )
                    job.result = result.stdout
                    if result.returncode != 0:
                        job.error = result.stderr
                        job.status = JobStatus.FAILED
                    else:
                        job.status = JobStatus.COMPLETED
                else:
                    job.result = fn(*args, **kwargs)
                    job.status = JobStatus.COMPLETED
            except Exception as e:
                job.error = str(e)
                job.status = JobStatus.FAILED
            job.completed_at = time.time()

    def get_job(self, job_id: str) -> Optional[Job]:
        return self._jobs.get(job_id)

    def list_jobs(self) -> List[Job]:
        return list(self._jobs.values())

    def cancel(self, job_id: str) -> bool:
        job = self._jobs.get(job_id)
        if job and job.status == JobStatus.QUEUED:
            job.status = JobStatus.CANCELLED
            return True
        return False

    @property
    def stats(self) -> dict:
        jobs = list(self._jobs.values())
        return {
            "total": len(jobs),
            "queued": sum(1 for j in jobs if j.status == JobStatus.QUEUED),
            "running": sum(1 for j in jobs if j.status == JobStatus.RUNNING),
            "completed": sum(1 for j in jobs if j.status == JobStatus.COMPLETED),
            "failed": sum(1 for j in jobs if j.status == JobStatus.FAILED),
        }


# ---------------------------------------------------------------------------
# HPC job submitters (stubs)
# ---------------------------------------------------------------------------

class SLURMSubmitter:
    """SLURM job submission (generates sbatch scripts).

    In a real HPC environment, this would call ``sbatch``.  Here it
    generates the script and (optionally) submits it.
    """

    def __init__(self, partition: str = "normal", time_limit: str = "01:00:00",
                 nodes: int = 1, cpus_per_task: int = 4):
        self.partition = partition
        self.time_limit = time_limit
        self.nodes = nodes
        self.cpus_per_task = cpus_per_task

    def make_script(self, job_name: str, command: str,
                    output: str = "slurm_%j.out") -> str:
        return f"""#!/bin/bash
#SBATCH --job-name={job_name}
#SBATCH --partition={self.partition}
#SBATCH --time={self.time_limit}
#SBATCH --nodes={self.nodes}
#SBATCH --cpus-per-task={self.cpus_per_task}
#SBATCH --output={output}

module load python/3.11
{command}
"""

    def submit(self, job_name: str, command: str) -> str:
        """Submit a job (stub — returns a fake job ID)."""
        script = self.make_script(job_name, command)
        # In production: subprocess.run(["sbatch", script_path])
        return f"slurm-job-{uuid.uuid4().hex[:8]}"


class PBSSubmitter:
    """PBS/Torque job submission (stub)."""

    def __init__(self, queue: str = "normal", walltime: str = "01:00:00",
                 nodes: int = 1, ppn: int = 4):
        self.queue = queue
        self.walltime = walltime
        self.nodes = nodes
        self.ppn = ppn

    def make_script(self, job_name: str, command: str) -> str:
        return f"""#!/bin/bash
#PBS -N {job_name}
#PBS -q {self.queue}
#PBS -l walltime={self.walltime}
#PBS -l nodes={self.nodes}:ppn={self.ppn}

{command}
"""

    def submit(self, job_name: str, command: str) -> str:
        return f"pbs-job-{uuid.uuid4().hex[:8]}"


# ---------------------------------------------------------------------------
# V37 -- Industrial-scale HPC extensions: job arrays, DAG submission, dry-run
# ---------------------------------------------------------------------------

class SLURMJobArray:
    """Generate and (dry-run) submit a SLURM job array for ensembles.

    A 100-realization history-match ensemble becomes a single SLURM job
    array, which the scheduler allocates as one logical unit -- far more
    efficient than 100 separate ``sbatch`` calls.

    Parameters
    ----------
    submitter : SLURMSubmitter
        The base submitter (provides partition, time-limit, etc.).
    array_size : int
        Number of array tasks (e.g. 100 realizations).
    """

    def __init__(self, submitter: "SLURMSubmitter", array_size: int):
        self.submitter = submitter
        self.array_size = array_size

    def make_script(self, job_name: str, command: str,
                    output: str = "array_%A_%a.out") -> str:
        s = self.submitter
        return f"""#!/bin/bash
#SBATCH --job-name={job_name}
#SBATCH --partition={s.partition}
#SBATCH --time={s.time_limit}
#SBATCH --nodes={s.nodes}
#SBATCH --cpus-per-task={s.cpus_per_task}
#SBATCH --array=1-{self.array_size}
#SBATCH --output={output}

module load python/3.11
# SLURM_ARRAY_TASK_ID selects realization index
{command}
"""

    def submit(self, job_name: str, command: str) -> str:
        """Dry-run submit (returns synthetic array job ID)."""
        script = self.make_script(job_name, command)
        issues = validate_sbatch_script(script)
        if issues:
            raise ValueError(f"invalid sbatch script: {issues}")
        return f"slurm-array-{uuid.uuid4().hex[:8]}"


class DAGSubmitter:
    """Submit a DAG of jobs with SLURM ``--dependency=afterok`` chaining.

    Given an ordered list of (job_name, command, depends_on) tuples,
    generates one sbatch script per node, each depending on the
    successful completion of its predecessors.  This models the
    seismic -> inversion -> simulation -> history-match pipeline as a
    single resumable unit.
    """

    def __init__(self, submitter: "SLURMSubmitter"):
        self.submitter = submitter
        self._job_ids: Dict[str, str] = {}

    def submit_dag(self, nodes: List[Dict[str, Any]]) -> Dict[str, str]:
        """Submit a DAG.

        Parameters
        ----------
        nodes : list of dict
            Each dict has keys ``name``, ``command``, and ``depends_on``
            (list of predecessor node names).

        Returns
        -------
        dict mapping node name -> backend job ID.
        """
        ordered = self._topo_order(nodes)
        result: Dict[str, str] = {}
        for node in ordered:
            deps = [result[d] for d in node.get("depends_on", []) if d in result]
            script = self.submitter.make_script(node["name"], node["command"])
            if deps:
                dep_str = ":".join(deps)
                script = script.replace(
                    "#SBATCH --output=",
                    f"#SBATCH --dependency=afterok:{dep_str}\n#SBATCH --output=",
                )
            issues = validate_sbatch_script(script)
            if issues:
                raise ValueError(f"DAG node {node['name']} invalid: {issues}")
            jid = f"slurm-dag-{uuid.uuid4().hex[:8]}"
            result[node["name"]] = jid
            self._job_ids[node["name"]] = jid
        return result

    @staticmethod
    def _topo_order(nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Kahn topological sort of DAG nodes by depends_on."""
        by_name = {n["name"]: n for n in nodes}
        in_deg = {n["name"]: 0 for n in nodes}
        adj: Dict[str, List[str]] = {n["name"]: [] for n in nodes}
        for n in nodes:
            for d in n.get("depends_on", []):
                if d in by_name:
                    adj[d].append(n["name"])
                    in_deg[n["name"]] += 1
        queue = [nm for nm, dg in in_deg.items() if dg == 0]
        order: List[str] = []
        while queue:
            nm = queue.pop(0)
            order.append(nm)
            for child in adj[nm]:
                in_deg[child] -= 1
                if in_deg[child] == 0:
                    queue.append(child)
        if len(order) != len(nodes):
            raise ValueError("DAG has a cycle; cannot order")
        return [by_name[nm] for nm in order]


def validate_sbatch_script(script: str) -> List[str]:
    """Dry-run validation of a SLURM sbatch script.

    Checks structural integrity without a real SLURM installation.
    Returns a list of issue strings (empty = valid).
    """
    issues: List[str] = []
    lines = script.strip().splitlines()
    if not lines:
        return ["empty script"]
    if not lines[0].startswith("#!"):
        issues.append("missing shebang line")
    has_job_name = any("#SBATCH --job-name" in l for l in lines)
    has_partition = any("#SBATCH --partition" in l for l in lines)
    has_time = any("#SBATCH --time" in l for l in lines)
    has_cpus = any("#SBATCH --cpus-per-task" in l or "#SBATCH --ntasks" in l
                   for l in lines)
    if not has_job_name:
        issues.append("missing --job-name")
    if not has_partition:
        issues.append("missing --partition")
    if not has_time:
        issues.append("missing --time")
    if not has_cpus:
        issues.append("missing CPU allocation (--cpus-per-task or --ntasks)")
    for l in lines:
        if "--dependency=afterok:" in l:
            dep_part = l.split("afterok:")[1].strip()
            if not dep_part:
                issues.append("empty dependency list")
    body = [l for l in lines if not l.startswith("#") and l.strip()]
    if not body:
        issues.append("no command body (only SBATCH directives)")
    return issues


def validate_pbs_script(script: str) -> List[str]:
    """Dry-run validation of a PBS/Torque script."""
    issues: List[str] = []
    lines = script.strip().splitlines()
    if not lines:
        return ["empty script"]
    if not lines[0].startswith("#!"):
        issues.append("missing shebang line")
    if not any("#PBS -N" in l for l in lines):
        issues.append("missing #PBS -N (job name)")
    if not any("#PBS -q" in l for l in lines):
        issues.append("missing #PBS -q (queue)")
    if not any("walltime" in l for l in lines):
        issues.append("missing walltime")
    if not any("ppn" in l for l in lines):
        issues.append("missing ppn (processors per node)")
    body = [l for l in lines if not l.startswith("#") and l.strip()]
    if not body:
        issues.append("no command body")
    return issues


# ---------------------------------------------------------------------------
# Cloud storage (S3-compatible stub)
# ---------------------------------------------------------------------------

class CloudStorage:
    """S3-compatible object storage adapter (local filesystem stub).

    In production, replace with ``boto3`` for actual S3 / MinIO / Ceph.
    """

    def __init__(self, bucket: str = "petroppo", base_dir: str = "/tmp/petroppo_cloud"):
        self.bucket = bucket
        self.base_dir = os.path.join(base_dir, bucket)
        os.makedirs(self.base_dir, exist_ok=True)

    def put(self, key: str, data: bytes) -> None:
        path = os.path.join(self.base_dir, key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)

    def get(self, key: str) -> Optional[bytes]:
        path = os.path.join(self.base_dir, key)
        if not os.path.exists(path):
            return None
        with open(path, "rb") as f:
            return f.read()

    def delete(self, key: str) -> bool:
        path = os.path.join(self.base_dir, key)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    def list(self, prefix: str = "") -> List[str]:
        result = []
        for root, _, files in os.walk(self.base_dir):
            for f in files:
                rel = os.path.relpath(os.path.join(root, f), self.base_dir)
                if rel.startswith(prefix):
                    result.append(rel)
        return sorted(result)

    def size(self, key: str) -> int:
        path = os.path.join(self.base_dir, key)
        return os.path.getsize(path) if os.path.exists(path) else 0


# ---------------------------------------------------------------------------
# REST API server
# ---------------------------------------------------------------------------

class RESTServer:
    """Lightweight REST API server for remote petroppo execution.

    Parameters
    ----------
    executor : CloudExecutor
        The job executor to use.
    port : int
        TCP port to listen on.
    host : str
        Bind address.
    """

    def __init__(self, executor: Optional[CloudExecutor] = None,
                 port: int = 8080, host: str = "0.0.0.0"):
        self.executor = executor or CloudExecutor()
        self.port = port
        self.host = host
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> str:
        """Start the server in a background thread.  Returns the URL."""
        self.executor.start()
        handler = self._make_handler()
        self._server = HTTPServer((self.host, self.port), handler)
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True
        )
        self._thread.start()
        return f"http://{self.host}:{self.port}"

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()
        self.executor.stop()

    def _make_handler(self):
        executor = self.executor

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass  # suppress logs

            def _json(self, code, data):
                body = json.dumps(data, default=str).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                parsed = urlparse(self.path)
                path = parsed.path
                if path == "/health":
                    self._json(200, {"status": "ok",
                                     "time": time.time(),
                                     "stats": executor.stats})
                elif path == "/api/v1/jobs":
                    jobs = [j.to_dict() for j in executor.list_jobs()]
                    self._json(200, {"jobs": jobs, "stats": executor.stats})
                elif path.startswith("/api/v1/jobs/"):
                    jid = path.split("/")[-1]
                    job = executor.get_job(jid)
                    if job:
                        self._json(200, job.to_dict())
                    else:
                        self._json(404, {"error": "job not found"})
                elif path.startswith("/api/v1/results/"):
                    jid = path.split("/")[-1]
                    job = executor.get_job(jid)
                    if job and job.status == JobStatus.COMPLETED:
                        self._json(200, {"result": job.result})
                    elif job:
                        self._json(202, {"status": job.status})
                    else:
                        self._json(404, {"error": "job not found"})
                else:
                    self._json(404, {"error": "not found"})

            def do_POST(self):
                parsed = urlparse(self.path)
                path = parsed.path
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length) if length else b"{}"
                try:
                    data = json.loads(body)
                except json.JSONDecodeError:
                    self._json(400, {"error": "invalid JSON"})
                    return
                if path == "/api/v1/jobs":
                    name = data.get("name", "unnamed")
                    cmd = data.get("command", "")
                    job = executor.submit_command(name, cmd)
                    self._json(201, job.to_dict())
                elif path == "/api/v1/auth/login":
                    # Stub authentication
                    token = f"token-{uuid.uuid4().hex}"
                    self._json(200, {"token": token, "expires_in": 3600})
                else:
                    self._json(404, {"error": "not found"})

        return Handler

    @staticmethod
    def benchmark(n_jobs: int = 20) -> dict:
        """Benchmark job submission and execution."""
        executor = CloudExecutor(max_workers=4)
        executor.start()
        t0 = time.time()
        jobs = []
        for i in range(n_jobs):
            j = executor.submit(
                f"job_{i}", lambda x: x ** 2, i
            )
            jobs.append(j)
        # Wait for completion
        while all(j.status in (JobStatus.COMPLETED, JobStatus.FAILED)
                  for j in jobs) is False:
            time.sleep(0.01)
        dt = time.time() - t0
        executor.stop()
        completed = sum(1 for j in jobs if j.status == JobStatus.COMPLETED)
        return {
            "n_jobs": n_jobs,
            "total_time_s": dt,
            "jobs_per_s": n_jobs / dt if dt > 0 else 0,
            "completed": completed,
            "stats": executor.stats,
        }
