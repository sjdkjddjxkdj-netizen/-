"""petroppo V38 — Compliance & Audit (SOC2 / ISO27001 / GDPR).

Provides the audit-trail and compliance infrastructure required for
enterprise deployments in regulated industries (oil & gas, finance,
government):

* **Hash-chained audit trail** — every audit entry includes a SHA-256
  hash of the previous entry, forming a tamper-evident chain.  Any
  modification or deletion of a past entry breaks the chain and is
  immediately detectable.
* **Append-only storage** — the audit log is append-only; entries can
  be added but never modified or deleted (except by the retention
  policy, which logs the purged entry hashes).
* **Data classification** — artifacts are classified by sensitivity
  level: ``PUBLIC``, ``INTERNAL``, ``CONFIDENTIAL``, ``RESTRICTED``.
  Access to higher-sensitivity data requires elevated authorization.
* **PII detection & redaction** — automatically detect and redact
  personally identifiable information (emails, phone numbers, SSNs,
  credit card numbers) in text before logging or export.
* **Retention policies** — configurable data retention rules with
  automatic expiration.  Expired data is purged and the purge is
  itself audited.
* **Compliance report generation** — generate structured reports for
  SOC 2 (Trust Services Criteria), ISO 27001 (Annex A controls), and
  GDPR (data subject rights, retention).

This is a pure-Python implementation using only the standard library
(``hashlib``, ``hmac``, ``json``, ``re``, ``time``, ``dataclasses``).

References
----------
* AICPA (2017). *SOC 2 Trust Services Criteria*.
* ISO/IEC 27001:2022 — *Information security management systems*.
* EU (2016). *General Data Protection Regulation (GDPR)*.
* NIST SP 800-92 — *Guide to Computer Security Log Management*.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, Callable

__all__ = [
    "AuditChainError",
    "RetentionPolicyError",
    "SensitivityLevel",
    "AuditEntry",
    "HashChainedAuditLog",
    "DataClassifier",
    "PIIRedactor",
    "RetentionRule",
    "RetentionPolicy",
    "ComplianceReport",
    "ComplianceReporter",
    "SOC2Report",
    "ISO27001Report",
    "GDPRReport",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class AuditChainError(Exception):
    """Raised when the audit chain is broken (tamper detected)."""


class RetentionPolicyError(Exception):
    """Raised when a retention policy operation fails."""


# ---------------------------------------------------------------------------
# Sensitivity levels
# ---------------------------------------------------------------------------

class SensitivityLevel(str, Enum):
    """Data sensitivity classification levels."""

    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"

    @property
    def level(self) -> int:
        """Numeric level for comparison (higher = more sensitive)."""
        return {
            SensitivityLevel.PUBLIC: 0,
            SensitivityLevel.INTERNAL: 1,
            SensitivityLevel.CONFIDENTIAL: 2,
            SensitivityLevel.RESTRICTED: 3,
        }[self]


# ---------------------------------------------------------------------------
# Audit entry
# ---------------------------------------------------------------------------

@dataclass
class AuditEntry:
    """A single entry in the hash-chained audit log.

    Each entry contains:
    - ``seq``: monotonically increasing sequence number
    - ``timestamp``: Unix epoch (float)
    - ``actor``: who performed the action (username, service account)
    - ``action``: what was done (create, read, update, delete, login, ...)
    - ``resource``: what was acted upon (resource ID or path)
    - ``tenant_id``: which tenant the action belongs to
    - ``details``: additional context (dict)
    - ``prev_hash``: SHA-256 hash of the previous entry (chain link)
    - ``entry_hash``: SHA-256 hash of this entry (computed from all fields)
    - ``sensitivity``: sensitivity level of the resource involved
    """

    seq: int
    timestamp: float
    actor: str
    action: str
    resource: str
    tenant_id: str = ""
    details: dict = field(default_factory=dict)
    prev_hash: str = ""
    entry_hash: str = ""
    sensitivity: str = SensitivityLevel.INTERNAL.value

    def compute_hash(self, prev_hash: str) -> str:
        """Compute this entry's hash given the previous entry's hash.

        The hash is computed over: seq + timestamp + actor + action +
        resource + tenant_id + details (JSON, sorted keys) +
        sensitivity + prev_hash.
        """
        content = json.dumps({
            "seq": self.seq,
            "timestamp": self.timestamp,
            "actor": self.actor,
            "action": self.action,
            "resource": self.resource,
            "tenant_id": self.tenant_id,
            "details": self.details,
            "sensitivity": self.sensitivity,
            "prev_hash": prev_hash,
        }, sort_keys=True)
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def seal(self, prev_hash: str) -> None:
        """Seal this entry by computing and storing its hash."""
        self.prev_hash = prev_hash
        self.entry_hash = self.compute_hash(prev_hash)

    def verify(self, prev_hash: str) -> bool:
        """Verify this entry's hash is consistent with the given prev_hash."""
        expected = self.compute_hash(prev_hash)
        return hmac.compare_digest(expected, self.entry_hash)

    def to_dict(self) -> dict:
        return {
            "seq": self.seq,
            "timestamp": self.timestamp,
            "actor": self.actor,
            "action": self.action,
            "resource": self.resource,
            "tenant_id": self.tenant_id,
            "details": self.details,
            "prev_hash": self.prev_hash,
            "entry_hash": self.entry_hash,
            "sensitivity": self.sensitivity,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "AuditEntry":
        return cls(**d)


# ---------------------------------------------------------------------------
# Hash-chained audit log
# ---------------------------------------------------------------------------

class HashChainedAuditLog:
    """An append-only, hash-chained audit log.

    The log is tamper-evident: each entry's hash includes the hash of
    the previous entry, forming a chain.  Any modification of a past
    entry breaks the chain.  The ``verify_chain()`` method detects
    tampering.

    The log is append-only: entries cannot be modified or deleted
    after being sealed.  The only way to remove entries is via the
    retention policy, which logs the purge itself.
    """

    def __init__(self):
        self._entries: List[AuditEntry] = []
        self._genesis_hash: str = hashlib.sha256(b"petroppo-audit-genesis").hexdigest()
        self._purged_hashes: List[str] = []  # hashes of purged entries (for retention)

    @property
    def length(self) -> int:
        return len(self._entries)

    @property
    def head_hash(self) -> str:
        """Return the hash of the most recent entry (or genesis)."""
        if not self._entries:
            return self._genesis_hash
        return self._entries[-1].entry_hash

    def append(
        self,
        actor: str,
        action: str,
        resource: str,
        tenant_id: str = "",
        details: Optional[dict] = None,
        sensitivity: str = SensitivityLevel.INTERNAL.value,
        timestamp: Optional[float] = None,
    ) -> AuditEntry:
        """Append a new audit entry to the chain.

        Returns
        -------
        AuditEntry
            The sealed entry.
        """
        seq = len(self._entries) + 1
        ts = timestamp if timestamp is not None else time.time()
        prev = self.head_hash

        entry = AuditEntry(
            seq=seq,
            timestamp=ts,
            actor=actor,
            action=action,
            resource=resource,
            tenant_id=tenant_id,
            details=details or {},
            sensitivity=sensitivity,
        )
        entry.seal(prev)
        self._entries.append(entry)
        return entry

    def verify_chain(self) -> bool:
        """Verify the integrity of the entire hash chain.

        Returns
        -------
        bool
            True if the chain is intact, False if tampering is detected.
        """
        prev = self._genesis_hash
        for entry in self._entries:
            if entry.prev_hash != prev:
                return False
            if not entry.verify(prev):
                return False
            prev = entry.entry_hash
        return True

    def find_tamper(self) -> Optional[int]:
        """Find the first entry where the chain is broken.

        Returns
        -------
        int or None
            The sequence number of the first tampered entry, or None
            if the chain is intact.
        """
        prev = self._genesis_hash
        for entry in self._entries:
            if entry.prev_hash != prev:
                return entry.seq
            if not entry.verify(prev):
                return entry.seq
            prev = entry.entry_hash
        return None

    def query(
        self,
        actor: Optional[str] = None,
        action: Optional[str] = None,
        resource: Optional[str] = None,
        tenant_id: Optional[str] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        sensitivity: Optional[str] = None,
        limit: int = 100,
    ) -> List[AuditEntry]:
        """Query audit entries with filters."""
        results = []
        for entry in reversed(self._entries):  # most recent first
            if actor and entry.actor != actor:
                continue
            if action and entry.action != action:
                continue
            if resource and entry.resource != resource:
                continue
            if tenant_id and entry.tenant_id != tenant_id:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            if sensitivity and entry.sensitivity != sensitivity:
                continue
            results.append(entry)
            if len(results) >= limit:
                break
        return results

    def get_entry(self, seq: int) -> Optional[AuditEntry]:
        """Get an entry by sequence number (1-indexed)."""
        if 1 <= seq <= len(self._entries):
            return self._entries[seq - 1]
        return None

    def export(self) -> List[dict]:
        """Export all entries as a list of dicts (for persistence)."""
        return [e.to_dict() for e in self._entries]

    def to_json(self) -> str:
        """Export the entire log as JSON."""
        return json.dumps({
            "entries": self.export(),
            "genesis_hash": self._genesis_hash,
            "purged_hashes": self._purged_hashes,
        }, indent=2)

    def purge_before(self, cutoff_time: float, purged_by: str = "system") -> List[AuditEntry]:
        """Purge entries older than cutoff_time (retention policy).

        The purge itself is logged as a new audit entry after removal.
        Returns the list of purged entries.
        """
        to_keep = []
        purged = []
        for entry in self._entries:
            if entry.timestamp < cutoff_time:
                purged.append(entry)
                self._purged_hashes.append(entry.entry_hash)
            else:
                to_keep.append(entry)

        self._entries = to_keep

        # Re-seal the chain from the beginning (since we removed entries,
        # the chain links change).  In a real system, purged entries would
        # be moved to cold storage with their hash preserved.  Here we
        # re-chain the remaining entries.
        prev = self._genesis_hash
        for i, entry in enumerate(self._entries):
            entry.seq = i + 1
            entry.seal(prev)
            prev = entry.entry_hash

        # Log the purge itself
        if purged:
            self.append(
                actor=purged_by,
                action="audit_purge",
                resource="audit_log",
                details={
                    "purged_count": len(purged),
                    "purged_hashes": [e.entry_hash for e in purged],
                    "cutoff_time": cutoff_time,
                },
                sensitivity=SensitivityLevel.RESTRICTED.value,
            )

        return purged

    def stats(self) -> dict:
        """Return statistics about the audit log."""
        actions: Dict[str, int] = {}
        actors: Dict[str, int] = {}
        sensitivity_counts: Dict[str, int] = {}
        tenant_counts: Dict[str, int] = {}

        for e in self._entries:
            actions[e.action] = actions.get(e.action, 0) + 1
            actors[e.actor] = actors.get(e.actor, 0) + 1
            sensitivity_counts[e.sensitivity] = sensitivity_counts.get(e.sensitivity, 0) + 1
            if e.tenant_id:
                tenant_counts[e.tenant_id] = tenant_counts.get(e.tenant_id, 0) + 1

        return {
            "total_entries": len(self._entries),
            "purged_entries": len(self._purged_hashes),
            "actions": actions,
            "top_actors": dict(sorted(actors.items(), key=lambda x: -x[1])[:10]),
            "sensitivity_distribution": sensitivity_counts,
            "tenant_distribution": tenant_counts,
            "chain_verified": self.verify_chain(),
            "first_entry_time": self._entries[0].timestamp if self._entries else None,
            "last_entry_time": self._entries[-1].timestamp if self._entries else None,
        }


# ---------------------------------------------------------------------------
# Data classifier
# ---------------------------------------------------------------------------

class DataClassifier:
    """Classifies data by sensitivity level.

    Uses keyword matching and pattern detection to suggest a
    classification level for a given data artifact.
    """

    # Keywords that suggest higher sensitivity
    CONFIDENTIAL_KEYWORDS = {
        "financial", "revenue", "profit", "salary", "contract", "merger",
        "acquisition", "proprietary", "trade secret", "intellectual property",
    }
    RESTRICTED_KEYWORDS = {
        "password", "secret", "private key", "credit card", "ssn",
        "social security", "passport", "classified", "top secret",
        "medical record", "health record", "biometric",
    }

    # Patterns for PII / sensitive data
    _CC_PATTERN = re.compile(r"\b(?:\d[ -]*?){13,16}\b")
    _SSN_PATTERN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
    _EMAIL_PATTERN = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
    _PHONE_PATTERN = re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b")

    def classify(self, text: str, explicit: Optional[str] = None) -> SensitivityLevel:
        """Classify a text string by sensitivity.

        Parameters
        ----------
        text : str
            The content to classify.
        explicit : str, optional
            An explicit sensitivity level that overrides detection.

        Returns
        -------
        SensitivityLevel
        """
        if explicit:
            try:
                return SensitivityLevel(explicit)
            except ValueError:
                pass

        text_lower = text.lower()

        # Check for restricted patterns first
        if self._CC_PATTERN.search(text) or self._SSN_PATTERN.search(text):
            return SensitivityLevel.RESTRICTED

        for kw in self.RESTRICTED_KEYWORDS:
            if kw in text_lower:
                return SensitivityLevel.RESTRICTED

        for kw in self.CONFIDENTIAL_KEYWORDS:
            if kw in text_lower:
                return SensitivityLevel.CONFIDENTIAL

        if self._EMAIL_PATTERN.search(text) or self._PHONE_PATTERN.search(text):
            return SensitivityLevel.CONFIDENTIAL

        return SensitivityLevel.INTERNAL

    def classify_dict(self, data: dict) -> SensitivityLevel:
        """Classify a dictionary by examining all string values."""
        max_level = SensitivityLevel.PUBLIC
        for v in data.values():
            if isinstance(v, str):
                level = self.classify(v)
                if level.level > max_level.level:
                    max_level = level
            elif isinstance(v, dict):
                level = self.classify_dict(v)
                if level.level > max_level.level:
                    max_level = level
        return max_level


# ---------------------------------------------------------------------------
# PII Redactor
# ---------------------------------------------------------------------------

class PIIRedactor:
    """Detects and redacts PII in text.

    Supported PII types:
    - Email addresses
    - Phone numbers (US format)
    - Social Security Numbers (SSN)
    - Credit card numbers
    - IP addresses
    """

    EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
    PHONE = re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b")
    SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
    CREDIT_CARD = re.compile(r"\b(?:\d[ -]*?){13,16}\b")
    IP_ADDR = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

    def __init__(self, custom_patterns: Optional[Dict[str, re.Pattern]] = None):
        self._patterns: Dict[str, re.Pattern] = {
            "ssn": self.SSN,
            "credit_card": self.CREDIT_CARD,
            "email": self.EMAIL,
            "phone": self.PHONE,
            "ip_address": self.IP_ADDR,
        }
        if custom_patterns:
            self._patterns.update(custom_patterns)

    def detect(self, text: str) -> List[Dict[str, Any]]:
        """Detect all PII occurrences in text.

        Returns
        -------
        list of dict
            Each dict has: type, value, start, end.
        """
        findings = []
        for pii_type, pattern in self._patterns.items():
            for match in pattern.finditer(text):
                findings.append({
                    "type": pii_type,
                    "value": match.group(),
                    "start": match.start(),
                    "end": match.end(),
                })
        # Sort by position
        findings.sort(key=lambda f: f["start"])
        return findings

    def redact(self, text: str, replacement: str = "[REDACTED]") -> Tuple[str, List[Dict[str, Any]]]:
        """Redact all PII in text.

        Returns
        -------
        (redacted_text, findings)
            The redacted text and a list of what was redacted.
        """
        findings = self.detect(text)
        # Redact from end to start to preserve offsets
        redacted = text
        for f in reversed(findings):
            redacted = redacted[:f["start"]] + replacement + redacted[f["end"]:]
        return redacted, findings

    def has_pii(self, text: str) -> bool:
        """Check if text contains any PII."""
        return len(self.detect(text)) > 0

    @property
    def pattern_types(self) -> List[str]:
        return list(self._patterns.keys())


# ---------------------------------------------------------------------------
# Retention policy
# ---------------------------------------------------------------------------

@dataclass
class RetentionRule:
    """A single retention rule.

    Parameters
    ----------
    name : str
        Rule name.
    action_pattern : str
        Regex pattern to match audit action names.  Empty = match all.
    sensitivity : str
        Minimum sensitivity level this rule applies to.
    retention_days : int
        Number of days to retain entries matching this rule.
    """

    name: str
    action_pattern: str = ""
    sensitivity: str = SensitivityLevel.INTERNAL.value
    retention_days: int = 365

    def matches(self, entry: AuditEntry) -> bool:
        """Check if this rule applies to an entry."""
        if self.action_pattern:
            if not re.search(self.action_pattern, entry.action):
                return False
        if self.sensitivity:
            try:
                entry_level = SensitivityLevel(entry.sensitivity).level
                rule_level = SensitivityLevel(self.sensitivity).level
                if entry_level < rule_level:
                    return False
            except ValueError:
                pass
        return True


class RetentionPolicy:
    """A collection of retention rules.

    When multiple rules match an entry, the one with the longest
    retention period applies (most conservative).
    """

    def __init__(self, rules: Optional[List[RetentionRule]] = None,
                 default_retention_days: int = 90):
        self._rules: List[RetentionRule] = rules or []
        self._default_retention_days: int = default_retention_days

    def add_rule(self, rule: RetentionRule) -> None:
        self._rules.append(rule)

    @property
    def rules(self) -> List[RetentionRule]:
        return list(self._rules)

    def get_retention_days(self, entry: AuditEntry) -> int:
        """Get the retention period (in days) for an entry.

        Uses the longest matching rule (most conservative).
        If no rule matches, uses the default retention period.
        """
        max_days = 0
        any_matched = False
        for rule in self._rules:
            if rule.matches(entry):
                any_matched = True
                if rule.retention_days > max_days:
                    max_days = rule.retention_days
        if not any_matched:
            return self._default_retention_days
        return max_days

    def compute_purge_cutoff(self, entries: List[AuditEntry], now: Optional[float] = None) -> float:
        """Compute the cutoff timestamp for purging expired entries.

        Any entry older than the cutoff should be purged.
        """
        now = now if now is not None else time.time()
        # Find the earliest timestamp that should be kept
        keep_before = float("inf")
        for entry in entries:
            retention_days = self.get_retention_days(entry)
            expiry = entry.timestamp + retention_days * 86400
            if expiry < now:
                # This entry should be purged; but we need the cutoff
                # such that all expired entries are before it
                if entry.timestamp < keep_before:
                    pass  # will be purged
            else:
                # This entry should be kept
                if entry.timestamp < keep_before:
                    keep_before = entry.timestamp

        # If all entries should be purged, return now (purge everything)
        if keep_before == float("inf"):
            return now

        # Purge entries older than the oldest entry we need to keep
        return keep_before

    def evaluate(self, entries: List[AuditEntry], now: Optional[float] = None) -> dict:
        """Evaluate which entries should be purged vs retained.

        Returns
        -------
        dict
            {"purge": [...], "retain": [...], "cutoff": float}
        """
        now = now if now is not None else time.time()
        purge = []
        retain = []
        for entry in entries:
            retention_days = self.get_retention_days(entry)
            expiry = entry.timestamp + retention_days * 86400
            if expiry < now:
                purge.append(entry)
            else:
                retain.append(entry)
        cutoff = min((e.timestamp for e in retain), default=now)
        return {
            "purge": purge,
            "retain": retain,
            "cutoff": cutoff,
            "purge_count": len(purge),
            "retain_count": len(retain),
        }


# ---------------------------------------------------------------------------
# Compliance reports
# ---------------------------------------------------------------------------

@dataclass
class ComplianceReport:
    """Base compliance report."""

    framework: str
    generated_at: float = field(default_factory=time.time)
    generated_by: str = "system"
    findings: List[dict] = field(default_factory=list)
    controls: List[dict] = field(default_factory=list)
    summary: dict = field(default_factory=dict)
    passed: bool = True

    def to_dict(self) -> dict:
        return {
            "framework": self.framework,
            "generated_at": self.generated_at,
            "generated_by": self.generated_by,
            "findings": self.findings,
            "controls": self.controls,
            "summary": self.summary,
            "passed": self.passed,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


@dataclass
class SOC2Report(ComplianceReport):
    """SOC 2 Trust Services Criteria report."""

    framework: str = "SOC 2 (TSC 2017)"
    trust_services_criteria: List[str] = field(default_factory=lambda: [
        "CC1 (Control Environment)",
        "CC2 (Communication and Information)",
        "CC3 (Risk Assessment)",
        "CC4 (Monitoring Activities)",
        "CC5 (Control Activities)",
        "CC6 (Logical and Physical Access)",
        "CC7 (System Operations)",
        "CC8 (Change Management)",
        "CC9 (Risk Mitigation)",
    ])


@dataclass
class ISO27001Report(ComplianceReport):
    """ISO 27001 Annex A controls report."""

    framework: str = "ISO 27001:2022 (Annex A)"
    annex_a_controls: List[str] = field(default_factory=lambda: [
        "A.5.1 (Information security policies)",
        "A.5.15 (Access control)",
        "A.5.16 (Identity management)",
        "A.5.17 (Authentication information)",
        "A.5.30 (ICT readiness for business continuity)",
        "A.5.33 (Test information)",
        "A.5.34 (Privacy and protection of PII)",
        "A.8.2 (Privileged access rights)",
        "A.8.5 (Secure authentication)",
        "A.8.15 (Logging)",
        "A.8.16 (Monitoring activities)",
    ])


@dataclass
class GDPRReport(ComplianceReport):
    """GDPR compliance report."""

    framework: str = "GDPR (EU 2016/679)"
    data_subject_rights: List[str] = field(default_factory=lambda: [
        "Article 15 (Right of access)",
        "Article 16 (Right to rectification)",
        "Article 17 (Right to erasure / right to be forgotten)",
        "Article 18 (Right to restriction of processing)",
        "Article 20 (Right to data portability)",
        "Article 21 (Right to object)",
    ])


# ---------------------------------------------------------------------------
# Compliance reporter
# ---------------------------------------------------------------------------

class ComplianceReporter:
    """Generates compliance reports from audit logs and system state.

    Parameters
    ----------
    audit_log : HashChainedAuditLog
        The audit log to analyze.
    """

    def __init__(self, audit_log: HashChainedAuditLog):
        self.audit_log = audit_log
        self.classifier = DataClassifier()
        self.redactor = PIIRedactor()

    def generate_soc2_report(self, generated_by: str = "compliance-officer") -> SOC2Report:
        """Generate a SOC 2 compliance report.

        Evaluates each Trust Services Criterion based on audit log
        evidence.
        """
        report = SOC2Report(generated_by=generated_by)
        stats = self.audit_log.stats()
        chain_ok = stats["chain_verified"]

        # CC6: Logical access — check for access control events
        access_events = self.audit_log.query(action="login") + \
                        self.audit_log.query(action="logout") + \
                        self.audit_log.query(action="access_denied")
        cc6_pass = len(access_events) > 0 and chain_ok
        report.controls.append({
            "criterion": "CC6 (Logical and Physical Access)",
            "status": "PASS" if cc6_pass else "FAIL",
            "evidence": f"{len(access_events)} access control events logged",
            "chain_intact": chain_ok,
        })

        # CC7: System operations — check for operational events
        ops_events = self.audit_log.query(action="backup") + \
                     self.audit_log.query(action="health_check") + \
                     self.audit_log.query(action="audit_purge")
        cc7_pass = chain_ok
        report.controls.append({
            "criterion": "CC7 (System Operations)",
            "status": "PASS" if cc7_pass else "FAIL",
            "evidence": f"{len(ops_events)} operational events logged",
            "chain_intact": chain_ok,
        })

        # CC8: Change management — check for update/delete events
        change_events = self.audit_log.query(action="update") + \
                        self.audit_log.query(action="delete") + \
                        self.audit_log.query(action="deploy")
        cc8_pass = chain_ok and len(change_events) > 0
        report.controls.append({
            "criterion": "CC8 (Change Management)",
            "status": "PASS" if cc8_pass else "WARN",
            "evidence": f"{len(change_events)} change events logged",
        })

        # Overall
        report.passed = chain_ok and cc6_pass
        report.summary = {
            "total_entries": stats["total_entries"],
            "chain_verified": chain_ok,
            "access_events": len(access_events),
            "operational_events": len(ops_events),
            "change_events": len(change_events),
            "sensitivity_distribution": stats["sensitivity_distribution"],
        }

        if not chain_ok:
            report.findings.append({
                "severity": "CRITICAL",
                "description": "Audit chain integrity check FAILED — tampering detected",
                "tampered_entry": self.audit_log.find_tamper(),
            })

        return report

    def generate_iso27001_report(self, generated_by: str = "iso-admin") -> ISO27001Report:
        """Generate an ISO 27001 compliance report."""
        report = ISO27001Report(generated_by=generated_by)
        stats = self.audit_log.stats()
        chain_ok = stats["chain_verified"]

        # A.8.15: Logging
        report.controls.append({
            "control": "A.8.15 (Logging)",
            "status": "PASS" if stats["total_entries"] > 0 else "FAIL",
            "evidence": f"{stats['total_entries']} log entries, chain verified: {chain_ok}",
        })

        # A.5.34: Privacy and PII protection
        pii_findings = 0
        for entry in self.audit_log.query(limit=1000):
            if self.redactor.has_pii(json.dumps(entry.details)):
                pii_findings += 1
        report.controls.append({
            "control": "A.5.34 (Privacy and PII protection)",
            "status": "PASS" if pii_findings == 0 else "WARN",
            "evidence": f"{pii_findings} entries with potential unredacted PII in details",
        })

        # A.8.5: Secure authentication
        auth_events = self.audit_log.query(action="login") + \
                      self.audit_log.query(action="sso_login")
        report.controls.append({
            "control": "A.8.5 (Secure authentication)",
            "status": "PASS" if len(auth_events) > 0 else "WARN",
            "evidence": f"{len(auth_events)} authentication events",
        })

        report.passed = chain_ok
        report.summary = {
            "total_entries": stats["total_entries"],
            "chain_verified": chain_ok,
            "auth_events": len(auth_events),
            "pii_risk_entries": pii_findings,
        }

        if not chain_ok:
            report.findings.append({
                "severity": "CRITICAL",
                "description": "Audit chain integrity FAILED",
                "control": "A.8.15",
            })

        return report

    def generate_gdpr_report(self, generated_by: str = "dpo") -> GDPRReport:
        """Generate a GDPR compliance report."""
        report = GDPRReport(generated_by=generated_by)
        stats = self.audit_log.stats()
        chain_ok = stats["chain_verified"]

        # Article 17: Right to erasure — check for data deletion events
        deletion_events = self.audit_log.query(action="delete") + \
                          self.audit_log.query(action="data_subject_erasure")
        report.controls.append({
            "right": "Article 17 (Right to erasure)",
            "status": "PASS" if len(deletion_events) > 0 else "WARN",
            "evidence": f"{len(deletion_events)} deletion events logged",
        })

        # Article 15: Right of access — check for data export events
        export_events = self.audit_log.query(action="data_export") + \
                        self.audit_log.query(action="read")
        report.controls.append({
            "right": "Article 15 (Right of access)",
            "status": "PASS" if chain_ok else "FAIL",
            "evidence": f"{len(export_events)} access/export events, chain: {chain_ok}",
        })

        # Article 33: Breach notification
        breach_events = self.audit_log.query(action="security_breach")
        report.controls.append({
            "right": "Article 33 (Breach notification)",
            "status": "PASS" if len(breach_events) == 0 else "FAIL",
            "evidence": f"{len(breach_events)} breach events recorded",
        })

        report.passed = chain_ok
        report.summary = {
            "total_entries": stats["total_entries"],
            "chain_verified": chain_ok,
            "deletion_events": len(deletion_events),
            "export_events": len(export_events),
            "breach_events": len(breach_events),
        }

        return report

    def generate_all_reports(self, generated_by: str = "compliance-system") -> dict:
        """Generate all compliance reports at once."""
        return {
            "soc2": self.generate_soc2_report(generated_by).to_dict(),
            "iso27001": self.generate_iso27001_report(generated_by).to_dict(),
            "gdpr": self.generate_gdpr_report(generated_by).to_dict(),
        }
