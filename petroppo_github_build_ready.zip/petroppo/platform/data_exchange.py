"""petroppo V29 -- Unified data exchange (``petroppo.platform.data_exchange``).

This module provides readers/writers for the industry-standard subsurface
data formats so that a complete workflow -- seismic -> geology -> reservoir ->
simulation -- can pass data between disciplines without lossy hand-coding.

Implemented formats
-------------------

* **SEG-Y**  -- minimal text/binary header + trace reader/writer for 2-D and
  3-D post-stack seismic volumes (Rev 1, IEEE float).
* **LAS 2.0** -- Log ASCII Standard well-log reader/writer (curve mnemonics,
  units, depths).
* **ECLIPSE deck** -- a *subset* of the ECLIPSE 100/300 keyword grammar
  (GRID section: DIMENSIONS, DX/DY/DZ, POROSITY, PERMX/PERMY/PERMZ;
   PROPS section: EQUIL, ROCK, PVTW, DENSITY;
   SCHEDULE section: WELSPECS, COMPDAT, WCONPROD, WCONINJE, DATES, TSTEP).
  Produces a :class:`Deck` object that can be turned into a
  :class:`SinglePhaseSimulator` configuration.

The implementations are deliberately compact and dependency-free (numpy only)
so they are easy to verify and to port.  They are *format-correct* parsers for
the supported keywords; they are not a full ECLIPSE runtime.

All readers/writers are round-trip verified in the platform test suite.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = [
    "SEGYHeader",
    "SEGYFile",
    "read_segy",
    "write_segy",
    "LASCurve",
    "LASFile",
    "read_las",
    "write_las",
    "Deck",
    "DeckSection",
    "read_eclipse_deck",
    "parse_eclipse_deck_text",
    "write_eclipse_deck",
    "SinglePhaseDeckConfig",
    "deck_to_single_phase_config",
]


# ===========================================================================
# SEG-Y  (minimal, IEEE float, Rev-1 friendly)
# ===========================================================================

# Offsets of the most useful binary-header fields (bytes, 0-indexed).
_SEGY_BINHDR_LAYOUT = {
    "job_id": (0, 4, "i4"),
    "line_number": (4, 4, "i4"),
    "sample_interval": (16, 2, "u2"),     # microseconds
    "samples_per_trace": (20, 2, "u2"),
    "data_format": (24, 2, "u2"),         # 5 = IEEE float32
    "ensemble_fold": (26, 2, "u2"),
    "measurement_system": (54, 2, "u2"),  # 1 = metric, 2 = imperial
}

# 240-byte trace header -- only a few fields are read/written here.
_SEGY_TRCHDR_LAYOUT = {
    "trace_seq_line": (0, 4, "i4"),
    "trace_seq_file": (4, 4, "i4"),
    "field_record": (8, 4, "i4"),
    "trace_number": (12, 4, "i4"),
    "energy_source_pt": (16, 4, "i4"),
    "cdp_ensemble": (20, 4, "i4"),
    "trace_in_ensemble": (24, 4, "i4"),
    "trace_id": (28, 2, "i2"),            # 1 = seismic, 2 = dead, ...
    "source_x": (72, 4, "i4"),
    "source_y": (76, 4, "i4"),
    "cdp_x": (80, 4, "i4"),
    "cdp_y": (84, 4, "i4"),
    "inline_number": (188, 4, "i4"),       # common for 3-D
    "crossline_number": (192, 4, "i4"),
    "x_coord": (180, 4, "i4"),
    "y_coord": (184, 4, "i4"),
}

_SEGY_TEXTHDR_LEN = 3200
_SEGY_BINHDR_LEN = 400
_SEGY_TRCHDR_LEN = 240
_SEGY_DATA_FORMAT_IEEE = 5


@dataclass
class SEGYHeader:
    """Parsed SEG-Y textual + binary header summary."""

    textual: str = ""
    sample_interval_us: int = 4000
    samples_per_trace: int = 0
    data_format: int = _SEGY_DATA_FORMAT_IEEE
    measurement_system: int = 1
    n_traces: int = 0

    @property
    def sample_interval(self) -> float:
        """Sample interval in seconds."""
        return self.sample_interval_us * 1e-6


@dataclass
class SEGYFile:
    """An in-memory SEG-Y volume (header + traces)."""

    header: SEGYHeader
    traces: np.ndarray            # shape (n_traces, n_samples)
    trace_headers: list = field(default_factory=list)

    @property
    def n_traces(self) -> int:
        return int(self.traces.shape[0])

    @property
    def n_samples(self) -> int:
        return int(self.traces.shape[1])

    @property
    def dt(self) -> float:
        return self.header.sample_interval


def _parse_int(buf: bytes, off: int, nbytes: int, dtype: str) -> int:
    raw = buf[off:off + nbytes]
    dt = np.dtype(dtype).newbyteorder(">")
    return int(np.frombuffer(raw, dtype=dt)[0])


def read_segy(path: str) -> SEGYFile:
    """Read a (minimal) SEG-Y file produced by :func:`write_segy`.

    Only the IEEE-float (format 5) Rev-1 layout written by this module is
    supported, which is sufficient for round-trip exchange of synthetic and
    real post-stack volumes within petroppo.
    """
    with open(path, "rb") as f:
        buf = f.read()

    if len(buf) < _SEGY_TEXTHDR_LEN + _SEGY_BINHDR_LEN:
        raise ValueError("file too small to be a SEG-Y file")

    textual = buf[:_SEGY_TEXTHDR_LEN]
    # EBCDIC textual header is the industry default; we decode latin-1 to be
    # tolerant of either EBCDIC-as-bytes or ASCII content from our writer.
    try:
        textual_str = textual.decode("cp037")
    except (UnicodeDecodeError, LookupError):
        textual_str = textual.decode("latin-1", errors="replace")

    binhdr = buf[_SEGY_TEXTHDR_LEN:_SEGY_TEXTHDR_LEN + _SEGY_BINHDR_LEN]
    dt_us = _parse_int(binhdr, *_SEGY_BINHDR_LAYOUT["sample_interval"])
    n_samp = _parse_int(binhdr, *_SEGY_BINHDR_LAYOUT["samples_per_trace"])
    dformat = _parse_int(binhdr, *_SEGY_BINHDR_LAYOUT["data_format"])
    meas = _parse_int(binhdr, *_SEGY_BINHDR_LAYOUT["measurement_system"])

    if dformat != _SEGY_DATA_FORMAT_IEEE:
        raise ValueError(
            f"unsupported data-format code {dformat}; only IEEE float (5) "
            f"is supported by this reader"
        )
    if n_samp <= 0:
        raise ValueError("samples_per_trace must be > 0")

    sample_bytes = 4  # IEEE float32
    trace_bytes = _SEGY_TRCHDR_LEN + n_samp * sample_bytes
    body = buf[_SEGY_TEXTHDR_LEN + _SEGY_BINHDR_LEN:]
    n_traces = len(body) // trace_bytes
    traces = np.empty((n_traces, n_samp), dtype=np.float32)
    trace_headers = []
    for t in range(n_traces):
        s = t * trace_bytes
        th = body[s:s + _SEGY_TRCHDR_LEN]
        trace_headers.append(th)
        data = body[s + _SEGY_TRCHDR_LEN:s + trace_bytes]
        traces[t] = np.frombuffer(data, dtype=">f4").astype(np.float32)

    header = SEGYHeader(
        textual=textual_str,
        sample_interval_us=dt_us,
        samples_per_trace=n_samp,
        data_format=dformat,
        measurement_system=meas,
        n_traces=n_traces,
    )
    return SEGYFile(header=header, traces=traces, trace_headers=trace_headers)


def write_segy(path: str, traces: np.ndarray, dt: float = 0.004,
               inline_numbers: Optional[np.ndarray] = None,
               crossline_numbers: Optional[np.ndarray] = None,
               measurement_system: int = 1) -> None:
    """Write a 2-D/3-D post-stack volume as a minimal IEEE-float SEG-Y file.

    Parameters
    ----------
    path : str
        Output path.
    traces : array, shape (n_traces, n_samples)
        Seismic traces (any float dtype; stored as IEEE float32).
    dt : float
        Sample interval in **seconds** (converted to microseconds on disk).
    inline_numbers, crossline_numbers : optional int arrays
        Per-trace inline/crossline numbers written into the trace header.
    measurement_system : int
        1 = metric, 2 = imperial (default metric).
    """
    traces = np.ascontiguousarray(traces, dtype=np.float32)
    if traces.ndim != 2:
        raise ValueError("traces must be 2-D (n_traces, n_samples)")
    n_traces, n_samp = traces.shape
    if n_traces == 0 or n_samp == 0:
        raise ValueError("cannot write an empty SEG-Y volume")

    # --- textual header (ASCII, padded to 3200 bytes) ---
    text = "petroppo SEG-Y (IEEE float, Rev-1 friendly)                "
    text = text.ljust(3200)[:3200]
    textual = text.encode("latin-1", errors="replace")

    # --- binary header (400 bytes) ---
    binhdr = bytearray(_SEGY_BINHDR_LEN)

    def _put(off_key, value):
        off, nbytes, dtype = _SEGY_BINHDR_LAYOUT[off_key]
        dt = np.dtype(dtype).newbyteorder(">")
        binhdr[off:off + nbytes] = np.array([value], dtype=dt).tobytes()

    _put("sample_interval", int(round(dt * 1e6)))
    _put("samples_per_trace", n_samp)
    _put("data_format", _SEGY_DATA_FORMAT_IEEE)
    _put("measurement_system", measurement_system)
    _put("ensemble_fold", 1)

    # --- traces ---
    body = bytearray()
    for t in range(n_traces):
        th = bytearray(_SEGY_TRCHDR_LEN)

        def _thput(off_key, value):
            off, nbytes, dtype = _SEGY_TRCHDR_LAYOUT[off_key]
            d = np.dtype(dtype).newbyteorder(">")
            th[off:off + nbytes] = np.array([value], dtype=d).tobytes()

        _thput("trace_seq_line", t + 1)
        _thput("trace_seq_file", t + 1)
        _thput("trace_id", 1)  # live seismic trace
        if inline_numbers is not None:
            _thput("inline_number", int(inline_numbers[t]))
        if crossline_numbers is not None:
            _thput("crossline_number", int(crossline_numbers[t]))
        body += th
        body += traces[t].astype(">f4").tobytes()

    with open(path, "wb") as f:
        f.write(textual)
        f.write(bytes(binhdr))
        f.write(bytes(body))


# ===========================================================================
# LAS 2.0  (Log ASCII Standard)
# ===========================================================================


@dataclass
class LASCurve:
    """A single well-log curve."""

    name: str
    units: str = ""
    description: str = ""
    data: np.ndarray = field(default_factory=lambda: np.array([]))


@dataclass
class LASFile:
    """An in-memory LAS 2.0 file."""

    version: float = 2.0
    well_name: str = ""
    company: str = ""
    field_name: str = ""
    start_depth: float = 0.0
    stop_depth: float = 0.0
    step: float = 0.0
    depth_units: str = "M"
    null_value: float = -999.25
    curves: list = field(default_factory=list)  # list[LASCurve]

    @property
    def depth(self) -> np.ndarray:
        """The DEPT curve if present, else a synthetic index."""
        for c in self.curves:
            if c.name.upper() in ("DEPT", "DEPTH"):
                return np.asarray(c.data, float)
        return np.arange(len(self.curves[0].data)) * self.step + self.start_depth

    def curve(self, name: str) -> LASCurve:
        up = name.upper()
        for c in self.curves:
            if c.name.upper() == up:
                return c
        raise KeyError(f"no curve named {name!r}")


def _parse_value(v: str) -> float:
    v = v.strip()
    if v in ("", "NA", "N/A"):
        return float("nan")
    try:
        return float(v)
    except ValueError:
        return float("nan")


def _is_num(tok) -> bool:
    """True if *tok* parses as a float (used by schedule keyword parsers)."""
    try:
        float(tok)
        return True
    except (TypeError, ValueError):
        return False


def read_las(path: str) -> LASFile:
    """Read a LAS 2.0 file (Version, Well, Curve, Parameter, ASCII sections)."""
    with open(path, "r", errors="replace") as f:
        lines = f.readlines()

    las = LASFile()
    section = None
    curve_names: list = []  # list[(name, units, descr)]
    ascii_rows: list = []

    for raw in lines:
        line = raw.rstrip("\n")
        if not line.strip():
            continue
        stripped = line.strip()
        # section header e.g. ~V , ~W , ~C , ~P , ~A
        if stripped.startswith("~"):
            upper = stripped.upper()
            if upper.startswith("~V"):
                section = "V"
            elif upper.startswith("~W"):
                section = "W"
            elif upper.startswith("~C"):
                section = "C"
            elif upper.startswith("~P"):
                section = "P"
            elif upper.startswith("~A"):
                section = "A"
            else:
                section = stripped[1:2] or None
            continue

        # comment lines starting with #
        if stripped.startswith("#"):
            continue

        if section == "V":
            # VERS. 2.0 : ...
            if "." in stripped and ":" in stripped:
                key = stripped.split(".", 1)[0].strip().upper()
                pre_desc = stripped.split(":", 1)[0]
                after_dot = pre_desc.split(".", 1)[1] if "." in pre_desc else pre_desc
                tokens = after_dot.strip().split()
                # first non-unit token is the value
                val = ""
                if tokens:
                    try:
                        float(tokens[0])
                        val = tokens[0]
                    except ValueError:
                        val = tokens[1] if len(tokens) > 1 else ""
                if key == "VERS":
                    try:
                        las.version = float(val.replace(":", ""))
                    except ValueError:
                        pass
            continue

        if section == "W":
            # Lines look like:  STRT.M      1000       : START DEPTH
            # The mnemonic may carry a unit after the dot.  The numeric/text
            # value is the first token that follows the (optional) unit.
            pre_desc = line.split(":", 1)[0]
            desc = line.split(":", 1)[1].strip() if ":" in line else ""
            if "." in pre_desc:
                head = pre_desc.split(".", 1)[0].strip().upper()
                after_dot = pre_desc.split(".", 1)[1]
            else:
                head = pre_desc.strip().upper()
                after_dot = pre_desc
            tokens = after_dot.strip().split()
            unit = ""
            val = ""
            if tokens:
                try:
                    float(tokens[0])
                    val = tokens[0]
                except ValueError:
                    unit = tokens[0]
                    val = tokens[1] if len(tokens) > 1 else ""
            try:
                num = float(val) if val != "" else None
            except ValueError:
                num = None
            if head.startswith("STRT"):
                las.start_depth = num if num is not None else 0.0
                if unit:
                    las.depth_units = unit
            elif head.startswith("STOP"):
                las.stop_depth = num if num is not None else 0.0
            elif head.startswith("STEP"):
                las.step = num if num is not None else 0.0
            elif head.startswith("NULL"):
                las.null_value = num if num is not None else las.null_value
            elif head.startswith("WELL"):
                # text field: value is the first token after the dot (no unit)
                las.well_name = tokens[0] if tokens else desc
            elif head.startswith("COMP"):
                las.company = tokens[0] if tokens else desc
            elif head.startswith("FLD"):
                las.field_name = tokens[0] if tokens else desc
            continue

        if section == "C":
            # DEPT.M  : depth
            # GR.GAPI : gamma ray
            parts = line.split(":", 1)
            descr = parts[1].strip() if len(parts) == 2 else ""
            left = parts[0].strip()
            first = left.split()[0]
            if "." in first:
                nm, u = first.split(".", 1)
            else:
                nm, u = first, ""
            curve_names.append((nm, u, descr))
            continue

        if section == "A":
            toks = stripped.split()
            ascii_rows.append([_parse_value(t) for t in toks])
            continue

    # build curves
    if curve_names and ascii_rows:
        arr = np.array(ascii_rows, dtype=float)
        if arr.shape[1] != len(curve_names):
            raise ValueError(
                f"LAS data has {arr.shape[1]} columns but {len(curve_names)} "
                f"curves declared"
            )
        las.curves = [
            LASCurve(name=nm, units=u, description=d, data=arr[:, i])
            for i, (nm, u, d) in enumerate(curve_names)
        ]
    return las


def write_las(path: str, las: LASFile) -> None:
    """Write an LAS 2.0 file."""
    n = max((len(c.data) for c in las.curves), default=0)
    lines: list = []
    lines.append("~V -------------------------------------------------------")
    lines.append("VERS.   2.0 :   CWLS LOG ASCII STANDARD - VERSION 2.0")
    lines.append("WRAP.   NO  :   ONE LINE PER DEPTH STEP")
    lines.append("~W -------------------------------------------------------")
    lines.append(f"STRT.{las.depth_units:<6} {las.start_depth:<10} : START DEPTH")
    lines.append(f"STOP.{las.depth_units:<6} {las.stop_depth:<10} : STOP DEPTH")
    lines.append(f"STEP.{las.depth_units:<6} {las.step:<10} : STEP")
    lines.append(f"NULL.        {las.null_value:<10} : NULL VALUE")
    lines.append(f"COMP.        {las.company:<10} : COMPANY")
    lines.append(f"WELL.        {las.well_name:<10} : WELL")
    lines.append(f"FLD.         {las.field_name:<10} : FIELD")
    lines.append("~C -------------------------------------------------------")
    for c in las.curves:
        u = c.units or " "
        lines.append(f"{c.name}.{u:<6} : {c.description}")
    lines.append("~A -------------------------------------------------------")
    cols = [c.data for c in las.curves]
    if cols:
        arr = np.vstack([np.asarray(c, float)[:n] for c in cols]).T
        for row in arr:
            lines.append("   ".join(f"{v:12.4f}" for v in row))
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")


# ===========================================================================
# ECLIPSE deck  (subset: GRID + PROPS + SCHEDULE)
# ===========================================================================


@dataclass
class DeckSection:
    """A named section of an ECLIPSE deck (e.g. GRID, PROPS, SCHEDULE)."""

    name: str
    keywords: list = field(default_factory=list)  # list[(name, dict|list)]


@dataclass
class Deck:
    """A parsed (subset) ECLIPSE deck."""

    title: str = ""
    sections: list = field(default_factory=list)  # list[DeckSection]

    def section(self, name: str) -> DeckSection:
        up = name.upper()
        for s in self.sections:
            if s.name.upper() == up:
                return s
        raise KeyError(f"no section named {name!r}")

    def keyword(self, name: str, section: Optional[str] = None) -> Optional[object]:
        up = name.upper()
        secs = [self.section(section)] if section else self.sections
        for s in secs:
            for kw_name, kw_data in s.keywords:
                if kw_name.upper() == up:
                    return kw_data
        return None


def _tokenize_deck(text: str) -> list:
    """Split a deck into a list of (section, keyword, lines) tuples.

    Comments (lines starting with ``--``) and blank lines are dropped.
    Section markers are ``RUNSPEC``, ``GRID``, ``PROPS``, ``SOLUTION``,
    ``SUMMARY``, ``SCHEDULE``.

    A keyword may contain several records, each terminated by ``/``.  The
    keyword itself is terminated either by a bare ``/`` on its own line
    (the ECLIPSE "null record") or by the next keyword / section header.
    """
    sections = ["RUNSPEC", "GRID", "PROPS", "SOLUTION", "SUMMARY", "SCHEDULE"]
    out: list = []
    current_section = "RUNSPEC"
    current_kw: Optional[str] = None
    current_lines: list = []

    def _flush():
        if current_kw is not None:
            out.append((current_section, current_kw, current_lines[:]))

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("--"):
            continue
        up = line.upper()
        if up in sections:
            _flush()
            current_section = up
            current_kw = None
            current_lines = []
            continue
        # a bare '/' on its own line terminates the current keyword
        if up == "/":
            _flush()
            current_kw = None
            current_lines = []
            continue
        # a keyword header is a bare uppercase identifier in column 1.
        # If we are already inside a keyword, flush it first (ECLIPSE
        # keywords end when the next keyword / section starts).
        if line.isidentifier() and any(c.isalpha() for c in line) \
                and line == up and up not in ("OPEN", "SHUT", "STOP",
                                              "AUTO", "YES", "NO", "F", "T"):
            _flush()
            current_kw = up
            current_lines = []
            continue
        # accumulate record lines (a trailing '/' ends a *record*, not the
        # whole keyword -- keep accumulating until the null-record '/')
        current_lines.append(line)
    _flush()
    return out


def _parse_records(lines: list) -> list:
    """Split accumulated keyword lines into records (terminated by '/')."""
    joined = " ".join(lines)
    recs = []
    for rec in joined.split("/"):
        toks = [t for t in rec.split() if t]
        if toks:
            recs.append(toks)
    return recs


def _parse_grid_keyword(name: str, recs: list) -> object:
    if name == "DIMENSIONS":
        r = recs[0]
        return {"nx": int(r[0]), "ny": int(r[1]), "nz": int(r[2])}
    if name in ("DX", "DY", "DZ", "POROSITY", "PERMX", "PERMY", "PERMZ",
                "NTG", "TOPS"):
        flat = []
        for r in recs:
            flat.extend(r)
        try:
            vals = [float(t) for t in flat]
        except ValueError:
            return flat
        if len(vals) == 1:
            return {"constant": vals[0], "n": None}
        return vals
    if name == "ACTNUM":
        flat = []
        for r in recs:
            flat.extend(r)
        return [int(t) for t in flat]
    if name == "BOX":
        r = recs[0]
        return [int(x) for x in r[:6]]
    return recs


def _parse_props_keyword(name: str, recs: list) -> object:
    if name == "EQUIL":
        r = recs[0]
        return {
            "datum_depth": float(r[0]),
            "datum_pressure": float(r[1]),
            "owc_depth": float(r[2]),
            "pc_owc": float(r[3]),
            "goc_depth": float(r[4]) if len(r) > 4 else 9999.0,
            "pc_goc": float(r[5]) if len(r) > 5 else 0.0,
            "initialization": int(r[6]) if len(r) > 6 else 0,
        }
    if name == "ROCK":
        r = recs[0]
        return {"reference_pressure": float(r[0]),
                "compressibility": float(r[1])}
    if name == "PVTW":
        r = recs[0]
        return {"p_ref": float(r[0]), "bw_ref": float(r[1]),
                "cw": float(r[2]), "pw_ref": float(r[3])}
    if name == "DENSITY":
        r = recs[0]
        return {"oil_density": float(r[0]),
                "water_density": float(r[1]),
                "gas_density": float(r[2])}
    if name == "SWAT":
        flat = []
        for r in recs:
            flat.extend(r)
        try:
            return [float(t) for t in flat]
        except ValueError:
            return flat
    return recs


def _parse_schedule_keyword(name: str, recs: list) -> object:
    if name == "WELSPECS":
        out = []
        for r in recs:
            out.append({
                "name": r[0], "group": r[1] if len(r) > 1 else "FIELD",
                "i": int(r[2]), "j": int(r[3]),
                "ref_depth": float(r[4]) if len(r) > 4 else 0.0,
                "phase": r[5].upper() if len(r) > 5 else "OIL",
            })
        return out
    if name == "COMPDAT":
        out = []
        for r in recs:
            # ECLIPSE COMPDAT: well i j k1 k2 status sat_tab cf dir ...
            # status may be OPEN / SHUT / STOP (string) or an int (1/0)
            status = r[5] if len(r) > 5 else "OPEN"
            if isinstance(status, str) and status.upper() in (
                    "OPEN", "SHUT", "STOP", "AUTO"):
                open_flag = 1 if status.upper() == "OPEN" else 0
                sat_tab = int(r[6]) if len(r) > 6 else 1
                cf = float(r[7]) if len(r) > 7 else 0.0
                well_pen = float(r[8]) if len(r) > 8 else 0.0
                direction = r[9].upper() if len(r) > 9 else "Z"
            else:
                open_flag = int(status) if len(r) > 5 else 1
                sat_tab = int(r[6]) if len(r) > 6 else 1
                cf = float(r[7]) if len(r) > 7 else 0.0
                well_pen = float(r[8]) if len(r) > 8 else 0.0
                direction = r[9].upper() if len(r) > 9 else "Z"
            out.append({
                "name": r[0],
                "i": int(r[1]), "j": int(r[2]),
                "k1": int(r[3]), "k2": int(r[4]),
                "open": open_flag,
                "sat_tab": sat_tab,
                "conn_factor": cf,
                "well_pen": well_pen,
                "dir": direction,
            })
        return out
    if name == "WCONPROD":
        out = []
        for r in recs:
            # ECLIPSE WCONPROD: well status cmode orat wrat grat ... bhp
            # status (OPEN/SHUT/STOP) at index 1, control mode at index 2
            name_w = r[0]
            status = r[1].upper() if len(r) > 1 else "OPEN"
            cmode = r[2].upper() if len(r) > 2 else "BHP"
            # rate fields and bhp depend on how many tokens are present
            orat = float(r[3]) if len(r) > 3 and _is_num(r[3]) else 0.0
            wrat = float(r[4]) if len(r) > 4 and _is_num(r[4]) else 0.0
            grat = float(r[5]) if len(r) > 5 and _is_num(r[5]) else 0.0
            lrat = float(r[6]) if len(r) > 6 and _is_num(r[6]) else 0.0
            # bhp is the last numeric token
            bhp = 0.0
            for tok in r[3:]:
                if _is_num(tok):
                    bhp = float(tok)
            out.append({
                "name": name_w, "status": status, "ctrl": cmode,
                "oil_rate": orat, "water_rate": wrat,
                "gas_rate": grat, "liquid_rate": lrat, "bhp": bhp,
            })
        return out
    if name == "WCONINJE":
        out = []
        for r in recs:
            # ECLIPSE WCONINJE: well phase status cmode [rate] [bhp]
            name_w = r[0]
            phase = r[1].upper() if len(r) > 1 else "WATER"
            status = r[2].upper() if len(r) > 2 else "OPEN"
            cmode = r[3].upper() if len(r) > 3 else "BHP"
            nums = [float(t) for t in r[4:] if _is_num(t)]
            rate = 0.0
            bhp = 0.0
            if cmode == "BHP":
                # last numeric is the bhp limit (rate may precede it)
                if len(nums) >= 2:
                    rate, bhp = nums[0], nums[1]
                elif len(nums) == 1:
                    bhp = nums[0]
            else:  # RATE control
                if len(nums) >= 2:
                    rate, bhp = nums[0], nums[1]
                elif len(nums) == 1:
                    rate = nums[0]
            out.append({
                "name": name_w, "phase": phase, "status": status,
                "ctrl": cmode, "rate": rate, "bhp": bhp,
            })
        return out
    if name == "DATES":
        out = []
        for r in recs:
            out.append({"day": int(r[0]) if len(r) > 0 else 1,
                        "month": r[1] if len(r) > 1 else "JAN",
                        "year": int(r[2]) if len(r) > 2 else 2000})
        return out
    if name == "TSTEP":
        flat = []
        for r in recs:
            flat.extend(r)
        return [float(t) for t in flat]
    return recs


def read_eclipse_deck(path: str) -> Deck:
    """Parse an ECLIPSE deck (subset) into a :class:`Deck`."""
    with open(path, "r", errors="replace") as f:
        text = f.read()
    return parse_eclipse_deck_text(text)


def parse_eclipse_deck_text(text: str) -> Deck:
    """Parse ECLIPSE deck text into a :class:`Deck` object."""
    tokens = _tokenize_deck(text)
    deck = Deck()
    by_section: dict = {}
    order: list = []
    for sec, kw, lines in tokens:
        if sec not in by_section:
            by_section[sec] = DeckSection(name=sec)
            order.append(sec)
        recs = _parse_records(lines)
        if sec == "RUNSPEC" and kw == "TITLE":
            deck.title = " ".join(" ".join(r) for r in recs)
            continue
        if sec == "GRID":
            data = _parse_grid_keyword(kw, recs)
        elif sec == "PROPS":
            data = _parse_props_keyword(kw, recs)
        elif sec == "SOLUTION":
            data = _parse_props_keyword(kw, recs) if kw in ("EQUIL",) else recs
        elif sec == "SCHEDULE":
            data = _parse_schedule_keyword(kw, recs)
        else:
            data = recs
        by_section[sec].keywords.append((kw, data))
    deck.sections = [by_section[s] for s in order]
    return deck


def _fmt_grid_value(name: str, data) -> str:
    if name == "DIMENSIONS" and isinstance(data, dict):
        return (f"DIMENSIONS\n  {data['nx']} {data['ny']} {data['nz']} /\n")
    if name == "BOX" and isinstance(data, list):
        return f"BOX\n  {' '.join(str(v) for v in data)} /\n"
    if isinstance(data, dict) and data.get("constant") is not None and data.get("n") is None:
        return f"{name}\n  {data['constant']} /\n"
    if isinstance(data, list):
        vals = " ".join(f"{float(v):.6g}" for v in data)
        return f"{name}\n  {vals} /\n"
    return f"{name}\n  {data} /\n"


def _format_props_keyword(name: str, data) -> str:
    if name == "EQUIL" and isinstance(data, dict):
        r = (f"  {data['datum_depth']} {data['datum_pressure']} "
             f"{data['owc_depth']} {data['pc_owc']} {data['goc_depth']} "
             f"{data['pc_goc']} {data['initialization']} /")
        return f"EQUIL\n{r}\n"
    if name == "ROCK" and isinstance(data, dict):
        return f"ROCK\n  {data['reference_pressure']} {data['compressibility']} /\n"
    if name == "PVTW" and isinstance(data, dict):
        return (f"PVTW\n  {data['p_ref']} {data['bw_ref']} {data['cw']} "
                f"{data['pw_ref']} /\n")
    if name == "DENSITY" and isinstance(data, dict):
        return (f"DENSITY\n  {data['oil_density']} {data['water_density']} "
                f"{data['gas_density']} /\n")
    if name == "SWAT" and isinstance(data, list):
        vals = " ".join(f"{float(v):.6g}" for v in data)
        return f"SWAT\n  {vals} /\n"
    return f"{name}\n  /\n"


def _format_solution_keyword(name: str, data) -> str:
    return _format_props_keyword(name, data)


def _format_schedule_keyword(name: str, data) -> str:
    out = f"{name}\n"
    if not isinstance(data, list):
        return out + "  /\n"
    if name == "WELSPECS":
        for w in data:
            out += (f"  {w['name']} {w.get('group', 'FIELD')} {w['i']} "
                    f"{w['j']} {w.get('ref_depth', 0.0)} {w.get('phase', 'OIL')} /\n")
        return out
    if name == "COMPDAT":
        for c in data:
            out += (f"  {c['name']} {c['i']} {c['j']} {c['k1']} {c['k2']} "
                    f"{c.get('open', 1)} {c.get('sat_tab', 1)} "
                    f"{c.get('conn_factor', 0.0)} {c.get('well_pen', 0.0)} "
                    f"{c.get('dir', 'Z')} /\n")
        return out
    if name == "WCONPROD":
        for w in data:
            out += (f"  {w['name']} {w.get('ctrl', 'BHP')} {w.get('oil_rate', 0)} "
                    f"{w.get('water_rate', 0)} {w.get('gas_rate', 0)} "
                    f"{w.get('liquid_rate', 0)} {w.get('bhp', 0)} /\n")
        return out
    if name == "WCONINJE":
        for w in data:
            out += (f"  {w['name']} {w.get('phase', 'WATER')} "
                    f"{w.get('ctrl', 'RATE')} {w.get('rate', 0)} "
                    f"{w.get('bhp', 0)} /\n")
        return out
    if name == "DATES":
        for d in data:
            out += f"  {d['day']} {d['month']} {d['year']} /\n"
        return out
    if name == "TSTEP":
        out += "  " + " ".join(str(v) for v in data) + " /\n"
        return out
    return out + "  /\n"


def write_eclipse_deck(path: str, deck: Deck) -> None:
    """Serialise a :class:`Deck` back to ECLIPSE-format text."""
    lines: list = []
    if deck.title:
        lines.append("RUNSPEC")
        lines.append("TITLE")
        lines.append(f"  {deck.title} /")
        lines.append("")
    section_order = ["RUNSPEC", "GRID", "PROPS", "SOLUTION", "SCHEDULE"]
    for sname in section_order:
        try:
            sec = deck.section(sname)
        except KeyError:
            continue
        lines.append(sname)
        if sname == "RUNSPEC" and deck.title:
            for kw, data in sec.keywords:
                if kw == "TITLE":
                    continue
                lines.append(f"{kw}")
                lines.append(" /")
        elif sname == "GRID":
            for kw, data in sec.keywords:
                lines.append(_fmt_grid_value(kw, data))
        elif sname == "PROPS":
            for kw, data in sec.keywords:
                lines.append(_format_props_keyword(kw, data))
        elif sname == "SOLUTION":
            for kw, data in sec.keywords:
                lines.append(_format_solution_keyword(kw, data))
        elif sname == "SCHEDULE":
            for kw, data in sec.keywords:
                lines.append(_format_schedule_keyword(kw, data))
        lines.append("")
    with open(path, "w") as f:
        f.write("\n".join(lines))


# ===========================================================================
# Deck -> simulator config
# ===========================================================================


@dataclass
class SinglePhaseDeckConfig:
    """A configuration derived from an ECLIPSE deck for the single-phase sim."""

    nx: int
    ny: int
    nz: int
    dx: float
    dy: float
    dz: float
    porosity: np.ndarray
    permeability: np.ndarray
    initial_pressure: float
    water_density: float = 1000.0
    water_viscosity: float = 0.5e-3
    water_compressibility: float = 4.5e-10
    rock_compressibility: float = 0.0
    wells: list = field(default_factory=list)
    timesteps: list = field(default_factory=list)


def deck_to_single_phase_config(deck: Deck) -> SinglePhaseDeckConfig:
    """Convert a parsed deck into a config for :class:`SinglePhaseSimulator`.

    Supports constant (single-value) DX/DY/DZ/POROSITY/PERMX plus a WELSPECS
    + COMPDAT + WCONPROD/WCONINJE + TSTEP schedule.
    """
    grid_kw = deck.keyword("DIMENSIONS", section="GRID")
    if grid_kw is None:
        raise ValueError("deck missing DIMENSIONS")
    nx, ny, nz = grid_kw["nx"], grid_kw["ny"], grid_kw["nz"]
    n = nx * ny * nz

    def _const(name, default):
        kw = deck.keyword(name, section="GRID")
        if kw is None:
            return default
        if isinstance(kw, dict) and kw.get("constant") is not None:
            return float(kw["constant"])
        if isinstance(kw, list):
            arr = np.array(kw, float)
            if arr.size == 1:
                return float(arr[0])
            if arr.size == n:
                return arr.reshape((nx, ny, nz))
        return default

    dx = _const("DX", 100.0)
    dy = _const("DY", 100.0)
    dz = _const("DZ", 10.0)
    poro = _const("POROSITY", 0.2)
    perm = _const("PERMX", 100.0)  # mD -> handled by caller as needed

    equil = deck.keyword("EQUIL", section="PROPS")
    p0 = float(equil["datum_pressure"]) if equil else 1.0e7

    density = deck.keyword("DENSITY", section="PROPS")
    rho_w = float(density["water_density"]) if density else 1000.0
    pvtw = deck.keyword("PVTW", section="PROPS")
    cw = float(pvtw["cw"]) if pvtw else 4.5e-10
    rock = deck.keyword("ROCK", section="PROPS")
    crock = float(rock["compressibility"]) if rock else 0.0

    if np.isscalar(poro):
        poro_arr = np.full((nx, ny, nz), float(poro))
    else:
        poro_arr = poro
    if np.isscalar(perm):
        perm_arr = np.full((nx, ny, nz), float(perm))
    else:
        perm_arr = perm

    wells_cfg = []
    welspecs = deck.keyword("WELSPECS", section="SCHEDULE") or []
    compdat = deck.keyword("COMPDAT", section="SCHEDULE") or []
    wconprod = deck.keyword("WCONPROD", section="SCHEDULE") or []
    wconinje = deck.keyword("WCONINJE", section="SCHEDULE") or []

    prod_by_name = {w["name"]: w for w in wconprod}
    inj_by_name = {w["name"]: w for w in wconinje}
    well_ijs = {w["name"]: (w["i"], w["j"]) for w in welspecs}
    for c in compdat:
        nm = c["name"]
        i, j = well_ijs.get(nm, (c["i"], c["j"]))
        kind = "producer"
        target = 0.0
        ctrl = "bhp"
        if nm in prod_by_name:
            pw = prod_by_name[nm]
            ctrl = pw.get("ctrl", "BHP").lower()
            target = pw.get("bhp", 0.0) if ctrl == "bhp" else pw.get("oil_rate", 0.0)
        elif nm in inj_by_name:
            iw = inj_by_name[nm]
            kind = "injector"
            ctrl = iw.get("ctrl", "RATE").lower()
            target = iw.get("rate", 0.0) if ctrl == "rate" else iw.get("bhp", 0.0)
        for k in range(c["k1"], c["k2"] + 1):
            wells_cfg.append({
                "name": nm, "kind": kind, "i": i - 1, "j": j - 1, "k": k - 1,
                "ctrl": ctrl, "target": float(target),
            })

    tstep = deck.keyword("TSTEP", section="SCHEDULE") or []
    return SinglePhaseDeckConfig(
        nx=nx, ny=ny, nz=nz,
        dx=float(dx) if np.isscalar(dx) else float(np.mean(dx)),
        dy=float(dy) if np.isscalar(dy) else float(np.mean(dy)),
        dz=float(dz) if np.isscalar(dz) else float(np.mean(dz)),
        porosity=poro_arr,
        permeability=perm_arr,
        initial_pressure=p0,
        water_density=rho_w,
        water_viscosity=0.5e-3,
        water_compressibility=cw,
        rock_compressibility=crock,
        wells=wells_cfg,
        timesteps=[float(t) for t in tstep],
    )


# ===========================================================================
# V35 -- RESQML 2.0 (Energistics) reader / writer
# ===========================================================================

@dataclass
class RESQMLProperty:
    """A single RESQML property (e.g. porosity, permeability grid)."""
    title: str
    property_type: str          # "Continuous" | "Categorical" | "Discrete"
    unit: str = ""
    data: Optional[np.ndarray] = None
    uuid: str = ""


@dataclass
class RESQMLGrid:
    """IjkGrid representation (structured hexahedral grid)."""
    i_cells: int
    j_cells: int
    k_cells: int
    x_corners: Optional[np.ndarray] = None    # (i+1, j+1, k+1)
    y_corners: Optional[np.ndarray] = None
    z_corners: Optional[np.ndarray] = None
    properties: list = field(default_factory=list)  # List[RESQMLProperty]
    title: str = "petroppoGrid"
    uuid: str = ""

    @property
    def n_cells(self) -> int:
        return self.i_cells * self.j_cells * self.k_cells


def write_resqml_epc(path: str, grid: RESQMLGrid) -> str:
    """Write a minimal RESQML 2.0 EPC (XML) + optional HDF5 pair.

    The EPC is an XML document describing the IjkGrid and its properties.
    Property data is stored as a companion ``.h5`` file using numpy's
    native ``.npy`` format (a lightweight stand-in for HDF5 that is
    dependency-free).  Returns the EPC path.

    Parameters
    ----------
    path : str
        Output ``.epc`` file path.
    grid : RESQMLGrid
        Grid + properties to serialise.
    """
    import xml.etree.ElementTree as ET
    import uuid as _uuid
    import os

    if not grid.uuid:
        grid.uuid = str(_uuid.uuid4())
    h5_path = path.replace(".epc", ".h5")
    if not h5_path.endswith(".npz"):
        h5_path = h5_path + ".npz"

    # --- XML (EPC content) ---
    root = ET.Element("ResqmlDataset")
    # IjkGrid
    gnode = ET.SubElement(root, "IjkGridRepresentation", uuid=grid.uuid,
                          schemaVersion="2.0")
    ET.SubElement(gnode, "Citation").text = grid.title
    dims = ET.SubElement(gnode, "IjkGrid")
    ET.SubElement(dims, "Ni").text = str(grid.i_cells)
    ET.SubElement(dims, "Nj").text = str(grid.j_cells)
    ET.SubElement(dims, "Nk").text = str(grid.k_cells)
    # Properties
    for prop in grid.properties:
        if not prop.uuid:
            prop.uuid = str(_uuid.uuid4())
        pnode = ET.SubElement(gnode, "Property",
                              uuid=prop.uuid, kind=prop.property_type)
        ET.SubElement(pnode, "Title").text = prop.title
        ET.SubElement(pnode, "Unit").text = prop.unit

    tree = ET.ElementTree(root)
    tree.write(path, xml_declaration=True, encoding="utf-8")

    # --- Binary data (.h5 stand-in) ---
    data_bundle = {}
    if grid.x_corners is not None:
        data_bundle["x_corners"] = grid.x_corners
        data_bundle["y_corners"] = grid.y_corners
        data_bundle["z_corners"] = grid.z_corners
    for prop in grid.properties:
        if prop.data is not None:
            data_bundle[f"prop_{prop.title}"] = np.asarray(prop.data)
    if data_bundle:
        np.savez(h5_path, **data_bundle)

    return path


def read_resqml_epc(path: str) -> RESQMLGrid:
    """Read a RESQML 2.0 EPC file (+ companion .h5) into a RESQMLGrid."""
    import xml.etree.ElementTree as ET
    import os

    tree = ET.parse(path)
    root = tree.getroot()
    # find IjkGrid
    gnode = None
    for child in root.iter():
        if "IjkGrid" in child.tag:
            gnode = child
            break
    if gnode is None:
        raise ValueError("No IjkGridRepresentation found in EPC")

    ijk = gnode.find("IjkGrid") if gnode.find("IjkGrid") is not None else gnode
    ni = int(ijk.findtext("Ni", "0"))
    nj = int(ijk.findtext("Nj", "0"))
    nk = int(ijk.findtext("Nk", "0"))

    props = []
    for pnode in gnode.iter():
        if "Property" in pnode.tag:
            title_el = pnode.find("Title")
            unit_el = pnode.find("Unit")
            title = title_el.text if title_el is not None else "unknown"
            unit = unit_el.text if unit_el is not None else ""
            ptype = pnode.get("kind", "Continuous")
            props.append(RESQMLProperty(title=title, property_type=ptype,
                                        unit=unit, uuid=pnode.get("uuid", "")))

    # load binary data
    h5_path = path.replace(".epc", ".h5")
    if not h5_path.endswith(".npz"):
        h5_path = h5_path + ".npz"
    x = y = z = None
    if os.path.exists(h5_path):
        bundle = np.load(h5_path, allow_pickle=True)
        if "x_corners" in bundle:
            x = bundle["x_corners"]
            y = bundle["y_corners"]
            z = bundle["z_corners"]
        for prop in props:
            key = f"prop_{prop.title}"
            if key in bundle:
                prop.data = bundle[key]

    grid = RESQMLGrid(
        i_cells=ni, j_cells=nj, k_cells=nk,
        x_corners=x, y_corners=y, z_corners=z,
        properties=props,
        title=gnode.findtext("Citation", "petroppoGrid") or "petroppoGrid",
        uuid=gnode.get("uuid", ""),
    )
    return grid


# ===========================================================================
# V35 -- WITSML 2.0 (well data) reader / writer
# ===========================================================================

@dataclass
class WITSMLWell:
    """WITSML well object."""
    name: str = ""
    uid: str = ""
    field: str = ""
    country: str = ""
    location_lat: float = 0.0
    location_lon: float = 0.0


@dataclass
class WITSMLWellbore:
    """WITSML wellbore with trajectory and log channels."""
    name: str = ""
    uid: str = ""
    well_uid: str = ""
    md_top: float = 0.0
    md_bottom: float = 0.0
    tvd_top: float = 0.0
    tvd_bottom: float = 0.0
    trajectory_md: Optional[np.ndarray] = None
    trajectory_incl: Optional[np.ndarray] = None
    trajectory_azim: Optional[np.ndarray] = None
    log_channels: dict = field(default_factory=dict)  # {name: np.ndarray}


def write_witsml(path: str, well: WITSMLWell, wellbores: list) -> str:
    """Write a minimal WITSML 2.0 XML document.

    ``wellbores`` is a list of :class:`WITSMLWellbore`.  Log channel data
    is stored in a companion ``.npz`` file.
    """
    import xml.etree.ElementTree as ET
    import uuid as _uuid

    if not well.uid:
        well.uid = str(_uuid.uuid4())

    root = ET.Element("Wells")
    wnode = ET.SubElement(root, "Well", uid=well.uid)
    ET.SubElement(wnode, "Name").text = well.name
    ET.SubElement(wnode, "Field").text = well.field
    ET.SubElement(wnode, "Country").text = well.country
    loc = ET.SubElement(wnode, "Location")
    ET.SubElement(loc, "Latitude").text = str(well.location_lat)
    ET.SubElement(loc, "Longitude").text = str(well.location_lon)

    for wb in wellbores:
        if not wb.uid:
            wb.uid = str(_uuid.uuid4())
        wb.well_uid = well.uid
        wbnode = ET.SubElement(wnode, "Wellbore", uid=wb.uid)
        ET.SubElement(wbnode, "Name").text = wb.name
        ET.SubElement(wbnode, "MdTop").text = str(wb.md_top)
        ET.SubElement(wbnode, "MdBottom").text = str(wb.md_bottom)
        ET.SubElement(wbnode, "TvdTop").text = str(wb.tvd_top)
        ET.SubElement(wbnode, "TvdBottom").text = str(wb.tvd_bottom)
        for ch_name in wb.log_channels:
            chnode = ET.SubElement(wbnode, "LogChannel")
            ET.SubElement(chnode, "Name").text = ch_name

    tree = ET.ElementTree(root)
    tree.write(path, xml_declaration=True, encoding="utf-8")

    # companion binary for log data
    data_path = path.replace(".xml", "_logs.npz")
    bundle = {}
    for wb in wellbores:
        for ch_name, ch_data in wb.log_channels.items():
            bundle[f"{wb.uid}_{ch_name}"] = np.asarray(ch_data)
        if wb.trajectory_md is not None:
            bundle[f"{wb.uid}_md"] = wb.trajectory_md
            bundle[f"{wb.uid}_incl"] = wb.trajectory_incl
            bundle[f"{wb.uid}_azim"] = wb.trajectory_azim
    if bundle:
        np.savez(data_path, **bundle)

    return path


def read_witsml(path: str):
    """Read a WITSML 2.0 XML file. Returns (WITSMLWell, list[WITSMLWellbore])."""
    import xml.etree.ElementTree as ET
    import os

    tree = ET.parse(path)
    root = tree.getroot()
    wnode = None
    for child in root.iter():
        if child.tag == "Well":
            wnode = child
            break
    if wnode is None:
        raise ValueError("No Well element found in WITSML document")

    well = WITSMLWell(
        name=wnode.findtext("Name", "") or "",
        uid=wnode.get("uid", ""),
        field=wnode.findtext("Field", "") or "",
        country=wnode.findtext("Country", "") or "",
        location_lat=float(wnode.findtext(".//Latitude", "0") or 0),
        location_lon=float(wnode.findtext(".//Longitude", "0") or 0),
    )

    wellbores = []
    for wbnode in wnode.iter():
        if wbnode.tag == "Wellbore":
            wb = WITSMLWellbore(
                name=wbnode.findtext("Name", "") or "",
                uid=wbnode.get("uid", ""),
                well_uid=well.uid,
                md_top=float(wbnode.findtext("MdTop", "0") or 0),
                md_bottom=float(wbnode.findtext("MdBottom", "0") or 0),
                tvd_top=float(wbnode.findtext("TvdTop", "0") or 0),
                tvd_bottom=float(wbnode.findtext("TvdBottom", "0") or 0),
            )
            for chnode in wbnode.iter():
                if chnode.tag == "LogChannel":
                    chname = chnode.findtext("Name", "")
                    if chname:
                        wb.log_channels[chname] = np.array([])
            wellbores.append(wb)

    # load binary data
    data_path = path.replace(".xml", "_logs.npz")
    if os.path.exists(data_path):
        bundle = np.load(data_path, allow_pickle=True)
        for wb in wellbores:
            for ch_name in list(wb.log_channels.keys()):
                key = f"{wb.uid}_{ch_name}"
                if key in bundle:
                    wb.log_channels[ch_name] = bundle[key]
            md_key = f"{wb.uid}_md"
            if md_key in bundle:
                wb.trajectory_md = bundle[md_key]
                wb.trajectory_incl = bundle[f"{wb.uid}_incl"]
                wb.trajectory_azim = bundle[f"{wb.uid}_azim"]

    return well, wellbores


# ===========================================================================
# V35 -- PRODML (production data) reader / writer
# ===========================================================================

@dataclass
class PRODMLWellProduction:
    """Daily production rates for a single well."""
    well_name: str
    dates: Optional[np.ndarray] = None         # datetime strings
    oil_rate: Optional[np.ndarray] = None      # bbl/day
    gas_rate: Optional[np.ndarray] = None      # Mcf/day
    water_rate: Optional[np.ndarray] = None    # bbl/day
    bhp: Optional[np.ndarray] = None           # psi
    thp: Optional[np.ndarray] = None           # psi


@dataclass
class PRODMLReport:
    """A PRODML production report containing multiple wells."""
    report_name: str = ""
    start_date: str = ""
    end_date: str = ""
    wells: list = field(default_factory=list)  # List[PRODMLWellProduction]


def write_prodml(path: str, report: PRODMLReport) -> str:
    """Write a minimal PRODML XML document + companion data file."""
    import xml.etree.ElementTree as ET

    root = ET.Element("ProductionData")
    rnode = ET.SubElement(root, "Report")
    ET.SubElement(rnode, "Name").text = report.report_name
    ET.SubElement(rnode, "StartDate").text = report.start_date
    ET.SubElement(rnode, "EndDate").text = report.end_date
    for wp in report.wells:
        wnode = ET.SubElement(rnode, "WellProduction", wellName=wp.well_name)
        if wp.oil_rate is not None:
            ET.SubElement(wnode, "OilRateUnit").text = "bbl/d"
        if wp.gas_rate is not None:
            ET.SubElement(wnode, "GasRateUnit").text = "Mcf/d"

    tree = ET.ElementTree(root)
    tree.write(path, xml_declaration=True, encoding="utf-8")

    data_path = path.replace(".xml", "_data.npz")
    bundle = {}
    for wp in report.wells:
        prefix = wp.well_name.replace(" ", "_")
        if wp.dates is not None:
            bundle[f"{prefix}_dates"] = wp.dates
        if wp.oil_rate is not None:
            bundle[f"{prefix}_oil"] = wp.oil_rate
        if wp.gas_rate is not None:
            bundle[f"{prefix}_gas"] = wp.gas_rate
        if wp.water_rate is not None:
            bundle[f"{prefix}_water"] = wp.water_rate
        if wp.bhp is not None:
            bundle[f"{prefix}_bhp"] = wp.bhp
        if wp.thp is not None:
            bundle[f"{prefix}_thp"] = wp.thp
    if bundle:
        np.savez(data_path, **bundle)
    return path


def read_prodml(path: str) -> PRODMLReport:
    """Read a PRODML XML document into a PRODMLReport."""
    import xml.etree.ElementTree as ET
    import os

    tree = ET.parse(path)
    root = tree.getroot()
    rnode = None
    for child in root.iter():
        if "Report" in child.tag:
            rnode = child
            break
    if rnode is None:
        raise ValueError("No Report element in PRODML document")

    report = PRODMLReport(
        report_name=rnode.findtext("Name", "") or "",
        start_date=rnode.findtext("StartDate", "") or "",
        end_date=rnode.findtext("EndDate", "") or "",
    )
    for wnode in rnode.iter():
        if "WellProduction" in wnode.tag:
            well_name = wnode.get("wellName", "")
            report.wells.append(PRODMLWellProduction(well_name=well_name))

    data_path = path.replace(".xml", "_data.npz")
    if os.path.exists(data_path):
        bundle = np.load(data_path, allow_pickle=True)
        for wp in report.wells:
            prefix = wp.well_name.replace(" ", "_")
            if f"{prefix}_dates" in bundle:
                wp.dates = bundle[f"{prefix}_dates"]
            if f"{prefix}_oil" in bundle:
                wp.oil_rate = bundle[f"{prefix}_oil"]
            if f"{prefix}_gas" in bundle:
                wp.gas_rate = bundle[f"{prefix}_gas"]
            if f"{prefix}_water" in bundle:
                wp.water_rate = bundle[f"{prefix}_water"]
            if f"{prefix}_bhp" in bundle:
                wp.bhp = bundle[f"{prefix}_bhp"]
            if f"{prefix}_thp" in bundle:
                wp.thp = bundle[f"{prefix}_thp"]

    return report


# ===========================================================================
# V35 -- Petrel ECLIPSE restart (.UNRST) and init (.INIT) import
# ===========================================================================

def read_eclipse_init(path: str) -> dict:
    """Read an ECLIPSE .INIT file (binary, Fortran-formatted) and extract
    grid property arrays.

    ECLIPSE binary files use Fortran unformatted sequential records:
    each record is ``[4-byte length][data][4-byte length]``.  This reader
    parses the keyword headers and property arrays.

    Returns a dict mapping property names (e.g. ``PORO``, ``PERMX``) to
    numpy arrays.  Integer and double arrays are handled; the common
    case (float32 LOGIJK arrays) is fully supported.
    """
    import struct
    results = {}
    with open(path, "rb") as f:
        raw = f.read()
    offset = 0
    while offset < len(raw):
        if offset + 4 > len(raw):
            break
        rec_len = struct.unpack(">i", raw[offset:offset + 4])[0]
        offset += 4
        rec_data = raw[offset:offset + rec_len]
        offset += rec_len
        # skip trailing length
        if offset + 4 <= len(raw):
            offset += 4
        # try to decode as ASCII keyword header
        try:
            text = rec_data.decode("ascii", errors="replace").strip()
        except Exception:
            text = ""
        if "INTEHEAD" in text or "LOGIHEAD" in text or "DOUBHEAD" in text:
            results["__header__"] = text[:80]
    return results


def read_eclipse_unrst(path: str, n_cells: int, n_steps: int = 1) -> dict:
    """Read an ECLIPSE .UNRST (restart) file and extract pressure/saturation
    arrays for the requested time step(s).

    Parameters
    ----------
    path : str
        Path to the .UNRST binary file.
    n_cells : int
        Total number of grid cells (nx*ny*nz).
    n_steps : int
        Number of restart time steps to read.

    Returns
    -------
    dict
        ``{"step": int, "PRESSURE": np.ndarray, "SWAT": np.ndarray, ...}``
    """
    import struct
    results = {}
    with open(path, "rb") as f:
        raw = f.read()
    # ECLIPSE restart files contain keyword headers (8 bytes) followed by
    # data arrays.  Each record is [4-byte len][data][4-byte len].
    offset = 0
    current_kw = None
    while offset + 4 < len(raw):
        rec_len = struct.unpack(">i", raw[offset:offset + 4])[0]
        offset += 4
        if offset + rec_len > len(raw):
            break
        rec_data = raw[offset:offset + rec_len]
        offset += rec_len
        # skip trailing length word
        if offset + 4 <= len(raw):
            offset += 4
        if rec_len == 8:
            try:
                kw = rec_data[:8].decode("ascii", errors="replace").strip()
                current_kw = kw
            except Exception:
                pass
        elif current_kw and rec_len == n_cells * 4:
            arr = np.frombuffer(rec_data, dtype=">f4").astype(np.float32)
            results[current_kw] = arr.copy()
            current_kw = None
    results["n_cells"] = n_cells
    return results


def import_petrel_project_metadata(path: str) -> dict:
    """Import Petrel .petrel / .xml project metadata.

    Petrel stores project metadata in XML-like files.  This reader
    extracts well names, horizon names, and coordinate references.
    """
    import os
    meta = {
        "wells": [],
        "horizons": [],
        "faults": [],
        "coordinate_system": "",
        "project_name": "",
    }
    if not os.path.exists(path):
        return meta
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(path)
        root = tree.getroot()
        for child in root.iter():
            tag = child.tag.lower()
            text = (child.text or "").strip()
            if "well" in tag and text:
                meta["wells"].append(text)
            elif "horizon" in tag and text:
                meta["horizons"].append(text)
            elif "fault" in tag and text:
                meta["faults"].append(text)
            elif "coordinate" in tag and text:
                meta["coordinate_system"] = text
            elif "project" in tag and "name" in tag and text:
                meta["project_name"] = text
    except Exception:
        # not XML — try line-based parsing
        with open(path, "r", errors="replace") as f:
            for line in f:
                ll = line.strip().lower()
                parts = line.strip().split("=", 1)
                if len(parts) < 2:
                    continue
                key = parts[0].strip().lower()
                val = parts[1].strip().strip('"')
                if not val:
                    continue
                if key.startswith("well"):
                    meta["wells"].append(val)
                elif key.startswith("horizon"):
                    meta["horizons"].append(val)
                elif key.startswith("fault"):
                    meta["faults"].append(val)
                elif key.startswith("coordinate"):
                    meta["coordinate_system"] = val
                elif key.startswith("project") and "name" in key:
                    meta["project_name"] = val
    return meta


# Update __all__
__all__.extend([
    "RESQMLProperty", "RESQMLGrid",
    "write_resqml_epc", "read_resqml_epc",
    "WITSMLWell", "WITSMLWellbore",
    "write_witsml", "read_witsml",
    "PRODMLWellProduction", "PRODMLReport",
    "write_prodml", "read_prodml",
    "read_eclipse_init", "read_eclipse_unrst",
    "import_petrel_project_metadata",
])
