"""petroppo V35 — Diagnostics & self-healing layer.

Closes the technical-support gap with Schlumberger's global support by
providing built-in auto-diagnostics, self-healing, and auto-generated
documentation:

* :class:`DiagnosticsEngine` — runs health checks on all petroppo modules
  and reports status (healthy / degraded / failed) with detailed diagnostics.
* :class:`SelfHealer` — automatically retries failed operations with
  fallback strategies (e.g., GPU→CPU, parallel→serial, high-res→low-res).
* :class:`ErrorTaxonomy` — classifies errors into categories with recovery
  suggestions (memory, I/O, numerical, dependency, permission).
* :func:`generate_api_docs` — auto-generates API reference documentation
  from module introspection.
* :func:`health_report` — produces a human-readable health report.

This module makes petroppo self-diagnosing and self-healing, reducing the
need for external technical support.
"""

from __future__ import annotations

import os
import sys
import time
import traceback
import importlib
import inspect
import json
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Callable, Tuple
from enum import Enum

__all__ = [
    "HealthStatus",
    "HealthCheck",
    "DiagnosticsEngine",
    "SelfHealer",
    "ErrorCategory",
    "ErrorTaxonomy",
    "generate_api_docs",
    "health_report",
]


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    FAILED = "failed"
    UNKNOWN = "unknown"


@dataclass
class HealthCheck:
    """Result of a single health check."""
    name: str
    status: HealthStatus = HealthStatus.UNKNOWN
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    elapsed_s: float = 0.0


# ---------------------------------------------------------------------------
# Error taxonomy
# ---------------------------------------------------------------------------

class ErrorCategory(str, Enum):
    MEMORY = "memory"
    IO = "io"
    NUMERICAL = "numerical"
    DEPENDENCY = "dependency"
    PERMISSION = "permission"
    TIMEOUT = "timeout"
    CONFIGURATION = "configuration"
    UNKNOWN = "unknown"


@dataclass
class ErrorTaxonomy:
    """Classifies errors and provides recovery suggestions."""

    SUGGESTIONS: Dict[ErrorCategory, List[str]] = field(default_factory=lambda: {
        ErrorCategory.MEMORY: [
            "Reduce volume size or use chunked processing (ChunkedVolume)",
            "Enable out-of-core mode in performance module",
            "Close unused project artifacts",
        ],
        ErrorCategory.IO: [
            "Check file permissions and disk space",
            "Verify file format (SEG-Y, LAS, RESQML)",
            "Use memory-mapped I/O (mmap_segy_read)",
        ],
        ErrorCategory.NUMERICAL: [
            "Check for NaN/Inf in input data",
            "Verify data normalization",
            "Reduce iteration count or relax convergence criteria",
        ],
        ErrorCategory.DEPENDENCY: [
            "Install missing package: pip install <package>",
            "Check Python version compatibility (3.11+)",
            "Update to latest petroppo version",
        ],
        ErrorCategory.PERMISSION: [
            "Check user role and permissions (RBAC)",
            "Contact admin for elevated access",
            "Verify file system permissions",
        ],
        ErrorCategory.TIMEOUT: [
            "Increase timeout setting",
            "Reduce problem size",
            "Use parallel processing (parallel_map)",
        ],
        ErrorCategory.CONFIGURATION: [
            "Check configuration file syntax",
            "Verify parameter ranges",
            "Reset to default configuration",
        ],
        ErrorCategory.UNKNOWN: [
            "Check the error traceback",
            "Report to petroppo support with full diagnostics",
            "Try running the diagnostics engine",
        ],
    })

    ERROR_PATTERNS: Dict[ErrorCategory, List[str]] = field(default_factory=lambda: {
        ErrorCategory.MEMORY: ["MemoryError", "OutOfMemory", "ENOMEM",
                               "out of memory", "malloc failed"],
        ErrorCategory.IO: ["FileNotFoundError", "IOError", "OSError",
                           "PermissionError", "disk full", "No space left"],
        ErrorCategory.NUMERICAL: ["ValueError", "FloatingPointError",
                                  "NaN", "Inf", "singular matrix",
                                  "convergence"],
        ErrorCategory.DEPENDENCY: ["ImportError", "ModuleNotFoundError",
                                   "No module named", "cannot import"],
        ErrorCategory.PERMISSION: ["PermissionError", "AccessDenied",
                                   "403", "forbidden"],
        ErrorCategory.TIMEOUT: ["TimeoutError", "timed out", "deadline"],
        ErrorCategory.CONFIGURATION: ["ConfigError", "KeyError",
                                      "invalid parameter"],
    })

    def classify(self, error: Exception) -> ErrorCategory:
        """Classify an exception into a category."""
        msg = str(error)
        type_name = type(error).__name__
        for cat, patterns in self.ERROR_PATTERNS.items():
            for p in patterns:
                if p.lower() in msg.lower() or p in type_name:
                    return cat
        return ErrorCategory.UNKNOWN

    def suggest(self, error: Exception) -> List[str]:
        """Get recovery suggestions for an error."""
        cat = self.classify(error)
        return self.SUGGESTIONS.get(cat, self.SUGGESTIONS[ErrorCategory.UNKNOWN])


# ---------------------------------------------------------------------------
# Self-healer
# ---------------------------------------------------------------------------

@dataclass
class SelfHealer:
    """Automatic retry and fallback for failed operations.

    Strategies:
    * **retry** — retry with exponential backoff.
    * **fallback** — try a fallback function if the primary fails.
    * **degrade** — reduce problem size and retry.
    """

    taxonomy: ErrorTaxonomy = field(default_factory=ErrorTaxonomy)
    max_retries: int = 3
    base_delay: float = 0.1

    def execute(self, fn: Callable, *args,
                fallback: Optional[Callable] = None,
                degrade: Optional[Callable] = None,
                **kwargs) -> Tuple[bool, Any, Optional[str]]:
        """Execute a function with self-healing.

        Returns ``(success, result, error_message)``.
        """
        last_error = None
        for attempt in range(self.max_retries):
            try:
                result = fn(*args, **kwargs)
                return True, result, None
            except Exception as e:
                last_error = e
                cat = self.taxonomy.classify(e)
                # Memory error → try degrade
                if cat == ErrorCategory.MEMORY and degrade:
                    try:
                        result = degrade(*args, **kwargs)
                        return True, result, "degraded"
                    except Exception as e2:
                        last_error = e2
                        continue
                # Any error → try fallback
                if fallback and attempt == self.max_retries - 1:
                    try:
                        result = fallback(*args, **kwargs)
                        return True, result, "fallback"
                    except Exception as e2:
                        last_error = e2
                # Exponential backoff
                delay = self.base_delay * (2 ** attempt)
                time.sleep(delay)
        return False, None, f"{type(last_error).__name__}: {last_error}"


# ---------------------------------------------------------------------------
# Diagnostics engine
# ---------------------------------------------------------------------------

class DiagnosticsEngine:
    """Run health checks on all petroppo modules."""

    def __init__(self):
        self.checks: List[HealthCheck] = []
        self._registered: Dict[str, Callable] = {}

    def register(self, name: str, check_fn: Callable[[], HealthCheck]):
        """Register a health check."""
        self._registered[name] = check_fn

    def _check_import(self, module_name: str) -> HealthCheck:
        """Check if a module can be imported."""
        t0 = time.time()
        try:
            mod = importlib.import_module(module_name)
            return HealthCheck(
                name=module_name, status=HealthStatus.HEALTHY,
                message=f"OK ({len(dir(mod))} symbols)",
                elapsed_s=time.time() - t0,
            )
        except Exception as e:
            return HealthCheck(
                name=module_name, status=HealthStatus.FAILED,
                message=str(e), elapsed_s=time.time() - t0,
            )

    def _check_memory(self) -> HealthCheck:
        """Check available memory."""
        t0 = time.time()
        try:
            import resource
            mem = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
            status = HealthStatus.HEALTHY if mem < 4096 else HealthStatus.DEGRADED
            return HealthCheck(
                name="memory", status=status,
                message=f"Peak RSS: {mem:.0f} MB",
                details={"peak_mb": mem},
                elapsed_s=time.time() - t0,
            )
        except Exception as e:
            return HealthCheck(
                name="memory", status=HealthStatus.UNKNOWN,
                message=str(e), elapsed_s=time.time() - t0,
            )

    def _check_dependencies(self) -> HealthCheck:
        """Check required Python packages."""
        t0 = time.time()
        required = ["numpy", "scipy", "sklearn"]
        missing = []
        for pkg in required:
            try:
                importlib.import_module(pkg)
            except ImportError:
                missing.append(pkg)
        if missing:
            return HealthCheck(
                name="dependencies", status=HealthStatus.FAILED,
                message=f"Missing: {missing}",
                details={"missing": missing},
                elapsed_s=time.time() - t0,
            )
        return HealthCheck(
            name="dependencies", status=HealthStatus.HEALTHY,
            message=f"All {len(required)} packages present",
            elapsed_s=time.time() - t0,
        )

    def _check_disk(self) -> HealthCheck:
        """Check disk space in /tmp."""
        t0 = time.time()
        try:
            stat = os.statvfs("/tmp")
            free_gb = (stat.f_bavail * stat.f_frsize) / (1024 ** 3)
            status = HealthStatus.HEALTHY if free_gb > 1 else HealthStatus.DEGRADED
            return HealthCheck(
                name="disk", status=status,
                message=f"Free: {free_gb:.1f} GB",
                details={"free_gb": free_gb},
                elapsed_s=time.time() - t0,
            )
        except Exception as e:
            return HealthCheck(
                name="disk", status=HealthStatus.UNKNOWN,
                message=str(e), elapsed_s=time.time() - t0,
            )

    def run_all(self) -> List[HealthCheck]:
        """Run all registered + built-in health checks."""
        self.checks = []
        # Built-in checks
        self.checks.append(self._check_dependencies())
        self.checks.append(self._check_memory())
        self.checks.append(self._check_disk())
        # Module import checks
        modules = [
            "petroppo.physics.seismic.horizon_ai",
            "petroppo.physics.seismic.fault_ai",
            "petroppo.physics.seismic.acoustic_inversion",
            "petroppo.physics.uncertainty_p10p50p90",
            "petroppo.platform.viz3d_engine",
            "petroppo.platform.performance",
            "petroppo.platform.collaboration",
            "petroppo.platform.security",
            "petroppo.platform.cloud",
            "petroppo.platform.diagnostics",
        ]
        for mod in modules:
            self.checks.append(self._check_import(mod))
        # Custom registered checks
        for name, fn in self._registered.items():
            try:
                self.checks.append(fn())
            except Exception as e:
                self.checks.append(HealthCheck(
                    name=name, status=HealthStatus.FAILED, message=str(e),
                ))
        return self.checks

    @property
    def summary(self) -> dict:
        """Aggregate health summary."""
        if not self.checks:
            self.run_all()
        healthy = sum(1 for c in self.checks if c.status == HealthStatus.HEALTHY)
        degraded = sum(1 for c in self.checks if c.status == HealthStatus.DEGRADED)
        failed = sum(1 for c in self.checks if c.status == HealthStatus.FAILED)
        total = len(self.checks)
        overall = (HealthStatus.HEALTHY if failed == 0 and degraded == 0
                   else HealthStatus.DEGRADED if failed == 0
                   else HealthStatus.FAILED)
        return {
            "overall": overall.value,
            "healthy": healthy,
            "degraded": degraded,
            "failed": failed,
            "total": total,
            "checks": [asdict(c) for c in self.checks],
        }


# ---------------------------------------------------------------------------
# Auto-generated API docs
# ---------------------------------------------------------------------------

def generate_api_docs(package_name: str = "petroppo",
                      output_path: str = "API_REFERENCE.md") -> str:
    """Auto-generate API reference documentation from introspection.

    Walks all submodules of ``package_name``, extracts public classes and
    functions with their docstrings and signatures, and writes a Markdown
    reference file.
    """
    lines = [f"# {package_name} — API Reference\n"]
    lines.append(f"Auto-generated on {time.strftime('%Y-%m-%d %H:%M')}\n")

    try:
        pkg = importlib.import_module(package_name)
    except ImportError:
        return f"# Error: cannot import {package_name}\n"

    # Collect modules
    pkg_dir = os.path.dirname(pkg.__file__)
    modules = []
    for root, _, files in os.walk(pkg_dir):
        for f in files:
            if f.endswith(".py") and not f.startswith("_"):
                rel = os.path.relpath(os.path.join(root, f), pkg_dir)
                mod_name = (f"{package_name}."
                            + rel.replace(os.sep, ".").replace(".py", ""))
                modules.append(mod_name)
    modules.sort()

    for mod_name in modules:
        try:
            mod = importlib.import_module(mod_name)
        except Exception:
            continue
        public = [
            (name, obj) for name, obj in inspect.getmembers(mod)
            if (inspect.isclass(obj) or inspect.isfunction(obj))
            and not name.startswith("_")
            and obj.__module__ == mod_name
        ]
        if not public:
            continue
        lines.append(f"\n## {mod_name}\n")
        if mod.__doc__:
            lines.append(f"{mod.__doc__.strip()}\n")
        for name, obj in sorted(public):
            kind = "class" if inspect.isclass(obj) else "function"
            lines.append(f"### `{name}` ({kind})\n")
            if obj.__doc__:
                lines.append(f"{obj.__doc__.strip()}\n")
            try:
                sig = inspect.signature(obj)
                lines.append(f"**Signature:** `{name}{sig}`\n")
            except (ValueError, TypeError):
                pass

    content = "\n".join(lines)
    with open(output_path, "w") as f:
        f.write(content)
    return content


# ---------------------------------------------------------------------------
# Human-readable health report
# ---------------------------------------------------------------------------

def health_report() -> str:
    """Generate a human-readable health report."""
    engine = DiagnosticsEngine()
    engine.run_all()
    s = engine.summary
    lines = [
        "=" * 60,
        "petroppo V35 — Health Report",
        "=" * 60,
        f"Overall status: {s['overall'].upper()}",
        f"  Healthy:  {s['healthy']}/{s['total']}",
        f"  Degraded: {s['degraded']}/{s['total']}",
        f"  Failed:   {s['failed']}/{s['total']}",
        "",
        "Detailed checks:",
    ]
    for c in s["checks"]:
        icon = {"healthy": "✅", "degraded": "⚠️ ",
                "failed": "❌", "unknown": "❓"}.get(c["status"], "?")
        lines.append(f"  {icon} {c['name']}: {c['message']} "
                     f"({c['elapsed_s']:.3f}s)")
    lines.append("=" * 60)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Register default diagnostics on import
# ---------------------------------------------------------------------------

_default_engine = DiagnosticsEngine()
