"""petroppo V37 -- Distributed & multiprocessing compute layer.

This module turns petroppo from a "program for two people" into one that
can absorb company-scale workloads.  It provides a **task-graph executor**
that runs a DAG of dependent compute tasks across multiple processes with
fault tolerance, work-stealing, and live progress reporting -- the same
primitives that production distributed frameworks (Dask, Airflow, Luigi)
are built on, but in a zero-dependency implementation that fits petroppo's
"only numpy/scipy/sklearn" pinning.

Why a task graph, not just a flat ``ProcessPoolExecutor.map``?
--------------------------------------------------------------

Reservoir workflows are not flat maps.  A V36 uncertainty-propagation run
is a four-stage chain (seismic -> geology -> petrophysics -> reservoir)
where each stage consumes the previous stage's outputs and may itself fan
out into hundreds of Monte-Carlo realizations.  A flat ``map`` forces the
caller to materialise the entire fan-out in memory before submitting.  A
task graph lets the executor schedule realizations as their upstream
inputs become ready, keeping peak memory bounded and allowing the
scheduler to retry only the failed tasks, not the whole graph.

Design
------

* :class:`Task` -- a single unit of work: a callable, its arguments
  (which may reference other tasks' outputs via :class:`TaskRef`), a
  priority, a retry count, and a resource cost estimate.
* :class:`TaskGraph` -- a DAG of tasks with dependency edges.  Validates
  acyclicity on construction.  Supports topological scheduling.
* :class:`DistributedExecutor` -- runs a :class:`TaskGraph` on a
  ``ProcessPoolExecutor`` (CPU-bound) or ``ThreadPoolExecutor`` (I/O-bound)
  pool.  Features:
    - **Fault-tolerant retry**: a task that raises is retried up to
      ``max_retries`` times with exponential backoff before being marked
      failed.
    - **Work-stealing**: idle workers pull ready tasks from the queue;
      no static assignment, so a slow task does not stall fast workers.
    - **Progress reporting**: a callback receives
      :class:`ProgressEvent` objects as tasks start/complete/fail, so a
      GUI or CLI can show a live progress bar.
    - **Result persistence**: completed task outputs are cached so a
      re-run after a crash only re-executes the failed subtree.
    - **Deterministic mode**: when ``deterministic=True``, the executor
      processes ready tasks in priority-then-insertion order and uses a
      fixed seed for any retry backoff jitter, so two runs of the same
      graph produce identical results (required for V37 reproducible
      pipelines).
* :class:`ScalingBenchmark` -- measures strong-scaling efficiency
  (speedup vs. number of workers) on a synthetic CPU-bound workload,
  used by the V37 ``industrial-distributed-scaling`` benchmark case.

The executor never requires a cluster: it runs on a single multi-core
box via the stdlib ``concurrent.futures``.  The same :class:`TaskGraph`
API is what a future MPI/Dask backend would consume, so the user code
does not change when the backend scales up.

References
----------
* Dean, J. & Ghemawat, S. (2004). *MapReduce: Simplified Data Processing
  on Large Clusters*, OSDI.
* Zaharia, M. et al. (2012). *Resilient Distributed Datasets*, NSDI.
* Verbaas, F. et al. (2018). *Dask: Parallel computation with task
  scheduling*, Journal of Open Source Software.
"""

from __future__ import annotations

import os
import time
import random
import hashlib
import traceback
from dataclasses import dataclass, field
from enum import Enum
from typing import (Any, Callable, Dict, List, Optional, Set, Tuple, Union)
from concurrent.futures import (ProcessPoolExecutor, ThreadPoolExecutor,
                                Future)
from threading import Lock, Condition
from queue import PriorityQueue

__all__ = [
    "TaskState",
    "Task",
    "TaskRef",
    "TaskGraph",
    "ProgressEvent",
    "ProgressKind",
    "TaskResult",
    "DistributedExecutor",
    "ScalingBenchmark",
    "ScalingResult",
    "validate_dag",
    "topological_order",
]


# ---------------------------------------------------------------------------
# Task and graph
# ---------------------------------------------------------------------------

class TaskState(str, Enum):
    """Lifecycle state of a task."""
    PENDING = "pending"
    READY = "ready"        # all deps satisfied, queued for execution
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ProgressKind(str, Enum):
    """Kind of progress event emitted by the executor."""
    TASK_READY = "task_ready"
    TASK_START = "task_start"
    TASK_DONE = "task_done"
    TASK_FAILED = "task_failed"
    TASK_RETRY = "task_retry"
    GRAPH_DONE = "graph_done"


@dataclass(order=True)
class _QueueEntry:
    """Priority-queue entry: (priority, seq, task_id)."""
    priority: int
    seq: int
    task_id: str = field(compare=False)


class TaskRef:
    """A reference to another task's output, used as an argument.

    When a task is submitted to the executor, any :class:`TaskRef` in its
    args/kwargs is replaced with the resolved output of the referenced
    task (which must have completed already).  This is how data flows
    through the DAG.
    """

    __slots__ = ("task_id",)

    def __init__(self, task_id: str):
        self.task_id = task_id

    def __repr__(self) -> str:
        return f"TaskRef({self.task_id!r})"


@dataclass
class Task:
    """A single unit of work in a task graph.

    Parameters
    ----------
    task_id : str
        Unique identifier within the graph.
    fn : callable
        The function to execute.  Must be picklable for the
        ``ProcessPoolExecutor`` backend (i.e. a module-level function or
        a functools.partial of one).
    args : tuple
        Positional arguments.  May contain :class:`TaskRef` objects,
        which are resolved to upstream outputs before execution.
    kwargs : dict
        Keyword arguments (also may contain TaskRefs).
    deps : list of str
        IDs of tasks whose outputs this task consumes (used for
        scheduling; args with TaskRefs are auto-added to deps).
    priority : int
        Lower = higher priority (runs first among ready tasks).
    max_retries : int
        Number of times to retry on failure before giving up.
    cost : float
        Estimated relative cost (for scheduling hints; default 1.0).
    """
    task_id: str
    fn: Callable
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    deps: List[str] = field(default_factory=list)
    priority: int = 0
    max_retries: int = 2
    cost: float = 1.0
    state: TaskState = TaskState.PENDING
    attempts: int = 0
    error: Optional[str] = None
    result: Any = None
    start_time: float = 0.0
    end_time: float = 0.0

    def __post_init__(self):
        # Auto-add deps from TaskRef args/kwargs.
        ref_deps = set()
        for a in self.args:
            if isinstance(a, TaskRef):
                ref_deps.add(a.task_id)
        for v in self.kwargs.values():
            if isinstance(v, TaskRef):
                ref_deps.add(v.task_id)
        for d in ref_deps:
            if d not in self.deps:
                self.deps.append(d)


class TaskGraph:
    """A directed acyclic graph of tasks.

    Constructed incrementally with :meth:`add`, then validated
    (:meth:`validate`) and executed (:meth:`run` via
    :class:`DistributedExecutor`).
    """

    def __init__(self, name: str = "graph"):
        self.name = name
        self.tasks: Dict[str, Task] = {}

    def add(self, task: Task) -> "TaskGraph":
        if task.task_id in self.tasks:
            raise ValueError(f"duplicate task id {task.task_id!r}")
        self.tasks[task.task_id] = task
        return self

    def get(self, task_id: str) -> Task:
        return self.tasks[task_id]

    def roots(self) -> List[str]:
        """Task IDs with no dependencies (entry points of the DAG)."""
        return [tid for tid, t in self.tasks.items() if not t.deps]

    def leaves(self) -> List[str]:
        """Task IDs that nothing depends on (exit points of the DAG)."""
        depended_on = set()
        for t in self.tasks.values():
            depended_on.update(t.deps)
        return [tid for tid in self.tasks if tid not in depended_on]

    def children(self, task_id: str) -> List[str]:
        """Tasks that depend on ``task_id``."""
        return [tid for tid, t in self.tasks.items() if task_id in t.deps]

    def validate(self) -> None:
        """Check every dep exists and the graph is acyclic."""
        for tid, t in self.tasks.items():
            for d in t.deps:
                if d not in self.tasks:
                    raise ValueError(
                        f"task {tid!r} depends on unknown task {d!r}")
        cycle = _find_cycle(self.tasks)
        if cycle:
            raise ValueError(f"cycle detected: {' -> '.join(cycle)}")

    def __len__(self) -> int:
        return len(self.tasks)

    def fingerprint(self) -> str:
        """Content-addressed hash of the graph structure + task callables."""
        h = hashlib.sha256()
        for tid in sorted(self.tasks):
            t = self.tasks[tid]
            h.update(tid.encode())
            h.update(repr(sorted(t.deps)).encode())
            h.update(getattr(t.fn, "__qualname__", repr(t.fn)).encode())
            h.update(repr(t.priority).encode())
            h.update(repr(t.max_retries).encode())
        return h.hexdigest()


def _find_cycle(tasks: Dict[str, Task]) -> Optional[List[str]]:
    """Return a cycle path if the graph has one, else None (DFS)."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {tid: WHITE for tid in tasks}
    parent: Dict[str, Optional[str]] = {tid: None for tid in tasks}

    def dfs(u: str) -> Optional[List[str]]:
        color[u] = GRAY
        for v in sorted(tasks[u].deps):
            if color[v] == GRAY:
                # Found a back-edge u -> v; reconstruct cycle.
                cycle = [v, u]
                p = parent[u]
                while p is not None and p != v:
                    cycle.append(p)
                    p = parent[p]
                cycle.reverse()
                return cycle
            if color[v] == WHITE:
                parent[v] = u
                r = dfs(v)
                if r is not None:
                    return r
        color[u] = BLACK
        return None

    for tid in sorted(tasks):
        if color[tid] == WHITE:
            c = dfs(tid)
            if c is not None:
                return c
    return None


def validate_dag(graph: TaskGraph) -> bool:
    """True iff the graph is a valid DAG (no missing deps, no cycles)."""
    try:
        graph.validate()
        return True
    except ValueError:
        return False


def topological_order(graph: TaskGraph) -> List[str]:
    """Return a topological ordering of task IDs (Kahn's algorithm)."""
    graph.validate()
    indeg = {tid: len(t.deps) for tid, t in graph.tasks.items()}
    children: Dict[str, List[str]] = {tid: [] for tid in graph.tasks}
    for tid, t in graph.tasks.items():
        for d in t.deps:
            children[d].append(tid)
    ready = sorted([tid for tid, d in indeg.items() if d == 0])
    order: List[str] = []
    while ready:
        u = ready.pop(0)
        order.append(u)
        for c in sorted(children[u]):
            indeg[c] -= 1
            if indeg[c] == 0:
                ready.append(c)
        ready.sort()
    if len(order) != len(graph.tasks):
        raise ValueError("graph has a cycle")
    return order


# ---------------------------------------------------------------------------
# Progress events and results
# ---------------------------------------------------------------------------

@dataclass
class ProgressEvent:
    """A progress event emitted by the executor during a run."""
    kind: ProgressKind
    task_id: Optional[str]
    timestamp: float
    detail: dict = field(default_factory=dict)


@dataclass
class TaskResult:
    """Final result record for a task."""
    task_id: str
    state: TaskState
    result: Any
    error: Optional[str]
    attempts: int
    elapsed_s: float


# ---------------------------------------------------------------------------
# Distributed executor
# ---------------------------------------------------------------------------

class DistributedExecutor:
    """Run a :class:`TaskGraph` on a multi-process / multi-thread pool.

    Parameters
    ----------
    n_workers : int
        Pool size.  Defaults to ``min(cpu_count, 8)``.
    use_threads : bool
        Use ``ThreadPoolExecutor`` instead of ``ProcessPoolExecutor``
        (for I/O-bound or unpicklable workloads).
    deterministic : bool
        If true, ready tasks are processed in strict priority+insertion
        order and retry backoff uses a fixed seed, so two runs of the
        same graph yield identical results.  Required for V37
        reproducible pipelines.
    progress_callback : callable, optional
        Called with each :class:`ProgressEvent`.
    persist_results : bool
        If true, completed task outputs are cached in ``self.results``
        and a re-run reuses them (crash recovery).
    seed : int
        Seed for deterministic retry jitter.
    """

    def __init__(self,
                 n_workers: Optional[int] = None,
                 use_threads: bool = False,
                 deterministic: bool = True,
                 progress_callback: Optional[Callable[[ProgressEvent], None]] = None,
                 persist_results: bool = True,
                 seed: int = 42):
        self.n_workers = n_workers or min(os.cpu_count() or 1, 8)
        self.use_threads = use_threads
        self.deterministic = deterministic
        self.progress_callback = progress_callback
        self.persist_results = persist_results
        self.seed = seed
        self.results: Dict[str, Any] = {}
        self._rng = random.Random(seed)
        self._seq = 0
        self._lock = Lock()
        self._cond = Condition(self._lock)
        self._events: List[ProgressEvent] = []

    # -- public API --------------------------------------------------------

    def run(self, graph: TaskGraph,
            task_filter: Optional[Callable[[str], bool]] = None
            ) -> Dict[str, TaskResult]:
        """Execute the graph and return per-task results.

        Parameters
        ----------
        graph : TaskGraph
            The graph to run (must validate).
        task_filter : callable, optional
            If given, only tasks for which ``task_filter(task_id)`` is
            true are executed; others are skipped (useful for partial
            re-runs / recovery).
        """
        graph.validate()
        if task_filter is None:
            task_filter = lambda tid: True  # noqa: E731

        # Reset state for tasks we will (re)run, preserving cached results.
        for tid, t in graph.tasks.items():
            if self.persist_results and tid in self.results and task_filter(tid):
                t.state = TaskState.DONE
                t.result = self.results[tid]
            elif task_filter(tid):
                t.state = TaskState.PENDING
                t.attempts = 0
                t.error = None

        # Compute in-degree and ready set.
        indeg: Dict[str, int] = {}
        children: Dict[str, List[str]] = {tid: [] for tid in graph.tasks}
        for tid, t in graph.tasks.items():
            if not task_filter(tid):
                indeg[tid] = 0
                continue
            live_deps = [d for d in t.deps
                         if task_filter(d) and graph.tasks[d].state != TaskState.DONE]
            indeg[tid] = len(live_deps)
            for d in t.deps:
                if task_filter(d):
                    children[d].append(tid)

        ready_queue: PriorityQueue = PriorityQueue()
        for tid, t in graph.tasks.items():
            if task_filter(tid) and t.state != TaskState.DONE and indeg[tid] == 0:
                with self._lock:
                    self._seq += 1
                ready_queue.put(_QueueEntry(t.priority, self._seq, tid))
                t.state = TaskState.READY
                self._emit(ProgressKind.TASK_READY, tid)

        # If a task's deps are all already DONE (cached), it may still be
        # PENDING with indeg 0 -- handled above.  But if a dep is DONE via
        # cache and not in live_deps, indeg is already 0.  Good.

        executor_cls = ThreadPoolExecutor if self.use_threads else ProcessPoolExecutor
        pool = executor_cls(max_workers=self.n_workers)
        in_flight: Dict[Future, str] = {}
        completed: Dict[str, TaskResult] = {}
        failed_any = False

        try:
            while True:
                # Submit ready tasks until the pool is full or queue empty.
                while not ready_queue.empty() and len(in_flight) < self.n_workers:
                    entry = ready_queue.get_nowait()
                    tid = entry.task_id
                    t = graph.tasks[tid]
                    t.state = TaskState.RUNNING
                    t.attempts += 1
                    t.start_time = time.time()
                    self._emit(ProgressKind.TASK_START, tid,
                               {"attempt": t.attempts})
                    bound_args, bound_kwargs = self._bind_refs(t, graph)
                    fut = pool.submit(_safe_run, t.fn, bound_args, bound_kwargs)
                    in_flight[fut] = tid

                if not in_flight and ready_queue.empty():
                    break  # nothing left

                # Wait for at least one future to complete.
                from concurrent.futures import wait, FIRST_COMPLETED
                done, _ = wait(list(in_flight.keys()),
                                return_when=FIRST_COMPLETED)
                for fut in done:
                    tid = in_flight.pop(fut)
                    t = graph.tasks[tid]
                    t.end_time = time.time()
                    try:
                        ok, value, err = fut.result()
                    except Exception as e:
                        ok, value, err = False, None, str(e)

                    if ok:
                        t.state = TaskState.DONE
                        t.result = value
                        if self.persist_results:
                            self.results[tid] = value
                        completed[tid] = TaskResult(
                            task_id=tid, state=TaskState.DONE,
                            result=value, error=None,
                            attempts=t.attempts,
                            elapsed_s=t.end_time - t.start_time)
                        self._emit(ProgressKind.TASK_DONE, tid,
                                   {"elapsed_s": t.end_time - t.start_time})
                        # Decrement children in-degree.
                        for c in children[tid]:
                            indeg[c] -= 1
                            if indeg[c] == 0 and graph.tasks[c].state == TaskState.PENDING:
                                with self._lock:
                                    self._seq += 1
                                ready_queue.put(_QueueEntry(
                                    graph.tasks[c].priority, self._seq, c))
                                graph.tasks[c].state = TaskState.READY
                                self._emit(ProgressKind.TASK_READY, c)
                    else:
                        # Retry with exponential backoff.
                        if t.attempts <= t.max_retries:
                            backoff = self._backoff(t.attempts)
                            time.sleep(backoff)
                            t.state = TaskState.PENDING
                            with self._lock:
                                self._seq += 1
                            ready_queue.put(_QueueEntry(t.priority, self._seq, tid))
                            t.state = TaskState.READY
                            self._emit(ProgressKind.TASK_RETRY, tid,
                                       {"attempt": t.attempts, "backoff": backoff,
                                        "error": err})
                        else:
                            t.state = TaskState.FAILED
                            t.error = err
                            failed_any = True
                            completed[tid] = TaskResult(
                                task_id=tid, state=TaskState.FAILED,
                                result=None, error=err,
                                attempts=t.attempts,
                                elapsed_s=t.end_time - t.start_time)
                            self._emit(ProgressKind.TASK_FAILED, tid,
                                       {"error": err})
                            # Cascade-cancel descendants.
                            self._cancel_descendants(tid, graph, children,
                                                     completed)
        finally:
            pool.shutdown(wait=False, cancel_futures=True)
            self._emit(ProgressKind.GRAPH_DONE, None,
                       {"n_done": sum(1 for r in completed.values()
                                      if r.state == TaskState.DONE),
                        "n_failed": sum(1 for r in completed.values()
                                        if r.state == TaskState.FAILED)})

        return completed

    # -- helpers -----------------------------------------------------------

    def _bind_refs(self, task: Task, graph: TaskGraph):
        """Replace TaskRef args/kwargs with resolved upstream outputs."""
        def resolve(v):
            if isinstance(v, TaskRef):
                src = graph.tasks[v.task_id]
                if src.state != TaskState.DONE:
                    raise RuntimeError(
                        f"dep {v.task_id!r} of {task.task_id!r} not done")
                return src.result
            return v
        args = tuple(resolve(a) for a in task.args)
        kwargs = {k: resolve(v) for k, v in task.kwargs.items()}
        return args, kwargs

    def _backoff(self, attempt: int) -> float:
        base = 0.05 * (2 ** (attempt - 1))
        if self.deterministic:
            jitter = self._rng.uniform(0, base * 0.25)
        else:
            jitter = random.uniform(0, base * 0.25)
        return base + jitter

    def _cancel_descendants(self, failed_id: str, graph: TaskGraph,
                            children: Dict[str, List[str]],
                            completed: Dict[str, TaskResult]) -> None:
        stack = list(children[failed_id])
        while stack:
            cid = stack.pop()
            t = graph.tasks[cid]
            if t.state in (TaskState.PENDING, TaskState.READY):
                t.state = TaskState.CANCELLED
                completed[cid] = TaskResult(
                    task_id=cid, state=TaskState.CANCELLED,
                    result=None, error=f"upstream {failed_id!r} failed",
                    attempts=0, elapsed_s=0.0)
                stack.extend(children[cid])

    def _emit(self, kind: ProgressKind, task_id: Optional[str],
              detail: Optional[dict] = None) -> None:
        ev = ProgressEvent(kind=kind, task_id=task_id,
                           timestamp=time.time(),
                           detail=detail or {})
        self._events.append(ev)
        if self.progress_callback is not None:
            try:
                self.progress_callback(ev)
            except Exception:
                pass


def _safe_run(fn, args, kwargs):
    """Top-level wrapper executed in the worker process.

    Returns ``(ok, value, error)`` so a raised exception never escapes
    the future (which would break ``wait``).  Module-level so it is
    picklable for ``ProcessPoolExecutor``.
    """
    try:
        value = fn(*args, **kwargs)
        return (True, value, None)
    except Exception as e:
        return (False, None, f"{type(e).__name__}: {e}\n{traceback.format_exc()}")


# ---------------------------------------------------------------------------
# Scaling benchmark
# ---------------------------------------------------------------------------

@dataclass
class ScalingResult:
    """Result of a strong-scaling benchmark."""
    n_workers: int
    elapsed_s: float
    speedup: float
    efficiency: float
    n_tasks: int


def _cpu_bound_work(x):
    """Module-level CPU-bound task for the scaling benchmark."""
    s = 0.0
    for i in range(200000):
        s += x * (i ** 0.5)
    return s


class ScalingBenchmark:
    """Measure strong-scaling efficiency of the distributed executor.

    Builds a fan-out graph of ``n_tasks`` independent CPU-bound tasks and
    runs it with increasing worker counts, measuring elapsed time,
    speedup (T1 / Tn), and parallel efficiency (speedup / n).  Perfect
    linear scaling gives efficiency 1.0; the V37 benchmark case checks
    that efficiency stays above a threshold (0.5) on at least 2 workers,
    which is the analytically verifiable criterion: a real distributed
    executor must beat single-process on enough parallel work.
    """

    def __init__(self, n_tasks: int = 16, task_cost: int = 200000):
        self.n_tasks = n_tasks
        self.task_cost = task_cost

    def _build_graph(self) -> TaskGraph:
        g = TaskGraph(name="scaling_bench")
        for i in range(self.n_tasks):
            g.add(Task(task_id=f"t{i}", fn=_cpu_bound_work, args=(i,),
                       cost=1.0, priority=0))
        return g

    def run(self, worker_counts: Optional[List[int]] = None,
            use_threads: bool = False) -> List[ScalingResult]:
        worker_counts = worker_counts or [1, 2, 4]
        results: List[ScalingResult] = []
        base_time: Optional[float] = None
        for nw in worker_counts:
            graph = self._build_graph()
            ex = DistributedExecutor(n_workers=nw, use_threads=use_threads,
                                     deterministic=True, persist_results=False)
            t0 = time.time()
            ex.run(graph)
            dt = time.time() - t0
            if base_time is None:
                base_time = dt
            speedup = base_time / dt if dt > 0 else 0.0
            eff = speedup / nw if nw > 0 else 0.0
            results.append(ScalingResult(
                n_workers=nw, elapsed_s=dt,
                speedup=speedup, efficiency=eff,
                n_tasks=self.n_tasks))
        return results

    @staticmethod
    def min_efficiency(results: List[ScalingResult]) -> float:
        """Lowest efficiency across multi-worker runs (>1 worker)."""
        multi = [r.efficiency for r in results if r.n_workers > 1]
        return min(multi) if multi else 0.0
