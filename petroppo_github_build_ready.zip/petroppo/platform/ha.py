"""petroppo V38 -- High Availability & Deployment layer.

This module makes petroppo deployable in a Fortune-500 data-centre where
"downtime is not an option."  It provides the four HA primitives that every
production service mesh needs:

1. **Leader election** (Raft-style) -- a cluster of petroppo nodes elects
   exactly one leader that owns singleton responsibilities (the scheduler
   tick, the audit-log seal, the quota reset).  If the leader dies, a
   follower is elected within one election timeout.

2. **Health checks** -- every node runs a liveness probe (is the process
   alive?) and a readiness probe (are all downstream dependencies -- the
   tenant manager, the audit log, the API gateway -- responding?).  The
   service registry consumes these to decide which nodes receive traffic.

3. **Failover** -- when the active leader or a primary backend fails, the
   HA manager promotes a standby, updates the service registry, and emits
   a failover event into the audit log.

4. **Service registry** -- a directory of all running petroppo services
   (API gateway, compute workers, storage nodes) with their addresses,
   health, and capacity.  Used for client-side load balancing and
   discovery.

5. **Deployment templates** -- serialisable descriptions of a petroppo
   cluster topology (how many nodes, which roles, resource limits, update
   strategy) that an operator can version, diff, and apply.  These map
   directly to Kubernetes / Nomad / Docker-Compose manifests but are
   expressed in petroppo's own schema so they can be validated and tested
   without a cluster.

Why Raft and not Paxos?
-----------------------

Raft was designed for *understandability* (Ongaro & Oki 2014).  Its
decomposition into leader election, log replication, and safety is far
easier to implement correctly in a few hundred lines than Paxos, and its
term-based voting gives deterministic test behaviour.  petroppo's
implementation is a *single-process simulation* of a Raft cluster -- it
models N nodes as in-memory objects with a shared logical clock, so the
election algorithm, term advancement, and vote tallying can be unit-tested
deterministically without network sockets.  The same state machine
transitions govern a real distributed deployment; only the transport
changes (in-process calls vs. gRPC).

Design
------

* :class:`NodeState` -- FOLLUNTER / CANDIDATE / LEADER / OBSERVER.
* :class:`ClusterNode` -- a single Raft node with its term, voted-for,
  log, and election timer.
* :class:`RaftCluster` -- the in-process cluster simulator.  Calls
  ``tick()`` to advance the logical clock; nodes time out and start
  elections; votes are tallied; a leader emerges.
* :class:`HealthCheck` / :class:`HealthStatus` -- liveness + readiness
  probes with configurable interval, timeout, and failure threshold.
* :class:`ServiceRegistry` -- register / deregister / discover services;
  tracks health and capacity; returns healthy instances for a service
  name.
* :class:`FailoverManager` -- watches a primary; on failure, promotes a
  standby, updates the registry, and records the event.
* :class:`DeploymentTemplate` -- a versioned cluster topology descriptor
  with roles, replicas, resources, and update strategy.  Validates
  against a schema and serialises to JSON for manifest generation.
* :class:`HAManager` -- the top-level orchestrator that wires the cluster,
  registry, health checks, and failover together.

All implementations are pure Python (stdlib only): ``time``, ``hashlib``,
``random``, ``json``, ``dataclasses``, ``enum``, ``collections``,
``typing``.  No external HA library (etcd, ZooKeeper, Consul) is required
for the core logic; the templates can be exported to those systems.

References
----------
* Ongaro, D. & Oki, J. (2014). *In Search of an Understandable Consensus
  Algorithm (Raft).* USENIX ATC.
* SIGOPS (2015). *The Raft Paper: Reflections on Raft and the Curious
  World It Enabled.*
* Google SRE Book (2016), Chapter 6: *Monitoring Distributed Systems*.

This module is part of petroppo V38 (Enterprise Edition).
"""

from __future__ import annotations

import hashlib
import json
import random
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple


# ===========================================================================
# Enums
# ===========================================================================

class NodeState(Enum):
    """Raft node states."""
    FOLLOWER = "follower"
    CANDIDATE = "candidate"
    LEADER = "leader"
    OBSERVER = "observer"  # non-voting member


class HealthState(Enum):
    """Health probe states (Kubernetes-style)."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class UpdateStrategy(Enum):
    """Deployment update strategies."""
    ROLLING = "rolling"        # update one pod at a time
    BLUE_GREEN = "blue_green"  # spin up new, switch, tear down old
    CANARY = "canary"          # route small % to new, increase
    RECREATE = "recreate"      # tear down all, spin up all new


class ServiceRole(Enum):
    """Roles a petroppo node can play."""
    API_GATEWAY = "api_gateway"
    COMPUTE_WORKER = "compute_worker"
    STORAGE_NODE = "storage_node"
    SCHEDULER = "scheduler"
    AUDIT_SERVICE = "audit_service"
    SSO_SERVICE = "sso_service"


# ===========================================================================
# Raft-style leader election
# ===========================================================================

@dataclass
class LogEntry:
    """A single entry in the Raft log."""
    term: int
    index: int
    command: str
    data: Any = None

    def to_dict(self) -> dict:
        return {"term": self.term, "index": self.index,
                "command": self.command, "data": self.data}


@dataclass
class ClusterNode:
    """A single node in a Raft cluster (in-process simulation).

    Each node maintains:
    - ``term``: the current Raft term (monotonically increasing).
    - ``voted_for``: the candidate ID this node voted for in the current
      term (or None).
    - ``state``: FOLLOWER / CANDIDATE / LEADER.
    - ``log``: the replicated log (list of :class:`LogEntry`).
    - ``election_timeout``: how long (in logical ticks) before a follower
      starts an election if it hears no heartbeat.
    - ``last_heartbeat``: the logical time of the last heartbeat received.
    - ``commit_index``: the highest log index known to be committed.
    """

    node_id: str
    state: NodeState = NodeState.FOLLOWER
    term: int = 0
    voted_for: Optional[str] = None
    log: List[LogEntry] = field(default_factory=list)
    election_timeout: int = 10  # logical ticks
    last_heartbeat: float = 0.0
    commit_index: int = -1
    leader_id: Optional[str] = None
    # Votes received in current election (set of node_ids)
    votes_received: set = field(default_factory=set)
    # Whether this node is alive (for failure simulation)
    alive: bool = True

    def reset_election_timer(self, now: float, jitter: int = 0) -> None:
        """Reset the election timer with optional random jitter."""
        self.last_heartbeat = now
        self.election_timeout = 10 + jitter

    def become_follower(self, term: int, leader_id: Optional[str] = None) -> None:
        """Transition to follower state for a given term."""
        self.state = NodeState.FOLLOWER
        self.term = term
        self.voted_for = None
        self.leader_id = leader_id
        self.votes_received.clear()

    def become_candidate(self, now: float) -> None:
        """Transition to candidate and start an election."""
        self.state = NodeState.CANDIDATE
        self.term += 1
        self.voted_for = self.node_id  # vote for self
        self.votes_received = {self.node_id}
        self.leader_id = None
        self.reset_election_timer(now, jitter=random.randint(0, 5))

    def become_leader(self, now: float) -> None:
        """Transition to leader."""
        self.state = NodeState.LEADER
        self.leader_id = self.node_id
        self.votes_received.clear()

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "state": self.state.value,
            "term": self.term,
            "voted_for": self.voted_for,
            "log_length": len(self.log),
            "commit_index": self.commit_index,
            "leader_id": self.leader_id,
            "alive": self.alive,
        }


class RaftCluster:
    """An in-process Raft cluster simulator.

    Models N nodes that communicate via in-memory method calls.  The
    cluster advances via ``tick()`` which increments the logical clock
    and lets nodes time out and start elections.

    This is a *deterministic* simulation -- no real network, no real
    timeouts.  It exists so the leader-election algorithm can be tested
    and benchmarked without infrastructure.  The same state-machine
    transitions apply in a real deployment.

    Parameters
    ----------
    node_ids : list of str
        The IDs of the cluster nodes.
    seed : int
        Random seed for deterministic election jitter.
    """

    def __init__(self, node_ids: List[str], seed: int = 42):
        self.nodes: Dict[str, ClusterNode] = {
            nid: ClusterNode(node_id=nid) for nid in node_ids
        }
        self._clock: float = 0.0
        self._rng = random.Random(seed)
        # Election timeout per node (randomised to avoid split votes)
        for nid in node_ids:
            self.nodes[nid].election_timeout = 10 + self._rng.randint(0, 5)
        self._election_events: Deque[dict] = deque(maxlen=1000)

    # -- clock --

    @property
    def clock(self) -> float:
        return self._clock

    def tick(self, dt: float = 1.0) -> None:
        """Advance the logical clock by ``dt`` ticks.

        For each alive follower/candidate, check if its election timer
        has expired; if so, it starts a new election.  For the leader,
        send heartbeats (reset all followers' timers).
        """
        self._clock += dt

        # Find current leader
        leader = self._current_leader()

        # Leader sends heartbeats
        if leader is not None and leader.alive:
            for nid, node in self.nodes.items():
                if nid != leader.node_id and node.alive and node.state != NodeState.OBSERVER:
                    node.last_heartbeat = self._clock
                    if node.term < leader.term:
                        node.become_follower(leader.term, leader.node_id)

        # Followers/candidates check election timeout
        for nid, node in self.nodes.items():
            if not node.alive or node.state == NodeState.LEADER:
                continue
            if node.state == NodeState.OBSERVER:
                continue
            elapsed = self._clock - node.last_heartbeat
            if elapsed >= node.election_timeout:
                self._start_election(node)

    def _current_leader(self) -> Optional[ClusterNode]:
        """Return the current leader node if one exists and is alive."""
        for node in self.nodes.values():
            if node.state == NodeState.LEADER and node.alive:
                return node
        return None

    def _start_election(self, candidate: ClusterNode) -> None:
        """A node starts an election (RequestVote RPC simulation)."""
        candidate.become_candidate(self._clock)
        term = candidate.term

        votes = 0
        for nid, node in self.nodes.items():
            if nid == candidate.node_id or not node.alive:
                continue
            if node.state == NodeState.OBSERVER:
                continue
            # A node grants its vote if:
            # - it hasn't voted in this term, OR
            # - it already voted for this candidate, AND
            # - the candidate's term is >= the node's term
            if node.term <= term and (
                node.voted_for is None or node.voted_for == candidate.node_id
            ):
                node.voted_for = candidate.node_id
                node.term = term
                node.last_heartbeat = self._clock  # reset timer
                votes += 1

        # Candidate always votes for itself
        total_votes = votes + 1
        majority = len(self.nodes) // 2 + 1

        self._election_events.append({
            "time": self._clock,
            "candidate": candidate.node_id,
            "term": term,
            "votes": total_votes,
            "majority": majority,
            "result": "won" if total_votes >= majority else "lost",
        })

        if total_votes >= majority:
            candidate.become_leader(self._clock)
            # All followers reset to this term
            for nid, node in self.nodes.items():
                if nid != candidate.node_id and node.alive and node.state != NodeState.OBSERVER:
                    node.become_follower(term, candidate.node_id)
                    node.last_heartbeat = self._clock

    # -- public API --

    def get_leader(self) -> Optional[ClusterNode]:
        """Return the current leader, or None if no leader elected."""
        return self._current_leader()

    def kill_node(self, node_id: str) -> None:
        """Simulate a node crash."""
        node = self.nodes.get(node_id)
        if node:
            node.alive = False
            if node.state == NodeState.LEADER:
                node.state = NodeState.FOLLOWER  # demote on crash
                node.leader_id = None

    def revive_node(self, node_id: str) -> None:
        """Simulate a node recovery."""
        node = self.nodes.get(node_id)
        if node:
            node.alive = True
            node.state = NodeState.FOLLOWER
            node.voted_for = None
            node.last_heartbeat = self._clock

    def add_node(self, node_id: str, observer: bool = False) -> ClusterNode:
        """Add a new node to the cluster."""
        node = ClusterNode(node_id=node_id)
        if observer:
            node.state = NodeState.OBSERVER
        node.election_timeout = 10 + self._rng.randint(0, 5)
        node.last_heartbeat = self._clock
        self.nodes[node_id] = node
        return node

    def remove_node(self, node_id: str) -> None:
        """Remove a node from the cluster."""
        self.nodes.pop(node_id, None)

    def append_entry(self, command: str, data: Any = None) -> Optional[LogEntry]:
        """Leader appends a new log entry (replication simulated)."""
        leader = self._current_leader()
        if leader is None:
            return None
        entry = LogEntry(
            term=leader.term,
            index=len(leader.log),
            command=command,
            data=data,
        )
        leader.log.append(entry)
        # Replicate to all followers (in-process: immediate)
        for node in self.nodes.values():
            if node.node_id != leader.node_id and node.alive:
                node.log.append(LogEntry(
                    term=entry.term, index=entry.index,
                    command=entry.command, data=entry.data,
                ))
        # Commit (majority reached since we replicated to all)
        leader.commit_index = entry.index
        for node in self.nodes.values():
            if node.alive and node.state != NodeState.OBSERVER:
                node.commit_index = entry.index
        return entry

    def election_history(self) -> List[dict]:
        """Return the history of election events."""
        return list(self._election_events)

    def cluster_status(self) -> dict:
        """Return a summary of cluster state."""
        leader = self._current_leader()
        return {
            "clock": self._clock,
            "leader": leader.node_id if leader else None,
            "leader_term": leader.term if leader else None,
            "node_count": len(self.nodes),
            "alive_nodes": sum(1 for n in self.nodes.values() if n.alive),
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "elections": len(self._election_events),
        }


# ===========================================================================
# Health checks
# ===========================================================================

@dataclass
class HealthStatus:
    """Result of a health probe."""
    state: HealthState
    message: str = ""
    timestamp: float = field(default_factory=time.time)
    checks: Dict[str, bool] = field(default_factory=dict)  # sub-check results
    latency_ms: float = 0.0

    @property
    def is_healthy(self) -> bool:
        return self.state == HealthState.HEALTHY

    def to_dict(self) -> dict:
        return {
            "state": self.state.value,
            "message": self.message,
            "timestamp": self.timestamp,
            "checks": dict(self.checks),
            "latency_ms": round(self.latency_ms, 2),
        }


class HealthCheck:
    """A health probe (liveness or readiness).

    Parameters
    ----------
    name : str
        Probe name (e.g., "liveness", "readiness").
    check_fn : callable
        Called as ``check_fn() -> bool`` (or dict of sub-checks).  If it
        returns True or a dict where all values are True, the probe is
        healthy.
    interval : float
        Seconds between checks (real time).
    timeout : float
        Seconds before a check is considered timed out.
    failure_threshold : int
        Consecutive failures before marking unhealthy.
    success_threshold : int
        Consecutive successes before marking healthy (after recovery).
    """

    def __init__(
        self,
        name: str,
        check_fn: Callable[[], Any],
        interval: float = 5.0,
        timeout: float = 2.0,
        failure_threshold: int = 3,
        success_threshold: int = 2,
    ):
        self.name = name
        self.check_fn = check_fn
        self.interval = interval
        self.timeout = timeout
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self._consecutive_failures = 0
        self._consecutive_successes = 0
        self._state = HealthState.UNKNOWN
        self._last_check: float = 0.0
        self._history: Deque[HealthStatus] = deque(maxlen=100)

    def run(self, now: Optional[float] = None) -> HealthStatus:
        """Run the health check and return the status."""
        if now is None:
            now = time.time()
        t0 = time.perf_counter()

        sub_checks: Dict[str, bool] = {}
        ok = False
        message = ""

        try:
            result = self.check_fn()
            if isinstance(result, dict):
                sub_checks = {k: bool(v) for k, v in result.items()}
                ok = all(sub_checks.values()) if sub_checks else True
                if not ok:
                    failed = [k for k, v in sub_checks.items() if not v]
                    message = f"Failed checks: {', '.join(failed)}"
            elif isinstance(result, bool):
                ok = result
            elif result is None:
                ok = False
                message = "Check returned None"
            else:
                ok = bool(result)
        except Exception as e:
            ok = False
            message = f"Exception: {e}"

        latency = (time.perf_counter() - t0) * 1000
        self._last_check = now

        # Update consecutive counters
        if ok:
            self._consecutive_successes += 1
            self._consecutive_failures = 0
        else:
            self._consecutive_failures += 1
            self._consecutive_successes = 0

        # State transition
        if ok and self._consecutive_successes >= self.success_threshold:
            self._state = HealthState.HEALTHY
        elif not ok and self._consecutive_failures >= self.failure_threshold:
            self._state = HealthState.UNHEALTHY
        elif not ok and self._consecutive_failures > 0:
            self._state = HealthState.DEGRADED
        # else: keep current state

        status = HealthStatus(
            state=self._state,
            message=message,
            timestamp=now,
            checks=sub_checks,
            latency_ms=latency,
        )
        self._history.append(status)
        return status

    @property
    def state(self) -> HealthState:
        return self._state

    @property
    def last_status(self) -> Optional[HealthStatus]:
        return self._history[-1] if self._history else None

    def history(self) -> List[HealthStatus]:
        return list(self._history)


# ===========================================================================
# Service registry
# ===========================================================================

@dataclass
class ServiceInstance:
    """A registered service instance."""
    service_name: str
    instance_id: str
    host: str
    port: int
    role: ServiceRole = ServiceRole.API_GATEWAY
    weight: int = 1
    capacity: int = 100  # max concurrent requests
    current_load: int = 0
    registered_at: float = field(default_factory=time.time)
    last_heartbeat: float = field(default_factory=time.time)
    health: HealthState = HealthState.UNKNOWN
    metadata: Dict[str, str] = field(default_factory=dict)

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"

    @property
    def is_available(self) -> bool:
        return self.health == HealthState.HEALTHY and self.current_load < self.capacity

    def to_dict(self) -> dict:
        return {
            "service_name": self.service_name,
            "instance_id": self.instance_id,
            "host": self.host,
            "port": self.port,
            "address": self.address,
            "role": self.role.value,
            "weight": self.weight,
            "capacity": self.capacity,
            "current_load": self.current_load,
            "health": self.health.value,
            "registered_at": self.registered_at,
            "last_heartbeat": self.last_heartbeat,
            "metadata": dict(self.metadata),
        }


class ServiceRegistry:
    """A service registry for discovery and load balancing.

    Services register themselves on startup, send periodic heartbeats,
    and deregister on shutdown.  Clients query the registry to discover
    healthy instances and pick one (round-robin or least-loaded).
    """

    def __init__(self, heartbeat_timeout: float = 30.0):
        self._services: Dict[str, Dict[str, ServiceInstance]] = defaultdict(dict)
        self._rr_counters: Dict[str, int] = defaultdict(int)
        self.heartbeat_timeout = heartbeat_timeout

    def register(self, instance: ServiceInstance) -> None:
        """Register a service instance."""
        self._services[instance.service_name][instance.instance_id] = instance

    def deregister(self, service_name: str, instance_id: str) -> bool:
        """Deregister a service instance."""
        if service_name in self._services:
            return self._services[service_name].pop(instance_id, None) is not None
        return False

    def heartbeat(self, service_name: str, instance_id: str) -> bool:
        """Update the heartbeat timestamp for an instance."""
        inst = self._services.get(service_name, {}).get(instance_id)
        if inst is None:
            return False
        inst.last_heartbeat = time.time()
        inst.health = HealthState.HEALTHY
        return True

    def update_health(self, service_name: str, instance_id: str,
                      state: HealthState) -> None:
        """Update the health state of an instance."""
        inst = self._services.get(service_name, {}).get(instance_id)
        if inst:
            inst.health = state

    def update_load(self, service_name: str, instance_id: str, load: int) -> None:
        """Update the current load of an instance."""
        inst = self._services.get(service_name, {}).get(instance_id)
        if inst:
            inst.current_load = load

    def discover(self, service_name: str, healthy_only: bool = True) -> List[ServiceInstance]:
        """Discover instances of a service."""
        instances = list(self._services.get(service_name, {}).values())
        if healthy_only:
            instances = [i for i in instances if i.health == HealthState.HEALTHY]
        return instances

    def select(self, service_name: str, strategy: str = "round_robin") -> Optional[ServiceInstance]:
        """Select an instance using the given strategy.

        Strategies:
        - ``round_robin``: cycle through healthy instances.
        - ``least_loaded``: pick the instance with the lowest current_load/capacity ratio.
        - ``random``: pick a random healthy instance.
        """
        instances = self.discover(service_name, healthy_only=True)
        if not instances:
            return None

        if strategy == "least_loaded":
            return min(instances, key=lambda i: i.current_load / max(i.capacity, 1))
        elif strategy == "random":
            return random.choice(instances)
        else:  # round_robin
            idx = self._rr_counters[service_name] % len(instances)
            self._rr_counters[service_name] += 1
            return instances[idx]

    def purge_stale(self, now: Optional[float] = None) -> List[str]:
        """Remove instances that haven't sent a heartbeat within the timeout."""
        if now is None:
            now = time.time()
        purged = []
        for service_name, instances in list(self._services.items()):
            for iid, inst in list(instances.items()):
                if now - inst.last_heartbeat > self.heartbeat_timeout:
                    inst.health = HealthState.UNHEALTHY
                    # Mark unhealthy but keep registered (may recover)
                    purged.append(f"{service_name}/{iid}")
        return purged

    def list_services(self) -> Dict[str, List[dict]]:
        """List all registered services and their instances."""
        return {
            name: [inst.to_dict() for inst in instances.values()]
            for name, instances in self._services.items()
        }

    def stats(self) -> dict:
        """Return registry statistics."""
        total = sum(len(insts) for insts in self._services.values())
        healthy = sum(
            1 for insts in self._services.values()
            for i in insts.values()
            if i.health == HealthState.HEALTHY
        )
        return {
            "service_count": len(self._services),
            "total_instances": total,
            "healthy_instances": healthy,
            "unhealthy_instances": total - healthy,
        }


# ===========================================================================
# Failover manager
# ===========================================================================

@dataclass
class FailoverEvent:
    """Recorded when a failover occurs."""
    timestamp: float
    service_name: str
    failed_instance: str
    promoted_instance: str
    reason: str
    recovery_time_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "service_name": self.service_name,
            "failed_instance": self.failed_instance,
            "promoted_instance": self.promoted_instance,
            "reason": self.reason,
            "recovery_time_ms": round(self.recovery_time_ms, 2),
        }


class FailoverManager:
    """Monitors a primary service and promotes a standby on failure.

    Parameters
    ----------
    registry : ServiceRegistry
        The service registry to update on failover.
    audit_callback : callable, optional
        Called as ``audit_callback(event: FailoverEvent)`` to record the
        failover in the audit log.
    """

    def __init__(
        self,
        registry: ServiceRegistry,
        audit_callback: Optional[Callable[[FailoverEvent], None]] = None,
    ):
        self.registry = registry
        self.audit_callback = audit_callback
        self._events: Deque[FailoverEvent] = deque(maxlen=1000)
        self._primaries: Dict[str, str] = {}  # service_name -> instance_id

    def set_primary(self, service_name: str, instance_id: str) -> None:
        """Designate the current primary for a service."""
        self._primaries[service_name] = instance_id

    def get_primary(self, service_name: str) -> Optional[str]:
        """Return the current primary instance ID."""
        return self._primaries.get(service_name)

    def check_and_failover(
        self,
        service_name: str,
        now: Optional[float] = None,
    ) -> Optional[FailoverEvent]:
        """Check if the primary is healthy; if not, promote a standby.

        Returns the :class:`FailoverEvent` if a failover occurred, else None.
        """
        if now is None:
            now = time.time()
        primary_id = self._primaries.get(service_name)
        if primary_id is None:
            return None

        primary = self.registry._services.get(service_name, {}).get(primary_id)
        if primary is None:
            return None

        if primary.health == HealthState.HEALTHY:
            return None  # primary is fine

        # Primary is unhealthy -- find a healthy standby
        standbys = [
            inst for inst in self.registry.discover(service_name, healthy_only=True)
            if inst.instance_id != primary_id
        ]
        if not standbys:
            return None  # no standby available

        t0 = time.perf_counter()
        # Promote the least-loaded standby
        standby = min(standbys, key=lambda i: i.current_load / max(i.capacity, 1))

        event = FailoverEvent(
            timestamp=now,
            service_name=service_name,
            failed_instance=primary_id,
            promoted_instance=standby.instance_id,
            reason=f"Primary {primary_id} health={primary.health.value}",
            recovery_time_ms=(time.perf_counter() - t0) * 1000,
        )
        self._events.append(event)
        self._primaries[service_name] = standby.instance_id

        if self.audit_callback:
            try:
                self.audit_callback(event)
            except Exception:
                pass  # don't let audit failure block failover

        return event

    def events(self) -> List[FailoverEvent]:
        """Return the history of failover events."""
        return list(self._events)

    def failover_count(self) -> int:
        return len(self._events)


# ===========================================================================
# Deployment templates
# ===========================================================================

@dataclass
class ResourceSpec:
    """Resource requirements for a node."""
    cpu_cores: float = 2.0
    memory_mb: int = 4096
    storage_gb: int = 100
    gpu_count: int = 0

    def to_dict(self) -> dict:
        return {
            "cpu_cores": self.cpu_cores,
            "memory_mb": self.memory_mb,
            "storage_gb": self.storage_gb,
            "gpu_count": self.gpu_count,
        }

    def validate(self) -> List[str]:
        """Validate the resource spec. Returns list of errors (empty if OK)."""
        errors = []
        if self.cpu_cores <= 0:
            errors.append("cpu_cores must be positive")
        if self.memory_mb <= 0:
            errors.append("memory_mb must be positive")
        if self.storage_gb < 0:
            errors.append("storage_gb must be non-negative")
        if self.gpu_count < 0:
            errors.append("gpu_count must be non-negative")
        return errors


@dataclass
class ServiceTemplate:
    """Template for deploying a single service in the cluster."""
    name: str
    role: ServiceRole
    replicas: int = 1
    resources: ResourceSpec = field(default_factory=ResourceSpec)
    port: int = 8080
    update_strategy: UpdateStrategy = UpdateStrategy.ROLLING
    max_unavailable: int = 1  # for rolling updates
    health_check_path: str = "/health"
    readiness_check_path: str = "/ready"
    env: Dict[str, str] = field(default_factory=dict)
    min_replicas: int = 1  # for auto-scaling
    max_replicas: int = 10

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "role": self.role.value,
            "replicas": self.replicas,
            "resources": self.resources.to_dict(),
            "port": self.port,
            "update_strategy": self.update_strategy.value,
            "max_unavailable": self.max_unavailable,
            "health_check_path": self.health_check_path,
            "readiness_check_path": self.readiness_check_path,
            "env": dict(self.env),
            "min_replicas": self.min_replicas,
            "max_replicas": self.max_replicas,
        }

    def validate(self) -> List[str]:
        """Validate the service template. Returns list of errors."""
        errors = []
        if not self.name:
            errors.append("service name cannot be empty")
        if self.replicas < 0:
            errors.append(f"{self.name}: replicas must be non-negative")
        if self.replicas < self.min_replicas:
            errors.append(f"{self.name}: replicas < min_replicas")
        if self.max_replicas < self.min_replicas:
            errors.append(f"{self.name}: max_replicas < min_replicas")
        if not (1 <= self.port <= 65535):
            errors.append(f"{self.name}: port must be 1-65535")
        if self.max_unavailable > self.replicas and self.replicas > 0:
            errors.append(f"{self.name}: max_unavailable > replicas")
        errors.extend(self.resources.validate())
        return errors


@dataclass
class DeploymentTemplate:
    """A complete cluster deployment topology.

    Describes how many nodes, which roles, resource limits, and update
    strategy.  This is petroppo's own schema that maps to Kubernetes /
    Nomad / Docker-Compose manifests but is self-contained for validation
    and testing.
    """

    name: str
    version: str = "1.0"
    services: List[ServiceTemplate] = field(default_factory=list)
    ha_enabled: bool = True
    leader_election: bool = True
    min_cluster_size: int = 3  # for Raft quorum
    network_policy: str = "tenant_isolation"
    dns_domain: str = "petroppo.internal"
    registry_url: str = ""
    image_tag: str = "v38"
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "services": [s.to_dict() for s in self.services],
            "ha_enabled": self.ha_enabled,
            "leader_election": self.leader_election,
            "min_cluster_size": self.min_cluster_size,
            "network_policy": self.network_policy,
            "dns_domain": self.dns_domain,
            "registry_url": self.registry_url,
            "image_tag": self.image_tag,
            "created_at": self.created_at,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)

    def validate(self) -> Tuple[bool, List[str]]:
        """Validate the entire deployment template.

        Returns (is_valid, list_of_errors).
        """
        errors: List[str] = []

        if not self.name:
            errors.append("deployment name cannot be empty")
        if not self.version:
            errors.append("version cannot be empty")

        if not self.services:
            errors.append("at least one service is required")

        # Check for unique service names
        names = [s.name for s in self.services]
        if len(names) != len(set(names)):
            errors.append("duplicate service names detected")

        # Validate each service
        for svc in self.services:
            svc_errors = svc.validate()
            for e in svc_errors:
                errors.append(e)

        # HA validation
        if self.ha_enabled and self.leader_election:
            # Need at least 3 nodes for Raft quorum (across scheduler/audit roles)
            scheduler_replicas = sum(
                s.replicas for s in self.services
                if s.role in (ServiceRole.SCHEDULER, ServiceRole.AUDIT_SERVICE)
            )
            if scheduler_replicas > 0 and scheduler_replicas < self.min_cluster_size:
                errors.append(
                    f"HA with leader election requires >= {self.min_cluster_size} "
                    f"scheduler/audit replicas, got {scheduler_replicas}"
                )

        # Network policy validation
        valid_policies = {"tenant_isolation", "open", "restricted"}
        if self.network_policy not in valid_policies:
            errors.append(f"network_policy must be one of {valid_policies}")

        return (len(errors) == 0, errors)

    def total_replicas(self) -> int:
        """Total number of node replicas across all services."""
        return sum(s.replicas for s in self.services)

    def total_resources(self) -> ResourceSpec:
        """Aggregate resource requirements across all services."""
        total = ResourceSpec()
        for svc in self.services:
            total.cpu_cores += svc.resources.cpu_cores * svc.replicas
            total.memory_mb += svc.resources.memory_mb * svc.replicas
            total.storage_gb += svc.resources.storage_gb * svc.replicas
            total.gpu_count += svc.resources.gpu_count * svc.replicas
        return total

    def to_docker_compose(self) -> str:
        """Generate a docker-compose.yml fragment from this template."""
        lines = ["version: '3.8'", "", "services:"]
        for svc in self.services:
            for i in range(svc.replicas):
                sname = f"{svc.name}_{i+1}" if svc.replicas > 1 else svc.name
                lines.append(f"  {sname}:")
                lines.append(f"    image: {self.registry_url or 'petroppo'}/{svc.name}:{self.image_tag}")
                lines.append(f"    ports:")
                lines.append(f"      - \"{svc.port + i}:{svc.port}\"")
                lines.append(f"    deploy:")
                lines.append(f"      resources:")
                lines.append(f"        limits:")
                lines.append(f"          cpus: '{svc.resources.cpu_cores}'")
                lines.append(f"          memory: {svc.resources.memory_mb}M")
                if svc.resources.gpu_count > 0:
                    lines.append(f"        reservations:")
                    lines.append(f"          devices:")
                    lines.append(f"            - capabilities: [gpu]")
                    lines.append(f"              count: {svc.resources.gpu_count}")
                if svc.env:
                    lines.append(f"    environment:")
                    for k, v in svc.env.items():
                        lines.append(f"      {k}: {v}")
                lines.append(f"    healthcheck:")
                lines.append(f"      test: [\"CMD\", \"curl\", \"-f\", \"http://localhost:{svc.port}{svc.health_check_path}\"]")
                lines.append(f"      interval: 10s")
                lines.append(f"      timeout: 5s")
                lines.append(f"      retries: 3")
                lines.append("")
        return "\n".join(lines)


# ===========================================================================
# Top-level HA manager
# ===========================================================================

class HAManager:
    """The top-level HA orchestrator.

    Wires together the Raft cluster, service registry, health checks,
    and failover manager into a single coordinator.

    Parameters
    ----------
    node_ids : list of str
        Initial cluster node IDs for leader election.
    seed : int
        Random seed for deterministic elections.
    """

    def __init__(self, node_ids: List[str], seed: int = 42):
        self.cluster = RaftCluster(node_ids, seed=seed)
        self.registry = ServiceRegistry()
        self.failover = FailoverManager(self.registry)
        self._health_checks: Dict[str, HealthCheck] = {}
        self._audit_log: Deque[dict] = deque(maxlen=10000)

    # -- health checks --

    def register_health_check(self, name: str, check: HealthCheck) -> None:
        """Register a named health check."""
        self._health_checks[name] = check

    def run_health_checks(self) -> Dict[str, HealthStatus]:
        """Run all registered health checks."""
        return {name: check.run() for name, check in self._health_checks.items()}

    def overall_health(self) -> HealthState:
        """Return the overall system health (worst of all checks)."""
        if not self._health_checks:
            return HealthState.UNKNOWN
        states = [check.state for check in self._health_checks.values()]
        if HealthState.UNHEALTHY in states:
            return HealthState.UNHEALTHY
        if HealthState.DEGRADED in states:
            return HealthState.DEGRADED
        if HealthState.HEALTHY in states:
            return HealthState.HEALTHY
        return HealthState.UNKNOWN

    # -- cluster operations --

    def elect_leader(self, max_ticks: int = 100) -> Optional[ClusterNode]:
        """Run the cluster until a leader is elected (or max_ticks)."""
        for _ in range(max_ticks):
            self.cluster.tick()
            leader = self.cluster.get_leader()
            if leader is not None:
                return leader
        return None

    def failover_all(self) -> List[FailoverEvent]:
        """Check all services with primaries and failover if needed."""
        events = []
        for service_name in list(self.failover._primaries.keys()):
            event = self.failover.check_and_failover(service_name)
            if event:
                events.append(event)
                self._audit_log.append({
                    "type": "failover",
                    "event": event.to_dict(),
                    "timestamp": time.time(),
                })
        return events

    # -- audit --

    def audit_trail(self) -> List[dict]:
        """Return the HA audit trail."""
        return list(self._audit_log)

    # -- status --

    def status(self) -> dict:
        """Return a comprehensive HA status report."""
        return {
            "cluster": self.cluster.cluster_status(),
            "registry": self.registry.stats(),
            "failover_count": self.failover.failover_count(),
            "overall_health": self.overall_health().value,
            "health_checks": {
                name: check.state.value
                for name, check in self._health_checks.items()
            },
            "audit_events": len(self._audit_log),
        }


# ===========================================================================
# Preset deployment templates
# ===========================================================================

def default_enterprise_template() -> DeploymentTemplate:
    """A reference enterprise deployment template for petroppo V38.

    3-node HA cluster with API gateways, compute workers, storage,
    scheduler, audit, and SSO services.
    """
    return DeploymentTemplate(
        name="petroppo-enterprise-ha",
        version="38.0",
        ha_enabled=True,
        leader_election=True,
        min_cluster_size=3,
        network_policy="tenant_isolation",
        dns_domain="petroppo.internal",
        image_tag="v38",
        services=[
            ServiceTemplate(
                name="api-gateway",
                role=ServiceRole.API_GATEWAY,
                replicas=3,
                resources=ResourceSpec(cpu_cores=2, memory_mb=4096, storage_gb=10),
                port=8080,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=1,
                min_replicas=2,
                max_replicas=10,
                env={"LOG_LEVEL": "INFO", "RATE_LIMIT_ENABLED": "true"},
            ),
            ServiceTemplate(
                name="compute-worker",
                role=ServiceRole.COMPUTE_WORKER,
                replicas=4,
                resources=ResourceSpec(cpu_cores=8, memory_mb=16384, storage_gb=50, gpu_count=1),
                port=9000,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=1,
                min_replicas=2,
                max_replicas=20,
                env={"WORKER_CONCURRENCY": "8", "GPU_ENABLED": "true"},
            ),
            ServiceTemplate(
                name="storage-node",
                role=ServiceRole.STORAGE_NODE,
                replicas=3,
                resources=ResourceSpec(cpu_cores=4, memory_mb=8192, storage_gb=500),
                port=7000,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=0,  # storage must never go to 0
                min_replicas=3,
                max_replicas=9,
                env={"REPLICATION_FACTOR": "3"},
            ),
            ServiceTemplate(
                name="scheduler",
                role=ServiceRole.SCHEDULER,
                replicas=3,
                resources=ResourceSpec(cpu_cores=4, memory_mb=8192, storage_gb=20),
                port=8500,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=1,
                min_replicas=3,  # Raft quorum
                max_replicas=5,
                env={"RAFT_CLUSTER_SIZE": "3"},
            ),
            ServiceTemplate(
                name="audit-service",
                role=ServiceRole.AUDIT_SERVICE,
                replicas=3,
                resources=ResourceSpec(cpu_cores=2, memory_mb=4096, storage_gb=200),
                port=8600,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=1,
                min_replicas=3,
                max_replicas=5,
                env={"AUDIT_HASH_CHAIN": "true"},
            ),
            ServiceTemplate(
                name="sso-service",
                role=ServiceRole.SSO_SERVICE,
                replicas=2,
                resources=ResourceSpec(cpu_cores=2, memory_mb=2048, storage_gb=10),
                port=8700,
                update_strategy=UpdateStrategy.ROLLING,
                max_unavailable=1,
                min_replicas=2,
                max_replicas=4,
                env={"SAML_ENABLED": "true", "OIDC_ENABLED": "true"},
            ),
        ],
    )


def single_node_template() -> DeploymentTemplate:
    """A minimal single-node deployment (for dev/testing)."""
    return DeploymentTemplate(
        name="petroppo-dev",
        version="38.0",
        ha_enabled=False,
        leader_election=False,
        min_cluster_size=1,
        network_policy="open",
        services=[
            ServiceTemplate(
                name="petroppo-all-in-one",
                role=ServiceRole.API_GATEWAY,
                replicas=1,
                resources=ResourceSpec(cpu_cores=2, memory_mb=4096, storage_gb=50),
                port=8080,
                update_strategy=UpdateStrategy.RECREATE,
                min_replicas=1,
                max_replicas=1,
            ),
        ],
    )


# ===========================================================================
# Benchmark
# ===========================================================================

def benchmark(num_nodes: int = 5, num_elections: int = 10, seed: int = 42) -> dict:
    """Benchmark leader election performance.

    Measures how long it takes to elect a leader, then kill it and
    re-elect, across ``num_elections`` cycles.
    """
    node_ids = [f"node_{i}" for i in range(num_nodes)]
    cluster = RaftCluster(node_ids, seed=seed)

    # Initial election
    t0 = time.perf_counter()
    leader = None
    for _ in range(200):
        cluster.tick()
        leader = cluster.get_leader()
        if leader:
            break
    initial_election_ms = (time.perf_counter() - t0) * 1000

    # Failover cycles
    failover_times = []
    for cycle in range(num_elections):
        current_leader = cluster.get_leader()
        if current_leader is None:
            # Force an election
            for _ in range(200):
                cluster.tick()
                if cluster.get_leader():
                    break
            continue
        # Kill the leader
        cluster.kill_node(current_leader.node_id)
        t0 = time.perf_counter()
        new_leader = None
        for _ in range(200):
            cluster.tick()
            new_leader = cluster.get_leader()
            if new_leader and new_leader.node_id != current_leader.node_id:
                break
        failover_ms = (time.perf_counter() - t0) * 1000
        failover_times.append(failover_ms)
        # Revive the old leader for next cycle
        cluster.revive_node(current_leader.node_id)

    avg_failover = sum(failover_times) / len(failover_times) if failover_times else 0
    max_failover = max(failover_times) if failover_times else 0

    return {
        "num_nodes": num_nodes,
        "num_elections": num_elections,
        "initial_election_ms": round(initial_election_ms, 3),
        "avg_failover_ms": round(avg_failover, 3),
        "max_failover_ms": round(max_failover, 3),
        "final_leader": cluster.get_leader().node_id if cluster.get_leader() else None,
        "total_election_events": len(cluster.election_history()),
    }


# ===========================================================================
# __all__
# ===========================================================================

__all__ = [
    # Enums
    "NodeState", "HealthState", "UpdateStrategy", "ServiceRole",
    # Raft
    "LogEntry", "ClusterNode", "RaftCluster",
    # Health
    "HealthStatus", "HealthCheck",
    # Registry
    "ServiceInstance", "ServiceRegistry",
    # Failover
    "FailoverEvent", "FailoverManager",
    # Deployment
    "ResourceSpec", "ServiceTemplate", "DeploymentTemplate",
    # Manager
    "HAManager",
    # Presets
    "default_enterprise_template", "single_node_template",
    # Benchmark
    "benchmark",
]
