"""
V39 Commercial licensing -- license management for commercial deployment.

This module provides the commercial licensing infrastructure that turns
petroppo from a technical platform into a commercially deployable
product.  It implements:

* **License types** -- community (free), professional, enterprise, trial
  with per-type feature access control.
* **License keys** -- cryptographically signed keys with generation,
  validation, expiration, and feature gating.  Keys use HMAC-SHA256
  signatures so they can be verified offline without contacting a
  license server.
* **Feature flags** -- per-license-type feature access control.  Each
  feature (e.g. "reservoir_simulation", "ai_copilot", "enterprise_sso")
  is gated by license type.
* **License server stub** -- online activation and offline verification.
  The server stub is a pure-Python in-process store that can be replaced
  by a real HTTP license server in production.
* **Usage tracking** -- per-license feature usage counters.  Enables
  metered billing and compliance reporting.

Design principles
-----------------
* **No external dependencies** -- uses only the Python standard library
  (``hashlib``, ``hmac``, ``secrets``, ``json``, ``time``, ``uuid``).
* **Offline-first** -- license keys are self-contained and verifiable
  without network access.  Online activation is optional.
* **Tamper-evident** -- keys are HMAC-signed; any modification
  invalidates the signature.
* **Auditable** -- all license operations (issue, activate, validate,
  expire) are logged.

References
----------
* NIST SP 800-108 (2009). *Recommendation for Key Derivation Using
  Pseudorandom Functions* -- HMAC-based key derivation.
* IETF RFC 2104 (1997). *HMAC: Keyed-Hashing for Message Authentication.*
* Software License Management Best Practices (Flexera, 2021).

This module is part of petroppo V39 (Proof & Commercial Edition).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

__all__ = [
    "LicenseType",
    "LicenseStatus",
    "LicenseFeatures",
    "License",
    "LicenseKeyGenerator",
    "LicenseManager",
    "LicenseServer",
    "UsageTracker",
    "LicenseError",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class LicenseError(Exception):
    """Base exception for licensing errors."""


class LicenseExpiredError(LicenseError):
    """Raised when a license has expired."""


class LicenseInvalidError(LicenseError):
    """Raised when a license key is invalid or tampered."""


class FeatureNotLicensedError(LicenseError):
    """Raised when a feature is not licensed under the current license."""


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class LicenseType(Enum):
    """License tier.

    Attributes
    ----------
    COMMUNITY : free, limited features, no expiration
    PROFESSIONAL : paid, standard features, annual expiration
    ENTERPRISE : paid, all features, annual expiration, multi-seat
    TRIAL : free, time-limited (30 days), professional features
    """

    COMMUNITY = "community"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"
    TRIAL = "trial"


class LicenseStatus(Enum):
    """License lifecycle status."""

    ACTIVE = "active"
    EXPIRED = "expired"
    SUSPENDED = "suspended"
    REVOKED = "revoked"
    PENDING_ACTIVATION = "pending_activation"


# ---------------------------------------------------------------------------
# Feature flags
# ---------------------------------------------------------------------------

class LicenseFeatures:
    """Feature flag definitions per license type.

    Each feature is a string key.  The ``FEATURE_MATRIX`` maps each
    :class:`LicenseType` to the set of features it grants access to.
    """

    # Core features (all license types)
    SEISMIC_PROCESSING = "seismic_processing"
    WELL_LOG_ANALYSIS = "well_log_analysis"
    PETROPHYSICS = "petrophysics"

    # Professional features
    RESERVOIR_SIMULATION = "reservoir_simulation"
    RESERVOIR_MODELING = "reservoir_modeling"
    HISTORY_MATCHING = "history_matching"
    UNCERTAINTY_QUANTIFICATION = "uncertainty_quantification"
    AI_COPILOT = "ai_copilot"
    FIELD_CASE_STUDIES = "field_case_studies"

    # Enterprise features
    MULTI_TENANCY = "multi_tenancy"
    SSO = "sso"
    COMPLIANCE_AUDIT = "compliance_audit"
    API_GATEWAY = "api_gateway"
    HIGH_AVAILABILITY = "high_availability"
    ENTERPRISE_CONFIG = "enterprise_config"
    CLOUD_DEPLOYMENT = "cloud_deployment"
    DISTRIBUTED_COMPUTE = "distributed_compute"

    FEATURE_MATRIX: dict = {
        LicenseType.COMMUNITY: {
            SEISMIC_PROCESSING,
            WELL_LOG_ANALYSIS,
            PETROPHYSICS,
        },
        LicenseType.PROFESSIONAL: {
            SEISMIC_PROCESSING,
            WELL_LOG_ANALYSIS,
            PETROPHYSICS,
            RESERVOIR_SIMULATION,
            RESERVOIR_MODELING,
            HISTORY_MATCHING,
            UNCERTAINTY_QUANTIFICATION,
            AI_COPILOT,
            FIELD_CASE_STUDIES,
        },
        LicenseType.ENTERPRISE: {
            # All features
            SEISMIC_PROCESSING,
            WELL_LOG_ANALYSIS,
            PETROPHYSICS,
            RESERVOIR_SIMULATION,
            RESERVOIR_MODELING,
            HISTORY_MATCHING,
            UNCERTAINTY_QUANTIFICATION,
            AI_COPILOT,
            FIELD_CASE_STUDIES,
            MULTI_TENANCY,
            SSO,
            COMPLIANCE_AUDIT,
            API_GATEWAY,
            HIGH_AVAILABILITY,
            ENTERPRISE_CONFIG,
            CLOUD_DEPLOYMENT,
            DISTRIBUTED_COMPUTE,
        },
        LicenseType.TRIAL: {
            # Trial gets professional features
            SEISMIC_PROCESSING,
            WELL_LOG_ANALYSIS,
            PETROPHYSICS,
            RESERVOIR_SIMULATION,
            RESERVOIR_MODELING,
            HISTORY_MATCHING,
            UNCERTAINTY_QUANTIFICATION,
            AI_COPILOT,
            FIELD_CASE_STUDIES,
        },
    }

    @classmethod
    def features_for(cls, license_type: LicenseType) -> set:
        """Return the set of features granted by a license type."""
        return cls.FEATURE_MATRIX.get(license_type, set())

    @classmethod
    def has_feature(cls, license_type: LicenseType, feature: str) -> bool:
        """Check if a license type grants access to a feature."""
        return feature in cls.features_for(license_type)

    @classmethod
    def all_features(cls) -> set:
        """Return all known feature keys."""
        all_f = set()
        for feats in cls.FEATURE_MATRIX.values():
            all_f |= feats
        return all_f


# ---------------------------------------------------------------------------
# License data model
# ---------------------------------------------------------------------------

@dataclass
class License:
    """A petroppo software license.

    Attributes
    ----------
    license_id : str
        Unique license identifier (UUID).
    license_type : LicenseType
        License tier (community, professional, enterprise, trial).
    customer : str
        Customer or organization name.
    email : str
        Contact email.
    issued_at : float
        Issue timestamp (Unix epoch seconds).
    expires_at : float
        Expiration timestamp (Unix epoch seconds).  0 = never expires
        (community licenses).
    max_seats : int
        Maximum number of concurrent seats (users).  Enterprise licenses
        support multi-seat; others are single-seat.
    features : set
        Set of feature keys granted by this license.  Derived from
        license_type but can be customized.
    status : LicenseStatus
        Current license status.
    activation_code : str
        One-time activation code for online activation.
    activated_at : float or None
        Activation timestamp, or None if not yet activated.
    signature : str
        HMAC-SHA256 signature of the license payload (for tamper
        detection).
    metadata : dict
        Additional metadata (sales order, PO number, etc.).
    """

    license_id: str
    license_type: LicenseType
    customer: str
    email: str
    issued_at: float
    expires_at: float
    max_seats: int = 1
    features: set = field(default_factory=set)
    status: LicenseStatus = LicenseStatus.PENDING_ACTIVATION
    activation_code: str = ""
    activated_at: Optional[float] = None
    signature: str = ""
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.features:
            self.features = LicenseFeatures.features_for(self.license_type)

    @property
    def is_expired(self) -> bool:
        """Check if the license has expired."""
        if self.expires_at == 0:
            return False  # never expires
        return time.time() > self.expires_at

    @property
    def is_active(self) -> bool:
        """Check if the license is active and not expired."""
        return (
            self.status == LicenseStatus.ACTIVE
            and not self.is_expired
        )

    @property
    def days_until_expiry(self) -> float:
        """Days until expiration (negative if expired).  inf if never expires."""
        if self.expires_at == 0:
            return float("inf")
        return (self.expires_at - time.time()) / 86400.0

    def has_feature(self, feature: str) -> bool:
        """Check if this license grants access to a feature."""
        return feature in self.features

    def to_dict(self) -> dict:
        """Serialize to a dict (for key generation / storage)."""
        return {
            "license_id": self.license_id,
            "license_type": self.license_type.value,
            "customer": self.customer,
            "email": self.email,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "max_seats": self.max_seats,
            "features": sorted(self.features),
            "status": self.status.value,
            "activation_code": self.activation_code,
            "activated_at": self.activated_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict, signature: str = "") -> "License":
        """Deserialize from a dict."""
        return cls(
            license_id=data["license_id"],
            license_type=LicenseType(data["license_type"]),
            customer=data["customer"],
            email=data["email"],
            issued_at=data["issued_at"],
            expires_at=data["expires_at"],
            max_seats=data.get("max_seats", 1),
            features=set(data.get("features", [])),
            status=LicenseStatus(data.get("status", "pending_activation")),
            activation_code=data.get("activation_code", ""),
            activated_at=data.get("activated_at"),
            signature=signature,
            metadata=data.get("metadata", {}),
        )

    def payload_string(self) -> str:
        """Canonical payload string for signing / verification."""
        d = self.to_dict()
        # Remove volatile fields from signature payload
        d.pop("status", None)  # status changes, not part of signature
        d.pop("activated_at", None)
        return json.dumps(d, sort_keys=True, separators=(",", ":"))


# ---------------------------------------------------------------------------
# License key generator (HMAC-signed)
# ---------------------------------------------------------------------------

class LicenseKeyGenerator:
    """Generate and verify HMAC-signed license keys.

    License keys are base64-encoded JSON payloads with an appended
    HMAC-SHA256 signature.  The key format is::

        <base64(payload_json)>.<base64(hmac_signature)>

    The signing key (secret) is known only to the license issuer
    (petroppo vendor).  Clients verify keys using a public verification
    key derived from the secret.
    """

    def __init__(self, secret: bytes = b"petroppo-license-secret-v39") -> None:
        if isinstance(secret, str):
            secret = secret.encode("utf-8")
        self.secret = secret

    def _sign(self, payload: str) -> str:
        """Compute HMAC-SHA256 signature of a payload string."""
        sig = hmac.new(self.secret, payload.encode("utf-8"), hashlib.sha256)
        return sig.hexdigest()

    def generate_key(self, license_obj: License) -> str:
        """Generate a signed license key string for a License.

        Parameters
        ----------
        license_obj : License
            The license to generate a key for.

        Returns
        -------
        key : str
            The license key string (payload.signature).
        """
        import base64
        payload = license_obj.payload_string()
        signature = self._sign(payload)
        license_obj.signature = signature
        payload_b64 = base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii")
        return f"{payload_b64}.{signature}"

    def verify_key(self, key: str) -> License:
        """Verify a license key and return the License object.

        Raises
        ------
        LicenseInvalidError
            If the key format is invalid or the signature does not match.
        """
        import base64
        try:
            parts = key.strip().split(".")
            if len(parts) != 2:
                raise LicenseInvalidError("Invalid key format: expected payload.signature")
            payload_b64, signature = parts
            payload = base64.urlsafe_b64decode(payload_b64.encode("ascii")).decode("utf-8")
        except Exception as e:
            raise LicenseInvalidError(f"Failed to decode key: {e}")

        expected_sig = self._sign(payload)
        if not hmac.compare_digest(signature, expected_sig):
            raise LicenseInvalidError("Invalid license key signature (tampered or wrong secret)")

        data = json.loads(payload)
        license_obj = License.from_dict(data, signature=signature)
        return license_obj


# ---------------------------------------------------------------------------
# Usage tracker
# ---------------------------------------------------------------------------

class UsageTracker:
    """Track per-license feature usage.

    Maintains counters for each feature used under each license.  This
    enables metered billing and compliance reporting.
    """

    def __init__(self) -> None:
        # {license_id: {feature: count}}
        self._counts: dict[str, dict[str, int]] = {}
        # {license_id: {feature: last_used_timestamp}}
        self._last_used: dict[str, dict[str, float]] = {}

    def record(self, license_id: str, feature: str) -> int:
        """Record one use of a feature under a license.  Returns new count."""
        if license_id not in self._counts:
            self._counts[license_id] = {}
            self._last_used[license_id] = {}
        self._counts[license_id][feature] = self._counts[license_id].get(feature, 0) + 1
        self._last_used[license_id][feature] = time.time()
        return self._counts[license_id][feature]

    def get_counts(self, license_id: str) -> dict[str, int]:
        """Get feature usage counts for a license."""
        return dict(self._counts.get(license_id, {}))

    def get_total(self, license_id: str) -> int:
        """Get total usage count across all features for a license."""
        return sum(self.get_counts(license_id).values())

    def get_last_used(self, license_id: str, feature: str) -> Optional[float]:
        """Get last-used timestamp for a feature under a license."""
        return self._last_used.get(license_id, {}).get(feature)

    def reset(self, license_id: str) -> None:
        """Reset usage counters for a license."""
        self._counts.pop(license_id, None)
        self._last_used.pop(license_id, None)

    def report(self, license_id: str) -> dict:
        """Generate a usage report for a license."""
        counts = self.get_counts(license_id)
        return {
            "license_id": license_id,
            "total_uses": sum(counts.values()),
            "features_used": len(counts),
            "per_feature": dict(counts),
            "last_used": dict(self._last_used.get(license_id, {})),
        }


# ---------------------------------------------------------------------------
# License server stub
# ---------------------------------------------------------------------------

class LicenseServer:
    """In-process license server stub.

    Provides online activation and license storage.  In production this
    would be replaced by an HTTP license server; the interface remains
    the same.

    The server stores licenses indexed by ``license_id`` and
    ``activation_code``.  Activation consumes the one-time activation
    code and transitions the license to ACTIVE status.
    """

    def __init__(self) -> None:
        self._licenses: dict[str, License] = {}  # by license_id
        self._by_activation: dict[str, str] = {}  # activation_code -> license_id
        self._log: list[dict] = []

    def _log_event(self, event: str, license_id: str, detail: str = "") -> None:
        self._log.append({
            "timestamp": time.time(),
            "event": event,
            "license_id": license_id,
            "detail": detail,
        })

    def register(self, license_obj: License) -> None:
        """Register a license on the server."""
        self._licenses[license_obj.license_id] = license_obj
        if license_obj.activation_code:
            self._by_activation[license_obj.activation_code] = license_obj.license_id
        self._log_event("register", license_obj.license_id)

    def activate(self, activation_code: str) -> License:
        """Activate a license by activation code.

        Raises
        ------
        LicenseError
            If the activation code is unknown or already used.
        LicenseExpiredError
            If the license has expired.
        """
        license_id = self._by_activation.get(activation_code)
        if license_id is None:
            raise LicenseError("Unknown activation code")
        license_obj = self._licenses[license_id]
        if license_obj.status == LicenseStatus.ACTIVE:
            raise LicenseError("License already activated")
        if license_obj.is_expired:
            raise LicenseExpiredError("License has expired")
        license_obj.status = LicenseStatus.ACTIVE
        license_obj.activated_at = time.time()
        # Consume activation code (one-time use)
        self._by_activation.pop(activation_code, None)
        self._log_event("activate", license_id, f"activated at {license_obj.activated_at}")
        return license_obj

    def validate(self, license_id: str) -> License:
        """Validate a license by ID (online check).

        Raises
        ------
        LicenseError
            If the license is unknown.
        LicenseExpiredError
            If the license has expired.
        """
        license_obj = self._licenses.get(license_id)
        if license_obj is None:
            raise LicenseError("Unknown license ID")
        if license_obj.is_expired:
            if license_obj.status != LicenseStatus.EXPIRED:
                license_obj.status = LicenseStatus.EXPIRED
                self._log_event("expire", license_id)
            raise LicenseExpiredError("License has expired")
        return license_obj

    def revoke(self, license_id: str) -> None:
        """Revoke a license."""
        license_obj = self._licenses.get(license_id)
        if license_obj is None:
            raise LicenseError("Unknown license ID")
        license_obj.status = LicenseStatus.REVOKED
        self._log_event("revoke", license_id)

    def suspend(self, license_id: str) -> None:
        """Suspend a license (temporarily)."""
        license_obj = self._licenses.get(license_id)
        if license_obj is None:
            raise LicenseError("Unknown license ID")
        license_obj.status = LicenseStatus.SUSPENDED
        self._log_event("suspend", license_id)

    def reactivate(self, license_id: str) -> None:
        """Reactivate a suspended license."""
        license_obj = self._licenses.get(license_id)
        if license_obj is None:
            raise LicenseError("Unknown license ID")
        if license_obj.is_expired:
            raise LicenseExpiredError("License has expired")
        license_obj.status = LicenseStatus.ACTIVE
        self._log_event("reactivate", license_id)

    def get(self, license_id: str) -> Optional[License]:
        """Get a license by ID, or None."""
        return self._licenses.get(license_id)

    def list_licenses(self) -> list[License]:
        """List all registered licenses."""
        return list(self._licenses.values())

    def audit_log(self) -> list[dict]:
        """Return the server audit log."""
        return list(self._log)


# ---------------------------------------------------------------------------
# License manager (client-side)
# ---------------------------------------------------------------------------

class LicenseManager:
    """Client-side license manager.

    Manages the current license on a petroppo installation.  Supports:
    * Loading a license from a key string (offline verification).
    * Online activation via a :class:`LicenseServer`.
    * Feature access checking.
    * Usage tracking.

    Parameters
    ----------
    secret : bytes
        The HMAC signing secret (must match the issuer's secret).
    server : LicenseServer or None
        Optional license server for online activation / validation.
    """

    def __init__(self, secret: bytes = b"petroppo-license-secret-v39",
                 server: Optional[LicenseServer] = None) -> None:
        self.generator = LicenseKeyGenerator(secret=secret)
        self.server = server
        self.usage = UsageTracker()
        self._current_license: Optional[License] = None
        self._log: list[dict] = []

    def _log_event(self, event: str, detail: str = "") -> None:
        self._log.append({
            "timestamp": time.time(),
            "event": event,
            "detail": detail,
        })

    # -- License loading -------------------------------------------------

    def load_key(self, key: str, activate: bool = False) -> License:
        """Load and verify a license from a key string.

        Parameters
        ----------
        key : str
            The license key (payload.signature).
        activate : bool
            If True and a server is connected, attempt online activation.

        Raises
        ------
        LicenseInvalidError
            If the key is invalid or tampered.
        LicenseExpiredError
            If the license has expired.
        """
        license_obj = self.generator.verify_key(key)
        if license_obj.is_expired:
            license_obj.status = LicenseStatus.EXPIRED
            self._log_event("load_expired", license_obj.license_id)
            raise LicenseExpiredError(f"License expired {license_obj.days_until_expiry:.1f} days ago")

        if activate and self.server is not None:
            if license_obj.activation_code:
                try:
                    license_obj = self.server.activate(license_obj.activation_code)
                    self._log_event("activate", license_obj.license_id)
                except LicenseError:
                    # Already activated or activation failed; fall through
                    pass

        # When loading offline (no server or activation not requested),
        # the HMAC signature proves the license was issued by the vendor.
        # Treat non-expired, non-revoked licenses as active for offline use.
        if license_obj.status in (LicenseStatus.PENDING_ACTIVATION,
                                  LicenseStatus.SUSPENDED):
            license_obj.status = LicenseStatus.ACTIVE

        self._current_license = license_obj
        self._log_event("load", license_obj.license_id)
        return license_obj

    def activate_online(self, activation_code: str) -> License:
        """Activate a license online via the license server.

        Raises
        ------
        LicenseError
            If no server is connected or activation fails.
        """
        if self.server is None:
            raise LicenseError("No license server connected")
        license_obj = self.server.activate(activation_code)
        self._current_license = license_obj
        self._log_event("activate_online", license_obj.license_id)
        return license_obj

    def validate_online(self) -> bool:
        """Validate the current license online.

        Returns True if valid, False otherwise.
        """
        if self._current_license is None:
            return False
        if self.server is None:
            # Offline validation: just check expiration
            return not self._current_license.is_expired
        try:
            self.server.validate(self._current_license.license_id)
            return True
        except (LicenseError, LicenseExpiredError):
            return False

    # -- Feature access --------------------------------------------------

    @property
    def current_license(self) -> Optional[License]:
        """The currently loaded license, or None."""
        return self._current_license

    @property
    def is_licensed(self) -> bool:
        """Check if a valid license is loaded."""
        return self._current_license is not None and self._current_license.is_active

    def check_feature(self, feature: str) -> bool:
        """Check if the current license grants access to a feature.

        Returns
        ------
        bool
            True if the feature is licensed, False otherwise.
        """
        if self._current_license is None:
            return False
        if not self._current_license.is_active:
            return False
        return self._current_license.has_feature(feature)

    def require_feature(self, feature: str) -> None:
        """Require a feature; raise if not licensed.

        Raises
        ------
        FeatureNotLicensedError
            If the feature is not available under the current license.
        LicenseError
            If no license is loaded.
        """
        if self._current_license is None:
            raise LicenseError("No license loaded")
        if not self._current_license.is_active:
            raise LicenseError(f"License is not active (status: {self._current_license.status.value})")
        if not self._current_license.has_feature(feature):
            raise FeatureNotLicensedError(
                f"Feature '{feature}' is not licensed under "
                f"{self._current_license.license_type.value} license"
            )
        # Track usage
        self.usage.record(self._current_license.license_id, feature)

    def available_features(self) -> set:
        """Return the set of features available under the current license."""
        if self._current_license is None:
            return set()
        return self._current_license.features

    def license_info(self) -> dict:
        """Return a summary of the current license."""
        if self._current_license is None:
            return {"licensed": False}
        lic = self._current_license
        return {
            "licensed": True,
            "license_id": lic.license_id,
            "license_type": lic.license_type.value,
            "customer": lic.customer,
            "email": lic.email,
            "status": lic.status.value,
            "is_active": lic.is_active,
            "is_expired": lic.is_expired,
            "days_until_expiry": lic.days_until_expiry,
            "max_seats": lic.max_seats,
            "features": sorted(lic.features),
            "n_features": len(lic.features),
            "activated_at": lic.activated_at,
        }

    def audit_log(self) -> list[dict]:
        """Return the manager audit log."""
        return list(self._log)

    def clear(self) -> None:
        """Clear the current license."""
        self._current_license = None
        self._log_event("clear")


# ---------------------------------------------------------------------------
# License factory (convenience for issuing licenses)
# ---------------------------------------------------------------------------

def create_license(
    license_type: LicenseType,
    customer: str,
    email: str,
    duration_days: float = 365.0,
    max_seats: int = 1,
    metadata: Optional[dict] = None,
) -> License:
    """Create a new License with sensible defaults.

    Parameters
    ----------
    license_type : LicenseType
        The license tier.
    customer : str
        Customer or organization name.
    email : str
        Contact email.
    duration_days : float
        License duration in days.  Use 0 for community (never expires).
        Default 365 for paid licenses, 30 for trial.
    max_seats : int
        Maximum concurrent seats.
    metadata : dict, optional
        Additional metadata.

    Returns
    -------
    License
        A new License object (not yet signed or activated).
    """
    now = time.time()

    # Defaults per type
    if license_type == LicenseType.COMMUNITY:
        duration_days = 0  # never expires
        max_seats = 1
    elif license_type == LicenseType.TRIAL:
        duration_days = 30  # 30-day trial
        max_seats = 1
    elif license_type == LicenseType.ENTERPRISE:
        if max_seats < 1:
            max_seats = 10

    expires_at = 0.0 if duration_days == 0 else now + duration_days * 86400

    return License(
        license_id=str(uuid.uuid4()),
        license_type=license_type,
        customer=customer,
        email=email,
        issued_at=now,
        expires_at=expires_at,
        max_seats=max_seats,
        activation_code=secrets.token_hex(8),
        metadata=metadata or {},
    )


def issue_license_key(
    license_obj: License,
    secret: bytes = b"petroppo-license-secret-v39",
) -> str:
    """Sign a License and return its key string."""
    gen = LicenseKeyGenerator(secret=secret)
    return gen.generate_key(license_obj)
