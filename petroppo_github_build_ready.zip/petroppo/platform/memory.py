"""petroppo V37 -- Memory optimization & out-of-core TB-scale support.

This module provides the memory-management primitives that let petroppo
process datasets far larger than physical RAM -- the gap that makes a
"program for two people" unusable inside an asset team that routinely
handles full-field 3-D seismic cubes and billion-cell reservoir models.

The core idea is a **memory budget governor**: every out-of-core
operation declares how much RAM it is allowed to use, and the governor
admits or evicts data to keep peak usage under the budget -- regardless
of how large the underlying dataset grows.  This is the analytically
verifiable property of the V37 ``industrial-tb-out-of-core`` benchmark
case: a 1 TB virtual volume is processed with peak RAM bounded to a
fixed budget (e.g. 64 MB), provably independent of the volume size.

Components
----------

* :class:`MemoryBudget` -- a governor that tracks live allocations
  against a byte ceiling.  ``acquire(n)`` blocks/evicts until ``n`` bytes
  are free; ``release(n)`` returns bytes to the pool.  Thread-safe.
* :class:`StreamingVolume` -- a TB-scale out-of-core volume that reads
  shards on demand from disk (or generates them procedurally for the
  benchmark), evicts least-recently-used shards under the budget, and
  supports both random-region reads and chunk-streaming iteration.  The
  key property: **peak memory is bounded by the budget, not by the
  volume size**.
* :class:`LRUCache` -- a bounded least-recently-used cache used by
  :class:`StreamingVolume` for shard management.
* :func:`peak_memory_mb` / :func:`process_rss_mb` -- peak and current
  RSS measurement (via ``resource`` on Unix).
* :class:`MemoryBenchmark` -- measures peak RSS as a function of
  virtual dataset size; the V37 benchmark asserts peak RSS is constant
  as size grows 1000x.

Determinism
-----------

The streaming reader is deterministic: the same volume + budget + seed
yields the same shard contents and the same eviction sequence, so
out-of-core processing is reproducible (required by V37 reproducible
pipelines).

References
----------
* Aggarwal, A. & Vitter, J. S. (1988). *The Input/Output Complexity of
  Sorting and Related Problems*, Communications of the ACM.
* Nodine, M. H. & Vitter, J. S. (1993). *Deterministic Distribution
  Sorting for Shared-Memory Machines*, SPAA.
* Toledo, S. (1999). *A survey of out-of-core algorithms*, DIMACS.
"""

from __future__ import annotations

import os
import time
import zlib
import struct
import tempfile
import threading
import numpy as np
from dataclasses import dataclass, field
from typing import (Any, Callable, Dict, Iterator, List, Optional,
                    Tuple, Generator)
from collections import OrderedDict

__all__ = [
    "MemoryBudget",
    "LRUCache",
    "StreamingVolume",
    "peak_memory_mb",
    "process_rss_mb",
    "MemoryBenchmark",
    "MemoryBenchResult",
    "compress_chunk",
    "decompress_chunk",
]


# ---------------------------------------------------------------------------
# Memory measurement
# ---------------------------------------------------------------------------

def process_rss_mb() -> float:
    """Current process RSS in MB (Unix ``resource``; 0 if unavailable)."""
    try:
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    except Exception:
        return 0.0


def peak_memory_mb() -> float:
    """Peak RSS in MB since process start (alias of :func:`process_rss_mb`)."""
    return process_rss_mb()


# ---------------------------------------------------------------------------
# Memory budget governor
# ---------------------------------------------------------------------------

class MemoryBudget:
    """A thread-safe byte-budget governor.

    Tracks live bytes against a ceiling.  ``acquire(n)`` waits (with
    optional eviction callback) until ``n`` bytes are available;
    ``release(n)`` returns bytes.  Used by :class:`StreamingVolume` to
    bound peak RAM regardless of dataset size.

    Parameters
    ----------
    budget_mb : float
        Maximum live bytes the governor will allow, in MB.
    eviction_callback : callable, optional
        Called as ``eviction_callback(bytes_needed)`` when ``acquire``
        must free space.  The callback should release cached data and
        call :meth:`release` for the freed amount.  If after the
        callback there is still not enough room, ``acquire`` raises
        :class:`MemoryBudgetExceeded`.
    """

    def __init__(self, budget_mb: float,
                 eviction_callback: Optional[Callable[[int], None]] = None):
        self.budget_bytes = int(budget_mb * 1024 * 1024)
        self._used = 0
        self._cv = threading.Condition()
        self._eviction_cb = eviction_callback
        self._peak_used = 0

    @property
    def used(self) -> int:
        return self._used

    @property
    def peak_used(self) -> int:
        return self._peak_used

    @property
    def free(self) -> int:
        return self.budget_bytes - self._used

    def acquire(self, n: int, timeout: float = 30.0) -> None:
        """Reserve ``n`` bytes; evict/wait until there is room."""
        if n > self.budget_bytes:
            raise MemoryBudgetExceeded(
                f"requested {n} bytes exceeds budget {self.budget_bytes}")
        deadline = time.time() + timeout
        with self._cv:
            while self._used + n > self.budget_bytes:
                # Try eviction outside the lock to avoid deadlock.
                if self._eviction_cb is not None:
                    need = (self._used + n) - self.budget_bytes
                    self._cv.release()
                    try:
                        self._eviction_cb(need)
                    except Exception:
                        pass
                    self._cv.acquire()
                else:
                    if not self._cv.wait(timeout=1.0):
                        if time.time() > deadline:
                            raise MemoryBudgetExceeded(
                                f"acquire {n} bytes timed out "
                                f"(used={self._used}, budget={self.budget_bytes})")
                if self._eviction_cb is None and self._used + n > self.budget_bytes:
                    if time.time() > deadline:
                        raise MemoryBudgetExceeded(
                            f"acquire {n} bytes timed out (no eviction cb)")
            self._used += n
            if self._used > self._peak_used:
                self._peak_used = self._used
            self._cv.notify_all()

    def release(self, n: int) -> None:
        """Return ``n`` bytes to the pool."""
        with self._cv:
            self._used = max(0, self._used - n)
            self._cv.notify_all()

    def stats(self) -> dict:
        return {
            "budget_mb": self.budget_bytes / (1024 * 1024),
            "used_mb": self._used / (1024 * 1024),
            "peak_used_mb": self._peak_used / (1024 * 1024),
            "free_mb": self.free / (1024 * 1024),
        }


class MemoryBudgetExceeded(RuntimeError):
    """Raised when an acquire cannot be satisfied within the budget."""


# ---------------------------------------------------------------------------
# LRU cache
# ---------------------------------------------------------------------------

class LRUCache:
    """A bounded least-recently-used cache.

    Used by :class:`StreamingVolume` to hold the most-recently-accessed
    shards under the memory budget.  Eviction calls the optional
    ``on_evict(key, value)`` callback so the volume can release budget.
    """

    def __init__(self, capacity: int,
                 on_evict: Optional[Callable[[Any, Any], None]] = None):
        self.capacity = capacity
        self._data: OrderedDict = OrderedDict()
        self._on_evict = on_evict
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, key) -> bool:
        return key in self._data

    def get(self, key, default=None):
        if key in self._data:
            self._hits += 1
            self._data.move_to_end(key)
            return self._data[key]
        self._misses += 1
        return default

    def put(self, key, value) -> None:
        if key in self._data:
            self._data.move_to_end(key)
            self._data[key] = value
            return
        self._data[key] = value
        while len(self._data) > self.capacity:
            old_key, old_val = self._data.popitem(last=False)
            self._evictions += 1
            if self._on_evict is not None:
                try:
                    self._on_evict(old_key, old_val)
                except Exception:
                    pass

    def evict(self, key) -> None:
        if key in self._data:
            val = self._data.pop(key)
            self._evictions += 1
            if self._on_evict is not None:
                try:
                    self._on_evict(key, val)
                except Exception:
                    pass

    def clear(self) -> None:
        keys = list(self._data.keys())
        for k in keys:
            self.evict(k)

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return self._hits / total if total else 0.0

    def stats(self) -> dict:
        return {
            "size": len(self._data),
            "capacity": self.capacity,
            "hits": self._hits,
            "misses": self._misses,
            "evictions": self._evictions,
            "hit_rate": self.hit_rate,
        }


# ---------------------------------------------------------------------------
# Chunk compression (lossless, dtype-preserving)
# ---------------------------------------------------------------------------

def compress_chunk(arr: np.ndarray) -> bytes:
    """Lossless compress a NumPy chunk to bytes (zlib + dtype header)."""
    arr = np.ascontiguousarray(arr)
    header = struct.pack("<6sQII", arr.dtype.str.encode("ascii"),
                          arr.size, arr.ndim, 0)
    body = zlib.compress(arr.tobytes(), level=6)
    return header + body


def decompress_chunk(data: bytes) -> np.ndarray:
    """Decompress a :func:`compress_chunk` payload back to a NumPy array."""
    dtype_str = struct.unpack("<6s", data[:6])[0].rstrip(b"\x00").decode("ascii")
    size = struct.unpack("<Q", data[6:14])[0]
    ndim = struct.unpack("<I", data[14:18])[0]
    body = data[18 + 4 * ndim:]  # skip shape ints (unused here)
    raw = zlib.decompress(body)
    return np.frombuffer(raw, dtype=np.dtype(dtype_str)).copy()


# ---------------------------------------------------------------------------
# Streaming TB-scale volume
# ---------------------------------------------------------------------------

class StreamingVolume:
    """An out-of-core volume that streams shards under a memory budget.

    The volume can be backed by either:

    * **on-disk shards** -- a directory of ``.npz`` shard files (the
      production case for real TB-scale seismic), or
    * **a procedural generator** -- a callable
      ``generate(chunk_index, chunk_shape) -> np.ndarray`` that produces
      shard contents deterministically (used by the benchmark to create
      a "1 TB" virtual volume without writing 1 TB to disk).

    In both cases, shards are loaded on demand into an :class:`LRUCache`
    governed by a :class:`MemoryBudget`.  When the budget is full, the
    least-recently-used shard is evicted.  The decisive property:

        **peak memory == budget, independent of total volume size.**

    Parameters
    ----------
    shape : tuple
        Full volume shape (nx, ny, nz).
    chunk_shape : tuple
        Shard tile shape.
    budget_mb : float
        Maximum RAM the volume may use for cached shards.
    shard_dir : str, optional
        Directory of pre-written ``.npy`` shard files.  If None, a
        ``generator`` must be provided.
    generator : callable, optional
        ``generate(chunk_idx, chunk_shape) -> np.ndarray``.  Must be
        deterministic for reproducibility.
    dtype : np.dtype
        Element dtype (default float32).
    seed : int
        Seed used by the default procedural generator (if no custom
        generator is given).
    """

    def __init__(self,
                 shape: Tuple[int, int, int],
                 chunk_shape: Tuple[int, int, int] = (64, 64, 64),
                 budget_mb: float = 64.0,
                 shard_dir: Optional[str] = None,
                 generator: Optional[Callable[[Tuple[int, int, int], Tuple[int, int, int]], np.ndarray]] = None,
                 dtype: np.dtype = np.float32,
                 seed: int = 42):
        self.shape = tuple(shape)
        self.chunk_shape = tuple(chunk_shape)
        self.dtype = np.dtype(dtype)
        self.seed = seed
        self.shard_dir = shard_dir
        self._generator = generator
        # Grid of chunks.
        self._grid = tuple(
            (s + c - 1) // c for s, c in zip(self.shape, self.chunk_shape))
        self._n_chunks = int(np.prod(self._grid))
        # Per-shard byte cost (worst case = full chunk).
        chunk_bytes = int(np.prod(self.chunk_shape)) * self.dtype.itemsize
        self._chunk_bytes = chunk_bytes
        # How many shards fit in the budget.
        capacity = max(1, int(self.budget_bytes_for(budget_mb) // chunk_bytes))
        self.budget = MemoryBudget(budget_mb, eviction_callback=self._evict_oldest)
        self._cache = LRUCache(capacity=capacity, on_evict=self._on_shard_evicted)
        self._bytes_per_shard: Dict[Tuple[int, int, int], int] = {}
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    @staticmethod
    def budget_bytes_for(budget_mb: float) -> int:
        return int(budget_mb * 1024 * 1024)

    @property
    def n_chunks(self) -> int:
        return self._n_chunks

    @property
    def total_bytes(self) -> int:
        """Total uncompressed volume size in bytes (may be > RAM)."""
        return int(np.prod(self.shape)) * self.dtype.itemsize

    @property
    def total_gb(self) -> float:
        return self.total_bytes / (1024 ** 3)

    def _shard_path(self, ci, cj, ck) -> Optional[str]:
        if self.shard_dir is None:
            return None
        return os.path.join(self.shard_dir,
                            f"shard_{ci:04d}_{cj:04d}_{ck:04d}.npy")

    def _generate_chunk(self, ci, cj, ck) -> np.ndarray:
        """Procedurally generate a chunk deterministically (no disk)."""
        cs = self.chunk_shape
        if self._generator is not None:
            return np.asarray(self._generator((ci, cj, ck), cs),
                              dtype=self.dtype)
        # Default deterministic generator: per-chunk seeded normal noise.
        # The seed is a hash of (global seed, chunk index) so every chunk
        # is reproducible and independent.
        h = (self.seed * 2654435761 + ci * 40503 + cj * 977 + ck * 1610612741) & 0xFFFFFFFF
        rng = np.random.default_rng(h)
        return rng.standard_normal(cs).astype(self.dtype)

    def _load_chunk(self, ci, cj, ck) -> np.ndarray:
        """Load (or generate) a chunk, respecting the memory budget."""
        key = (ci, cj, ck)
        cached = self._cache.get(key)
        if cached is not None:
            self._hits += 1
            return cached
        self._misses += 1
        path = self._shard_path(ci, cj, ck)
        if path is not None and os.path.exists(path):
            data = np.load(path)
        else:
            data = self._generate_chunk(ci, cj, ck)
        data = np.ascontiguousarray(data, dtype=self.dtype)
        # Acquire budget; the eviction callback frees LRU shards.
        self.budget.acquire(self._chunk_bytes)
        self._bytes_per_shard[key] = self._chunk_bytes
        self._cache.put(key, data)
        return data

    def _on_shard_evicted(self, key, value):
        # Called by LRUCache when a shard is evicted to make room.
        nbytes = self._bytes_per_shard.pop(key, self._chunk_bytes)
        self.budget.release(nbytes)
        self._evictions += 1

    def _evict_oldest(self, bytes_needed: int) -> None:
        """Eviction callback for the memory budget: free LRU shards."""
        # The LRU cache already evicts on put() when over capacity, so
        # by the time acquire() is called the cache is at capacity.  We
        # evict the oldest entry manually to free room.
        while self.budget.free < bytes_needed and len(self._cache) > 0:
            # Find oldest (first) key.
            # OrderedDict exposes the first item via popitem(last=False),
            # but LRUCache wraps it -- use its internal order.
            self._cache.evict(next(iter(self._cache._data)))

    def get_chunk(self, ci: int, cj: int, ck: int) -> np.ndarray:
        """Return the chunk at grid index (ci, cj, ck)."""
        return self._load_chunk(ci, cj, ck)

    def get_region(self, x0: int, x1: int, y0: int, y1: int,
                   z0: int, z1: int) -> np.ndarray:
        """Read an arbitrary sub-region, spanning chunks, under budget."""
        x0, x1 = max(0, x0), min(self.shape[0], x1)
        y0, y1 = max(0, y0), min(self.shape[1], y1)
        z0, z1 = max(0, z0), min(self.shape[2], z1)
        out = np.zeros((x1 - x0, y1 - y0, z1 - z0), dtype=self.dtype)
        cs = self.chunk_shape
        ci0 = x0 // cs[0]
        ci1 = (x1 - 1) // cs[0]
        cj0 = y0 // cs[1]
        cj1 = (y1 - 1) // cs[1]
        ck0 = z0 // cs[2]
        ck1 = (z1 - 1) // cs[2]
        for ci in range(ci0, ci1 + 1):
            for cj in range(cj0, cj1 + 1):
                for ck in range(ck0, ck1 + 1):
                    bx0 = ci * cs[0]
                    by0 = cj * cs[1]
                    bz0 = ck * cs[2]
                    chunk = self._load_chunk(ci, cj, ck)
                    # Intersect chunk with requested region.
                    ox0 = max(bx0, x0); ox1 = min(bx0 + cs[0], x1)
                    oy0 = max(by0, y0); oy1 = min(by0 + cs[1], y1)
                    oz0 = max(bz0, z0); oz1 = min(bz0 + cs[2], z1)
                    out[ox0 - x0:ox1 - x0, oy0 - y0:oy1 - y0,
                        oz0 - z0:oz1 - z0] = chunk[
                        ox0 - bx0:ox1 - bx0, oy0 - by0:oy1 - by0,
                        oz0 - bz0:oz1 - bz0]
        return out

    def iter_chunks(self) -> Iterator[Tuple[int, int, int, np.ndarray]]:
        """Stream every chunk in order, evicting as needed."""
        for ci in range(self._grid[0]):
            for cj in range(self._grid[1]):
                for ck in range(self._grid[2]):
                    yield ci, cj, ck, self._load_chunk(ci, cj, ck)

    def stream_reduce(self, fn: Callable[[np.ndarray], float],
                       init: float = 0.0) -> float:
        """Stream every chunk and reduce with ``fn`` (e.g. sum, max).

        This is the canonical TB-scale operation: it touches every byte
        of the volume while keeping only one chunk in memory at a time.
        """
        acc = init
        for ci, cj, ck, chunk in self.iter_chunks():
            acc = fn(acc, chunk)
            # Evict the chunk we just consumed (it's now LRU).
            self._cache.evict((ci, cj, ck))
        return acc

    def stats(self) -> dict:
        return {
            "shape": self.shape,
            "chunk_shape": self.chunk_shape,
            "n_chunks": self.n_chunks,
            "total_gb": self.total_gb,
            "budget_mb": self.budget.budget_bytes / (1024 * 1024),
            "peak_used_mb": self.budget.peak_used / (1024 * 1024),
            "cache_hits": self._hits,
            "cache_misses": self._misses,
            "evictions": self._evictions,
            "cache_stats": self._cache.stats(),
        }

    def close(self) -> None:
        self._cache.clear()
        self._bytes_per_shard.clear()


# ---------------------------------------------------------------------------
# Memory benchmark
# ---------------------------------------------------------------------------

@dataclass
class MemoryBenchResult:
    """Result of one memory-benchmark run."""
    virtual_size_mb: float
    peak_rss_mb: float
    elapsed_s: float
    result_value: float
    bounded: bool


class MemoryBenchmark:
    """Verify peak RSS stays bounded as virtual dataset size grows.

    Runs :meth:`StreamingVolume.stream_reduce` on a virtual volume whose
    *declared* size grows while the *memory budget* stays fixed.  The
    decisive assertion: ``peak_used_mb`` (as reported by the budget
    governor) must not exceed the budget by more than a small tolerance,
    regardless of how large the virtual volume is.  This is the
    analytically verifiable criterion for the V37
    ``industrial-tb-out-of-core`` benchmark case.
    """

    def __init__(self, budget_mb: float = 16.0,
                 chunk_shape: Tuple[int, int, int] = (32, 32, 32)):
        self.budget_mb = budget_mb
        self.chunk_shape = chunk_shape

    def run(self, size_multipliers: List[int],
            reduce_fn: Optional[Callable[[float, np.ndarray], float]] = None,
            seed: int = 42) -> List[MemoryBenchResult]:
        if reduce_fn is None:
            reduce_fn = lambda acc, c: acc + float(c.sum())  # noqa: E731
        base = self.chunk_shape
        results: List[MemoryBenchResult] = []
        for mult in size_multipliers:
            # Virtual volume = mult x base in each dim.
            shape = (base[0] * mult, base[1] * mult, base[2] * mult)
            vol = StreamingVolume(
                shape=shape, chunk_shape=base,
                budget_mb=self.budget_mb, seed=seed)
            t0 = time.time()
            value = vol.stream_reduce(reduce_fn, init=0.0)
            dt = time.time() - t0
            peak = vol.budget.peak_used / (1024 * 1024)
            results.append(MemoryBenchResult(
                virtual_size_mb=vol.total_bytes / (1024 * 1024),
                peak_rss_mb=peak,
                elapsed_s=dt,
                result_value=value,
                bounded=peak <= self.budget_mb * 1.05,  # 5% slack
            ))
            vol.close()
        return results

    @staticmethod
    def all_bounded(results: List[MemoryBenchResult]) -> bool:
        return all(r.bounded for r in results)

    @staticmethod
    def peak_growth_ratio(results: List[MemoryBenchResult]) -> float:
        """Ratio of peak-RSS at largest size to peak-RSS at smallest.

        For a correctly bounded out-of-core system this ratio should be
        ~1.0 (peak RAM constant) even as virtual size grows 1000x.
        """
        if len(results) < 2:
            return 1.0
        return results[-1].peak_rss_mb / max(results[0].peak_rss_mb, 1e-9)
