"""petroppo V38 — Multi-Tenant Architecture.

Turns petroppo from a single-organisation deployment into a
multi-tenant platform where multiple companies / business units share
the same installation with **complete data isolation**.

Key properties
--------------

* **Tenant isolation** — a user in tenant A can never read, write, or
  even enumerate resources belonging to tenant B.  Every API call
  carries an explicit ``tenant_id``; the manager enforces scoping on
  every read/write path.
* **Tenant lifecycle** — create, suspend, resume, delete.  A suspended
  tenant's users cannot authenticate; a deleted tenant's data is
  purged.
* **Resource quotas** — per-tenant limits on storage bytes, number of
  projects, number of users, and number of API calls per hour.
  Exceeding a quota raises :class:`QuotaExceededError`.
* **Per-tenant encryption keys** — each tenant gets its own master key
  derived from a root key + tenant ID (HKDF-style), so compromising
  one tenant's key does not expose another.
* **Tenant-scoped RBAC** — user roles are scoped per-tenant.  A user
  can be an admin in tenant A and a viewer in tenant B.

This is a pure-Python implementation using only the standard library
(``hashlib``, ``hmac``, ``secrets``, ``json``, ``time``, ``dataclasses``).
No external database is required — the in-memory store can be
serialised to JSON for persistence.

References
----------
* NIST SP 800-204D — *Cloud Computing Security: Multi-Tenancy*.
* CSA Cloud Controls Matrix — *Tenant Isolation* (IAM-08).
* RFC 5869 — *HKDF: HMAC-based Extract-and-Expand Key Derivation*.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Set, Tuple

__all__ = [
    "QuotaExceededError",
    "TenantNotFoundError",
    "TenantSuspendedError",
    "TenantAlreadyExistsError",
    "TenantResource",
    "TenantQuota",
    "TenantUsage",
    "Tenant",
    "TenantScopedRole",
    "MultiTenantManager",
    "derive_tenant_key",
    "tenant_id_hash",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class QuotaExceededError(Exception):
    """Raised when a tenant exceeds a configured resource quota."""


class TenantNotFoundError(Exception):
    """Raised when an operation references a non-existent tenant."""


class TenantSuspendedError(Exception):
    """Raised when an operation is attempted on a suspended tenant."""


class TenantAlreadyExistsError(Exception):
    """Raised when trying to create a tenant with a duplicate name."""


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class TenantQuota:
    """Per-tenant resource limits.

    ``-1`` means unlimited.
    """

    max_storage_bytes: int = 10 * 1024**3       # 10 GB default
    max_projects: int = 100
    max_users: int = 50
    max_api_calls_per_hour: int = 10_000
    max_compute_hours_per_month: int = 500

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class TenantUsage:
    """Current resource consumption for a tenant."""

    storage_bytes: int = 0
    projects: int = 0
    users: int = 0
    api_calls_this_hour: int = 0
    api_calls_hour_window_start: float = 0.0
    compute_hours_this_month: float = 0.0
    compute_month_window_start: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class TenantResource:
    """A resource owned by a tenant (project, volume, well, model, etc.)."""

    resource_id: str
    tenant_id: str
    kind: str              # "project", "volume", "well_log", "model", ...
    name: str
    size_bytes: int = 0
    metadata: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    created_by: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Tenant:
    """A tenant (organisation / business unit)."""

    tenant_id: str
    name: str
    created_at: float = field(default_factory=time.time)
    suspended: bool = False
    suspended_at: Optional[float] = None
    suspended_reason: str = ""
    quota: TenantQuota = field(default_factory=TenantQuota)
    usage: TenantUsage = field(default_factory=TenantUsage)
    # Map of username -> role within this tenant
    user_roles: Dict[str, str] = field(default_factory=dict)
    # Per-tenant encryption key (derived from root key)
    encryption_key: bytes = b""
    # Resources owned by this tenant: resource_id -> TenantResource
    resources: Dict[str, TenantResource] = field(default_factory=dict)

    def to_dict(self, include_key: bool = False) -> dict:
        d = {
            "tenant_id": self.tenant_id,
            "name": self.name,
            "created_at": self.created_at,
            "suspended": self.suspended,
            "suspended_at": self.suspended_at,
            "suspended_reason": self.suspended_reason,
            "quota": self.quota.to_dict(),
            "usage": self.usage.to_dict(),
            "user_roles": dict(self.user_roles),
            "resource_count": len(self.resources),
        }
        if include_key:
            d["encryption_key_hex"] = self.encryption_key.hex()
        return d


@dataclass
class TenantScopedRole:
    """A user's role within a specific tenant."""

    tenant_id: str
    username: str
    role: str        # "viewer", "interpreter", "admin"
    assigned_at: float = field(default_factory=time.time)
    assigned_by: str = ""


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------

def derive_tenant_key(root_key: bytes, tenant_id: str) -> bytes:
    """Derive a per-tenant encryption key from a root key.

    Uses an HKDF-Expand-style construction (RFC 5869 simplified):
    ``PRK = HMAC-SHA256(root_key, salt=salt)``
    ``OKM = HMAC-SHA256(PRK, info=tenant_id)``

    This ensures each tenant gets a unique, independent key and that
    compromising one tenant's key reveals nothing about another.
    """
    if not isinstance(root_key, (bytes, bytearray)):
        raise TypeError("root_key must be bytes")
    if not tenant_id:
        raise ValueError("tenant_id must not be empty")

    salt = b"petroppo-tenant-key-derivation-v1"
    prk = hmac.new(bytes(root_key), salt, hashlib.sha256).digest()
    info = f"tenant:{tenant_id}".encode("utf-8")
    okm = hmac.new(prk, info, hashlib.sha256).digest()
    return okm


def tenant_id_hash(tenant_id: str) -> str:
    """Return a SHA-256 hash of a tenant ID (for logging without exposing it)."""
    return hashlib.sha256(tenant_id.encode("utf-8")).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Multi-Tenant Manager
# ---------------------------------------------------------------------------

class MultiTenantManager:
    """Central manager for multi-tenant isolation, quotas, and RBAC.

    Parameters
    ----------
    root_key : bytes, optional
        Master key from which per-tenant encryption keys are derived.
        If ``None``, a random key is generated (suitable for testing;
        in production, load from a secret store).
    """

    def __init__(self, root_key: Optional[bytes] = None):
        self._root_key: bytes = root_key if root_key is not None else secrets.token_bytes(32)
        self._tenants: Dict[str, Tenant] = {}
        self._name_index: Dict[str, str] = {}  # name -> tenant_id
        # Reverse index: username -> set of tenant_ids
        self._user_tenants: Dict[str, Set[str]] = {}
        # API call log: tenant_id -> list of timestamps (for rate limiting)
        self._api_call_log: Dict[str, List[float]] = {}
        # Global admin users (can manage tenants themselves)
        self._global_admins: Set[str] = set()

    # -- Tenant lifecycle -------------------------------------------------

    def create_tenant(
        self,
        name: str,
        quota: Optional[TenantQuota] = None,
        tenant_id: Optional[str] = None,
    ) -> Tenant:
        """Create a new tenant.

        Parameters
        ----------
        name : str
            Human-readable tenant name (must be unique).
        quota : TenantQuota, optional
            Resource limits. Defaults to :class:`TenantQuota` defaults.
        tenant_id : str, optional
            Explicit tenant ID. If ``None``, a random ID is generated.

        Returns
        -------
        Tenant
            The created tenant.

        Raises
        ------
        TenantAlreadyExistsError
            If a tenant with this name (or ID) already exists.
        """
        if not name or not name.strip():
            raise ValueError("tenant name must not be empty")
        if name in self._name_index:
            raise TenantAlreadyExistsError(f"tenant '{name}' already exists")

        tid = tenant_id or self._generate_tenant_id()
        if tid in self._tenants:
            raise TenantAlreadyExistsError(f"tenant_id '{tid}' already exists")

        tenant = Tenant(
            tenant_id=tid,
            name=name,
            quota=quota or TenantQuota(),
            encryption_key=derive_tenant_key(self._root_key, tid),
        )
        self._tenants[tid] = tenant
        self._name_index[name] = tid
        return tenant

    def get_tenant(self, tenant_id: str) -> Tenant:
        """Return the tenant with the given ID.

        Raises
        ------
        TenantNotFoundError
        """
        t = self._tenants.get(tenant_id)
        if t is None:
            raise TenantNotFoundError(f"tenant '{tenant_id}' not found")
        return t

    def get_tenant_by_name(self, name: str) -> Tenant:
        """Return the tenant with the given name."""
        tid = self._name_index.get(name)
        if tid is None:
            raise TenantNotFoundError(f"tenant '{name}' not found")
        return self._tenants[tid]

    def list_tenants(self, include_suspended: bool = True) -> List[Tenant]:
        """List all tenants."""
        result = []
        for t in self._tenants.values():
            if not include_suspended and t.suspended:
                continue
            result.append(t)
        return result

    def suspend_tenant(self, tenant_id: str, reason: str = "") -> None:
        """Suspend a tenant. Its users will no longer be able to authenticate."""
        t = self.get_tenant(tenant_id)
        t.suspended = True
        t.suspended_at = time.time()
        t.suspended_reason = reason

    def resume_tenant(self, tenant_id: str) -> None:
        """Resume a previously suspended tenant."""
        t = self.get_tenant(tenant_id)
        t.suspended = False
        t.suspended_at = None
        t.suspended_reason = ""

    def delete_tenant(self, tenant_id: str) -> None:
        """Delete a tenant and all its data.

        This removes all resources, user roles, and the encryption key.
        The operation is irreversible.
        """
        t = self._tenants.get(tenant_id)
        if t is None:
            raise TenantNotFoundError(f"tenant '{tenant_id}' not found")

        # Remove user-tenant index entries
        for username in t.user_roles:
            if username in self._user_tenants:
                self._user_tenants[username].discard(tenant_id)
                if not self._user_tenants[username]:
                    del self._user_tenants[username]

        # Remove name index
        if t.name in self._name_index:
            del self._name_index[t.name]

        # Remove API call log
        self._api_call_log.pop(tenant_id, None)

        # Remove tenant
        del self._tenants[tenant_id]

    def is_suspended(self, tenant_id: str) -> bool:
        """Check if a tenant is suspended."""
        try:
            return self.get_tenant(tenant_id).suspended
        except TenantNotFoundError:
            return False

    # -- User-tenant RBAC -------------------------------------------------

    def assign_role(
        self,
        tenant_id: str,
        username: str,
        role: str,
        assigned_by: str = "",
    ) -> TenantScopedRole:
        """Assign a role to a user within a tenant.

        Parameters
        ----------
        tenant_id : str
        username : str
        role : str
            One of "viewer", "interpreter", "admin".
        assigned_by : str
            The admin user performing the assignment.

        Raises
        ------
        TenantSuspendedError
            If the tenant is suspended.
        """
        valid_roles = {"viewer", "interpreter", "admin"}
        if role not in valid_roles:
            raise ValueError(f"invalid role '{role}'; must be one of {valid_roles}")

        t = self.get_tenant(tenant_id)
        if t.suspended:
            raise TenantSuspendedError(
                f"tenant '{tenant_id}' is suspended; cannot assign roles"
            )

        t.user_roles[username] = role
        if username not in self._user_tenants:
            self._user_tenants[username] = set()
        self._user_tenants[username].add(tenant_id)

        return TenantScopedRole(
            tenant_id=tenant_id,
            username=username,
            role=role,
            assigned_by=assigned_by,
        )

    def revoke_role(self, tenant_id: str, username: str) -> None:
        """Revoke a user's role within a tenant."""
        t = self.get_tenant(tenant_id)
        t.user_roles.pop(username, None)
        if username in self._user_tenants:
            self._user_tenants[username].discard(tenant_id)
            if not self._user_tenants[username]:
                del self._user_tenants[username]

    def get_role(self, tenant_id: str, username: str) -> Optional[str]:
        """Get a user's role within a tenant (None if not a member)."""
        t = self._tenants.get(tenant_id)
        if t is None:
            return None
        return t.user_roles.get(username)

    def list_user_tenants(self, username: str) -> List[Tuple[str, str]]:
        """List all tenants a user belongs to, with their role in each.

        Returns
        -------
        list of (tenant_id, role) tuples.
        """
        result = []
        for tid in self._user_tenants.get(username, set()):
            t = self._tenants.get(tid)
            if t is not None:
                result.append((tid, t.user_roles.get(username, "viewer")))
        return result

    def list_tenant_users(self, tenant_id: str) -> List[Tuple[str, str]]:
        """List all users in a tenant with their roles."""
        t = self.get_tenant(tenant_id)
        return [(u, r) for u, r in t.user_roles.items()]

    def check_permission(
        self,
        tenant_id: str,
        username: str,
        permission: str,
    ) -> bool:
        """Check if a user has a permission within a tenant.

        Permission mapping:
        - viewer: read
        - interpreter: read, write
        - admin: read, write, delete, manage
        """
        t = self._tenants.get(tenant_id)
        if t is None or t.suspended:
            return False

        role = t.user_roles.get(username)
        if role is None:
            return False

        role_perms = {
            "viewer": {"read"},
            "interpreter": {"read", "write"},
            "admin": {"read", "write", "delete", "manage"},
        }
        return permission in role_perms.get(role, set())

    # -- Resource management (tenant-scoped) ------------------------------

    def create_resource(
        self,
        tenant_id: str,
        kind: str,
        name: str,
        size_bytes: int = 0,
        created_by: str = "",
        metadata: Optional[dict] = None,
    ) -> TenantResource:
        """Create a resource within a tenant.

        Enforces:
        - Tenant must exist and not be suspended.
        - Storage quota check (if size_bytes > 0).
        - Project count quota (if kind == "project").

        Raises
        ------
        QuotaExceededError
        TenantSuspendedError
        """
        t = self.get_tenant(tenant_id)
        if t.suspended:
            raise TenantSuspendedError(
                f"tenant '{tenant_id}' is suspended; cannot create resources"
            )

        # Project count quota
        if kind == "project":
            project_count = sum(
                1 for r in t.resources.values() if r.kind == "project"
            )
            if t.quota.max_projects >= 0 and project_count >= t.quota.max_projects:
                raise QuotaExceededError(
                    f"tenant '{tenant_id}' has reached max_projects quota "
                    f"({t.quota.max_projects})"
                )

        # Storage quota
        if size_bytes > 0 and t.quota.max_storage_bytes >= 0:
            if t.usage.storage_bytes + size_bytes > t.quota.max_storage_bytes:
                raise QuotaExceededError(
                    f"tenant '{tenant_id}' storage quota exceeded: "
                    f"current={t.usage.storage_bytes}, "
                    f"requested={size_bytes}, "
                    f"limit={t.quota.max_storage_bytes}"
                )

        resource_id = self._generate_resource_id()
        resource = TenantResource(
            resource_id=resource_id,
            tenant_id=tenant_id,
            kind=kind,
            name=name,
            size_bytes=size_bytes,
            created_by=created_by,
            metadata=metadata or {},
        )
        t.resources[resource_id] = resource
        t.usage.storage_bytes += size_bytes
        if kind == "project":
            t.usage.projects += 1
        return resource

    def get_resource(self, tenant_id: str, resource_id: str) -> Optional[TenantResource]:
        """Get a resource within a tenant. Returns None if not found.

        This is the **isolation enforcement point**: a resource_id from
        tenant B will not be found when querying tenant A's scope.
        """
        t = self._tenants.get(tenant_id)
        if t is None:
            return None
        return t.resources.get(resource_id)

    def list_resources(
        self,
        tenant_id: str,
        kind: Optional[str] = None,
    ) -> List[TenantResource]:
        """List resources within a tenant. Optionally filter by kind.

        Only returns resources belonging to the specified tenant.
        """
        t = self._tenants.get(tenant_id)
        if t is None:
            return []
        if kind is None:
            return list(t.resources.values())
        return [r for r in t.resources.values() if r.kind == kind]

    def delete_resource(self, tenant_id: str, resource_id: str) -> bool:
        """Delete a resource within a tenant. Returns True if deleted."""
        t = self._tenants.get(tenant_id)
        if t is None:
            return False
        resource = t.resources.pop(resource_id, None)
        if resource is None:
            return False
        t.usage.storage_bytes = max(0, t.usage.storage_bytes - resource.size_bytes)
        if resource.kind == "project":
            t.usage.projects = max(0, t.usage.projects - 1)
        return True

    def update_resource_size(
        self,
        tenant_id: str,
        resource_id: str,
        new_size_bytes: int,
    ) -> None:
        """Update a resource's size (e.g., after appending data).

        Enforces storage quota.
        """
        t = self.get_tenant(tenant_id)
        resource = t.resources.get(resource_id)
        if resource is None:
            raise ValueError(f"resource '{resource_id}' not found in tenant '{tenant_id}'")

        delta = new_size_bytes - resource.size_bytes
        if delta > 0 and t.quota.max_storage_bytes >= 0:
            if t.usage.storage_bytes + delta > t.quota.max_storage_bytes:
                raise QuotaExceededError(
                    f"tenant '{tenant_id}' storage quota exceeded on update"
                )

        t.usage.storage_bytes += delta
        resource.size_bytes = new_size_bytes

    # -- Cross-tenant isolation verification ------------------------------

    def verify_isolation(self, tenant_a_id: str, tenant_b_id: str) -> bool:
        """Verify that tenant A cannot access tenant B's resources.

        This is a self-check that confirms:
        1. Tenant A's resource list contains only tenant A's resources.
        2. Tenant A's users are not in tenant B's user list (unless
           explicitly assigned to both).
        3. A resource_id from tenant B is not retrievable via tenant A.

        Returns
        -------
        bool
            True if isolation holds, False if any breach is detected.
        """
        ta = self._tenants.get(tenant_a_id)
        tb = self._tenants.get(tenant_b_id)
        if ta is None or tb is None:
            return True  # nothing to check

        # Check 1: all resources in A belong to A
        for r in ta.resources.values():
            if r.tenant_id != tenant_a_id:
                return False

        # Check 2: tenant B's resource IDs are not accessible via tenant A
        for rb_id in tb.resources:
            if self.get_resource(tenant_a_id, rb_id) is not None:
                return False

        # Check 3: user lists are independent (a user can be in both
        # only if explicitly assigned to both)
        a_users = set(ta.user_roles.keys())
        b_users = set(tb.user_roles.keys())
        shared = a_users & b_users
        for user in shared:
            if user not in self._user_tenants:
                return False
            if tenant_a_id not in self._user_tenants[user]:
                return False
            if tenant_b_id not in self._user_tenants[user]:
                return False

        return True

    # -- API call rate limiting -------------------------------------------

    def record_api_call(self, tenant_id: str) -> bool:
        """Record an API call for a tenant and check rate limit.

        Returns
        -------
        bool
            True if the call is allowed, False if rate-limited.

        Raises
        ------
        TenantNotFoundError
        TenantSuspendedError
        """
        t = self.get_tenant(tenant_id)
        if t.suspended:
            raise TenantSuspendedError(
                f"tenant '{tenant_id}' is suspended; API calls rejected"
            )

        now = time.time()
        hour = 3600.0

        # Reset hour window if expired
        if now - t.usage.api_calls_hour_window_start > hour:
            t.usage.api_calls_this_hour = 0
            t.usage.api_calls_hour_window_start = now

        if t.quota.max_api_calls_per_hour >= 0:
            if t.usage.api_calls_this_hour >= t.quota.max_api_calls_per_hour:
                return False

        t.usage.api_calls_this_hour += 1
        return True

    def record_compute_time(self, tenant_id: str, hours: float) -> bool:
        """Record compute hours for a tenant and check monthly quota.

        Returns
        -------
        bool
            True if allowed, False if quota exceeded.
        """
        t = self.get_tenant(tenant_id)
        now = time.time()
        month = 30 * 24 * 3600.0

        if now - t.usage.compute_month_window_start > month:
            t.usage.compute_hours_this_month = 0.0
            t.usage.compute_month_window_start = now

        if t.quota.max_compute_hours_per_month >= 0:
            if t.usage.compute_hours_this_month + hours > t.quota.max_compute_hours_per_month:
                return False

        t.usage.compute_hours_this_month += hours
        return True

    # -- Usage & quota inspection ----------------------------------------

    def get_usage(self, tenant_id: str) -> TenantUsage:
        """Return current usage for a tenant."""
        return self.get_tenant(tenant_id).usage

    def get_quota(self, tenant_id: str) -> TenantQuota:
        """Return the quota for a tenant."""
        return self.get_tenant(tenant_id).quota

    def set_quota(self, tenant_id: str, quota: TenantQuota) -> None:
        """Update the quota for a tenant."""
        t = self.get_tenant(tenant_id)
        t.quota = quota

    def check_quota_status(self, tenant_id: str) -> dict:
        """Return a dict of quota vs usage for each resource type."""
        t = self.get_tenant(tenant_id)
        q = t.quota
        u = t.usage
        return {
            "storage_bytes": {
                "limit": q.max_storage_bytes,
                "used": u.storage_bytes,
                "pct": (u.storage_bytes / q.max_storage_bytes * 100)
                if q.max_storage_bytes >= 0 and q.max_storage_bytes > 0
                else 0.0,
            },
            "projects": {
                "limit": q.max_projects,
                "used": u.projects,
                "pct": (u.projects / q.max_projects * 100)
                if q.max_projects >= 0 and q.max_projects > 0
                else 0.0,
            },
            "users": {
                "limit": q.max_users,
                "used": len(t.user_roles),
                "pct": (len(t.user_roles) / q.max_users * 100)
                if q.max_users >= 0 and q.max_users > 0
                else 0.0,
            },
            "api_calls_per_hour": {
                "limit": q.max_api_calls_per_hour,
                "used": u.api_calls_this_hour,
                "pct": (u.api_calls_this_hour / q.max_api_calls_per_hour * 100)
                if q.max_api_calls_per_hour >= 0 and q.max_api_calls_per_hour > 0
                else 0.0,
            },
            "compute_hours_per_month": {
                "limit": q.max_compute_hours_per_month,
                "used": u.compute_hours_this_month,
                "pct": (u.compute_hours_this_month / q.max_compute_hours_per_month * 100)
                if q.max_compute_hours_per_month >= 0 and q.max_compute_hours_per_month > 0
                else 0.0,
            },
        }

    # -- Serialization ----------------------------------------------------

    def to_dict(self, include_keys: bool = False) -> dict:
        """Serialize the manager state to a dict (for persistence)."""
        return {
            "tenants": {
                tid: t.to_dict(include_key=include_keys)
                for tid, t in self._tenants.items()
            },
            "global_admins": list(self._global_admins),
        }

    def to_json(self, include_keys: bool = False) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(include_keys=include_keys), indent=2)

    # -- Internal helpers -------------------------------------------------

    def _generate_tenant_id(self) -> str:
        return "tnt_" + secrets.token_hex(12)

    def _generate_resource_id(self) -> str:
        return "res_" + secrets.token_hex(12)

    # -- Global admin management -----------------------------------------

    def add_global_admin(self, username: str) -> None:
        """Grant a user global admin privileges (can manage all tenants)."""
        self._global_admins.add(username)

    def is_global_admin(self, username: str) -> bool:
        """Check if a user is a global admin."""
        return username in self._global_admins

    def remove_global_admin(self, username: str) -> None:
        """Revoke global admin privileges."""
        self._global_admins.discard(username)


# ---------------------------------------------------------------------------
# Benchmark helper
# ---------------------------------------------------------------------------

def benchmark(n_tenants: int = 10, n_resources_per_tenant: int = 50) -> dict:
    """Run a synthetic benchmark of multi-tenant operations.

    Returns timing and isolation-verification results.
    """
    import time as _time

    mgr = MultiTenantManager(root_key=secrets.token_bytes(32))

    t0 = _time.perf_counter()
    for i in range(n_tenants):
        mgr.create_tenant(f"tenant_{i}")
    t_create_tenants = _time.perf_counter() - t0

    t0 = _time.perf_counter()
    for i in range(n_tenants):
        tid = mgr.list_tenants()[i].tenant_id
        for j in range(n_resources_per_tenant):
            mgr.create_resource(tid, "project", f"proj_{j}", size_bytes=1024 * 100)
    t_create_resources = _time.perf_counter() - t0

    t0 = _time.perf_counter()
    isolation_ok = True
    for i in range(n_tenants):
        for j in range(n_tenants):
            if i != j:
                ta = mgr.list_tenants()[i].tenant_id
                tb = mgr.list_tenants()[j].tenant_id
                if not mgr.verify_isolation(ta, tb):
                    isolation_ok = False
                    break
    t_verify = _time.perf_counter() - t0

    return {
        "n_tenants": n_tenants,
        "n_resources_per_tenant": n_resources_per_tenant,
        "total_resources": n_tenants * n_resources_per_tenant,
        "time_create_tenants_s": round(t_create_tenants, 6),
        "time_create_resources_s": round(t_create_resources, 6),
        "time_verify_isolation_s": round(t_verify, 6),
        "isolation_verified": isolation_ok,
    }
