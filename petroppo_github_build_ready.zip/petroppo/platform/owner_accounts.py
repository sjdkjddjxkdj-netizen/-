"""petroppo — Owner accounts, user accounts, and the owner dashboard store.

This module is the *local* authority for:
  * **Owner accounts** — the two company owners (Moamen & Alaa) who have
    full visibility and control: who logged in, who paid, every account.
  * **Customer accounts** — users who sign up (via the website) and get a
    30-day trial, then must pay.
  * **Audit log** — every login, every payment, every license change.

Everything is persisted to a local SQLite database so the owner dashboard
has full history even when offline.  Passwords are stored as salted
SHA-256 hashes (never plaintext).

Owners:
    username: moamen      password: <generated, documented separately>
    username: alaa        password: <generated, documented separately>
"""
from __future__ import annotations

import hashlib
import os
import secrets
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Optional


def _resolve_db_path() -> str:
    """Resolve the accounts database path (writable when frozen)."""
    import sys
    if getattr(sys, "frozen", False):
        home = os.path.expanduser("~")
        if os.name == "nt":
            base = os.path.join(os.environ.get("APPDATA", home), "petroppo", "data")
        elif sys.platform == "darwin":
            base = os.path.join(home, "Library", "Application Support", "petroppo", "data")
        else:
            base = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.join(home, ".local", "share")),
                                "petroppo", "data")
        os.makedirs(base, exist_ok=True)
        return os.path.join(base, "petroppo_accounts.db")
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data", "petroppo_accounts.db",
    )


DB_PATH = _resolve_db_path()


# --------------------------------------------------------------------------- #
#  Password hashing (salted SHA-256)                                           #
# --------------------------------------------------------------------------- #
def _hash_password(password: str, salt: str) -> str:
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def make_password_hash(password: str) -> str:
    """Return 'salt$hash' string for a new password."""
    salt = secrets.token_hex(16)
    return f"{salt}${_hash_password(password, salt)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, h = stored.split("$", 1)
        return hmac.compare_digest(_hash_password(password, salt), h)
    except Exception:
        return False


import hmac  # used in verify_password


# --------------------------------------------------------------------------- #
#  Account roles                                                               #
# --------------------------------------------------------------------------- #
ROLE_OWNER = "owner"          # full control + dashboard
ROLE_CUSTOMER = "customer"    # trial / paid


# --------------------------------------------------------------------------- #
#  Account store (SQLite)                                                      #
# --------------------------------------------------------------------------- #
class AccountStore:
    """SQLite-backed store of owners, customers, and audit log."""

    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        c = self._conn.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS accounts (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT UNIQUE NOT NULL,
            full_name     TEXT,
            email         TEXT,
            password_hash TEXT NOT NULL,
            role          TEXT NOT NULL,             -- owner | customer
            license_type  TEXT NOT NULL,             -- trial | professional | enterprise | owner
            status        TEXT NOT NULL,             -- active | locked | expired
            trial_start   REAL,
            trial_end     REAL,                      -- epoch seconds
            paid_until    REAL,                      -- epoch seconds (for paid)
            machine_id    TEXT,
            created_at    REAL NOT NULL,
            last_login    REAL
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            ts        REAL NOT NULL,
            username  TEXT,
            action    TEXT,            -- login | login_failed | logout | payment | lock | trial_start | trial_end | license_change
            detail    TEXT
        );

        CREATE TABLE IF NOT EXISTS payments (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            ts         REAL NOT NULL,
            username   TEXT NOT NULL,
            plan       TEXT,           -- professional | enterprise
            amount_usd REAL,
            method     TEXT,           -- stripe | paddle | manual
            status     TEXT            -- success | pending | failed
        );
        """)
        self._conn.commit()

    # ----- audit -----
    def log(self, username: str, action: str, detail: str = ""):
        self._conn.execute(
            "INSERT INTO audit_log (ts, username, action, detail) VALUES (?,?,?,?)",
            (time.time(), username, action, detail),
        )
        self._conn.commit()

    # ----- account CRUD -----
    def add_account(self, username, full_name, email, password,
                    role=ROLE_CUSTOMER, license_type="trial"):
        pw = make_password_hash(password)
        now = time.time()
        trial_start = now if role == ROLE_CUSTOMER else None
        trial_end = (now + 30 * 86400) if role == ROLE_CUSTOMER else None
        self._conn.execute(
            """INSERT INTO accounts
               (username, full_name, email, password_hash, role, license_type,
                status, trial_start, trial_end, paid_until, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (username, full_name, email, pw, role, license_type,
             "active" if role == ROLE_OWNER else "trial",
             trial_start, trial_end, None, now),
        )
        self._conn.commit()
        self.log(username, "account_created", f"role={role} license={license_type}")

    def get_account(self, username: str) -> Optional[dict]:
        row = self._conn.execute(
            "SELECT * FROM accounts WHERE username=?", (username,)).fetchone()
        return dict(row) if row else None

    def list_accounts(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM accounts ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]

    def update_last_login(self, username: str):
        self._conn.execute(
            "UPDATE accounts SET last_login=? WHERE username=?",
            (time.time(), username))
        self._conn.commit()

    def set_machine_id(self, username: str, machine_id: str):
        self._conn.execute(
            "UPDATE accounts SET machine_id=? WHERE username=?",
            (machine_id, username))
        self._conn.commit()

    def mark_paid(self, username: str, plan: str, amount_usd: float,
                  method: str = "manual"):
        now = time.time()
        duration = 365 * 86400  # 1 year
        paid_until = now + duration
        self._conn.execute(
            "UPDATE accounts SET license_type=?, status='active', paid_until=? WHERE username=?",
            (plan, paid_until, username))
        self._conn.execute(
            """INSERT INTO payments (ts, username, plan, amount_usd, method, status)
               VALUES (?,?,?,?,?, 'success')""",
            (now, username, plan, amount_usd, method))
        self._conn.commit()
        self.log(username, "payment", f"plan={plan} amount=${amount_usd} method={method}")

    # ----- audit / payments queries -----
    def list_audit(self, limit: int = 200) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def list_payments(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM payments ORDER BY ts DESC").fetchall()
        return [dict(r) for r in rows]

    # ----- trial status -----
    def trial_expired(self, username: str) -> bool:
        acc = self.get_account(username)
        if not acc or acc["role"] == ROLE_OWNER:
            return False
        if acc["status"] == "active" and acc["paid_until"] and acc["paid_until"] > time.time():
            return False
        if acc["trial_end"] and time.time() > acc["trial_end"]:
            return True
        return False

    def days_left_trial(self, username: str) -> int:
        acc = self.get_account(username)
        if not acc or acc["role"] == ROLE_OWNER:
            return 9999
        if acc["paid_until"] and acc["paid_until"] > time.time():
            return int((acc["paid_until"] - time.time()) // 86400)
        if acc["trial_end"]:
            return max(0, int((acc["trial_end"] - time.time()) // 86400))
        return 0

    def lock_account(self, username: str):
        self._conn.execute(
            "UPDATE accounts SET status='locked' WHERE username=?", (username,))
        self._conn.commit()
        self.log(username, "lock", "trial expired - payment required")

    def close(self):
        self._conn.close()


# --------------------------------------------------------------------------- #
#  Machine fingerprint                                                         #
# --------------------------------------------------------------------------- #
def get_machine_id() -> str:
    """Best-effort unique machine fingerprint."""
    import platform
    import uuid as _uuid
    raw = platform.node() + str(_uuid.getnode()) + platform.machine()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


# --------------------------------------------------------------------------- #
#  Bootstrap owners                                                            #
# --------------------------------------------------------------------------- #
# Owner credentials are generated once and stored in the DB.  The plaintext
# passwords are written to a separate sealed file (owner_credentials.txt) at
# creation time so the owners can receive them, then never stored in code.
OWNERS = [
    {
        "username": "moamen",
        "full_name": "Moamen Mohamed Mahmoud",
        "email": "moamen@petroppo.io",
    },
    {
        "username": "alaa",
        "full_name": "Alaa Ibrahim Tantawi",
        "email": "alaa@petroppo.io",
    },
]


def bootstrap_owners(store: AccountStore, password_file: str | None = None) -> dict:
    """Create the two owner accounts if they don't exist yet.
    Returns {username: password} for the freshly created accounts (empty
    dict if they already existed)."""
    created = {}
    for o in OWNERS:
        if store.get_account(o["username"]):
            continue
        pw = secrets.token_urlsafe(12)
        store.add_account(
            username=o["username"],
            full_name=o["full_name"],
            email=o["email"],
            password=pw,
            role=ROLE_OWNER,
            license_type="owner",
        )
        created[o["username"]] = pw
    # write credentials file
    if created and password_file:
        os.makedirs(os.path.dirname(password_file), exist_ok=True)
        with open(password_file, "w", encoding="utf-8") as f:
            f.write("petroppo — Owner Credentials (PRIVATE)\n")
            f.write("=" * 48 + "\n\n")
            for u, pw in created.items():
                acc = store.get_account(u)
                f.write(f"Owner : {acc['full_name']}\n")
                f.write(f"Email : {acc['email']}\n")
                f.write(f"User  : {u}\n")
                f.write(f"Pass  : {pw}\n")
                f.write("-" * 40 + "\n")
            f.write("\nKeep this file private. Change passwords after first login.\n")
    return created
