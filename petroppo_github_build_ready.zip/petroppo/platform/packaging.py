"""
V39 Packaging & distribution -- commercial packaging and deployment.

This module provides the packaging and distribution infrastructure
that turns petroppo into a commercially deployable product.  It
implements:

* **Distribution metadata** -- version, build info, dependency manifest,
  component inventory.
* **Installer generator** -- pip-installable wheel specification,
  setup verification, entry-point definitions.
* **Health check** -- pre-deployment system verification (dependencies,
  memory, CPU, optional GPU, disk space).
* **Deployment configurator** -- generates deployment configs from
  templates (single-node, cluster, cloud).
* **Update manager** -- version comparison, changelog generation,
  migration checks, update planning.

Design principles
-----------------
* **No external dependencies** -- uses only the Python standard library
  (``json``, ``os``, ``sys``, ``platform``, ``time``, ``dataclasses``).
* **Pure metadata** -- this module generates specifications and configs,
  not actual binaries.  The actual wheel build is done by the standard
  Python packaging toolchain (pip, build, twine).
* **Idempotent** -- running the same configuration twice produces the
  same output (deterministic, timestamped).

References
----------
* PEP 427 (2012). *The Wheel Binary Package Format 1.0.*
* PEP 517 (2017). *A build-system independent format for source trees.*
* PEP 518 (2016). *Specifying minimum build system requirements.*
* Python Packaging User Guide (packaging.python.org, 2023).

This module is part of petroppo V39 (Proof & Commercial Edition).
"""

from __future__ import annotations

import json
import os
import platform
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

__all__ = [
    "DistributionMetadata",
    "DependencyManifest",
    "DependencySpec",
    "InstallerSpec",
    "EntryPoint",
    "HealthCheckResult",
    "HealthCheck",
    "DeploymentConfig",
    "DeploymentTemplate",
    "DeploymentConfigurator",
    "UpdateInfo",
    "UpdateManager",
    "VersionInfo",
    "compare_versions",
    "build_distribution_metadata",
]


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------

class VersionInfo:
    """Semantic version (major.minor.patch)."""

    def __init__(self, major: int, minor: int, patch: int,
                 pre: str = "") -> None:
        self.major = major
        self.minor = minor
        self.patch = patch
        self.pre = pre  # e.g. "rc1", "beta2"

    @classmethod
    def parse(cls, version_str: str) -> "VersionInfo":
        """Parse a version string like '39.0.0' or '38.2.1rc1'."""
        s = version_str.strip()
        pre = ""
        # Extract pre-release suffix
        for sep in ("rc", "beta", "alpha", "a", "b"):
            if sep in s:
                idx = s.index(sep)
                pre = s[idx:]
                s = s[:idx]
                break
        parts = s.split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        return cls(major, minor, patch, pre)

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}{self.pre}"

    def __eq__(self, other) -> bool:
        if not isinstance(other, VersionInfo):
            return False
        return (self.major, self.minor, self.patch, self.pre) == \
               (other.major, other.minor, other.patch, other.pre)

    def __lt__(self, other) -> bool:
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        # Pre-release versions are less than release
        if self.pre and not other.pre:
            return True
        if not self.pre and other.pre:
            return False
        return self.pre < other.pre

    def __le__(self, other) -> bool:
        return self == other or self < other

    def __gt__(self, other) -> bool:
        return not self <= other

    def __ge__(self, other) -> bool:
        return not self < other

    def to_dict(self) -> dict:
        return {
            "major": self.major,
            "minor": self.minor,
            "patch": self.patch,
            "pre": self.pre,
            "string": str(self),
        }


def compare_versions(v1: str, v2: str) -> int:
    """Compare two version strings.  Returns -1, 0, or 1."""
    a = VersionInfo.parse(v1)
    b = VersionInfo.parse(v2)
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


# ---------------------------------------------------------------------------
# Dependency manifest
# ---------------------------------------------------------------------------

@dataclass
class DependencySpec:
    """A single dependency specification.

    Attributes
    ----------
    name : str
        Package name (e.g. "numpy").
    version_spec : str
        Version specifier (e.g. ">=1.20,<2.0").
    required : bool
        If True, the package is required.  If False, it's optional.
    purpose : str
        Human-readable description of what the dependency is for.
    """

    name: str
    version_spec: str
    required: bool = True
    purpose: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version_spec": self.version_spec,
            "required": self.required,
            "purpose": self.purpose,
        }


@dataclass
class DependencyManifest:
    """Complete dependency manifest for a petroppo distribution.

    Lists all required and optional dependencies with version specs.
    """

    required: list[DependencySpec] = field(default_factory=list)
    optional: list[DependencySpec] = field(default_factory=list)

    def all_dependencies(self) -> list[DependencySpec]:
        """Return all dependencies (required + optional)."""
        return self.required + self.optional

    def to_dict(self) -> dict:
        return {
            "required": [d.to_dict() for d in self.required],
            "optional": [d.to_dict() for d in self.optional],
        }

    def to_requirements_txt(self) -> str:
        """Generate a requirements.txt file content."""
        lines = []
        lines.append("# petroppo required dependencies")
        for dep in self.required:
            lines.append(f"{dep.name}{dep.version_spec}")
        lines.append("")
        lines.append("# Optional dependencies (uncomment to enable)")
        for dep in self.optional:
            lines.append(f"# {dep.name}{dep.version_spec}  # {dep.purpose}")
        return "\n".join(lines) + "\n"


def _default_dependency_manifest() -> DependencyManifest:
    """Build the default petroppo dependency manifest."""
    return DependencyManifest(
        required=[
            DependencySpec("numpy", ">=1.20", True, "Numerical computing"),
            DependencySpec("scipy", ">=1.7", True, "Scientific computing, sparse solvers"),
            DependencySpec("scikit-learn", ">=1.0", True, "Machine learning, clustering"),
        ],
        optional=[
            DependencySpec("matplotlib", ">=3.4", False, "Plotting and visualization"),
            DependencySpec("numba", ">=0.55", False, "JIT compilation for speed"),
        ],
    )


# ---------------------------------------------------------------------------
# Distribution metadata
# ---------------------------------------------------------------------------

@dataclass
class DistributionMetadata:
    """Metadata for a petroppo distribution build.

    Attributes
    ----------
    name : str
        Distribution name (e.g. "petroppo").
    version : str
        Version string (e.g. "39.0.0").
    build_id : str
        Unique build identifier.
    build_time : float
        Build timestamp (Unix epoch).
    python_requires : str
        Required Python version (e.g. ">=3.9").
    dependencies : DependencyManifest
        Dependency manifest.
    components : list
        List of component modules included in this build.
    license_type : str
        License type for this distribution.
    changelog : list
        List of changelog entries for this version.
    """

    name: str = "petroppo"
    version: str = "39.0.0"
    build_id: str = ""
    build_time: float = 0.0
    python_requires: str = ">=3.9"
    dependencies: DependencyManifest = field(default_factory=_default_dependency_manifest)
    components: list = field(default_factory=list)
    license_type: str = "commercial"
    changelog: list = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.build_id:
            self.build_id = f"build-{int(time.time())}"
        if not self.build_time:
            self.build_time = time.time()

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "build_id": self.build_id,
            "build_time": self.build_time,
            "build_time_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                            time.gmtime(self.build_time)),
            "python_requires": self.python_requires,
            "dependencies": self.dependencies.to_dict(),
            "components": self.components,
            "license_type": self.license_type,
            "changelog": self.changelog,
        }

    def to_json(self, indent: int = 2) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.to_dict(), indent=indent)


def build_distribution_metadata(
    version: str = "39.0.0",
    components: Optional[list] = None,
    changelog: Optional[list] = None,
    license_type: str = "commercial",
) -> DistributionMetadata:
    """Build a DistributionMetadata for the current petroppo version."""
    if components is None:
        components = [
            "core", "physics", "processing", "io", "data",
            "petrophysics", "simulator", "engine", "ai",
            "benchmark", "validation", "platform",
            "cases", "gui", "web_console",
        ]
    if changelog is None:
        changelog = [
            "V39: Field case studies (North Sea, Carbonate, Turbidite)",
            "V39: Commercial licensing (community/professional/enterprise/trial)",
            "V39: Packaging & distribution (wheel spec, health checks, deployment)",
            "V39: Customer demo & evaluation harness",
            "V39: 5 new benchmark cases (35 total)",
        ]
    return DistributionMetadata(
        version=version,
        components=components,
        changelog=changelog,
        license_type=license_type,
    )


# ---------------------------------------------------------------------------
# Installer specification (wheel)
# ---------------------------------------------------------------------------

@dataclass
class EntryPoint:
    """A console or GUI entry point."""

    name: str
    module: str
    function: str
    type: str = "console"  # "console" or "gui"

    def to_spec(self) -> str:
        """Return entry-point spec string (module:function)."""
        return f"{self.module}:{self.function}"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "module": self.module,
            "function": self.function,
            "type": self.type,
            "spec": self.to_spec(),
        }


@dataclass
class InstallerSpec:
    """Specification for a pip-installable wheel.

    This is the metadata that would go into ``pyproject.toml`` /
    ``setup.cfg``.  The actual wheel is built by the standard Python
    packaging toolchain.

    Attributes
    ----------
    name : str
        Package name.
    version : str
        Version string.
    python_requires : str
        Python version requirement.
    dependencies : DependencyManifest
        Dependency manifest.
    entry_points : list
        Console/GUI entry points.
    metadata : DistributionMetadata
        Associated distribution metadata.
    """

    name: str = "petroppo"
    version: str = "39.0.0"
    python_requires: str = ">=3.9"
    dependencies: DependencyManifest = field(default_factory=_default_dependency_manifest)
    entry_points: list[EntryPoint] = field(default_factory=list)
    metadata: Optional[DistributionMetadata] = None

    def __post_init__(self) -> None:
        if not self.entry_points:
            self.entry_points = [
                EntryPoint("petroppo", "petroppo.cli", "main", "console"),
                EntryPoint("petroppo-demo", "petroppo.platform.demo", "main", "console"),
            ]

    def wheel_filename(self) -> str:
        """Return the expected wheel filename."""
        import platform as _p
        py_tag = f"py3"
        plat_tag = "any"  # pure Python
        return f"{self.name.replace('-', '_')}-{self.version}-{py_tag}-none-{plat_tag}.whl"

    def sdist_filename(self) -> str:
        """Return the expected sdist (tar.gz) filename."""
        return f"{self.name.replace('-', '_')}-{self.version}.tar.gz"

    def to_pyproject_toml(self) -> str:
        """Generate a pyproject.toml content for this installer."""
        deps = [f'"{d.name}{d.version_spec}"' for d in self.dependencies.required]
        deps_str = ",\n    ".join(deps)
        entry_strs = [f'{e.name} = "{e.to_spec()}"' for e in self.entry_points]
        entry_str = "\n".join(entry_strs)
        return f"""[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{self.name}"
version = "{self.version}"
description = "petroppo -- reservoir geophysics platform"
requires-python = "{self.python_requires}"
dependencies = [
    {deps_str}
]

[project.optional-dependencies]
viz = ["matplotlib>=3.4"]
accel = ["numba>=0.55"]

[project.scripts]
{entry_str}

[tool.setuptools.packages.find]
include = ["petroppo*"]
"""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "python_requires": self.python_requires,
            "wheel_filename": self.wheel_filename(),
            "sdist_filename": self.sdist_filename(),
            "entry_points": [e.to_dict() for e in self.entry_points],
            "dependencies": self.dependencies.to_dict(),
        }


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

class CheckStatus(Enum):
    """Health check status."""

    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class HealthCheckResult:
    """Result of a single health check."""

    name: str
    status: CheckStatus
    message: str
    detail: str = ""
    value: Any = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "detail": self.detail,
            "value": self.value,
        }


class HealthCheck:
    """Pre-deployment system health check.

    Verifies that the target system meets petroppo's requirements:
    * Python version
    * Required dependencies (numpy, scipy, scikit-learn)
    * Optional dependencies (matplotlib, numba)
    * CPU cores
    * Memory
    * Disk space (current directory)
    * Platform compatibility
    """

    def __init__(self,
                 min_python: str = "3.9",
                 min_memory_mb: float = 2048,
                 min_cpu_cores: int = 2,
                 min_disk_mb: float = 500) -> None:
        self.min_python = min_python
        self.min_memory_mb = min_memory_mb
        self.min_cpu_cores = min_cpu_cores
        self.min_disk_mb = min_disk_mb

    def _check_python(self) -> HealthCheckResult:
        """Check Python version."""
        current = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        cmp = compare_versions(current, self.min_python)
        if cmp >= 0:
            return HealthCheckResult(
                "python_version", CheckStatus.PASS,
                f"Python {current} meets requirement >= {self.min_python}",
                value=current,
            )
        return HealthCheckResult(
            "python_version", CheckStatus.FAIL,
            f"Python {current} is below required {self.min_python}",
            value=current,
        )

    def _check_dependency(self, name: str, required: bool = True) -> HealthCheckResult:
        """Check if a Python package is importable."""
        try:
            mod = __import__(name)
            version = getattr(mod, "__version__", "unknown")
            return HealthCheckResult(
                f"dep_{name}", CheckStatus.PASS if required else CheckStatus.PASS,
                f"{name} {version} available",
                value=version,
            )
        except ImportError:
            if required:
                return HealthCheckResult(
                    f"dep_{name}", CheckStatus.FAIL,
                    f"Required dependency {name} not found",
                )
            return HealthCheckResult(
                f"dep_{name}", CheckStatus.WARN,
                f"Optional dependency {name} not installed",
            )

    def _check_cpu(self) -> HealthCheckResult:
        """Check CPU cores."""
        try:
            n = os.cpu_count() or 1
            if n >= self.min_cpu_cores:
                return HealthCheckResult(
                    "cpu_cores", CheckStatus.PASS,
                    f"{n} CPU cores available (>= {self.min_cpu_cores})",
                    value=n,
                )
            return HealthCheckResult(
                "cpu_cores", CheckStatus.WARN,
                f"Only {n} CPU cores (recommended >= {self.min_cpu_cores})",
                value=n,
            )
        except Exception as e:
            return HealthCheckResult(
                "cpu_cores", CheckStatus.SKIP,
                f"Could not determine CPU cores: {e}",
            )

    def _check_memory(self) -> HealthCheckResult:
        """Check available memory."""
        try:
            # Try /proc/meminfo (Linux)
            if os.path.exists("/proc/meminfo"):
                with open("/proc/meminfo") as f:
                    for line in f:
                        if line.startswith("MemAvailable:"):
                            mem_kb = int(line.split()[1])
                            mem_mb = mem_kb / 1024
                            if mem_mb >= self.min_memory_mb:
                                return HealthCheckResult(
                                    "memory", CheckStatus.PASS,
                                    f"{mem_mb:.0f} MB available (>= {self.min_memory_mb})",
                                    value=mem_mb,
                                )
                            return HealthCheckResult(
                                "memory", CheckStatus.WARN,
                                f"{mem_mb:.0f} MB available (recommended >= {self.min_memory_mb})",
                                value=mem_mb,
                            )
        except Exception:
            pass
        return HealthCheckResult(
            "memory", CheckStatus.SKIP,
            "Could not determine available memory",
        )

    def _check_disk(self) -> HealthCheckResult:
        """Check disk space in current directory."""
        try:
            stat = os.statvfs(".")
            free_mb = (stat.f_bavail * stat.f_frsize) / (1024 * 1024)
            if free_mb >= self.min_disk_mb:
                return HealthCheckResult(
                    "disk_space", CheckStatus.PASS,
                    f"{free_mb:.0f} MB free (>= {self.min_disk_mb})",
                    value=free_mb,
                )
            return HealthCheckResult(
                "disk_space", CheckStatus.WARN,
                f"{free_mb:.0f} MB free (recommended >= {self.min_disk_mb})",
                value=free_mb,
            )
        except Exception as e:
            return HealthCheckResult(
                "disk_space", CheckStatus.SKIP,
                f"Could not determine disk space: {e}",
            )

    def _check_platform(self) -> HealthCheckResult:
        """Check platform compatibility."""
        plat = platform.platform()
        system = platform.system()
        if system in ("Linux", "Darwin", "Windows"):
            return HealthCheckResult(
                "platform", CheckStatus.PASS,
                f"Platform: {plat}",
                value=plat,
            )
        return HealthCheckResult(
            "platform", CheckStatus.WARN,
            f"Untested platform: {plat}",
            value=plat,
        )

    def _check_gpu(self) -> HealthCheckResult:
        """Check for GPU availability (optional)."""
        # Check for CUDA
        try:
            import subprocess
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                gpu_name = result.stdout.strip().split("\n")[0]
                return HealthCheckResult(
                    "gpu", CheckStatus.PASS,
                    f"GPU detected: {gpu_name}",
                    value=gpu_name,
                )
        except Exception:
            pass
        return HealthCheckResult(
            "gpu", CheckStatus.SKIP,
            "No GPU detected (optional, CPU-only operation supported)",
        )

    def run(self) -> dict:
        """Run all health checks.  Returns a report dict.

        The report includes:
        * ``checks``: list of individual check results
        * ``summary``: counts of pass/warn/fail/skip
        * ``overall``: "pass", "warn", or "fail"
        * ``ready``: True if no required checks failed
        """
        checks = [
            self._check_python(),
            self._check_platform(),
            self._check_dependency("numpy", required=True),
            self._check_dependency("scipy", required=True),
            self._check_dependency("sklearn", required=True),
            self._check_dependency("matplotlib", required=False),
            self._check_dependency("numba", required=False),
            self._check_cpu(),
            self._check_memory(),
            self._check_disk(),
            self._check_gpu(),
        ]

        summary = {
            "pass": sum(1 for c in checks if c.status == CheckStatus.PASS),
            "warn": sum(1 for c in checks if c.status == CheckStatus.WARN),
            "fail": sum(1 for c in checks if c.status == CheckStatus.FAIL),
            "skip": sum(1 for c in checks if c.status == CheckStatus.SKIP),
        }

        has_fail = summary["fail"] > 0
        has_warn = summary["warn"] > 0
        overall = "fail" if has_fail else ("warn" if has_warn else "pass")
        ready = not has_fail

        return {
            "timestamp": time.time(),
            "checks": [c.to_dict() for c in checks],
            "summary": summary,
            "overall": overall,
            "ready": ready,
            "n_checks": len(checks),
        }


# ---------------------------------------------------------------------------
# Deployment configurator
# ---------------------------------------------------------------------------

class DeploymentTemplate(Enum):
    """Deployment template types."""

    SINGLE_NODE = "single_node"
    CLUSTER = "cluster"
    CLOUD = "cloud"
    DOCKER = "docker"


@dataclass
class DeploymentConfig:
    """A deployment configuration for a petroppo installation.

    Attributes
    ----------
    template : DeploymentTemplate
        Deployment template type.
    name : str
        Deployment name.
    version : str
        petroppo version to deploy.
    settings : dict
        Template-specific settings.
    """

    template: DeploymentTemplate
    name: str
    version: str = "39.0.0"
    settings: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "template": self.template.value,
            "name": self.name,
            "version": self.version,
            "settings": self.settings,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


class DeploymentConfigurator:
    """Generate deployment configurations from templates.

    Parameters
    ----------
    version : str
        Default petroppo version for generated configs.
    """

    def __init__(self, version: str = "39.0.0") -> None:
        self.version = version

    def generate(self, template: DeploymentTemplate,
                 name: str = "petroppo-deployment",
                 **kwargs) -> DeploymentConfig:
        """Generate a deployment configuration.

        Parameters
        ----------
        template : DeploymentTemplate
            The deployment template to use.
        name : str
            Deployment name.
        **kwargs : dict
            Template-specific settings that override defaults.
        """
        defaults = self._template_defaults(template)
        defaults.update(kwargs)
        return DeploymentConfig(
            template=template,
            name=name,
            version=self.version,
            settings=defaults,
        )

    def _template_defaults(self, template: DeploymentTemplate) -> dict:
        """Return default settings for a template."""
        if template == DeploymentTemplate.SINGLE_NODE:
            return {
                "type": "single_node",
                "host": "localhost",
                "port": 8080,
                "workers": 1,
                "memory_limit_mb": 4096,
                "cpu_limit": 4,
                "storage": "local",
                "logging": "file",
                "log_level": "INFO",
            }
        elif template == DeploymentTemplate.CLUSTER:
            return {
                "type": "cluster",
                "scheduler_host": "scheduler.local",
                "scheduler_port": 8786,
                "n_workers": 4,
                "worker_memory_mb": 8192,
                "worker_cpus": 4,
                "shared_storage": "/shared/petroppo",
                "logging": "centralized",
                "log_level": "INFO",
                "ha": True,
                "failover": "automatic",
            }
        elif template == DeploymentTemplate.CLOUD:
            return {
                "type": "cloud",
                "provider": "aws",
                "region": "us-east-1",
                "instance_type": "c5.4xlarge",
                "auto_scaling": True,
                "min_instances": 2,
                "max_instances": 10,
                "storage": "s3",
                "storage_bucket": "petroppo-data",
                "database": "rds-postgres",
                "logging": "cloudwatch",
                "log_level": "INFO",
            }
        elif template == DeploymentTemplate.DOCKER:
            return {
                "type": "docker",
                "image": "petroppo:39.0.0",
                "container_name": "petroppo",
                "ports": {"8080": "8080"},
                "volumes": {"petroppo-data": "/data"},
                "environment": {
                    "PETROPPO_LOG_LEVEL": "INFO",
                    "PETROPPO_LICENSE_KEY": "",
                },
                "restart_policy": "unless-stopped",
                "memory": "4g",
                "cpus": "4",
            }
        return {}

    def generate_all(self) -> list[DeploymentConfig]:
        """Generate all template configurations."""
        return [self.generate(t) for t in DeploymentTemplate]


# ---------------------------------------------------------------------------
# Update manager
# ---------------------------------------------------------------------------

@dataclass
class UpdateInfo:
    """Information about a potential update.

    Attributes
    ----------
    current_version : str
        Currently installed version.
    target_version : str
        Available update version.
    available : bool
        True if an update is available.
    is_major : bool
        True if the update is a major version bump.
    is_minor : bool
        True if the update is a minor version bump.
    is_patch : bool
        True if the update is a patch version bump.
    changelog : list
        Changelog entries for the target version.
    migration_required : bool
        True if a migration is required to update.
    migration_notes : str
        Migration notes if migration is required.
    """

    current_version: str
    target_version: str
    available: bool = False
    is_major: bool = False
    is_minor: bool = False
    is_patch: bool = False
    changelog: list = field(default_factory=list)
    migration_required: bool = False
    migration_notes: str = ""

    def to_dict(self) -> dict:
        return {
            "current_version": self.current_version,
            "target_version": self.target_version,
            "available": self.available,
            "update_type": "major" if self.is_major else ("minor" if self.is_minor else ("patch" if self.is_patch else "none")),
            "changelog": self.changelog,
            "migration_required": self.migration_required,
            "migration_notes": self.migration_notes,
        }


class UpdateManager:
    """Manage petroppo version updates.

    Compares the current version against available versions, determines
    the update type (major/minor/patch), checks for required migrations,
    and provides changelog information.

    Parameters
    ----------
    current_version : str
        The currently installed version.
    version_registry : dict
        A registry of available versions with their changelogs and
        migration info.  Keys are version strings, values are dicts
        with "changelog" (list) and "migration" (dict or None).
    """

    def __init__(self, current_version: str,
                 version_registry: Optional[dict] = None) -> None:
        self.current_version = current_version
        self.version_registry = version_registry or self._default_registry()

    def _default_registry(self) -> dict:
        """Default version registry with known petroppo versions."""
        return {
            "34.0.0": {
                "changelog": ["V34: Accuracy improvements, benchmark framework"],
                "migration": None,
            },
            "36.0.0": {
                "changelog": ["V36: Reservoir dominance, physics engines"],
                "migration": {"from_below": "34", "notes": "Reservoir modules restructured"},
            },
            "37.0.0": {
                "changelog": ["V37: Industrial scale, distributed, memory"],
                "migration": {"from_below": "36", "notes": "Platform modules added"},
            },
            "38.0.0": {
                "changelog": ["V38: Enterprise, multi-tenancy, SSO, compliance"],
                "migration": {"from_below": "37", "notes": "Enterprise platform layer added"},
            },
            "39.0.0": {
                "changelog": [
                    "V39: Field case studies (3 synthetic reservoirs)",
                    "V39: Commercial licensing",
                    "V39: Packaging & distribution",
                    "V39: Customer demo & evaluation",
                    "V39: 5 new benchmark cases (35 total)",
                ],
                "migration": {"from_below": "38", "notes": "Commercial modules added, no breaking changes"},
            },
        }

    def check_for_update(self, target_version: Optional[str] = None) -> UpdateInfo:
        """Check for an available update.

        Parameters
        ----------
        target_version : str or None
            If specified, check for update to this specific version.
            If None, find the latest available version.
        """
        if target_version is None:
            # Find the latest version in the registry
            all_versions = sorted(self.version_registry.keys(),
                                  key=lambda v: VersionInfo.parse(v))
            target_version = all_versions[-1] if all_versions else self.current_version

        current = VersionInfo.parse(self.current_version)
        target = VersionInfo.parse(target_version)
        available = target > current

        is_major = target.major > current.major
        is_minor = (not is_major) and target.minor > current.minor
        is_patch = (not is_major and not is_minor) and target.patch > current.patch

        # Get changelog and migration info
        reg_entry = self.version_registry.get(target_version, {})
        changelog = reg_entry.get("changelog", [])
        migration = reg_entry.get("migration")

        migration_required = False
        migration_notes = ""
        if migration and available:
            migration_required = True
            migration_notes = migration.get("notes", "")

        return UpdateInfo(
            current_version=self.current_version,
            target_version=target_version,
            available=available,
            is_major=is_major,
            is_minor=is_minor,
            is_patch=is_patch,
            changelog=changelog,
            migration_required=migration_required,
            migration_notes=migration_notes,
        )

    def update_plan(self, target_version: str) -> dict:
        """Generate an update plan for upgrading to a target version.

        Returns a dict with steps, warnings, and estimated time.
        """
        info = self.check_for_update(target_version)
        if not info.available:
            return {
                "action": "none",
                "reason": f"Version {target_version} is not newer than current {self.current_version}",
            }

        steps = []
        if info.migration_required:
            steps.append("1. Review migration notes: " + info.migration_notes)
            steps.append("2. Backup current configuration and data")
            steps.append("3. Run migration script")
        steps.append(f"{len(steps)+1}. Install petroppo {target_version}")
        steps.append(f"{len(steps)+1}. Verify installation (run health check)")
        steps.append(f"{len(steps)+1}. Run smoke tests")
        steps.append(f"{len(steps)+1}. Restart services")

        return {
            "action": "update",
            "from": self.current_version,
            "to": target_version,
            "update_type": "major" if info.is_major else ("minor" if info.is_minor else "patch"),
            "steps": steps,
            "migration_required": info.migration_required,
            "migration_notes": info.migration_notes,
            "changelog": info.changelog,
            "warnings": [
                "Major version update -- review changelog for breaking changes"
            ] if info.is_major else [],
        }

    def list_available_versions(self) -> list[dict]:
        """List all versions newer than the current version."""
        current = VersionInfo.parse(self.current_version)
        result = []
        for ver_str, entry in sorted(self.version_registry.items(),
                                     key=lambda x: VersionInfo.parse(x[0])):
            ver = VersionInfo.parse(ver_str)
            if ver > current:
                result.append({
                    "version": ver_str,
                    "changelog": entry.get("changelog", []),
                    "migration": entry.get("migration") is not None,
                })
        return result
