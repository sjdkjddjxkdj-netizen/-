"""petroppo V37 -- Provenance capture & reproducible pipelines.

A reservoir study is reproducible when: **same inputs + same code + same
environment = byte-identical outputs**.  This module captures the full
provenance of a petroppo pipeline run and provides the machinery to
re-run it deterministically.

Provenance is recorded in a W3C-PROV-inspired model:

* **Entities** -- data artifacts (arrays, decks, reports), each
  identified by its content hash (via :mod:`versioning`).
* **Activities** -- computational steps (inversion, simulation, etc.),
  with start/end times, parameters, and code version.
* **Agents** -- users / processes that initiated activities.
* **WasGeneratedBy** / **Used** -- edges linking entities to activities.

The :class:`ProvenanceGraph` stores these as a JSON document that can
be serialized, diffed, and re-executed.

The :class:`ReproduciblePipeline` builds on the provenance graph to
guarantee byte-identical re-execution:

1. **Deterministic execution** -- all randomness is seeded; iteration
   order is sorted; float operations are ordered identically.
2. **Environment pinning** -- the exact versions of numpy / scipy /
   scikit-learn / numba are recorded and verified on re-run.
3. **Content-addressed I/O** -- inputs and outputs are stored in the
   :class:`~petroppo.platform.versioning.ObjectStore`, so a re-run
   with the same inputs produces the same output hashes.
4. **Re-verification** -- :func:`verify_reproducibility` runs a
   pipeline twice and asserts the output trees are identical.

References
----------
* W3C Provenance Working Group (2013). *PROV-DM: The PROV Data Model*.
  https://www.w3.org/TR/prov-dm/
* Stodden, V. et al. (2016). *Enhancing reproducibility for
  computational methods*, Science.
* Sandve, G. et al. (2013). *Ten Simple Rules for Reproducible
  Computational Research*, PLOS Computational Biology.
"""

from __future__ import annotations

import os
import io
import json
import time
import hashlib
import platform
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import (Any, Callable, Dict, List, Optional, Tuple, Set)

__all__ = [
    "ProvenanceEntity",
    "ProvenanceActivity",
    "ProvenanceAgent",
    "ProvenanceGraph",
    "EnvironmentSnapshot",
    "capture_environment",
    "ReproduciblePipeline",
    "PipelineStep",
    "verify_reproducibility",
    "PROV_NS",
]

PROV_NS = "https://www.w3.org/ns/prov#"


# ---------------------------------------------------------------------------
# Environment capture
# ---------------------------------------------------------------------------

@dataclass
class EnvironmentSnapshot:
    """Pinned software environment for reproducibility."""
    python_version: str = ""
    numpy_version: str = ""
    scipy_version: str = ""
    sklearn_version: str = ""
    numba_version: str = ""
    platform: str = ""
    machine: str = ""
    processor: str = ""
    petroppo_version: str = ""
    captured_at: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    def hash(self) -> str:
        return hashlib.sha256(
            json.dumps(self.to_dict(), sort_keys=True).encode()
        ).hexdigest()

    def matches(self, other: "EnvironmentSnapshot",
                strict: bool = True) -> Tuple[bool, List[str]]:
        """Check if this environment matches another.

        If ``strict``, all versions must match exactly.  Otherwise only
        Python major.minor and the core library major.minor must match.
        """
        diffs: List[str] = []
        if strict:
            fields = ["python_version", "numpy_version", "scipy_version",
                       "sklearn_version", "numba_version"]
            for f in fields:
                a = getattr(self, f)
                b = getattr(other, f, "")
                if a != b:
                    diffs.append(f"{f}: {a} != {b}")
        else:
            def major_minor(v: str) -> str:
                parts = v.split(".")
                return ".".join(parts[:2]) if len(parts) >= 2 else v
            for f in ["python_version", "numpy_version", "scipy_version"]:
                a = major_minor(getattr(self, f))
                b = major_minor(getattr(other, f, ""))
                if a != b:
                    diffs.append(f"{f}: {a} != {b}")
        return (len(diffs) == 0, diffs)


def capture_environment(petroppo_version: str = "") -> EnvironmentSnapshot:
    """Capture the current software environment."""
    versions = {}
    for pkg in ("numpy", "scipy", "sklearn", "numba"):
        try:
            mod = __import__(pkg if pkg != "sklearn" else "sklearn")
            versions[pkg] = getattr(mod, "__version__", "unknown")
        except ImportError:
            versions[pkg] = "not-installed"
    return EnvironmentSnapshot(
        python_version=platform.python_version(),
        numpy_version=versions.get("numpy", "unknown"),
        scipy_version=versions.get("scipy", "unknown"),
        sklearn_version=versions.get("sklearn", "unknown"),
        numba_version=versions.get("numba", "not-installed"),
        platform=platform.system(),
        machine=platform.machine(),
        processor=platform.processor(),
        petroppo_version=petroppo_version,
        captured_at=time.time(),
    )


# ---------------------------------------------------------------------------
# PROV nodes
# ---------------------------------------------------------------------------

@dataclass
class ProvenanceEntity:
    """A data artifact (W3C PROV Entity)."""
    id: str
    content_hash: str
    path: str = ""
    dtype: str = ""
    shape: Tuple[int, ...] = ()
    generated_by: Optional[str] = None    # activity id
    attributes: dict = field(default_factory=dict)


@dataclass
class ProvenanceActivity:
    """A computational step (W3C PROV Activity)."""
    id: str
    name: str
    start_time: float = 0.0
    end_time: float = 0.0
    parameters: dict = field(default_factory=dict)
    used_entities: List[str] = field(default_factory=list)
    generated_entities: List[str] = field(default_factory=list)
    code_version: str = ""
    seed: Optional[int] = None


@dataclass
class ProvenanceAgent:
    """A user or process (W3C PROV Agent)."""
    id: str
    name: str
    kind: str = "user"     # "user", "process", "system"


# ---------------------------------------------------------------------------
# Provenance graph
# ---------------------------------------------------------------------------

class ProvenanceGraph:
    """A W3C-PROV-inspired provenance graph for a pipeline run.

    Stores entities, activities, agents, and their relationships.
    Serializable to JSON for archival and diffing.
    """

    def __init__(self, run_id: str = ""):
        self.run_id = run_id or f"run-{int(time.time()*1000)}"
        self.entities: Dict[str, ProvenanceEntity] = {}
        self.activities: Dict[str, ProvenanceActivity] = {}
        self.agents: Dict[str, ProvenanceAgent] = {}
        self.environment: Optional[EnvironmentSnapshot] = None
        self._act_counter = 0
        self._ent_counter = 0

    def add_agent(self, name: str, kind: str = "user") -> ProvenanceAgent:
        aid = f"agent-{name}-{self._act_counter}"
        self._act_counter += 1
        a = ProvenanceAgent(id=aid, name=name, kind=kind)
        self.agents[aid] = a
        return a

    def add_entity(self, content_hash: str, path: str = "",
                   dtype: str = "", shape: Tuple = (),
                   generated_by: Optional[str] = None,
                   attributes: Optional[dict] = None) -> ProvenanceEntity:
        eid = f"entity-{self._ent_counter}"
        self._ent_counter += 1
        e = ProvenanceEntity(
            id=eid, content_hash=content_hash, path=path,
            dtype=dtype, shape=shape, generated_by=generated_by,
            attributes=attributes or {},
        )
        self.entities[eid] = e
        return e

    def add_activity(self, name: str, parameters: Optional[dict] = None,
                     seed: Optional[int] = None,
                     code_version: str = "") -> ProvenanceActivity:
        aid = f"activity-{self._act_counter}"
        self._act_counter += 1
        a = ProvenanceActivity(
            id=aid, name=name, parameters=parameters or {},
            seed=seed, code_version=code_version,
        )
        self.activities[aid] = a
        return a

    def record_used(self, activity_id: str, entity_id: str):
        if activity_id in self.activities:
            self.activities[activity_id].used_entities.append(entity_id)

    def record_generated(self, activity_id: str, entity_id: str):
        if activity_id in self.activities:
            self.activities[activity_id].generated_entities.append(entity_id)

    def start_activity(self, activity_id: str):
        if activity_id in self.activities:
            self.activities[activity_id].start_time = time.time()

    def end_activity(self, activity_id: str):
        if activity_id in self.activities:
            self.activities[activity_id].end_time = time.time()

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "environment": self.environment.to_dict() if self.environment else None,
            "entities": {k: asdict(v) for k, v in self.entities.items()},
            "activities": {k: asdict(v) for k, v in self.activities.items()},
            "agents": {k: asdict(v) for k, v in self.agents.items()},
        }

    def to_deterministic_dict(self) -> dict:
        """A dict with volatile timestamps zeroed for reproducible hashing."""
        d = self.to_dict()
        # Zero out timestamps that vary between runs.
        if d["environment"]:
            d["environment"]["captured_at"] = 0.0
        for act in d["activities"].values():
            act["start_time"] = 0.0
            act["end_time"] = 0.0
        # run_id contains a timestamp; normalize it.
        d["run_id"] = "normalized"
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True,
                          default=str)

    def hash(self) -> str:
        """Content hash of the provenance graph (deterministic).

        Excludes volatile timestamps so that two runs of the same
        pipeline with the same inputs produce identical provenance
        hashes (required for reproducible-pipeline verification).
        """
        return hashlib.sha256(
            json.dumps(self.to_deterministic_dict(), sort_keys=True,
                       default=str).encode("utf-8")
        ).hexdigest()

    def summary(self) -> dict:
        return {
            "run_id": self.run_id,
            "n_entities": len(self.entities),
            "n_activities": len(self.activities),
            "n_agents": len(self.agents),
            "env_hash": self.environment.hash() if self.environment else None,
            "graph_hash": self.hash(),
        }


# ---------------------------------------------------------------------------
# Reproducible pipeline
# ---------------------------------------------------------------------------

@dataclass
class PipelineStep:
    """One step in a reproducible pipeline.

    Parameters
    ----------
    name : str
        Step name (e.g. "inversion").
    fn : callable
        The function to execute.  Must be deterministic: given the same
        inputs (including seed), produces the same output.
    inputs : list of str
        Logical names of input artifacts (keys in the input dict).
    outputs : list of str
        Logical names of output artifacts (keys in the output dict).
    parameters : dict
        Step parameters (recorded in provenance).
    seed : int, optional
        Random seed for this step.
    """
    name: str
    fn: Callable
    inputs: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    parameters: dict = field(default_factory=dict)
    seed: Optional[int] = None


class ReproduciblePipeline:
    """A deterministic, provenance-tracked pipeline.

    The pipeline is a sequence of :class:`PipelineStep` objects.  When
    :meth:`run` is called:

    1. the environment is captured and pinned,
    2. each step executes with its inputs (from the artifact store) and
       seed; outputs are content-hashed and stored,
    3. a :class:`ProvenanceGraph` records the full lineage,
    4. the pipeline can be re-run and the outputs verified identical.

    Parameters
    ----------
    name : str
        Pipeline name.
    petroppo_version : str
        petroppo version string (recorded in provenance).
    """

    def __init__(self, name: str = "pipeline",
                 petroppo_version: str = "37.0.0"):
        self.name = name
        self.petroppo_version = petroppo_version
        self.steps: List[PipelineStep] = []
        self.provenance: Optional[ProvenanceGraph] = None
        self.last_outputs: Dict[str, str] = {}   # logical name -> content hash

    def add_step(self, step: PipelineStep) -> "ReproduciblePipeline":
        self.steps.append(step)
        return self

    def run(self, inputs: Dict[str, Any],
            store=None,
            seed: int = 42) -> Tuple[Dict[str, str], ProvenanceGraph]:
        """Execute the pipeline deterministically.

        Parameters
        ----------
        inputs : dict
            Input artifacts: logical name -> content (bytes / str /
            numpy array / JSON-serializable).
        store : ObjectStore, optional
            Content-addressed store for inputs/outputs.  If None, a
            temporary in-memory hash map is used (hashes only, no
            persistence).
        seed : int
            Base seed; each step gets ``seed + step_index``.

        Returns
        -------
        (outputs, provenance) where outputs is logical name ->
        content hash.
        """
        from petroppo.platform.versioning import ObjectStore, sha256_hex
        if store is None:
            store = _MemoryStore()
        prov = ProvenanceGraph(run_id=f"{self.name}-{int(time.time())}")
        prov.environment = capture_environment(self.petroppo_version)

        # Record input entities.
        artifact_hashes: Dict[str, str] = {}
        for name, content in inputs.items():
            h = self._store_content(store, content)
            artifact_hashes[name] = h
            prov.add_entity(h, path=name, generated_by=None,
                            attributes={"role": "input"})

        # Execute steps in order.
        current = dict(artifact_hashes)
        for i, step in enumerate(self.steps):
            step_seed = (seed + i) if step.seed is None else step.seed
            act = prov.add_activity(
                step.name, parameters=step.parameters,
                seed=step_seed, code_version=self.petroppo_version,
            )
            # Record used entities.
            for inp_name in step.inputs:
                if inp_name in current:
                    ents = [e for e in prov.entities.values()
                            if e.content_hash == current[inp_name]
                            and e.path == inp_name]
                    if ents:
                        prov.record_used(act.id, ents[-1].id)
            prov.start_activity(act.id)

            # Gather step inputs (actual content).
            step_inputs = {}
            for inp_name in step.inputs:
                if inp_name in current:
                    step_inputs[inp_name] = store.get_bytes(current[inp_name]) \
                        if hasattr(store, "get_bytes") else current[inp_name]

            # Execute the step function.
            step_outputs = step.fn(step_inputs, seed=step_seed,
                                   **step.parameters)

            # Store outputs and record entities.
            if isinstance(step_outputs, dict):
                for out_name in step.outputs:
                    if out_name in step_outputs:
                        h = self._store_content(store, step_outputs[out_name])
                        current[out_name] = h
                        ent = prov.add_entity(
                            h, path=out_name, generated_by=act.id,
                            attributes={"role": "output"},
                        )
                        prov.record_generated(act.id, ent.id)
            prov.end_activity(act.id)

        self.provenance = prov
        self.last_outputs = {n: h for n, h in current.items()
                             if n not in artifact_hashes}
        return dict(current), prov

    @staticmethod
    def _store_content(store, content: Any) -> str:
        from petroppo.platform.versioning import ObjectStore
        if isinstance(content, bytes):
            if hasattr(store, "put_bytes"):
                return store.put_bytes(content)
            return hashlib.sha256(content).hexdigest()
        elif isinstance(content, str):
            if hasattr(store, "put_text"):
                return store.put_text(content)
            return hashlib.sha256(content.encode()).hexdigest()
        else:
            try:
                import numpy as np
                if isinstance(content, np.ndarray):
                    if hasattr(store, "put_array"):
                        return store.put_array(content)
                    buf = io.BytesIO()
                    np.save(buf, content)
                    return hashlib.sha256(buf.getvalue()).hexdigest()
            except ImportError:
                pass
            serialized = json.dumps(content, sort_keys=True, default=str)
            if hasattr(store, "put_json"):
                return store.put_json(content)
            return hashlib.sha256(serialized.encode()).hexdigest()


class _MemoryStore:
    """Minimal in-memory content store (hash-only, for testing)."""
    def __init__(self):
        self._data: Dict[str, bytes] = {}

    def put_bytes(self, data: bytes) -> str:
        h = hashlib.sha256(data).hexdigest()
        self._data[h] = data
        return h

    def put_text(self, text: str) -> str:
        return self.put_bytes(text.encode())

    def put_json(self, obj: Any) -> str:
        return self.put_text(json.dumps(obj, sort_keys=True, default=str))

    def put_array(self, arr) -> str:
        import numpy as np
        buf = io.BytesIO()
        np.save(buf, arr)
        return self.put_bytes(buf.getvalue())

    def get_bytes(self, h: str) -> bytes:
        return self._data.get(h, b"")


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def verify_reproducibility(pipeline: ReproduciblePipeline,
                           inputs: Dict[str, Any],
                           store=None,
                           seed: int = 42) -> dict:
    """Run a pipeline twice and verify byte-identical outputs.

    This is the analytically verifiable criterion for the V37
    ``industrial-reproducible-pipeline`` benchmark case: the same
    pipeline, same inputs, same seed, same environment must produce
    identical output content hashes.
    """
    outputs1, prov1 = pipeline.run(inputs, store=store, seed=seed)
    outputs2, prov2 = pipeline.run(inputs, store=store, seed=seed)
    # Compare output hashes for all non-input artifacts.
    input_names = set(inputs.keys())
    out1 = {k: v for k, v in outputs1.items() if k not in input_names}
    out2 = {k: v for k, v in outputs2.items() if k not in input_names}
    all_keys = set(out1) | set(out2)
    differing: List[str] = []
    for k in sorted(all_keys):
        if out1.get(k) != out2.get(k):
            differing.append(k)
    return {
        "identical": len(differing) == 0,
        "n_outputs": len(all_keys),
        "differing": differing,
        "output_hashes_1": out1,
        "output_hashes_2": out2,
        "provenance_hash_1": prov1.hash(),
        "provenance_hash_2": prov2.hash(),
        "environment_pinned": prov1.environment is not None
                              and prov2.environment is not None,
    }
