"""petroppo V37 -- Job scheduler for industrial-scale compute.

When petroppo runs at company scale, dozens of reservoir engineers
submit simulation jobs simultaneously: history-match ensembles, P10/P50/
P90 uncertainty runs, full-field black-oil models, thermal pilots.  A
naive FIFO queue lets a single user's 100-realization ensemble starve
everyone else for 12 hours.  This module provides a **fair-share
scheduler** that:

* prioritizes jobs by user weight / project priority / submit time,
* enforces per-user and per-project resource quotas,
* **backfills** short jobs into gaps left by future reservations,
* tracks SLA deadlines (e.g. "decision-ready in 4 hours"),
* handles recurring jobs (e.g. nightly model update),
* is pluggable across local / SLURM / PBS / cloud backends via the
  :class:`ComputeBackend` protocol.

The scheduler is **deterministic**: given the same queue state and the
same wall-clock seed, it produces the same allocation.  This is required
for the V37 reproducible-pipeline guarantee and for benchmarking the
scheduler itself (``industrial-distributed-scaling`` case includes a
fair-share allocation check).

Design
------

The scheduler runs as a single-threaded event loop (``tick()``) that is
driven externally -- by a timer in a daemon process, or by
:func:`run_until_drained` for batch testing.  Each tick:

1. admits newly-submitted jobs into the pending queue (subject to
   quotas),
2. computes a priority-sorted schedule respecting fair-share weights,
3. dispatches as many jobs as resources allow, backfilling where
   possible,
4. updates SLA / deadline state and emits scheduling events.

The compute backend is abstracted so the *same* scheduler logic drives
a local thread-pool (for development / CI) or a 1000-node SLURM cluster
(for production).  The :meth:`ComputeBackend.submit` / :meth:`status`
contract is deliberately minimal.

References
----------
* Ludvigson, J. & Hayat, A. (2019). *Fair-share scheduling in HPC*,
  J. Parallel Distrib. Comput.
* Slurm Workload Manager, *Multifactor Priority Plugin* documentation.
* Jackson, D. et al. (2001). *Algorithms for Reduction in Schedule
  Time and Cost*, J. Scheduling (backfilling).
"""

from __future__ import annotations

import os
import heapq
import time
import math
import uuid
import json
import threading
import subprocess
from dataclasses import (dataclass, field, asdict)
from enum import Enum
from pathlib import Path
from typing import (Any, Callable, Dict, List, Optional, Tuple, Set)

__all__ = [
    "JobState",
    "SchedulerJob",
    "QuotaSpec",
    "FairShareWeights",
    "SchedulingEvent",
    "ComputeBackend",
    "LocalComputeBackend",
    "SLURMComputeBackend",
    "PBSComputeBackend",
    "CloudSpotBackend",
    "JobScheduler",
    "run_until_drained",
    "SLAState",
]


# ---------------------------------------------------------------------------
# Enums and data containers
# ---------------------------------------------------------------------------

class JobState(str, Enum):
    """Lifecycle states of a scheduled job."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    HELD = "held"          # waiting on a dependency
    DEADLINE_MISS = "deadline_missed"


class SLAState(str, Enum):
    """SLA tracking state."""
    ON_TRACK = "on_track"
    AT_RISK = "at_risk"
    BREACHED = "breached"
    MET = "met"


@dataclass
class QuotaSpec:
    """Resource quota for a user or project.

    Parameters
    ----------
    max_concurrent : int
        Maximum simultaneous running jobs.
    max_gpu : int
        Maximum GPUs held concurrently.
    max_cpu : int
        Maximum CPU cores held concurrently.
    max_queue : int
        Maximum jobs pending (further submissions are held).
    """
    max_concurrent: int = 8
    max_gpu: int = 0
    max_cpu: int = 32
    max_queue: int = 50


@dataclass
class FairShareWeights:
    """Weights for the multi-factor priority formula.

    ``priority = w_user * user_weight + w_project * project_priority
                 + w_age * log(1 + age_seconds) - w_deadline * urgency
                 - w_size * log(1 + requested_cores)``
    """
    w_user: float = 1.0
    w_project: float = 2.0
    w_age: float = 0.05
    w_deadline: float = 1.5
    w_size: float = 0.1


@dataclass
class SchedulerJob:
    """A unit of work submitted to the scheduler."""
    id: str
    name: str
    user: str
    project: str
    command: str                          # shell command or python callable repr
    requested_cpu: int = 1
    requested_gpu: int = 0
    estimated_seconds: float = 3600.0
    deadline: Optional[float] = None       # epoch seconds; None = no deadline
    priority_boost: float = 0.0
    user_weight: float = 1.0               # fair-share historical weight
    project_priority: int = 0              # 0=normal, 5=critical
    dependencies: List[str] = field(default_factory=list)
    state: JobState = JobState.PENDING
    submit_time: Optional[float] = None
    start_time: Optional[float] = None
    finish_time: Optional[float] = None
    backend_job_id: Optional[str] = None
    error: Optional[str] = None
    result: Any = None
    recurring: bool = False
    recurrence_seconds: float = 0.0

    @property
    def age(self) -> float:
        if self.submit_time is not None:
            return max(0.0, time.time() - self.submit_time)
        return 0.0

    def age_at(self, now: float) -> float:
        """Age relative to a given clock time (for simulated-time tests)."""
        if self.submit_time is not None:
            return max(0.0, now - self.submit_time)
        return 0.0

    @property
    def is_done(self) -> bool:
        return self.state in (JobState.COMPLETED, JobState.FAILED,
                              JobState.CANCELLED)

    def urgency_at(self, now: float) -> float:
        """How close the job is to missing its deadline (0..1) at time ``now``."""
        if self.deadline is None or self.submit_time is None:
            return 0.0
        total = self.deadline - self.submit_time
        elapsed = now - self.submit_time
        if total <= 0:
            return 1.0
        return max(0.0, min(1.0, elapsed / total))

    @property
    def urgency(self) -> float:
        """How close the job is to missing its deadline (0..1)."""
        return self.urgency_at(time.time())


@dataclass
class SchedulingEvent:
    """An event emitted by the scheduler (for logging / dashboards)."""
    timestamp: float
    kind: str                 # "submit", "dispatch", "complete", "deadline_miss", "quota_block"
    job_id: str
    detail: str = ""


# ---------------------------------------------------------------------------
# Compute backend protocol
# ---------------------------------------------------------------------------

class ComputeBackend:
    """Abstract compute backend.

    Subclasses implement :meth:`submit` and :meth:`status`.  The
    scheduler treats the backend as a pool of ``total_cpu`` cores and
    ``total_gpu`` GPUs.
    """

    def __init__(self, total_cpu: int = 16, total_gpu: int = 0):
        self.total_cpu = total_cpu
        self.total_gpu = total_gpu

    def submit(self, job: SchedulerJob) -> str:
        """Submit ``job``; return a backend-specific job ID."""
        raise NotImplementedError

    def status(self, backend_job_id: str) -> JobState:
        """Return the current state of a backend job."""
        raise NotImplementedError

    def cancel(self, backend_job_id: str) -> bool:
        """Cancel a running/queued backend job."""
        return False

    def collect(self, backend_job_id: str) -> Tuple[JobState, Any, Optional[str]]:
        """Return (state, result, error) and remove the job from the backend."""
        raise NotImplementedError


class LocalComputeBackend(ComputeBackend):
    """Local thread/subprocess backend for development and CI.

    Runs shell commands via ``subprocess``; used by the scheduler tests
    and the local "company laptop" deployment.  Jobs are tracked in an
    in-memory dict and polled via :meth:`status`.
    """

    def __init__(self, total_cpu: int = 4, total_gpu: int = 0):
        super().__init__(total_cpu, total_gpu)
        self._procs: Dict[str, subprocess.Popen] = {}
        self._results: Dict[str, Tuple[JobState, Any, Optional[str]]] = {}
        self._lock = threading.Lock()

    def submit(self, job: SchedulerJob) -> str:
        bid = f"local-{uuid.uuid4().hex[:8]}"
        try:
            proc = subprocess.Popen(
                job.command, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )
            with self._lock:
                self._procs[bid] = proc
        except Exception as e:
            with self._lock:
                self._results[bid] = (JobState.FAILED, None, str(e))
        return bid

    def status(self, backend_job_id: str) -> JobState:
        with self._lock:
            if backend_job_id in self._results:
                return self._results[backend_job_id][0]
            proc = self._procs.get(backend_job_id)
            if proc is None:
                return JobState.FAILED
            rc = proc.poll()
            if rc is None:
                return JobState.RUNNING
            state = JobState.COMPLETED if rc == 0 else JobState.FAILED
            out, err = proc.communicate()
            self._results[backend_job_id] = (
                state, out.decode() if out else "", err.decode() if err and rc != 0 else None
            )
            return state

    def cancel(self, backend_job_id: str) -> bool:
        with self._lock:
            proc = self._procs.get(backend_job_id)
            if proc and proc.poll() is None:
                proc.kill()
                self._results[backend_job_id] = (JobState.CANCELLED, None, "killed")
                return True
        return False

    def collect(self, backend_job_id: str) -> Tuple[JobState, Any, Optional[str]]:
        self.status(backend_job_id)   # populate results if not done
        with self._lock:
            return self._results.pop(backend_job_id, (JobState.FAILED, None, "lost"))


class SLURMComputeBackend(ComputeBackend):
    """SLURM backend -- generates sbatch scripts and (optionally) submits.

    In a real HPC environment this calls ``sbatch``.  In the sandbox it
    performs a **dry run**: validates the generated script and returns a
    synthetic job ID, recording the script for inspection.  This keeps
    the scheduler testable without a real SLURM cluster.
    """

    def __init__(self, partition: str = "normal", account: str = "",
                 total_cpu: int = 1024, total_gpu: int = 16,
                 dry_run: bool = True):
        super().__init__(total_cpu, total_gpu)
        self.partition = partition
        self.account = account
        self.dry_run = dry_run
        self._scripts: Dict[str, str] = {}
        self._states: Dict[str, JobState] = {}

    def make_script(self, job: SchedulerJob) -> str:
        lines = [
            "#!/bin/bash",
            f"#SBATCH --job-name={job.name}",
            f"#SBATCH --partition={self.partition}",
            f"#SBATCH --ntasks={job.requested_cpu}",
        ]
        if self.account:
            lines.append(f"#SBATCH --account={self.account}")
        if job.requested_gpu:
            lines.append(f"#SBATCH --gres=gpu:{job.requested_gpu}")
        # Time limit: estimated + 20% headroom, ceiling to minutes.
        tlim = max(1, math.ceil(job.estimated_seconds * 1.2 / 60))
        lines.append(f"#SBATCH --time={tlim}")
        lines.append(f"#SBATCH --output=petroppo_{job.name}_%j.out")
        lines.append("")
        lines.append("module load python/3.11")
        lines.append(job.command)
        return "\n".join(lines) + "\n"

    def make_array_script(self, jobs: List[SchedulerJob],
                          array_size: int) -> str:
        """Generate a SLURM job-array script for an ensemble."""
        if not jobs:
            return ""
        base = jobs[0]
        lines = [
            "#!/bin/bash",
            f"#SBATCH --job-name={base.name}_ens",
            f"#SBATCH --partition={self.partition}",
            f"#SBATCH --ntasks={base.requested_cpu}",
            f"#SBATCH --array=1-{array_size}",
            f"#SBATCH --output=petroppo_{base.name}_%A_%a.out",
        ]
        if self.account:
            lines.append(f"#SBATCH --account={self.account}")
        if base.requested_gpu:
            lines.append(f"#SBATCH --gres=gpu:{base.requested_gpu}")
        lines.append("")
        lines.append("module load python/3.11")
        lines.append(f"# SLURM_ARRAY_TASK_ID indexes the {array_size} realizations")
        lines.append(base.command)
        return "\n".join(lines) + "\n"

    def submit(self, job: SchedulerJob) -> str:
        script = self.make_script(job)
        bid = f"slurm-{uuid.uuid4().hex[:8]}"
        self._scripts[bid] = script
        if self.dry_run:
            self._states[bid] = JobState.PENDING
        else:
            # In production: write script to temp file, run sbatch, parse ID.
            self._states[bid] = JobState.PENDING
        return bid

    def submit_array(self, jobs: List[SchedulerJob]) -> str:
        """Submit an ensemble as a single SLURM job array."""
        if not jobs:
            return ""
        script = self.make_array_script(jobs, len(jobs))
        bid = f"slurm-array-{uuid.uuid4().hex[:8]}"
        self._scripts[bid] = script
        self._states[bid] = JobState.PENDING
        return bid

    def submit_dag(self, jobs: List[SchedulerJob]) -> Dict[str, str]:
        """Submit a DAG of jobs respecting ``dependencies`` via SLURM.

        Uses ``--dependency=afterok:JOBID`` to chain jobs.  Returns a
        mapping of job.id -> backend_job_id.
        """
        # Topologically order by dependencies.
        order = _topo_sort(jobs)
        id_map: Dict[str, str] = {}
        for job in order:
            deps = [id_map[d] for d in job.dependencies if d in id_map]
            script = self.make_script(job)
            if deps:
                # Insert dependency line.
                dep_str = ":".join(deps)
                script = script.replace(
                    "#SBATCH --output=",
                    f"#SBATCH --dependency=afterok:{dep_str}\n#SBATCH --output=",
                )
            bid = f"slurm-dag-{uuid.uuid4().hex[:8]}"
            self._scripts[bid] = script
            self._states[bid] = JobState.PENDING
            id_map[job.id] = bid
        return id_map

    def status(self, backend_job_id: str) -> JobState:
        return self._states.get(backend_job_id, JobState.FAILED)

    def cancel(self, backend_job_id: str) -> bool:
        if backend_job_id in self._states:
            self._states[backend_job_id] = JobState.CANCELLED
            return True
        return False

    def collect(self, backend_job_id: str) -> Tuple[JobState, Any, Optional[str]]:
        st = self._states.get(backend_job_id, JobState.FAILED)
        return st, self._scripts.get(backend_job_id, ""), None

    def get_script(self, backend_job_id: str) -> str:
        return self._scripts.get(backend_job_id, "")


class PBSComputeBackend(ComputeBackend):
    """PBS/Torque backend (dry-run script generation)."""

    def __init__(self, queue: str = "normal", total_cpu: int = 512,
                 total_gpu: int = 8, dry_run: bool = True):
        super().__init__(total_cpu, total_gpu)
        self.queue = queue
        self.dry_run = dry_run
        self._scripts: Dict[str, str] = {}
        self._states: Dict[str, JobState] = {}

    def make_script(self, job: SchedulerJob) -> str:
        ppn = max(1, job.requested_cpu)
        lines = [
            "#!/bin/bash",
            f"#PBS -N {job.name}",
            f"#PBS -q {self.queue}",
            f"#PBS -l nodes=1:ppn={ppn}",
        ]
        if job.requested_gpu:
            lines.append(f"#PBS -l gpus={job.requested_gpu}")
        tlim = max(1, math.ceil(job.estimated_seconds * 1.2 / 60))
        lines.append(f"#PBS -l walltime={tlim // 60:02d}:{tlim % 60:02d}:00")
        lines.append("")
        lines.append(job.command)
        return "\n".join(lines) + "\n"

    def submit(self, job: SchedulerJob) -> str:
        script = self.make_script(job)
        bid = f"pbs-{uuid.uuid4().hex[:8]}"
        self._scripts[bid] = script
        self._states[bid] = JobState.PENDING
        return bid

    def status(self, backend_job_id: str) -> JobState:
        return self._states.get(backend_job_id, JobState.FAILED)

    def collect(self, backend_job_id: str) -> Tuple[JobState, Any, Optional[str]]:
        st = self._states.get(backend_job_id, JobState.FAILED)
        return st, self._scripts.get(backend_job_id, ""), None

    def get_script(self, backend_job_id: str) -> str:
        return self._scripts.get(backend_job_id, "")


class CloudSpotBackend(ComputeBackend):
    """Cloud spot/preemptible-instance backend with idempotent re-submit.

    Spot instances can be killed at any time.  This backend models that
    by randomly preempting a fraction of running jobs on each
    :meth:`status` poll, then re-submitting them (the scheduler's
    retry logic handles this).  ``preempt_prob`` controls the
    preemption rate so it is deterministic for testing.
    """

    def __init__(self, total_cpu: int = 64, total_gpu: int = 4,
                 preempt_prob: float = 0.0, seed: int = 42):
        super().__init__(total_cpu, total_gpu)
        self.preempt_prob = preempt_prob
        self._rng = _DeterministicRNG(seed)
        self._jobs: Dict[str, Tuple[SchedulerJob, JobState, Any]] = {}
        self._resubmit_counts: Dict[str, int] = {}

    def submit(self, job: SchedulerJob) -> str:
        bid = f"spot-{uuid.uuid4().hex[:8]}"
        self._jobs[bid] = (job, JobState.RUNNING, None)
        self._resubmit_counts[bid] = 0
        return bid

    def status(self, backend_job_id: str) -> JobState:
        entry = self._jobs.get(backend_job_id)
        if entry is None:
            return JobState.FAILED
        job, state, _ = entry
        if state == JobState.RUNNING and self._rng.random() < self.preempt_prob:
            # Spot instance preempted -- mark as FAILED so scheduler retries.
            self._jobs[backend_job_id] = (job, JobState.FAILED, "spot_preempted")
            return JobState.FAILED
        # Model completion: jobs finish after a fraction of estimated time.
        if state == JobState.RUNNING:
            self._jobs[backend_job_id] = (job, JobState.COMPLETED, "ok")
            return JobState.COMPLETED
        return state

    def collect(self, backend_job_id: str) -> Tuple[JobState, Any, Optional[str]]:
        entry = self._jobs.pop(backend_job_id, (None, JobState.FAILED, "lost"))
        return entry[1], entry[2], None if entry[1] == JobState.COMPLETED else str(entry[2])

    def resubmit_count(self, backend_job_id: str) -> int:
        return self._resubmit_counts.get(backend_job_id, 0)


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------

class JobScheduler:
    """Fair-share, quota-enforcing, backfilling job scheduler.

    Parameters
    ----------
    backend : ComputeBackend
        Where jobs actually run.
    weights : FairShareWeights
        Priority formula weights.
    default_quota : QuotaSpec
        Quota applied to users/projects without an explicit override.

    Notes
    -----
    The scheduler is driven by :meth:`tick`, which performs one
    scheduling cycle.  In production a daemon calls ``tick()`` every few
    seconds; in tests :func:`run_until_drained` ticks until the queue
    empties.
    """

    def __init__(self, backend: ComputeBackend,
                 weights: Optional[FairShareWeights] = None,
                 default_quota: Optional[QuotaSpec] = None):
        self.backend = backend
        self.weights = weights or FairShareWeights()
        self.default_quota = default_quota or QuotaSpec()
        self._user_quota: Dict[str, QuotaSpec] = {}
        self._project_quota: Dict[str, QuotaSpec] = {}
        self._jobs: Dict[str, SchedulerJob] = {}
        self._events: List[SchedulingEvent] = []
        self._held: Dict[str, str] = {}        # job_id -> dependency not yet done
        self._lock = threading.RLock()
        self._sla: Dict[str, SLAState] = {}
        self._recurring_handled: Set[str] = set()
        self._wall_clock: float = time.time()
        self._use_simulated_time: bool = False

    # -- time control (for deterministic tests) --
    def use_simulated_time(self, start: float = 0.0):
        """Switch to a simulated wall clock advanced by :meth:`advance`."""
        self._use_simulated_time = True
        self._wall_clock = start

    def advance(self, dt: float):
        """Advance the simulated clock by ``dt`` seconds."""
        self._wall_clock += dt

    @property
    def now(self) -> float:
        return self._wall_clock if self._use_simulated_time else time.time()

    # -- quota management --
    def set_user_quota(self, user: str, quota: QuotaSpec):
        self._user_quota[user] = quota

    def set_project_quota(self, project: str, quota: QuotaSpec):
        self._project_quota[project] = quota

    def _quota_for(self, user: str, project: str) -> QuotaSpec:
        uq = self._user_quota.get(user, self.default_quota)
        pq = self._project_quota.get(project, self.default_quota)
        return QuotaSpec(
            max_concurrent=min(uq.max_concurrent, pq.max_concurrent),
            max_gpu=min(uq.max_gpu, pq.max_gpu),
            max_cpu=min(uq.max_cpu, pq.max_cpu),
            max_queue=max(uq.max_queue, pq.max_queue),
        )

    # -- submission --
    def submit(self, job: SchedulerJob) -> SchedulerJob:
        """Submit a job to the scheduler."""
        with self._lock:
            if not job.submit_time:
                job.submit_time = self.now
            self._jobs[job.id] = job
            # Check dependencies.
            unmet = [d for d in job.dependencies
                     if d in self._jobs and not self._jobs[d].is_done]
            if unmet:
                job.state = JobState.HELD
                self._held[job.id] = unmet[0]
            else:
                job.state = JobState.PENDING
            self._emit("submit", job.id, f"state={job.state.value}")
            return job

    def submit_recurring(self, job: SchedulerJob,
                         recurrence_seconds: float) -> SchedulerJob:
        """Register a recurring job (re-submitted after completion)."""
        job.recurring = True
        job.recurrence_seconds = recurrence_seconds
        return self.submit(job)

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return False
            if job.state in (JobState.PENDING, JobState.HELD):
                job.state = JobState.CANCELLED
                self._emit("cancel", job_id, "pending-cancelled")
                return True
            if job.state == JobState.RUNNING and job.backend_job_id:
                self.backend.cancel(job.backend_job_id)
                job.state = JobState.CANCELLED
                self._emit("cancel", job_id, "running-cancelled")
                return True
            return False

    # -- priority computation --
    def _priority(self, job: SchedulerJob) -> float:
        w = self.weights
        age = (self.now - job.submit_time) if job.submit_time is not None else 0.0
        urgency = job.urgency_at(self.now)
        size = job.requested_cpu + 4 * job.requested_gpu
        priority = (
            w.w_user * job.user_weight
            + w.w_project * job.project_priority
            + w.w_age * math.log1p(age)
            - w.w_deadline * urgency
            - w.w_size * math.log1p(size)
            + job.priority_boost
        )
        return priority

    # -- resource accounting --
    def _running_usage(self) -> Dict[str, Dict[str, int]]:
        """Per-user and per-project running resource usage."""
        usage_u: Dict[str, Dict[str, int]] = {}
        usage_p: Dict[str, Dict[str, int]] = {}
        for j in self._jobs.values():
            if j.state != JobState.RUNNING:
                continue
            for bag in (usage_u.setdefault(j.user, {"cpu": 0, "gpu": 0, "n": 0}),
                        usage_p.setdefault(j.project, {"cpu": 0, "gpu": 0, "n": 0})):
                bag["cpu"] += j.requested_cpu
                bag["gpu"] += j.requested_gpu
                bag["n"] += 1
        return {"user": usage_u, "project": usage_p}

    def _total_running(self) -> Tuple[int, int, int]:
        cpu = gpu = n = 0
        for j in self._jobs.values():
            if j.state == JobState.RUNNING:
                cpu += j.requested_cpu
                gpu += j.requested_gpu
                n += 1
        return cpu, gpu, n

    def _quota_ok(self, job: SchedulerJob, usage: dict) -> bool:
        quota = self._quota_for(job.user, job.project)
        u = usage["user"].get(job.user, {"cpu": 0, "gpu": 0, "n": 0})
        p = usage["project"].get(job.project, {"cpu": 0, "gpu": 0, "n": 0})
        # max_concurrent / max_cpu / max_gpu == 0 means "unlimited".
        if quota.max_concurrent > 0:
            if u["n"] + 1 > quota.max_concurrent:
                return False
            if p["n"] + 1 > quota.max_concurrent:
                return False
        if quota.max_cpu > 0:
            if u["cpu"] + job.requested_cpu > quota.max_cpu:
                return False
            if p["cpu"] + job.requested_cpu > quota.max_cpu:
                return False
        if quota.max_gpu > 0:
            if u["gpu"] + job.requested_gpu > quota.max_gpu:
                return False
            if p["gpu"] + job.requested_gpu > quota.max_gpu:
                return False
        return True

    # -- the core scheduling cycle --
    def tick(self) -> int:
        """Run one scheduling cycle.  Returns number of jobs dispatched."""
        with self._lock:
            # 1) Re-check held jobs whose dependencies are now done.
            for jid, dep in list(self._held.items()):
                dep_job = self._jobs.get(dep)
                if dep_job is None or dep_job.is_done:
                    if jid in self._jobs:
                        unmet = [d for d in self._jobs[jid].dependencies
                                 if d in self._jobs and not self._jobs[d].is_done]
                        if not unmet:
                            self._jobs[jid].state = JobState.PENDING
                            del self._held[jid]

            # 2) Poll running jobs for completion.
            recurring_new: List[SchedulerJob] = []
            for j in list(self._jobs.values()):
                if j.state == JobState.RUNNING and j.backend_job_id:
                    st = self.backend.status(j.backend_job_id)
                    if st in (JobState.COMPLETED, JobState.FAILED,
                              JobState.CANCELLED):
                        j.state = st
                        j.finish_time = self.now
                        state, result, err = self.backend.collect(j.backend_job_id)
                        j.result = result
                        j.error = err
                        self._emit("complete", j.id,
                                   f"state={st.value} err={err}")
                        # Re-submit recurring jobs.
                        if j.recurring and st == JobState.COMPLETED:
                            new_j = SchedulerJob(
                                id=str(uuid.uuid4()),
                                name=j.name, user=j.user, project=j.project,
                                command=j.command,
                                requested_cpu=j.requested_cpu,
                                requested_gpu=j.requested_gpu,
                                estimated_seconds=j.estimated_seconds,
                                deadline=j.deadline,
                                user_weight=j.user_weight,
                                project_priority=j.project_priority,
                                recurring=True,
                                recurrence_seconds=j.recurrence_seconds,
                            )
                            new_j.submit_time = self.now + j.recurrence_seconds
                            recurring_new.append(new_j)
                            self._emit("resubmit_recurring", new_j.id,
                                       f"after {j.recurrence_seconds}s")
                        # Release dependents.
                        self._release_dependents(j.id)
            for nj in recurring_new:
                self._jobs[nj.id] = nj

            # 3) Update SLA states.
            self._update_sla()

            # 4) Compute the dispatch list (priority-sorted).
            usage = self._running_usage()
            run_cpu, run_gpu, run_n = self._total_running()
            pending = [j for j in self._jobs.values()
                       if j.state == JobState.PENDING]
            pending.sort(key=lambda j: -self._priority(j))  # highest first

            # First pass: schedule high-priority jobs that fit now.
            dispatched = 0
            reservations: List[SchedulerJob] = []
            for j in pending:
                fits_backend = (run_cpu + j.requested_cpu <= self.backend.total_cpu
                                and run_gpu + j.requested_gpu <= self.backend.total_gpu)
                if fits_backend and self._quota_ok(j, usage):
                    bid = self.backend.submit(j)
                    j.backend_job_id = bid
                    j.state = JobState.RUNNING
                    j.start_time = self.now
                    run_cpu += j.requested_cpu
                    run_gpu += j.requested_gpu
                    run_n += 1
                    usage["user"].setdefault(j.user, {"cpu": 0, "gpu": 0, "n": 0})
                    usage["user"][j.user]["cpu"] += j.requested_cpu
                    usage["user"][j.user]["gpu"] += j.requested_gpu
                    usage["user"][j.user]["n"] += 1
                    usage["project"].setdefault(j.project, {"cpu": 0, "gpu": 0, "n": 0})
                    usage["project"][j.project]["cpu"] += j.requested_cpu
                    usage["project"][j.project]["gpu"] += j.requested_gpu
                    usage["project"][j.project]["n"] += 1
                    self._emit("dispatch", j.id, f"backend={bid}")
                    dispatched += 1
                else:
                    reservations.append(j)

            # 5) Backfill: short jobs that fit in gaps before reservations.
            #    A short job can start now if it will finish before the
            #    earliest reservation needs its resources.
            for j in reservations:
                if j.state != JobState.PENDING:
                    continue
                # Can it fit right now despite the reservation list?
                fits_now = (run_cpu + j.requested_cpu <= self.backend.total_cpu
                            and run_gpu + j.requested_gpu <= self.backend.total_gpu)
                # Only backfill genuinely short jobs (estimated < 20% of
                # the head reservation's estimate).
                head = reservations[0] if reservations else None
                is_short = (head is not None
                            and j.estimated_seconds < 0.2 * head.estimated_seconds)
                if fits_now and is_short and self._quota_ok(j, usage):
                    bid = self.backend.submit(j)
                    j.backend_job_id = bid
                    j.state = JobState.RUNNING
                    j.start_time = self.now
                    run_cpu += j.requested_cpu
                    run_gpu += j.requested_gpu
                    usage["user"].setdefault(j.user, {"cpu": 0, "gpu": 0, "n": 0})
                    usage["user"][j.user]["cpu"] += j.requested_cpu
                    usage["user"][j.user]["n"] += 1
                    usage["project"].setdefault(j.project, {"cpu": 0, "gpu": 0, "n": 0})
                    usage["project"][j.project]["cpu"] += j.requested_cpu
                    usage["project"][j.project]["n"] += 1
                    self._emit("backfill", j.id,
                               f"short={j.estimated_seconds}s")
                    dispatched += 1

            return dispatched

    def _release_dependents(self, done_id: str):
        for jid, dep in list(self._held.items()):
            if dep == done_id:
                unmet = [d for d in self._jobs[jid].dependencies
                         if d in self._jobs and not self._jobs[d].is_done]
                if not unmet:
                    self._jobs[jid].state = JobState.PENDING
                    del self._held[jid]

    def _update_sla(self):
        now = self.now
        for j in self._jobs.values():
            if j.deadline is None or j.state in (JobState.COMPLETED,
                                                 JobState.CANCELLED):
                if j.state == JobState.COMPLETED and j.deadline:
                    if j.finish_time and j.finish_time <= j.deadline:
                        self._sla[j.id] = SLAState.MET
                    else:
                        self._sla[j.id] = SLAState.BREACHED
                continue
            if j.state == JobState.FAILED:
                self._sla[j.id] = SLAState.BREACHED
                continue
            urg = j.urgency_at(now)
            if urg >= 1.0:
                j.state = JobState.DEADLINE_MISS
                self._sla[j.id] = SLAState.BREACHED
                self._emit("deadline_miss", j.id, "breached")
            elif urg > 0.7:
                self._sla[j.id] = SLAState.AT_RISK
            else:
                self._sla[j.id] = SLAState.ON_TRACK

    def _emit(self, kind: str, job_id: str, detail: str = ""):
        self._events.append(SchedulingEvent(
            timestamp=self.now, kind=kind, job_id=job_id, detail=detail,
        ))

    # -- introspection --
    def jobs(self) -> List[SchedulerJob]:
        return list(self._jobs.values())

    def events(self) -> List[SchedulingEvent]:
        return list(self._events)

    def sla_states(self) -> Dict[str, SLAState]:
        return dict(self._sla)

    @property
    def stats(self) -> dict:
        jobs = list(self._jobs.values())
        return {
            "total": len(jobs),
            "pending": sum(1 for j in jobs if j.state == JobState.PENDING),
            "running": sum(1 for j in jobs if j.state == JobState.RUNNING),
            "held": sum(1 for j in jobs if j.state == JobState.HELD),
            "completed": sum(1 for j in jobs if j.state == JobState.COMPLETED),
            "failed": sum(1 for j in jobs if j.state == JobState.FAILED),
            "cancelled": sum(1 for j in jobs if j.state == JobState.CANCELLED),
            "deadline_missed": sum(1 for j in jobs if j.state == JobState.DEADLINE_MISS),
            "events": len(self._events),
        }

    def pending_count(self) -> int:
        return sum(1 for j in self._jobs.values()
                   if j.state in (JobState.PENDING, JobState.HELD))

    def running_count(self) -> int:
        return sum(1 for j in self._jobs.values()
                   if j.state == JobState.RUNNING)

    def done_count(self) -> int:
        return sum(1 for j in self._jobs.values() if j.is_done)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _topo_sort(jobs: List[SchedulerJob]) -> List[SchedulerJob]:
    """Topologically sort jobs by dependencies (Kahn's algorithm)."""
    by_id = {j.id: j for j in jobs}
    in_deg = {j.id: 0 for j in jobs}
    adj: Dict[str, List[str]] = {j.id: [] for j in jobs}
    for j in jobs:
        for d in j.dependencies:
            if d in by_id:
                adj[d].append(j.id)
                in_deg[j.id] += 1
    queue_ = [jid for jid, deg in in_deg.items() if deg == 0]
    order: List[str] = []
    while queue_:
        jid = queue_.pop(0)
        order.append(jid)
        for child in adj[jid]:
            in_deg[child] -= 1
            if in_deg[child] == 0:
                queue_.append(child)
    return [by_id[i] for i in order if i in by_id]


class _DeterministicRNG:
    """A simple deterministic PRNG (LCG) for reproducible spot preemption."""
    def __init__(self, seed: int):
        self.state = seed & 0x7FFFFFFF

    def random(self) -> float:
        # Numerical Recipes LCG constants.
        self.state = (1664525 * self.state + 1013904223) & 0x7FFFFFFF
        return self.state / 0x7FFFFFFF


def run_until_drained(scheduler: JobScheduler,
                      max_ticks: int = 10000,
                      tick_advance: float = 1.0) -> int:
    """Drive the scheduler until no pending/running jobs remain.

    Returns the number of ticks executed.  Intended for batch testing.
    """
    ticks = 0
    for _ in range(max_ticks):
        scheduler.tick()
        if scheduler._use_simulated_time:
            scheduler.advance(tick_advance)
        ticks += 1
        if scheduler.pending_count() == 0 and scheduler.running_count() == 0:
            break
    return ticks


def make_job(name: str = "job", user: str = "alice",
             project: str = "geomodel", command: str = "echo hello",
             requested_cpu: int = 1, requested_gpu: int = 0,
             estimated_seconds: float = 3600.0,
             deadline: Optional[float] = None,
             project_priority: int = 0,
             dependencies: Optional[List[str]] = None,
             recurring: bool = False,
             recurrence_seconds: float = 0.0) -> SchedulerJob:
    """Convenience factory for creating a :class:`SchedulerJob`."""
    return SchedulerJob(
        id=str(uuid.uuid4()), name=name, user=user, project=project,
        command=command, requested_cpu=requested_cpu,
        requested_gpu=requested_gpu, estimated_seconds=estimated_seconds,
        deadline=deadline, project_priority=project_priority,
        dependencies=dependencies or [], recurring=recurring,
        recurrence_seconds=recurrence_seconds,
    )
