"""petroppo V38 — Enterprise Single Sign-On (SSO).

Implements federated identity for enterprise deployments:

* **SAML 2.0** — parse and validate SAML assertions (Response,
  Assertion, Conditions, AttributeStatement).  Signature verification
  via XML-Signature (simplified HMAC-SHA1 for pure-Python, no external
  XMLSec dependency).
* **OIDC** — validate OpenID Connect ID tokens (JWT format),
  verify signature, check ``iss``, ``aud``, ``exp``, ``iat`` claims.
* **Just-in-time (JIT) provisioning** — auto-create a local user
  record on first SSO login, mapping IdP attributes to petroppo
  user fields.
* **Group → role mapping** — map IdP group/role claims to petroppo
  platform roles (viewer / interpreter / admin).
* **Session management** — create SSO sessions with timeout, logout,
  and session validation.

This is a pure-Python implementation using only the standard library
(``hashlib``, ``hmac``, ``base64``, ``json``, ``time``, ``xml.etree``).
It does **not** depend on ``python3-saml``, ``pySAML2``, or
``python-jose`` — those are optional in production.  The design
allows dropping in a real SAML/OIDC library by replacing the
verification functions.

References
----------
* OASIS (2005). *Security Assertion Markup Language (SAML) 2.0*.
* Sakimura, N. et al. (2014). *OpenID Connect Core 1.0*.
* RFC 7519 — *JSON Web Token (JWT)*.
* RFC 7515 — *JSON Web Signature (JWS)*.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import secrets
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import parse_qs, urlparse

__all__ = [
    "SSOError",
    "SAMLAssertionError",
    "OIDCTokenError",
    "SSOSessionExpired",
    "IdPConfig",
    "ServiceProviderConfig",
    "SAMLAttribute",
    "SAMLAssertion",
    "SAMLResponse",
    "OIDCClaims",
    "SSOUser",
    "SSOSession",
    "SAMLProvider",
    "OIDCProvider",
    "SSOManager",
    "GroupRoleMapper",
    "build_saml_response_xml",
    "build_oidc_id_token",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class SSOError(Exception):
    """Base exception for SSO errors."""


class SAMLAssertionError(SSOError):
    """Raised when a SAML assertion is invalid or cannot be parsed."""


class OIDCTokenError(SSOError):
    """Raised when an OIDC token is invalid or cannot be verified."""


class SSOSessionExpired(SSOError):
    """Raised when an SSO session has expired."""


# ---------------------------------------------------------------------------
# SAML namespace helpers
# ---------------------------------------------------------------------------

_SAML_NS = {
    "samlp": "urn:oasis:names:tc:SAML:2.0:protocol",
    "saml": "urn:oasis:names:tc:SAML:2.0:assertion",
    "ds": "http://www.w3.org/2000/09/xmldsig#",
}


def _ns(prefix: str, tag: str) -> str:
    """Build a namespaced XML tag."""
    return f"{{{_SAML_NS[prefix]}}}{tag}"


# ---------------------------------------------------------------------------
# Configuration dataclasses
# ---------------------------------------------------------------------------

@dataclass
class IdPConfig:
    """Identity Provider configuration."""

    entity_id: str                        # IdP entity ID (URL)
    sso_url: str                          # SSO service URL
    signing_key: bytes                    # Shared secret for HMAC signature
    certificates: List[str] = field(default_factory=list)
    issuer: str = ""                      # Often same as entity_id
    clock_skew_seconds: int = 60          # Allowed clock skew

    def to_dict(self) -> dict:
        return {
            "entity_id": self.entity_id,
            "sso_url": self.sso_url,
            "issuer": self.issuer or self.entity_id,
            "clock_skew_seconds": self.clock_skew_seconds,
        }


@dataclass
class ServiceProviderConfig:
    """Service Provider (petroppo) configuration."""

    entity_id: str = "https://petroppo.local/sp"
    acs_url: str = "https://petroppo.local/sso/acs"
    audience: str = "https://petroppo.local/sp"
    signing_key: bytes = b""              # SP signing key (for AuthnRequests)


# ---------------------------------------------------------------------------
# SAML data classes
# ---------------------------------------------------------------------------

@dataclass
class SAMLAttribute:
    """A SAML attribute (name -> list of values)."""

    name: str
    values: List[str] = field(default_factory=list)


@dataclass
class SAMLAssertion:
    """Parsed SAML assertion."""

    id: str = ""
    issuer: str = ""
    subject: str = ""                     # NameID
    subject_format: str = ""
    audience: str = ""
    not_before: float = 0.0
    not_on_or_after: float = 0.0
    attributes: Dict[str, List[str]] = field(default_factory=dict)
    authn_instant: float = 0.0
    session_index: str = ""
    signature_valid: bool = False

    def get_attribute(self, name: str) -> Optional[str]:
        """Get the first value of a named attribute."""
        vals = self.attributes.get(name)
        return vals[0] if vals else None

    def get_attributes(self, name: str) -> List[str]:
        """Get all values of a named attribute."""
        return self.attributes.get(name, [])

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "issuer": self.issuer,
            "subject": self.subject,
            "subject_format": self.subject_format,
            "audience": self.audience,
            "not_before": self.not_before,
            "not_on_or_after": self.not_on_or_after,
            "attributes": dict(self.attributes),
            "authn_instant": self.authn_instant,
            "session_index": self.session_index,
            "signature_valid": self.signature_valid,
        }


@dataclass
class SAMLResponse:
    """Parsed SAML Response (contains one or more assertions)."""

    id: str = ""
    issuer: str = ""
    destination: str = ""
    assertions: List[SAMLAssertion] = field(default_factory=list)
    signature_valid: bool = False

    @property
    def primary_assertion(self) -> Optional[SAMLAssertion]:
        """Return the first assertion (most responses have exactly one)."""
        return self.assertions[0] if self.assertions else None


# ---------------------------------------------------------------------------
# OIDC data classes
# ---------------------------------------------------------------------------

@dataclass
class OIDCClaims:
    """Parsed OIDC ID token claims."""

    iss: str = ""
    sub: str = ""                         # Subject (user ID at IdP)
    aud: str = ""
    exp: float = 0.0
    iat: float = 0.0
    nonce: str = ""
    email: str = ""
    name: str = ""
    preferred_username: str = ""
    groups: List[str] = field(default_factory=list)
    raw_claims: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "iss": self.iss,
            "sub": self.sub,
            "aud": self.aud,
            "exp": self.exp,
            "iat": self.iat,
            "nonce": self.nonce,
            "email": self.email,
            "name": self.name,
            "preferred_username": self.preferred_username,
            "groups": list(self.groups),
        }


# ---------------------------------------------------------------------------
# SSO User & Session
# ---------------------------------------------------------------------------

@dataclass
class SSOUser:
    """A user provisioned via SSO."""

    username: str
    email: str = ""
    display_name: str = ""
    idp_subject: str = ""                 # Subject ID at the IdP
    idp_name: str = ""                    # Which IdP authenticated them
    groups: List[str] = field(default_factory=list)
    mapped_roles: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    last_login: float = 0.0
    is_active: bool = True

    def to_dict(self) -> dict:
        return {
            "username": self.username,
            "email": self.email,
            "display_name": self.display_name,
            "idp_subject": self.idp_subject,
            "idp_name": self.idp_name,
            "groups": list(self.groups),
            "mapped_roles": list(self.mapped_roles),
            "created_at": self.created_at,
            "last_login": self.last_login,
            "is_active": self.is_active,
        }


@dataclass
class SSOSession:
    """An active SSO session."""

    session_id: str
    username: str
    idp_name: str
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    idle_timeout: float = 1800.0          # 30 min default
    last_activity: float = field(default_factory=time.time)
    attributes: dict = field(default_factory=dict)

    @property
    def is_expired(self) -> bool:
        now = time.time()
        if now > self.expires_at:
            return True
        if now - self.last_activity > self.idle_timeout:
            return True
        return False

    def touch(self) -> None:
        """Update last activity time (prevent idle timeout)."""
        self.last_activity = time.time()

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "username": self.username,
            "idp_name": self.idp_name,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "last_activity": self.last_activity,
            "is_expired": self.is_expired,
        }


# ---------------------------------------------------------------------------
# Group → Role Mapper
# ---------------------------------------------------------------------------

class GroupRoleMapper:
    """Maps IdP groups to petroppo platform roles.

    Example mapping::

        {
            "petroppo-admins": "admin",
            "petroppo-interpreters": "interpreter",
            "petroppo-viewers": "viewer",
        }

    A user's effective role is the highest-privilege role among all
    their groups.  Role hierarchy: admin > interpreter > viewer.
    """

    ROLE_HIERARCHY = {"viewer": 1, "interpreter": 2, "admin": 3}

    def __init__(self, mapping: Optional[Dict[str, str]] = None,
                 default_role: str = "viewer"):
        self._mapping: Dict[str, str] = mapping or {}
        self._default_role = default_role
        valid = set(self.ROLE_HIERARCHY.keys())
        for role in self._mapping.values():
            if role not in valid:
                raise ValueError(f"invalid role '{role}' in mapping")

    def add_mapping(self, group: str, role: str) -> None:
        """Add a group → role mapping."""
        if role not in self.ROLE_HIERARCHY:
            raise ValueError(f"invalid role '{role}'")
        self._mapping[group] = role

    def map_groups(self, groups: List[str]) -> List[str]:
        """Map a list of IdP groups to petroppo roles.

        Returns a list of unique roles (highest privilege first).
        """
        roles: Set[str] = set()
        for g in groups:
            if g in self._mapping:
                roles.add(self._mapping[g])
        if not roles:
            roles.add(self._default_role)
        # Sort by hierarchy descending (highest privilege first)
        return sorted(roles, key=lambda r: -self.ROLE_HIERARCHY.get(r, 0))

    @property
    def mapping(self) -> dict:
        return dict(self._mapping)


# ---------------------------------------------------------------------------
# SAML Provider
# ---------------------------------------------------------------------------

class SAMLProvider:
    """SAML 2.0 authentication provider.

    Parses SAML Responses and validates assertions against the
    configured IdP.
    """

    def __init__(
        self,
        idp_config: IdPConfig,
        sp_config: Optional[ServiceProviderConfig] = None,
    ):
        self.idp = idp_config
        self.sp = sp_config or ServiceProviderConfig()

    def parse_response(self, saml_response_xml: str) -> SAMLResponse:
        """Parse a SAML Response XML string.

        Raises
        ------
        SAMLAssertionError
            If the XML is malformed or missing required elements.
        """
        try:
            root = ET.fromstring(saml_response_xml)
        except ET.ParseError as e:
            raise SAMLAssertionError(f"invalid XML: {e}")

        if root.tag != _ns("samlp", "Response"):
            raise SAMLAssertionError(
                f"root element is not samlp:Response (got {root.tag})"
            )

        response = SAMLResponse(
            id=root.get("ID", ""),
            destination=root.get("Destination", ""),
        )

        # Issuer
        issuer_el = root.find(_ns("saml", "Issuer"))
        if issuer_el is not None and issuer_el.text:
            response.issuer = issuer_el.text.strip()

        # Assertions
        for assertion_el in root.findall(_ns("saml", "Assertion")):
            assertion = self._parse_assertion(assertion_el)
            response.assertions.append(assertion)

        # Signature verification (simplified)
        response.signature_valid = self._verify_response_signature(root)

        if not response.assertions:
            raise SAMLAssertionError("SAML Response contains no assertions")

        return response

    def _parse_assertion(self, el: ET.Element) -> SAMLAssertion:
        """Parse a single saml:Assertion element."""
        assertion = SAMLAssertion(
            id=el.get("ID", ""),
        )

        # Issuer
        issuer_el = el.find(_ns("saml", "Issuer"))
        if issuer_el is not None and issuer_el.text:
            assertion.issuer = issuer_el.text.strip()

        # Subject
        subject_el = el.find(_ns("saml", "Subject"))
        if subject_el is not None:
            nameid_el = subject_el.find(_ns("saml", "NameID"))
            if nameid_el is not None:
                assertion.subject = nameid_el.text or ""
                assertion.subject_format = nameid_el.get("Format", "")

        # Conditions
        conditions_el = el.find(_ns("saml", "Conditions"))
        if conditions_el is not None:
            assertion.not_before = self._parse_saml_time(
                conditions_el.get("NotBefore", "")
            )
            assertion.not_on_or_after = self._parse_saml_time(
                conditions_el.get("NotOnOrAfter", "")
            )
            audience_restriction = conditions_el.find(
                _ns("saml", "AudienceRestriction")
            )
            if audience_restriction is not None:
                audience_el = audience_restriction.find(_ns("saml", "Audience"))
                if audience_el is not None and audience_el.text:
                    assertion.audience = audience_el.text.strip()

        # AuthnStatement
        authn_el = el.find(_ns("saml", "AuthnStatement"))
        if authn_el is not None:
            assertion.authn_instant = self._parse_saml_time(
                authn_el.get("AuthnInstant", "")
            )
            assertion.session_index = authn_el.get("SessionIndex", "")

        # AttributeStatement
        attr_stmt = el.find(_ns("saml", "AttributeStatement"))
        if attr_stmt is not None:
            for attr_el in attr_stmt.findall(_ns("saml", "Attribute")):
                attr_name = attr_el.get("Name", "")
                values = []
                for val_el in attr_el.findall(_ns("saml", "AttributeValue")):
                    if val_el.text:
                        values.append(val_el.text)
                if attr_name:
                    assertion.attributes[attr_name] = values

        # Signature
        assertion.signature_valid = self._verify_assertion_signature(el)

        return assertion

    def validate_assertion(
        self,
        assertion: SAMLAssertion,
        expected_audience: Optional[str] = None,
    ) -> bool:
        """Validate a parsed SAML assertion.

        Checks:
        1. Issuer matches IdP entity_id.
        2. Audience matches expected (SP audience).
        3. Time window is valid (not_before <= now < not_on_or_after),
           with clock skew tolerance.
        4. Signature is valid.

        Returns
        -------
        bool
            True if the assertion is valid.
        """
        expected_audience = expected_audience or self.sp.audience
        now = time.time()
        skew = self.idp.clock_skew_seconds

        # Check issuer
        expected_issuer = self.idp.issuer or self.idp.entity_id
        if assertion.issuer and assertion.issuer != expected_issuer:
            return False

        # Check audience
        if assertion.audience and expected_audience:
            if assertion.audience != expected_audience:
                return False

        # Check time validity
        if assertion.not_on_or_after > 0:
            if now >= assertion.not_on_or_after + skew:
                return False
        if assertion.not_before > 0:
            if now < assertion.not_before - skew:
                return False

        # Check signature
        if not assertion.signature_valid:
            return False

        return True

    def _parse_saml_time(self, s: str) -> float:
        """Parse a SAML UTC time string (xs:dateTime) to epoch float."""
        if not s:
            return 0.0
        # Handle both "2024-01-01T00:00:00Z" and epoch
        try:
            # Try ISO format
            clean = s.replace("Z", "+00:00")
            from datetime import datetime
            dt = datetime.fromisoformat(clean)
            return dt.timestamp()
        except (ValueError, TypeError):
            try:
                return float(s)
            except ValueError:
                return 0.0

    def _verify_assertion_signature(self, el: ET.Element) -> bool:
        """Simplified signature verification using HMAC.

        In production, this would use XML-Signature (xmldsig).  Here
        we use a simplified approach: if a SignatureValue element is
        present, we verify it against the shared signing key.
        """
        sig_el = el.find(_ns("ds", "Signature"))
        if sig_el is None:
            # No signature present — check if signing is required
            return True  # Permissive for unsigned assertions in test mode

        sig_value_el = sig_el.find(_ns("ds", "SignatureValue"))
        if sig_value_el is None or not sig_value_el.text:
            return False

        # Compute expected signature over the assertion ID
        assertion_id = el.get("ID", "")
        expected = hmac.new(
            self.idp.signing_key,
            assertion_id.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        provided = sig_value_el.text.strip()
        return hmac.compare_digest(expected, provided)

    def _verify_response_signature(self, root: ET.Element) -> bool:
        """Verify the response-level signature (simplified)."""
        sig_el = root.find(_ns("ds", "Signature"))
        if sig_el is None:
            return True
        sig_value_el = sig_el.find(_ns("ds", "SignatureValue"))
        if sig_value_el is None or not sig_value_el.text:
            return False
        response_id = root.get("ID", "")
        expected = hmac.new(
            self.idp.signing_key,
            response_id.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        provided = sig_value_el.text.strip()
        return hmac.compare_digest(expected, provided)


# ---------------------------------------------------------------------------
# OIDC Provider
# ---------------------------------------------------------------------------

class OIDCProvider:
    """OpenID Connect token provider / validator.

    Validates JWT-format ID tokens issued by an OIDC IdP.
    """

    def __init__(
        self,
        issuer: str,
        client_id: str,
        client_secret: bytes,
        clock_skew_seconds: int = 60,
    ):
        self.issuer = issuer
        self.client_id = client_id
        self.client_secret = client_secret
        self.clock_skew = clock_skew_seconds

    def parse_id_token(self, id_token: str) -> OIDCClaims:
        """Parse and validate an OIDC ID token (JWT).

        Raises
        ------
        OIDCTokenError
            If the token is malformed, expired, or has invalid claims.
        """
        parts = id_token.split(".")
        if len(parts) != 3:
            raise OIDCTokenError("invalid JWT: expected 3 parts")

        header_b64, payload_b64, signature_b64 = parts

        # Decode header
        try:
            header = json.loads(self._b64url_decode(header_b64))
        except (json.JSONDecodeError, Exception) as e:
            raise OIDCTokenError(f"invalid JWT header: {e}")

        # Decode payload
        try:
            payload = json.loads(self._b64url_decode(payload_b64))
        except (json.JSONDecodeError, Exception) as e:
            raise OIDCTokenError(f"invalid JWT payload: {e}")

        # Verify signature (HMAC-SHA256)
        if not self._verify_signature(header_b64, payload_b64, signature_b64):
            raise OIDCTokenError("JWT signature verification failed")

        # Validate claims
        now = time.time()
        skew = self.clock_skew

        iss = payload.get("iss", "")
        if iss != self.issuer:
            raise OIDCTokenError(
                f"invalid iss: expected '{self.issuer}', got '{iss}'"
            )

        aud = payload.get("aud", "")
        aud_list = aud if isinstance(aud, list) else [aud]
        if self.client_id not in aud_list:
            raise OIDCTokenError(
                f"invalid aud: expected '{self.client_id}', got '{aud}'"
            )

        exp = payload.get("exp", 0)
        if exp and now > exp + skew:
            raise OIDCTokenError(f"token expired at {exp}")

        iat = payload.get("iat", 0)
        if iat and now < iat - skew:
            raise OIDCTokenError(f"token iat is in the future: {iat}")

        # Build claims
        claims = OIDCClaims(
            iss=iss,
            sub=payload.get("sub", ""),
            aud=aud if isinstance(aud, str) else (aud[0] if aud else ""),
            exp=float(exp) if exp else 0.0,
            iat=float(iat) if iat else 0.0,
            nonce=payload.get("nonce", ""),
            email=payload.get("email", ""),
            name=payload.get("name", ""),
            preferred_username=payload.get("preferred_username", ""),
            groups=payload.get("groups", []),
            raw_claims=payload,
        )

        return claims

    def _verify_signature(
        self,
        header_b64: str,
        payload_b64: str,
        signature_b64: str,
    ) -> bool:
        """Verify the JWT signature using HMAC-SHA256."""
        signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
        expected = hmac.new(
            self.client_secret,
            signing_input,
            hashlib.sha256,
        ).digest()
        expected_b64 = self._b64url_encode(expected).decode("ascii")
        return hmac.compare_digest(expected_b64, signature_b64)

    @staticmethod
    def _b64url_decode(data: str) -> bytes:
        """Decode a base64url string (with padding fix)."""
        padding = 4 - len(data) % 4
        if padding != 4:
            data += "=" * padding
        return base64.urlsafe_b64decode(data)

    @staticmethod
    def _b64url_encode(data: bytes) -> bytes:
        """Encode bytes to base64url (without padding)."""
        return base64.urlsafe_b64encode(data).rstrip(b"=")


# ---------------------------------------------------------------------------
# SSO Manager
# ---------------------------------------------------------------------------

class SSOManager:
    """Central SSO manager combining SAML + OIDC + JIT provisioning.

    Parameters
    ----------
    session_timeout : float
        Absolute session timeout in seconds (default 8 hours).
    idle_timeout : float
        Idle session timeout in seconds (default 30 min).
    """

    def __init__(
        self,
        session_timeout: float = 8 * 3600,
        idle_timeout: float = 1800,
    ):
        self._saml_providers: Dict[str, SAMLProvider] = {}
        self._oidc_providers: Dict[str, OIDCProvider] = {}
        self._sessions: Dict[str, SSOSession] = {}
        self._users: Dict[str, SSOUser] = {}  # username -> SSOUser
        self._subject_index: Dict[str, str] = {}  # idp:subject -> username
        self._group_mapper = GroupRoleMapper()
        self._session_timeout = session_timeout
        self._idle_timeout = idle_timeout

    # -- Provider registration -------------------------------------------

    def register_saml_provider(
        self,
        name: str,
        idp_config: IdPConfig,
        sp_config: Optional[ServiceProviderConfig] = None,
    ) -> None:
        """Register a SAML IdP."""
        self._saml_providers[name] = SAMLProvider(idp_config, sp_config)

    def register_oidc_provider(
        self,
        name: str,
        issuer: str,
        client_id: str,
        client_secret: bytes,
    ) -> None:
        """Register an OIDC IdP."""
        self._oidc_providers[name] = OIDCProvider(
            issuer=issuer,
            client_id=client_id,
            client_secret=client_secret,
        )

    def set_group_mapping(self, mapping: Dict[str, str], default_role: str = "viewer") -> None:
        """Configure group → role mapping."""
        self._group_mapper = GroupRoleMapper(mapping, default_role)

    # -- SAML authentication ---------------------------------------------

    def authenticate_saml(
        self,
        provider_name: str,
        saml_response_xml: str,
    ) -> Tuple[SSOUser, SSOSession]:
        """Authenticate a user via SAML response.

        Returns
        -------
        (SSOUser, SSOSession)

        Raises
        ------
        SSOError
            If the provider is not registered or authentication fails.
        """
        provider = self._saml_providers.get(provider_name)
        if provider is None:
            raise SSOError(f"SAML provider '{provider_name}' not registered")

        response = provider.parse_response(saml_response_xml)
        assertion = response.primary_assertion
        if assertion is None:
            raise SSOError("SAML response has no assertion")

        if not provider.validate_assertion(assertion):
            raise SSOError("SAML assertion validation failed")

        # Extract user identity
        subject = assertion.subject
        if not subject:
            raise SSOError("SAML assertion has no subject (NameID)")

        email = assertion.get_attribute("email") or assertion.get_attribute(
            "urn:oid:0.9.2342.19200300.100.1.3"  # LDAP email OID
        ) or ""
        display_name = assertion.get_attribute("displayname") or assertion.get_attribute(
            "urn:oid:2.16.840.1.113730.3.1.241"  # LDAP displayName OID
        ) or assertion.get_attribute("cn") or ""
        groups = assertion.get_attributes("groups") or assertion.get_attributes(
            "urn:oid:1.3.6.1.4.1.5923.1.5.1.1"  # eduPersonmemberOf
        )

        # JIT provisioning
        user = self._provision_user(
            subject=subject,
            idp_name=provider_name,
            email=email,
            display_name=display_name,
            groups=groups,
        )

        # Create session
        session = self._create_session(user, provider_name)

        return user, session

    # -- OIDC authentication ---------------------------------------------

    def authenticate_oidc(
        self,
        provider_name: str,
        id_token: str,
    ) -> Tuple[SSOUser, SSOSession]:
        """Authenticate a user via OIDC ID token.

        Returns
        -------
        (SSOUser, SSOSession)

        Raises
        ------
        SSOError
        """
        provider = self._oidc_providers.get(provider_name)
        if provider is None:
            raise SSOError(f"OIDC provider '{provider_name}' not registered")

        claims = provider.parse_id_token(id_token)

        # JIT provisioning
        username = claims.preferred_username or claims.email or claims.sub
        user = self._provision_user(
            subject=claims.sub,
            idp_name=provider_name,
            email=claims.email,
            display_name=claims.name or username,
            groups=claims.groups,
            username_override=username,
        )

        session = self._create_session(user, provider_name)
        return user, session

    # -- JIT provisioning -------------------------------------------------

    def _provision_user(
        self,
        subject: str,
        idp_name: str,
        email: str = "",
        display_name: str = "",
        groups: Optional[List[str]] = None,
        username_override: str = "",
    ) -> SSOUser:
        """Just-in-time provision a user on first SSO login.

        If the user already exists (matched by idp:subject), update
        their attributes.  Otherwise, create a new user.
        """
        groups = groups or []
        subject_key = f"{idp_name}:{subject}"

        existing_username = self._subject_index.get(subject_key)
        if existing_username and existing_username in self._users:
            # Update existing user
            user = self._users[existing_username]
            user.email = email or user.email
            user.display_name = display_name or user.display_name
            user.groups = groups
            user.last_login = time.time()
            user.mapped_roles = self._group_mapper.map_groups(groups)
            return user

        # Create new user
        username = username_override or email or subject
        # Ensure unique username
        base_username = username
        suffix = 1
        while username in self._users:
            username = f"{base_username}_{suffix}"
            suffix += 1

        user = SSOUser(
            username=username,
            email=email,
            display_name=display_name or username,
            idp_subject=subject,
            idp_name=idp_name,
            groups=groups,
            mapped_roles=self._group_mapper.map_groups(groups),
            last_login=time.time(),
        )
        self._users[username] = user
        self._subject_index[subject_key] = username
        return user

    # -- Session management -----------------------------------------------

    def _create_session(self, user: SSOUser, idp_name: str) -> SSOSession:
        """Create a new SSO session for a user."""
        now = time.time()
        session = SSOSession(
            session_id=self._generate_session_id(),
            username=user.username,
            idp_name=idp_name,
            created_at=now,
            expires_at=now + self._session_timeout,
            idle_timeout=self._idle_timeout,
            last_activity=now,
        )
        self._sessions[session.session_id] = session
        return session

    def validate_session(self, session_id: str) -> SSOSession:
        """Validate an SSO session.

        Raises
        ------
        SSOSessionExpired
            If the session is expired or not found.
        """
        session = self._sessions.get(session_id)
        if session is None:
            raise SSOSessionExpired("session not found")
        if session.is_expired:
            del self._sessions[session_id]
            raise SSOSessionExpired("session expired")
        session.touch()
        return session

    def logout(self, session_id: str) -> bool:
        """Logout (destroy) a session. Returns True if session existed."""
        return self._sessions.pop(session_id, None) is not None

    def list_active_sessions(self) -> List[SSOSession]:
        """List all active (non-expired) sessions."""
        now = time.time()
        active = []
        expired = []
        for sid, s in self._sessions.items():
            if s.is_expired:
                expired.append(sid)
            else:
                active.append(s)
        for sid in expired:
            del self._sessions[sid]
        return active

    # -- User management --------------------------------------------------

    def get_user(self, username: str) -> Optional[SSOUser]:
        """Get a provisioned user by username."""
        return self._users.get(username)

    def list_users(self) -> List[SSOUser]:
        """List all provisioned users."""
        return list(self._users.values())

    def deactivate_user(self, username: str) -> bool:
        """Deactivate a user (prevent future logins)."""
        user = self._users.get(username)
        if user is None:
            return False
        user.is_active = False
        # Destroy their sessions
        to_remove = [
            sid for sid, s in self._sessions.items() if s.username == username
        ]
        for sid in to_remove:
            del self._sessions[sid]
        return True

    # -- Internal helpers -------------------------------------------------

    def _generate_session_id(self) -> str:
        return "sso_" + secrets.token_hex(24)


# ---------------------------------------------------------------------------
# Test helpers — build synthetic SAML/OIDC tokens
# ---------------------------------------------------------------------------

def build_saml_response_xml(
    issuer: str,
    subject: str,
    audience: str,
    attributes: Dict[str, List[str]],
    signing_key: bytes,
    not_before: Optional[float] = None,
    not_on_or_after: Optional[float] = None,
    response_id: str = "",
    assertion_id: str = "",
) -> str:
    """Build a signed SAML Response XML string (for testing).

    This creates a valid SAML 2.0 Response with one Assertion,
    signed using the simplified HMAC approach.
    """
    now = time.time()
    nb = not_before if not_before is not None else now - 60
    noa = not_on_or_after if not_on_or_after is not None else now + 3600
    rsp_id = response_id or "rsp_" + secrets.token_hex(8)
    asr_id = assertion_id or "asr_" + secrets.token_hex(8)

    from datetime import datetime, timezone
    def fmt(t: float) -> str:
        return datetime.fromtimestamp(t, tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

    # Build attribute XML
    attr_xml = ""
    for name, values in attributes.items():
        vals_xml = "".join(
            f'<saml:AttributeValue>{v}</saml:AttributeValue>' for v in values
        )
        attr_xml += f'<saml:Attribute Name="{name}">{vals_xml}</saml:Attribute>'

    # Sign the assertion
    sig = hmac.new(signing_key, asr_id.encode(), hashlib.sha256).hexdigest()
    rsp_sig = hmac.new(signing_key, rsp_id.encode(), hashlib.sha256).hexdigest()

    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" ID="{rsp_id}" Version="2.0" IssueInstant="{fmt(now)}" Destination="https://petroppo.local/sso/acs">
  <saml:Issuer>{issuer}</saml:Issuer>
  <ds:Signature>
    <ds:SignatureValue>{rsp_sig}</ds:SignatureValue>
  </ds:Signature>
  <samlp:Status>
    <samlp:StatusCode Value="urn:oasis:names:tc:SAML:2.0:status:Success"/>
  </samlp:Status>
  <saml:Assertion ID="{asr_id}" Version="2.0" IssueInstant="{fmt(now)}">
    <saml:Issuer>{issuer}</saml:Issuer>
    <ds:Signature>
      <ds:SignatureValue>{sig}</ds:SignatureValue>
    </ds:Signature>
    <saml:Subject>
      <saml:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress">{subject}</saml:NameID>
    </saml:Subject>
    <saml:Conditions NotBefore="{fmt(nb)}" NotOnOrAfter="{fmt(noa)}">
      <saml:AudienceRestriction>
        <saml:Audience>{audience}</saml:Audience>
      </saml:AudienceRestriction>
    </saml:Conditions>
    <saml:AuthnStatement AuthnInstant="{fmt(now)}" SessionIndex="{asr_id}">
      <saml:AuthnContext>
        <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport</saml:AuthnContextClassRef>
      </saml:AuthnContext>
    </saml:AuthnStatement>
    <saml:AttributeStatement>
      {attr_xml}
    </saml:AttributeStatement>
  </saml:Assertion>
</samlp:Response>"""
    return xml


def build_oidc_id_token(
    issuer: str,
    sub: str,
    aud: str,
    secret: bytes,
    email: str = "",
    name: str = "",
    preferred_username: str = "",
    groups: Optional[List[str]] = None,
    exp_delta: float = 3600,
    nonce: str = "",
) -> str:
    """Build a signed OIDC ID token (JWT) for testing."""
    now = int(time.time())
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "iss": issuer,
        "sub": sub,
        "aud": aud,
        "exp": now + int(exp_delta),
        "iat": now,
        "email": email,
        "name": name,
        "preferred_username": preferred_username,
        "groups": groups or [],
    }
    if nonce:
        payload["nonce"] = nonce

    header_b64 = OIDCProvider._b64url_encode(
        json.dumps(header, separators=(",", ":")).encode()
    ).decode("ascii")
    payload_b64 = OIDCProvider._b64url_encode(
        json.dumps(payload, separators=(",", ":")).encode()
    ).decode("ascii")

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    sig = hmac.new(secret, signing_input, hashlib.sha256).digest()
    sig_b64 = OIDCProvider._b64url_encode(sig).decode("ascii")

    return f"{header_b64}.{payload_b64}.{sig_b64}"
