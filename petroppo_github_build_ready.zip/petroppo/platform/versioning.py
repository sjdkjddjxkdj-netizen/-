"""petroppo V37 -- Content-addressed project versioning.

A reservoir model is not a single file -- it is a *directed acyclic graph*
of derived products: seismic -> impedance inversion -> rock-physics ->
reservoir model -> simulation deck -> history match -> forecast.  When
an engineer asks "why did the forecast change?", the answer requires
tracing every input and transformation back to its exact content hash.

This module provides **content-addressed versioning** (git-like) for
petroppo projects:

* every artifact (array, deck, report, parameter set) is stored under
  its SHA-256 content hash -- identical content deduplicates and any
  change produces a new hash,
* a *commit* is a snapshot of the project tree (a mapping of logical
  paths to content hashes) plus provenance metadata,
* commits form a DAG via parent pointers, enabling branching and merge,
* :meth:`diff` shows which artifacts changed between two commits,
* :meth:`merge` combines two branches with 3-way merge semantics,
* the object store is on-disk (so it survives crashes) and append-only
  (so old commits are never lost -- critical for audit trails).

This is the backbone of V37's reproducible-pipeline guarantee: a
``commit`` fully determines the set of inputs, so re-running a pipeline
from a commit produces byte-identical output.

Design
------

* :class:`ObjectStore` -- content-addressed blob store (SHA-256 keys,
  zlib-compressed values, on-disk layout ``ab/cdef...`` to avoid huge
  directories).
* :class:`Tree` -- an immutable mapping of ``path -> hash`` (the
  project snapshot).
* :class:`Commit` -- a tree hash + parent commit hashes + author +
  timestamp + message.  Commits are themselves content-addressed.
* :class:`VersionedProject` -- the user-facing API: ``commit``,
  ``checkout``, ``branch``, ``merge``, ``diff``, ``log``.
* :func:`reproducibility_report` -- verifies that two commits produce
  identical artifact trees (the core reproducibility check).

References
----------
* Git's object model (Linus Torvalds, 2005).
* Wilson, G. et al. (2017). *Good Enough Practices for Scientific
  Computing*, PLOS Computational Biology.
* Stodden, V. et al. (2016). *Enhancing reproducibility for
  computational methods*, Science.
"""

from __future__ import annotations

import os
import io
import json
import time
import zlib
import hashlib
import tempfile
import shutil
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import (Any, Callable, Dict, List, Optional, Tuple, Set,
                    Iterator, Union)

__all__ = [
    "ObjectStore",
    "Tree",
    "Commit",
    "VersionedProject",
    "DiffEntry",
    "MergeResult",
    "reproducibility_report",
    "sha256_hex",
]


# ---------------------------------------------------------------------------
# Hashing helpers
# ---------------------------------------------------------------------------

def sha256_hex(data: bytes) -> str:
    """Return the hex SHA-256 digest of ``data``."""
    return hashlib.sha256(data).hexdigest()


def _hash_array(arr) -> str:
    """Content hash of a numpy array (dtype + shape + bytes)."""
    import numpy as np
    h = hashlib.sha256()
    h.update(str(arr.dtype).encode())
    h.update(str(arr.shape).encode())
    h.update(np.ascontiguousarray(arr).tobytes())
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Object store
# ---------------------------------------------------------------------------

class ObjectStore:
    """Content-addressed blob store.

    Blobs are stored on disk under ``<dir>/<ab>/<cdef...>`` (first two
    hex chars as a sub-directory), zlib-compressed.  The store is
    append-only: writing an existing hash is a no-op.

    Parameters
    ----------
    directory : str
        Root directory for the object store.
    compress : bool
        If True (default), zlib-compress blobs.
    """

    def __init__(self, directory: str, compress: bool = True):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.compress = compress

    def _path(self, h: str) -> Path:
        return self.directory / h[:2] / h[2:]

    def put_bytes(self, data: bytes) -> str:
        """Store ``data``; return its SHA-256 hash."""
        h = sha256_hex(data)
        p = self._path(h)
        if p.exists():
            return h  # dedup
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = zlib.compress(data) if self.compress else data
        # Atomic write.
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(payload)
        tmp.rename(p)
        return h

    def put_text(self, text: str) -> str:
        return self.put_bytes(text.encode("utf-8"))

    def put_json(self, obj: Any) -> str:
        return self.put_text(json.dumps(obj, sort_keys=True, indent=2,
                                        default=str))

    def put_array(self, arr) -> str:
        """Store a numpy array; return its content hash."""
        h = _hash_array(arr)
        p = self._path(h)
        if p.exists():
            return h
        import numpy as np
        buf = io.BytesIO()
        np.save(buf, np.ascontiguousarray(arr))
        return self.put_bytes(buf.getvalue())

    def get_bytes(self, h: str) -> bytes:
        p = self._path(h)
        if not p.exists():
            raise KeyError(f"object {h} not in store")
        data = p.read_bytes()
        if self.compress:
            try:
                data = zlib.decompress(data)
            except zlib.error:
                pass  # not compressed (legacy)
        return data

    def get_text(self, h: str) -> str:
        return self.get_bytes(h).decode("utf-8")

    def get_json(self, h: str) -> Any:
        return json.loads(self.get_text(h))

    def get_array(self, h: str):
        import numpy as np
        data = self.get_bytes(h)
        return np.load(io.BytesIO(data))

    def exists(self, h: str) -> bool:
        return self._path(h).exists()

    def count(self) -> int:
        n = 0
        for _ in self.directory.rglob("*"):
            if _.is_file() and not _.name.endswith(".tmp"):
                n += 1
        return n


# ---------------------------------------------------------------------------
# Tree and Commit
# ---------------------------------------------------------------------------

@dataclass
class Tree:
    """An immutable project snapshot: mapping of path -> content hash."""
    entries: Dict[str, str] = field(default_factory=dict)

    def hash(self) -> str:
        """Content hash of this tree (deterministic, sorted keys)."""
        payload = json.dumps(self.entries, sort_keys=True)
        return sha256_hex(payload.encode("utf-8"))

    def paths(self) -> List[str]:
        return sorted(self.entries.keys())

    def add(self, path: str, content_hash: str) -> "Tree":
        """Return a new Tree with ``path`` added/updated (immutable)."""
        new_entries = dict(self.entries)
        new_entries[path] = content_hash
        return Tree(new_entries)

    def remove(self, path: str) -> "Tree":
        new_entries = dict(self.entries)
        new_entries.pop(path, None)
        return Tree(new_entries)


@dataclass
class Commit:
    """A versioned snapshot of the project tree."""
    hash: str
    tree_hash: str
    parents: List[str]
    author: str
    timestamp: float
    message: str
    branch: str = "main"

    def to_dict(self) -> dict:
        return {
            "tree_hash": self.tree_hash,
            "parents": self.parents,
            "author": self.author,
            "timestamp": self.timestamp,
            "message": self.message,
            "branch": self.branch,
        }

    @staticmethod
    def from_dict(h: str, d: dict) -> "Commit":
        return Commit(
            hash=h, tree_hash=d["tree_hash"], parents=d.get("parents", []),
            author=d.get("author", ""), timestamp=d.get("timestamp", 0.0),
            message=d.get("message", ""), branch=d.get("branch", "main"),
        )


# ---------------------------------------------------------------------------
# Diff and merge
# ---------------------------------------------------------------------------

@dataclass
class DiffEntry:
    """One changed path between two trees."""
    path: str
    kind: str           # "added", "removed", "modified"
    old_hash: Optional[str] = None
    new_hash: Optional[str] = None


def diff_trees(old: Tree, new: Tree) -> List[DiffEntry]:
    """Compute the list of changed paths between two trees."""
    entries: List[DiffEntry] = []
    old_keys = set(old.entries)
    new_keys = set(new.entries)
    for p in sorted(old_keys | new_keys):
        in_old = p in old_keys
        in_new = p in new_keys
        if in_old and not in_new:
            entries.append(DiffEntry(p, "removed", old.entries[p], None))
        elif in_new and not in_old:
            entries.append(DiffEntry(p, "added", None, new.entries[p]))
        elif old.entries[p] != new.entries[p]:
            entries.append(DiffEntry(p, "modified",
                                     old.entries[p], new.entries[p]))
    return entries


@dataclass
class MergeResult:
    """Outcome of a 3-way merge."""
    success: bool
    merged_tree: Optional[Tree] = None
    conflicts: List[str] = field(default_factory=list)
    base_commit: Optional[str] = None
    our_commit: Optional[str] = None
    their_commit: Optional[str] = None


# ---------------------------------------------------------------------------
# Versioned project
# ---------------------------------------------------------------------------

class VersionedProject:
    """A content-addressed, branchable project with commit history.

    Parameters
    ----------
    directory : str
        Root directory; an ``objects/`` subdir holds the blob store and
        a ``refs/`` subdir holds branch pointers.
    author : str
        Default commit author.
    """

    COMMITS_DIR = "commits"
    OBJECTS_DIR = "objects"
    REFS_DIR = "refs"

    def __init__(self, directory: str, author: str = "system"):
        self.root = Path(directory)
        self.root.mkdir(parents=True, exist_ok=True)
        self.objects = ObjectStore(str(self.root / self.OBJECTS_DIR))
        self.commits_dir = self.root / self.COMMITS_DIR
        self.commits_dir.mkdir(exist_ok=True)
        self.refs_dir = self.root / self.REFS_DIR
        self.refs_dir.mkdir(exist_ok=True)
        self.author = author
        # Ensure 'main' branch exists.
        if not (self.refs_dir / "main").exists():
            self._set_ref("main", None)

    # -- refs --
    def _ref_path(self, branch: str) -> Path:
        return self.refs_dir / branch

    def _set_ref(self, branch: str, commit_hash: Optional[str]):
        p = self._ref_path(branch)
        if commit_hash is None:
            p.write_text("")
        else:
            p.write_text(commit_hash)

    def _get_ref(self, branch: str) -> Optional[str]:
        p = self._ref_path(branch)
        if not p.exists():
            return None
        h = p.read_text().strip()
        return h if h else None

    def branches(self) -> List[str]:
        return sorted([p.name for p in self.refs_dir.iterdir() if p.is_file()])

    def create_branch(self, name: str, from_branch: str = "main") -> str:
        """Create a new branch pointing at the same commit as ``from_branch``."""
        h = self._get_ref(from_branch)
        self._set_ref(name, h)
        return name

    def head(self, branch: str = "main") -> Optional[Commit]:
        """Return the latest commit on ``branch`` (or None if empty)."""
        h = self._get_ref(branch)
        if h is None:
            return None
        return self.get_commit(h)

    # -- commit storage --
    def _commit_path(self, h: str) -> Path:
        return self.commits_dir / h[:2] / h[2:]

    def _store_commit(self, c: Commit):
        p = self._commit_path(c.hash)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(c.to_dict(), indent=2))

    def get_commit(self, h: str) -> Commit:
        p = self._commit_path(h)
        if not p.exists():
            raise KeyError(f"commit {h} not found")
        return Commit.from_dict(h, json.loads(p.read_text()))

    def get_tree(self, tree_hash: str) -> Tree:
        return Tree(self.objects.get_json(tree_hash))

    # -- committing --
    def commit(self, tree: Tree, message: str,
               branch: str = "main",
               parents: Optional[List[str]] = None,
               author: Optional[str] = None) -> Commit:
        """Record a new commit on ``branch``.

        Parameters
        ----------
        tree : Tree
            The project snapshot to commit.
        message : str
            Commit message.
        branch : str
            Branch to commit onto (created if it doesn't exist).
        parents : list, optional
            Parent commit hashes.  Defaults to the current branch head.
        author : str, optional
            Override the default author.
        """
        # Store the tree.
        tree_hash = self.objects.put_json(tree.entries)
        if parents is None:
            head = self._get_ref(branch)
            parents = [head] if head else []
        commit_data = {
            "tree_hash": tree_hash,
            "parents": parents,
            "author": author or self.author,
            "timestamp": time.time(),
            "message": message,
            "branch": branch,
        }
        chash = sha256_hex(json.dumps(commit_data, sort_keys=True,
                                       default=str).encode("utf-8"))
        c = Commit(hash=chash, **commit_data)
        self._store_commit(c)
        self._set_ref(branch, chash)
        return c

    def commit_artifacts(self, artifacts: Dict[str, Any],
                         message: str,
                         branch: str = "main",
                         author: Optional[str] = None) -> Commit:
        """Convenience: commit a dict of ``path -> content`` directly.

        Content can be: ``bytes``, ``str``, ``numpy array``, or a
        JSON-serializable object.
        """
        tree = Tree()
        for path, content in artifacts.items():
            if isinstance(content, bytes):
                h = self.objects.put_bytes(content)
            elif isinstance(content, str):
                h = self.objects.put_text(content)
            else:
                # Try numpy array first, then JSON.
                try:
                    import numpy as np
                    if isinstance(content, np.ndarray):
                        h = self.objects.put_array(content)
                    else:
                        h = self.objects.put_json(content)
                except ImportError:
                    h = self.objects.put_json(content)
            tree = tree.add(path, h)
        return self.commit(tree, message, branch=branch, author=author)

    # -- checkout --
    def checkout(self, commit_hash: str) -> Dict[str, Any]:
        """Return the full tree content of a commit as ``path -> bytes``."""
        c = self.get_commit(commit_hash)
        tree = self.get_tree(c.tree_hash)
        result: Dict[str, Any] = {}
        for path, h in tree.entries.items():
            result[path] = self.objects.get_bytes(h)
        return result

    def checkout_text(self, commit_hash: str) -> Dict[str, str]:
        """Return the tree content as ``path -> str``."""
        c = self.get_commit(commit_hash)
        tree = self.get_tree(c.tree_hash)
        return {p: self.objects.get_text(h) for p, h in tree.entries.items()}

    # -- diff --
    def diff(self, old_commit: str, new_commit: str) -> List[DiffEntry]:
        """List changed paths between two commits."""
        c_old = self.get_commit(old_commit)
        c_new = self.get_commit(new_commit)
        t_old = self.get_tree(c_old.tree_hash)
        t_new = self.get_tree(c_new.tree_hash)
        return diff_trees(t_old, t_new)

    # -- log --
    def log(self, branch: str = "main",
            max_count: int = 100) -> List[Commit]:
        """Return commit history (newest first) on ``branch``."""
        result: List[Commit] = []
        h = self._get_ref(branch)
        seen: Set[str] = set()
        while h and len(result) < max_count and h not in seen:
            seen.add(h)
            c = self.get_commit(h)
            result.append(c)
            h = c.parents[0] if c.parents else None
        return result

    # -- merge --
    def merge(self, our_branch: str, their_branch: str) -> MergeResult:
        """3-way merge of ``their_branch`` into ``our_branch``.

        Finds the common ancestor (merge base), then for each path:
        - if only one side changed, take that side,
        - if both sides changed identically, take either,
        - if both sides changed differently, report a conflict.
        """
        our_head = self._get_ref(our_branch)
        their_head = self._get_ref(their_branch)
        if their_head is None:
            return MergeResult(True, None, [], None, our_head, their_head)
        if our_head is None:
            # Fast-forward: our branch is empty, take theirs.
            self._set_ref(our_branch, their_head)
            return MergeResult(True, None, [], None, our_head, their_head)
        if our_head == their_head:
            return MergeResult(True, None, [], our_head, our_head, their_head)

        base = self._merge_base(our_head, their_head)
        c_our = self.get_commit(our_head)
        c_their = self.get_commit(their_head)
        t_base = self.get_tree(self.get_commit(base).tree_hash) if base else Tree()
        t_our = self.get_tree(c_our.tree_hash)
        t_their = self.get_tree(c_their.tree_hash)

        all_paths = set(t_base.entries) | set(t_our.entries) | set(t_their.entries)
        merged = Tree()
        conflicts: List[str] = []
        for p in sorted(all_paths):
            b = t_base.entries.get(p)
            o = t_our.entries.get(p)
            t = t_their.entries.get(p)
            if o == t:
                # Both sides agree (including both None).
                if o is not None:
                    merged = merged.add(p, o)
            elif o == b:
                # Our side unchanged, take theirs.
                if t is not None:
                    merged = merged.add(p, t)
            elif t == b:
                # Their side unchanged, take ours.
                if o is not None:
                    merged = merged.add(p, o)
            else:
                # Both changed differently -> conflict.
                conflicts.append(p)
                # Take ours as the working version (caller resolves).
                if o is not None:
                    merged = merged.add(p, o)

        if conflicts:
            return MergeResult(False, merged, conflicts, base,
                               our_head, their_head)
        # No conflicts: create a merge commit.
        merge_c = self.commit(
            merged, f"Merge {their_branch} into {our_branch}",
            branch=our_branch, parents=[our_head, their_head],
        )
        return MergeResult(True, merged, [], base, our_head, their_head)

    def _merge_base(self, a: str, b: str) -> Optional[str]:
        """Find the common ancestor of commits a and b."""
        ancestors_a: Set[str] = set()
        stack = [a]
        while stack:
            h = stack.pop()
            if h in ancestors_a:
                continue
            ancestors_a.add(h)
            try:
                c = self.get_commit(h)
                stack.extend(c.parents)
            except KeyError:
                pass
        # BFS from b; first ancestor in ancestors_a is the merge base.
        from collections import deque
        queue = deque([b])
        visited: Set[str] = set()
        while queue:
            h = queue.popleft()
            if h in visited:
                continue
            visited.add(h)
            if h in ancestors_a:
                return h
            try:
                c = self.get_commit(h)
                queue.extend(c.parents)
            except KeyError:
                pass
        return None


# ---------------------------------------------------------------------------
# Reproducibility report
# ---------------------------------------------------------------------------

def reproducibility_report(project: VersionedProject,
                           commit_a: str,
                           commit_b: str) -> dict:
    """Verify that two commits have identical artifact trees.

    This is the core of the V37 ``industrial-reproducible-pipeline``
    benchmark: run the same pipeline twice from the same commit and
    assert the output trees are byte-identical (same content hashes).

    Returns
    -------
    dict with keys:
        identical : bool -- True if all artifact hashes match.
        n_artifacts : int -- number of artifacts compared.
        differing_paths : list -- paths whose hashes differ.
        commit_a, commit_b : the input commit hashes.
        tree_a, tree_b : the tree hashes.
    """
    c_a = project.get_commit(commit_a)
    c_b = project.get_commit(commit_b)
    t_a = project.get_tree(c_a.tree_hash)
    t_b = project.get_tree(c_b.tree_hash)
    all_paths = set(t_a.entries) | set(t_b.entries)
    differing: List[str] = []
    for p in sorted(all_paths):
        if t_a.entries.get(p) != t_b.entries.get(p):
            differing.append(p)
    return {
        "identical": len(differing) == 0,
        "n_artifacts": len(all_paths),
        "differing_paths": differing,
        "commit_a": commit_a,
        "commit_b": commit_b,
        "tree_a": c_a.tree_hash,
        "tree_b": c_b.tree_hash,
    }
