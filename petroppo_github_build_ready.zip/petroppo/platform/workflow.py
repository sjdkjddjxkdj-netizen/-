"""petroppo V29 -- Integrated subsurface workflow.

``petroppo.platform.workflow`` stitches the four discipline modules into a
single end-to-end pipeline:

    seismic  ->  geology  ->  reservoir model  ->  reservoir simulation

The pipeline is expressed as a small set of *stage* callables wrapped by an
orchestrating :class:`Workflow` object.  Each stage consumes the previous
stage's :class:`WorkflowState` and augments it, so the whole workflow is a
pure-Python data-transformation chain that can be inspected, re-run, and
unit-tested stage by stage.

Stages
------

1. :func:`seismic_stage`    -- build a synthetic seismic volume (impedance,
   reflectivity, convolutional seismogram) and extract a coherence
   attribute cube.
2. :func:`geology_stage`    -- build two horizon surfaces (top & base) from
   the seismic reflectors, define a fault plane, segment the area into fault
   blocks, and build a stratigraphic model.
3. :func:`reservoir_stage`  -- convert the structural model into a
   simulation grid (:func:`grid_from_horizons`), populate porosity &
   permeability by kriging well control points, set an initial pressure /
   contact, and assemble a :class:`RockProperties` + wells.
4. :func:`simulation_stage` -- build a :class:`SinglePhaseSimulator` from the
   reservoir stage output and run it on a schedule, returning the report
   and the final pressure / cumulative-production time series.

The whole thing can be run with :meth:`Workflow.run`, which returns a
:class:`WorkflowResult` containing every intermediate artefact so the user
can trace the data flow discipline by discipline -- exactly what a Petrel
"workflow" panel does, but in open, scriptable Python.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from petroppo.physics.seismic import seismogram, attributes
from petroppo.physics.geology import horizons, faults, stratigraphy
from petroppo.physics.geology.property_modeling import ordinary_kriging
from petroppo.physics.reservoir import grid as grid_mod
from petroppo.physics.reservoir.grid import ReservoirGrid
from petroppo.physics.reservoir.rock import RockProperties
from petroppo.physics.reservoir.pvt import WaterFluid
from petroppo.physics.reservoir.wells import (
    ProducerWell, InjectorWell, peaceman_well_index,
)
from petroppo.physics.reservoir.single_phase import SinglePhaseSimulator
from petroppo.physics.reservoir.structural_grid import grid_from_horizons

__all__ = [
    "WorkflowState",
    "WorkflowResult",
    "seismic_stage",
    "geology_stage",
    "reservoir_stage",
    "simulation_stage",
    "Workflow",
    "run_full_workflow",
]


# =========================================================================== #
# Shared state carried between stages
# =========================================================================== #

@dataclass
class WorkflowState:
    """Mutable bag passed through every stage of the workflow."""

    # --- inputs (set by user / seismic stage) ---
    nx: int = 20
    ny: int = 20
    nz: int = 5
    dx: float = 100.0
    dy: float = 100.0
    dz: float = 10.0
    dt: float = 0.004                 # seismic sample interval (s)
    wavelet_freq: float = 30.0        # Hz
    x0: float = 0.0
    y0: float = 0.0

    # --- seismic artefacts ---
    velocity: Optional[np.ndarray] = None   # (nz,) layer velocities
    density: Optional[np.ndarray] = None    # (nz,) layer densities
    impedance: Optional[np.ndarray] = None
    reflectivity: Optional[np.ndarray] = None
    seismic_volume: Optional[np.ndarray] = None  # (ny, nx, n_samples)
    coherence: Optional[np.ndarray] = None

    # --- geology artefacts ---
    top_horizon: Optional[object] = None     # HorizonSurface
    base_horizon: Optional[object] = None
    fault: Optional[faults.FaultPlane] = None
    block_map: Optional[np.ndarray] = None   # (ny, nx) block ids
    strata: Optional[stratigraphy.StrataModel] = None

    # --- reservoir artefacts ---
    sim_grid: Optional[ReservoirGrid] = None
    porosity: Optional[np.ndarray] = None    # (nx, ny, nz)
    permeability: Optional[np.ndarray] = None
    initial_pressure: float = 1.0e7
    rock: Optional[RockProperties] = None
    wells: list = field(default_factory=list)
    fluid: Optional[WaterFluid] = None

    # --- simulation artefacts ---
    simulator: Optional[SinglePhaseSimulator] = None
    times: Optional[np.ndarray] = None
    pressure_history: Optional[np.ndarray] = None
    pressure_min: Optional[np.ndarray] = None
    pressure_max: Optional[np.ndarray] = None
    cumulative_production: Optional[np.ndarray] = None
    report: Optional[object] = None


@dataclass
class WorkflowResult:
    """Final result of running the whole workflow."""

    state: WorkflowState
    stage_timings: dict = field(default_factory=dict)
    errors: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


# =========================================================================== #
# Stage 1 -- Seismic
# =========================================================================== #

def seismic_stage(state: WorkflowState) -> WorkflowState:
    """Build a synthetic post-stack seismic volume + coherence cube.

    The earth is a 1-D layered model (one layer per K-cell) with a mild
    lateral velocity perturbation so that the reflectors are gently dipping
    and the volume is realistic enough to drive the geology stage.  The
    reflectivity is computed from the impedance contrast between adjacent
    layers, convolved with a Ricker wavelet, and a C1 coherence cube is
    extracted.
    """
    nz = state.nz
    # layer velocities & densities increasing with depth
    base_v = np.linspace(2000.0, 3500.0, nz)
    base_d = np.linspace(2100.0, 2450.0, nz)
    state.velocity = base_v
    state.density = base_d
    state.impedance = seismogram.compute_impedance(base_v, base_d)
    # reflectivity is (nz-1,) interfaces; pad to nz for convenience
    rc_1d = seismogram.reflection_coefficients(state.impedance)
    rc = np.append(rc_1d, 0.0)

    # build a 2-D reflectivity panel with a gentle dip using a phase ramp
    nx, ny = state.nx, state.ny
    yy, xx = np.mgrid[0:ny, 0:nx]
    dip_shift = 0.25 * np.sin(2 * np.pi * xx / nx)  # in samples
    n_samp = nz
    # place each interface at its k index + dip shift (nearest sample)
    refl = np.zeros((ny, nx, n_samp), dtype=float)
    for k in range(nz - 1):
        # the k-th interface lives near sample k
        samp = np.clip(np.round(k + dip_shift).astype(int), 0, n_samp - 1)
        for j in range(ny):
            for i in range(nx):
                refl[j, i, samp[j, i]] = rc[k]

    # convolve each trace with a Ricker wavelet (synthetic_seismogram handles it)
    vol = np.zeros_like(refl)
    for j in range(ny):
        for i in range(nx):
            seis = seismogram.synthetic_seismogram(
                refl[j, i], dt=state.dt, wavelet_freq=state.wavelet_freq)
            vol[j, i] = seis.data
    state.seismic_volume = vol.astype(np.float32)

    # coherence cube (C1) -- cheap because the volume is small
    try:
        coh = attributes.coherence_c1(vol, window=(3, 3, 5))
        state.coherence = coh
    except Exception:
        state.coherence = np.ones_like(vol)
    return state


# =========================================================================== #
# Stage 2 -- Geology
# =========================================================================== #

def geology_stage(state: WorkflowState) -> WorkflowState:
    """Build two horizons + a fault + a stratigraphic model from the seismic.

    The top and base horizons are picked from the strongest reflectors in
    the seismic volume (peak amplitude at the first and last interfaces).
    A single normal fault is placed across the model, the map is segmented
    into fault blocks, and a :class:`StrataModel` is assembled from the two
    horizons.
    """
    nx, ny = state.nx, state.ny
    xs = state.x0 + state.dx * np.arange(nx)
    ys = state.y0 + state.dy * np.arange(ny)

    # pick top horizon = depth of the shallowest strong reflector
    vol = state.seismic_volume
    # envelope amplitude per (j,i) trace -> pick the deepest + shallowest peak
    env = np.abs(vol)
    top_idx = np.argmax(env[:, :, : max(2, state.nz // 2)], axis=2)
    base_idx = (state.nz - 1) - np.argmax(
        env[:, :, state.nz // 2:][:, :, ::-1], axis=2)
    # convert sample index -> depth (m) using a nominal avg velocity
    avg_v = float(np.mean(state.velocity))
    top_z = top_idx * state.dt * avg_v + 1000.0          # anchor at 1000 m
    base_z = base_idx * state.dt * avg_v + 1100.0
    # ensure monotonic (base deeper than top)
    base_z = np.maximum(base_z, top_z + 5.0 * state.dz)

    state.top_horizon = horizons.make_horizon_surface(xs, ys, top_z)
    state.base_horizon = horizons.make_horizon_surface(xs, ys, base_z)

    # one normal fault striking N (along y), dipping 60 deg, through the centre
    cx = state.x0 + state.dx * (nx / 2.0)
    cy = state.y0 + state.dy * (ny / 2.0)
    state.fault = faults.FaultPlane(
        strike=0.5 * np.pi, dip=np.radians(60.0),
        x0=cx, y0=cy, z0=1050.0)
    grid_extent = [state.x0, state.x0 + state.dx * nx,
                   state.y0, state.y0 + state.dy * ny]
    state.block_map = faults.segment_blocks(grid_extent, nx, ny, [state.fault])

    state.strata = stratigraphy.build_strata(
        [state.top_horizon, state.base_horizon], names=["top", "base"])
    return state


# =========================================================================== #
# Stage 3 -- Reservoir model
# =========================================================================== #

def reservoir_stage(state: WorkflowState,
                    well_points: Optional[np.ndarray] = None,
                    well_poro: Optional[np.ndarray] = None,
                    well_perm: Optional[np.ndarray] = None,
                    initial_pressure: float = 1.0e7) -> WorkflowState:
    """Convert the geological model into a simulation-ready reservoir model.

    The structural horizons are turned into a pillar simulation grid via
    :func:`grid_from_horizons`.  Porosity and permeability are populated by
    ordinary kriging of well control points onto the grid centroids, then
    tiled across all K-layers.  A single producer and injector are placed
    on opposite sides of the fault.
    """
    nx, ny, nz = state.nx, state.ny, state.nz
    state.initial_pressure = initial_pressure

    # --- structural -> simulation grid ---
    top_z = state.top_horizon.z        # (ny, nx)
    base_z = state.base_horizon.z
    grid = grid_from_horizons(
        top_horizon=top_z, base_horizon=base_z,
        nx=nx, ny=ny, nz=nz,
        x0=state.x0, y0=state.y0,
        dx=state.dx, dy=state.dy,
    )
    state.sim_grid = grid

    # --- property modelling (kriging) ---
    if well_points is None:
        # default: a few synthetic wells spread across the area
        well_points = np.array([
            [state.x0 + state.dx * 5, state.y0 + state.dy * 5],
            [state.x0 + state.dx * 15, state.y0 + state.dy * 10],
            [state.x0 + state.dx * 8, state.y0 + state.dy * 15],
        ])
    if well_poro is None:
        well_poro = np.array([0.22, 0.18, 0.25])
    if well_perm is None:
        well_perm = np.array([120.0, 80.0, 200.0])

    centroids = state.sim_grid.cell_centres()  # (nx, ny, nz, 3)
    # kriging is 2-D (areal) -- use top-layer centroids as the grid
    top_centroids = centroids[:, :, 0, :2].reshape(-1, 2)
    # fix a deterministic variogram
    poro_model = "spherical"
    poro_params = {"range": state.dx * 8.0, "sill": float(np.var(well_poro) or 0.01),
                   "nugget": 1e-4}
    perm_model = "spherical"
    perm_params = {"range": state.dx * 8.0, "sill": float(np.var(well_perm) or 100.0),
                   "nugget": 1.0}

    poro_res = ordinary_kriging(well_points, well_poro, top_centroids,
                                poro_model, poro_params, max_neighbours=8)
    perm_res = ordinary_kriging(well_points, well_perm, top_centroids,
                                perm_model, perm_params, max_neighbours=8)
    poro_areal = poro_res.estimate.reshape(nx, ny)
    perm_areal = perm_res.estimate.reshape(nx, ny)
    # clip to physically reasonable ranges and tile over K
    poro_areal = np.clip(poro_areal, 0.05, 0.45)
    perm_areal_mD = np.clip(perm_areal, 1.0, 2000.0)
    # The simulator + Peaceman WI expect permeability in m^2 (SI).
    # 1 mD = 9.869233e-16 m^2.  Store both: mD for reporting, m^2 for physics.
    MD_TO_M2 = 9.869233e-16
    perm_areal_m2 = perm_areal_mD * MD_TO_M2
    state.porosity = np.repeat(poro_areal[:, :, None], nz, axis=2)
    state.permeability = np.repeat(perm_areal_m2[:, :, None], nz, axis=2)  # m^2

    state.rock = RockProperties(
        porosity=state.porosity, permeability=state.permeability)

    # --- wells: producer on one side, injector on the other ---
    dx_cell = state.dx
    dy_cell = state.dy
    dz_cell = state.dz
    prod = ProducerWell(name="P1", control="bhp",
                        target=initial_pressure * 0.85, phase="oil")
    inj = InjectorWell(name="I1", control="bhp",
                       target=initial_pressure * 1.15, phase="water")
    prod_i, prod_j = nx - 3, ny - 3
    inj_i, inj_j = 2, 2
    # permeability is now in m^2 (SI) -- pass directly to Peaceman WI
    prod_kperm = float(state.permeability[prod_i, prod_j, 0])
    inj_kperm = float(state.permeability[inj_i, inj_j, 0])
    for k in range(nz):
        prod.add_perforation(prod_i, prod_j, k, prod_kperm,
                             dx_cell, dy_cell, dz_cell)
        inj.add_perforation(inj_i, inj_j, k, inj_kperm,
                            dx_cell, dy_cell, dz_cell)
    state.wells = [prod, inj]
    state.fluid = WaterFluid(
        ref_pressure=initial_pressure, ref_density=1000.0,
        ref_viscosity=0.5e-3, compressibility=4.5e-10)
    return state


# =========================================================================== #
# Stage 4 -- Simulation
# =========================================================================== #

def simulation_stage(state: WorkflowState,
                     total_time: float = 1.0e6,
                     dt: float = 1.0e5,
                     save_every: int = 1) -> WorkflowState:
    """Build and run the single-phase simulator on the reservoir model."""
    sim = SinglePhaseSimulator(
        grid=state.sim_grid,
        rock=state.rock,
        fluid=state.fluid,
        wells=state.wells,
        initial_pressure=state.initial_pressure,
    )
    state.simulator = sim
    report = sim.run(total_time=total_time, dt=dt, save_every=save_every)
    state.report = report

    # --- extract time series from the SimulationReport ---
    # The report stores a list of SimulationState objects, each carrying
    # .time, .pressure (cell array), .well_bhp (dict), .well_rates (dict).
    states = getattr(report, "states", None)
    if states:
        times = np.array([float(s.time) for s in states], dtype=float)
        pressures = np.array([np.asarray(s.pressure, float).mean()
                              for s in states], dtype=float)
        state.times = times
        state.pressure_history = pressures
        # also keep min / max cell pressure per step for diagnostics
        state.pressure_min = np.array(
            [np.asarray(s.pressure, float).min() for s in states], dtype=float)
        state.pressure_max = np.array(
            [np.asarray(s.pressure, float).max() for s in states], dtype=float)
        # cumulative production (reservoir m3) from the producer wells.
        # well_rates are in m3/s; integrate over the report dt_history.
        dt_hist = np.asarray(getattr(report, "dt_history", []), float)
        if dt_hist.size == 0:
            # fall back to uniform dt
            dt_hist = np.full(max(1, len(states) - 1), float(dt))
        # producer = negative rate; sum |rate| * dt over producers
        cum = np.zeros(len(states), dtype=float)
        running = 0.0
        for i, s in enumerate(states):
            if i > 0:
                step_dt = dt_hist[i - 1] if i - 1 < len(dt_hist) else float(dt)
                wr = getattr(s, "well_rates", None) or {}
                prod_rate = 0.0
                for w in state.wells:
                    name = getattr(w, "name", None)
                    if name and name in wr:
                        r = float(wr[name])
                        if r < 0:               # negative = production
                            prod_rate += -r
                running += prod_rate * step_dt
            cum[i] = running
        state.cumulative_production = cum
    else:
        # defensive fallback if the report API changes
        n_steps = max(1, int(round(total_time / dt)))
        state.times = np.linspace(dt, total_time, n_steps)
        state.pressure_history = np.full(state.times.shape,
                                         float(state.initial_pressure))
        state.pressure_min = state.pressure_history.copy()
        state.pressure_max = state.pressure_history.copy()
        state.cumulative_production = np.zeros(state.times.shape, dtype=float)
    return state


# =========================================================================== #
# Orchestrator
# =========================================================================== #

@dataclass
class Workflow:
    """Run the four-stage pipeline with optional overrides per stage."""

    seismic_fn: callable = staticmethod(seismic_stage)
    geology_fn: callable = staticmethod(geology_stage)
    reservoir_fn: callable = staticmethod(reservoir_stage)
    simulation_fn: callable = staticmethod(simulation_stage)

    def run(self, state: Optional[WorkflowState] = None,
            reservoir_kwargs: Optional[dict] = None,
            simulation_kwargs: Optional[dict] = None) -> WorkflowResult:
        """Execute the full pipeline; returns a :class:`WorkflowResult`.

        Parameters
        ----------
        state : WorkflowState, optional
            Initial state (a fresh one is created if omitted).
        reservoir_kwargs : dict, optional
            Extra keyword arguments forwarded to ``reservoir_fn``
            (e.g. ``well_points``, ``well_poro``, ``initial_pressure``).
        simulation_kwargs : dict, optional
            Extra keyword arguments forwarded to ``simulation_fn``
            (e.g. ``total_time``, ``dt``, ``save_every``).
        """
        import time as _time
        st = state if state is not None else WorkflowState()
        result = WorkflowResult(state=st)
        rkw = reservoir_kwargs or {}
        skw = simulation_kwargs or {}
        for label, fn, kw in [
            ("seismic", self.seismic_fn, {}),
            ("geology", self.geology_fn, {}),
            ("reservoir", self.reservoir_fn, rkw),
            ("simulation", self.simulation_fn, skw),
        ]:
            t0 = _time.perf_counter()
            try:
                if kw:
                    fn(st, **kw)
                else:
                    fn(st)
            except Exception as exc:  # noqa: BLE001
                result.errors.append(f"{label}: {exc!r}")
                result.stage_timings[label] = _time.perf_counter() - t0
                break
            result.stage_timings[label] = _time.perf_counter() - t0
        return result


# keyword arguments that belong to the simulation stage (not reservoir)
_SIM_KW = {"total_time", "dt", "save_every"}


def run_full_workflow(state: Optional[WorkflowState] = None,
                      **kwargs) -> WorkflowResult:
    """Convenience wrapper: run the default four-stage workflow.

    Any keyword arguments that are recognised by ``simulation_stage``
    (``total_time``, ``dt``, ``save_every``) are routed there; everything
    else is forwarded to ``reservoir_stage``.
    """
    sim_kw = {k: kwargs.pop(k) for k in list(kwargs) if k in _SIM_KW}
    res_kw = kwargs
    return Workflow().run(state=state,
                          reservoir_kwargs=res_kw,
                          simulation_kwargs=sim_kw)
