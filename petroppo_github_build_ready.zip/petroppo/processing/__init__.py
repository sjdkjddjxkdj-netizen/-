"""Processing, inversion, and interpretation engine.

This subpackage provides the inverse-problem and interpretation capabilities
that make petroppo a complete geophysical analysis platform:

- ``inversion``: smoothness-constrained ERT inversion (Gauss-Newton / Occam)
- ``hi_inversion``: high-accuracy inversion with a true finite-difference
  forward operator and numerical Jacobian (RES2DINV-grade accuracy)
- ``qc``: quality control, filtering, stacking, reciprocity checks
- ``interpretation``: anomaly detection, depth estimation, geological classification
- ``calibration``: instrument, geometric-factor, and drift calibration
- ``prospecting``: V6 multi-physics fusion (noisy-OR on fuzzy indicators)
- ``bayesian``: V7 calibrated Bayesian prospectivity with uncertainty (the
  scientifically rigorous replacement for the V6 fuzzy fusion)
- ``wellcal``: well-log calibration — learn reliabilities from known wells
"""
from .inversion import invert_ert, invert_from_model, InversionGrid
from .hi_inversion import (
    invert_ert_hi, invert_from_model_hi, InversionGrid as HiInversionGrid,
)
from .qc import (
    reciprocity_check, remove_spikes, lowpass_filter, stack_readings,
    quality_score, assemble_pseudosection, process_survey,
)
from .interpretation import (
    detect_anomalies, classify_resistivity, classify_gravity_anomaly,
    classify_magnetic_anomaly, estimate_depth_halfwidth,
    interpret_profile, generate_report,
    RESISTIVITY_CLASSES, GRAVITY_CLASSES, MAGNETIC_CLASSES,
)
from .calibration import (
    Calibration, calibrate_instrument, apply_calibration,
    geometric_factor, calibrate_geometric_factor, drift_correction,
)
from .prospecting import (
    FusionEngine, ProspectivityMap, HydrocarbonIndicator,
    fuse_prospectivity, hydrocarbon_prospectivity,
)
from .bayesian import (
    BayesianProspectivityEngine, BayesianProspectivityMap,
    CalibrationState, MethodCalibration,
    fit_calibration, reliability_diagram,
)
from .wellcal import (
    WellLog, extract_well_evidence, calibrate_from_wells,
    make_engine_from_wells, cross_validate_wells,
)

__all__ = [
    # inversion (standard)
    "invert_ert", "invert_from_model", "InversionGrid",
    # inversion (high accuracy)
    "invert_ert_hi", "invert_from_model_hi", "HiInversionGrid",
    # qc
    "reciprocity_check", "remove_spikes", "lowpass_filter", "stack_readings",
    "quality_score", "assemble_pseudosection", "process_survey",
    # interpretation
    "detect_anomalies", "classify_resistivity", "classify_gravity_anomaly",
    "classify_magnetic_anomaly", "estimate_depth_halfwidth",
    "interpret_profile", "generate_report",
    "RESISTIVITY_CLASSES", "GRAVITY_CLASSES", "MAGNETIC_CLASSES",
    # calibration
    "Calibration", "calibrate_instrument", "apply_calibration",
    "geometric_factor", "calibrate_geometric_factor", "drift_correction",
    # prospecting / fusion (V6)
    "FusionEngine", "ProspectivityMap", "HydrocarbonIndicator",
    "fuse_prospectivity", "hydrocarbon_prospectivity",
    # Bayesian prospectivity (V7)
    "BayesianProspectivityEngine", "BayesianProspectivityMap",
    "CalibrationState", "MethodCalibration",
    "fit_calibration", "reliability_diagram",
    # well-log calibration (V7)
    "WellLog", "extract_well_evidence", "calibrate_from_wells",
    "make_engine_from_wells", "cross_validate_wells",
]
