"""Calibration module — instrument & geometric-factor calibration.

Real geophysical instruments are not perfect: they have systematic gain errors,
contact-resistance offsets, electrode-polarisation drift, and geometric-factor
errors.  Before field data can be inverted, it must be **calibrated**:

1. **Instrument calibration** — compare readings against a known reference
   (a precision resistor for ERT, a base-station tie for gravity/magnetic)
   and derive a linear correction ``y_cal = gain * y_raw + offset``.

2. **Geometric-factor calibration** — for ERT, the geometric factor *K* depends
   on the exact electrode positions.  Field electrodes are never at the
   nominal positions, so *K* must be measured or computed from surveyed
   positions rather than assumed.

3. **Drift correction** — gravity and magnetic surveys suffer from instrument
   and tidal drift; repeated base-station readings are used to remove it.

This module provides:

* :class:`Calibration` — a linear (gain, offset) calibration with serialisation.
* :func:`calibrate_instrument` — derive a calibration from reference pairs.
* :func:`apply_calibration` — apply a calibration to a list of measurements.
* :func:`geometric_factor` — exact geometric factor for a four-electrode array.
* :func:`drift_correction` — linear drift removal from base-station ties.
"""
from __future__ import annotations

from dataclasses import dataclass, field as dc_field
from typing import Sequence

import numpy as np

from ..core import Measurement, get_logger

_log = get_logger("processing.calibration")


@dataclass
class Calibration:
    """Linear calibration: y_cal = gain * y_raw + offset.

    Attributes
    ----------
    field : str
        Name of the values-dict key this calibration applies to
        (e.g. ``"rho_a"``, ``"g"``, ``"b_total"``).
    gain : float
        Multiplicative gain (slope).  Default 1.0 (no correction).
    offset : float
        Additive offset (intercept).  Default 0.0.
    r_squared : float
        Coefficient of determination of the calibration fit (1.0 = perfect).
    n_points : int
        Number of reference pairs used.
    reference : str
        Human-readable description of the reference standard.
    """
    field: str = "rho_a"
    gain: float = 1.0
    offset: float = 0.0
    r_squared: float = 1.0
    n_points: int = 0
    reference: str = "uncalibrated"
    meta: dict = dc_field(default_factory=dict)

    def apply(self, value: float) -> float:
        return self.gain * value + self.offset

    def to_dict(self) -> dict:
        return {"field": self.field, "gain": self.gain, "offset": self.offset,
                "r_squared": self.r_squared, "n_points": self.n_points,
                "reference": self.reference, "meta": self.meta}

    @classmethod
    def from_dict(cls, d: dict) -> "Calibration":
        return cls(field=d.get("field", "rho_a"),
                   gain=d.get("gain", 1.0),
                   offset=d.get("offset", 0.0),
                   r_squared=d.get("r_squared", 1.0),
                   n_points=d.get("n_points", 0),
                   reference=d.get("reference", ""),
                   meta=d.get("meta", {}))


def calibrate_instrument(raw: Sequence[float], reference: Sequence[float],
                         field: str = "rho_a",
                         reference_name: str = "precision standard"
                         ) -> Calibration:
    """Derive a linear calibration from raw-vs-reference pairs.

    Fits ``reference = gain * raw + offset`` by least squares and returns a
    :class:`Calibration` that maps raw → reference.

    Parameters
    ----------
    raw : array-like
        Instrument readings (uncalibrated).
    reference : array-like
        Known true values (from a precision standard, base-station tie, etc.).
    field : str
        The values-dict key this calibration applies to.
    reference_name : str
        Human-readable label for the reference standard.
    """
    raw_arr = np.asarray(raw, dtype=float)
    ref_arr = np.asarray(reference, dtype=float)
    if raw_arr.size < 2 or ref_arr.size < 2:
        raise ValueError("Need at least 2 reference pairs for calibration")
    if raw_arr.size != ref_arr.size:
        raise ValueError("raw and reference must have the same length")
    # least-squares: ref = gain * raw + offset
    #   => solve [raw, 1] @ [gain, offset]^T = ref
    A = np.vstack([raw_arr, np.ones_like(raw_arr)]).T
    (gain, offset), residuals, rank, sv = np.linalg.lstsq(A, ref_arr, rcond=None)
    # R^2
    ss_res = float(np.sum((ref_arr - (gain * raw_arr + offset)) ** 2))
    ss_tot = float(np.sum((ref_arr - np.mean(ref_arr)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    _log.info("Calibration for '%s': gain=%.6f, offset=%.6f, R²=%.5f (%d pts)",
              field, gain, offset, r2, raw_arr.size)
    return Calibration(field=field, gain=float(gain), offset=float(offset),
                       r_squared=float(r2), n_points=int(raw_arr.size),
                       reference=reference_name,
                       meta={"residuals_std": float(np.sqrt(ss_res / raw_arr.size))})


def apply_calibration(measurements: list[Measurement],
                      cal: Calibration) -> list[Measurement]:
    """Apply a calibration to a list of measurements (in-place copy).

    Returns a new list of :class:`Measurement` objects with the calibrated
    field replaced and the calibration recorded in ``meta['calibration']``.
    """
    out: list[Measurement] = []
    for m in measurements:
        new_vals = dict(m.values)
        if cal.field in new_vals:
            new_vals[cal.field] = cal.apply(new_vals[cal.field])
        new_meta = dict(m.meta)
        new_meta["calibration"] = cal.to_dict()
        out.append(Measurement(
            id=m.id, survey_id=m.survey_id, device_id=m.device_id,
            method=m.method, timestamp=m.timestamp,
            x=m.x, y=m.y, z=m.z, values=new_vals,
            quality=m.quality, note=m.note, meta=new_meta,
        ))
    return out


# --------------------------------------------------------------------- #
#  Geometric factor (exact, for arbitrary electrode positions)          #
# --------------------------------------------------------------------- #
def geometric_factor(c1: float, p1: float, p2: float, c2: float) -> float:
    """Exact geometric factor for a four-electrode array on a half-space.

    For a homogeneous half-space the apparent resistivity is::

        rho_a = K * (dV / I)

    where the geometric factor is::

        K = 2*pi / ( 1/|C1P1| - 1/|C1P2| - 1/|C2P1| + 1/|C2P2| )

    This is the **exact** expression used by the FD forward solver, so using
    it here guarantees consistency between the geometric factor assumed during
    acquisition and the one used in forward modelling.
    """
    eps = 1e-12
    c1 = np.asarray(c1, dtype=float)
    p1 = np.asarray(p1, dtype=float)
    p2 = np.asarray(p2, dtype=float)
    c2 = np.asarray(c2, dtype=float)
    term = (1.0 / max(np.linalg.norm(p1 - c1), eps)
            - 1.0 / max(np.linalg.norm(p2 - c1), eps)
            - 1.0 / max(np.linalg.norm(p1 - c2), eps)
            + 1.0 / max(np.linalg.norm(p2 - c2), eps))
    return 2.0 * np.pi / max(abs(term), eps)


def calibrate_geometric_factor(measurements: list[Measurement],
                               surveyed_positions: dict[str, float] | None = None,
                               ) -> list[Measurement]:
    """Recompute apparent resistivity from V/I using the exact geometric factor.

    Each measurement's ``meta`` must contain ``c1, p1, p2, c2`` (electrode
    positions).  If ``surveyed_positions`` is given, electrode positions are
    looked up from it (keyed by electrode label) — this corrects for the fact
    that real electrodes are never at their nominal positions.

    Returns a new list of measurements with corrected ``rho_a``.
    """
    out: list[Measurement] = []
    for m in measurements:
        meta = m.meta
        c1 = meta.get("c1", m.x - 1.5 * m.values.get("a", 5.0))
        p1 = meta.get("p1", m.x - 0.5 * m.values.get("a", 5.0))
        p2 = meta.get("p2", m.x + 0.5 * m.values.get("a", 5.0))
        c2 = meta.get("c2", m.x + 1.5 * m.values.get("a", 5.0))
        if surveyed_positions:
            c1 = surveyed_positions.get("c1", c1)
            p1 = surveyed_positions.get("p1", p1)
            p2 = surveyed_positions.get("p2", p2)
            c2 = surveyed_positions.get("c2", c2)
        K = geometric_factor(c1, p1, p2, c2)
        v = m.values.get("v")
        i = m.values.get("i", 1.0)
        new_vals = dict(m.values)
        if v is not None and i and i != 0:
            new_vals["rho_a"] = K * v / i
        new_vals["K"] = K
        new_meta = dict(meta)
        new_meta["K"] = K
        out.append(Measurement(
            id=m.id, survey_id=m.survey_id, device_id=m.device_id,
            method=m.method, timestamp=m.timestamp,
            x=m.x, y=m.y, z=m.z, values=new_vals,
            quality=m.quality, note=m.note, meta=new_meta,
        ))
    return out


# --------------------------------------------------------------------- #
#  Drift correction (gravity / magnetic base-station ties)              #
# --------------------------------------------------------------------- #
def drift_correction(measurements: list[Measurement],
                     base_readings: list[tuple[float, float]],
                     field: str = "g") -> list[Measurement]:
    """Remove linear instrument drift using repeated base-station readings.

    Parameters
    ----------
    measurements : list[Measurement]
        The survey readings to correct.
    base_readings : list[(timestamp, value)]
        Repeated readings at the base station, ordered by time.
        Used to fit a linear drift model: ``drift(t) = a + b*t``.
    field : str
        The values-dict key to correct (``"g"`` for gravity, ``"b_total"``).

    Returns
    -------
    list[Measurement] with drift removed.
    """
    if len(base_readings) < 2:
        _log.warning("Need >=2 base-station readings for drift correction; "
                     "returning uncorrected data")
        return list(measurements)
    ts = np.array([b[0] for b in base_readings], dtype=float)
    vs = np.array([b[1] for b in base_readings], dtype=float)
    # Fit drift = a + b*t  (the base value is the mean; slope is the drift)
    t0 = ts[0]
    A = np.vstack([np.ones_like(ts), ts - t0]).T
    (a, b), *_ = np.linalg.lstsq(A, vs, rcond=None)
    # reference value = intercept (value at t0)
    ref = a
    _log.info("Drift correction for '%s': ref=%.6f, rate=%.6e /s over %.0fs",
              field, ref, b, ts[-1] - t0)

    out: list[Measurement] = []
    for m in measurements:
        drift = b * (m.timestamp - t0)
        new_vals = dict(m.values)
        if field in new_vals:
            new_vals[field] = new_vals[field] - drift
        new_meta = dict(m.meta)
        new_meta["drift_corrected"] = True
        new_meta["drift_rate"] = float(b)
        out.append(Measurement(
            id=m.id, survey_id=m.survey_id, device_id=m.device_id,
            method=m.method, timestamp=m.timestamp,
            x=m.x, y=m.y, z=m.z, values=new_vals,
            quality=m.quality, note=m.note, meta=new_meta,
        ))
    return out
