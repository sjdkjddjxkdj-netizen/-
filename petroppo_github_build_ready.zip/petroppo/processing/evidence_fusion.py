"""V9 multi-physics evidence fusion.

Instead of (or in addition to) cross-gradient coupling during inversion,
this module fuses the independently-inverted evidence maps from ERT,
seismic, and GPR into a single prospectivity map.  Each method's evidence
is normalised to [0, 1] and combined via a weighted probabilistic rule.

The fusion improves location accuracy because each method constrains a
different aspect of the subsurface:
  - ERT: resistivity contrast (direct hydrocarbon indicator)
  - Seismic: velocity anomaly (lithology / fluid change)
  - GPR: permittivity anomaly (shallow dielectric contrast)

When the methods agree, the fused evidence sharpens; when they disagree,
the fused evidence is damped (reducing false positives).
"""
import numpy as np
from scipy.ndimage import gaussian_filter, zoom


def _trapezoid(x, a, b, c, d):
    """Piecewise-linear trapezoidal membership: 0 below a, 1 on [b,c], 0 above d."""
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    m1 = (x >= a) & (x < b)
    out[m1] = (x[m1] - a) / max(b - a, 1e-12)
    m2 = (x >= b) & (x <= c)
    out[m2] = 1.0
    m3 = (x > c) & (x <= d)
    out[m3] = (d - x[m3]) / max(d - c, 1e-12)
    return np.clip(out, 0.0, 1.0)


def seismic_velocity_evidence(vel_grid, z_coords=None,
                              smooth_sigma=0.0, min_depth=8.0,
                              depth_weighting=False,
                              contrast_fraction=0.5,
                              plateau_start=0.4,
                              plateau_end=0.8,
                              cutoff=2.0):
    """Seismic hydrocarbon evidence from an inverted velocity grid.

    A high-velocity anomaly (tight/cemented reservoir, carbonate plug)
    relative to the local background indicates a potential reservoir.
    Uses the same contrast-aware trapezoid approach as the ERT evidence.

    Parameters
    ----------
    vel_grid : 2-D inverted velocity (m/s), shape (n_z, n_x).
    z_coords : 1-D array of cell-center depths (for depth weighting).
    plateau_start : velocity anomaly fraction above bg where plateau starts.
    plateau_end : velocity anomaly fraction above bg where plateau ends.
    cutoff : velocity anomaly fraction above bg where evidence drops to 0.
    """
    vel = np.asarray(vel_grid, dtype=float)
    bg = float(np.percentile(vel, 40))
    anom = vel - contrast_fraction * bg
    # velocity trapezoid: only score significant positive anomalies
    lo = max(plateau_start * 0.5 * bg, 1.0)
    pl = max(plateau_start * bg, lo + 1.0)
    ph = plateau_end * bg
    hi = cutoff * bg
    prob = _trapezoid(anom, lo, pl, ph, hi)

    if depth_weighting and z_coords is not None:
        zc = np.asarray(z_coords, dtype=float)
        ramp = np.clip((zc - min_depth) / 10.0, 0.0, 1.0)
        prob = prob * ramp[:, np.newaxis]

    if smooth_sigma > 0:
        prob = gaussian_filter(prob, sigma=smooth_sigma)

    return np.clip(prob, 0.0, 1.0)


def gpr_permittivity_evidence(eps_grid, z_coords=None,
                              smooth_sigma=0.0, min_depth=8.0,
                              depth_weighting=False,
                              contrast_fraction=0.5):
    """GPR hydrocarbon evidence from an inverted permittivity grid.

    A high-permittivity anomaly (water-saturated / clay-rich cap) or a
    low-permittivity anomaly (gas-charged) can indicate a reservoir.
    Here we score high-permittivity anomalies as potential cap-rock /
    fluid indicators.
    """
    eps = np.asarray(eps_grid, dtype=float)
    bg = float(np.percentile(eps, 40))
    anom = eps - contrast_fraction * bg
    lo = max(0.1 * bg, 0.01)
    pl = max(0.3 * bg, lo + 0.01)
    ph = 2.0 * bg
    hi = 5.0 * bg
    prob = _trapezoid(anom, lo, pl, ph, hi)

    if depth_weighting and z_coords is not None:
        zc = np.asarray(z_coords, dtype=float)
        ramp = np.clip((zc - min_depth) / 10.0, 0.0, 1.0)
        prob = prob * ramp[:, np.newaxis]

    if smooth_sigma > 0:
        prob = gaussian_filter(prob, sigma=smooth_sigma)

    return np.clip(prob, 0.0, 1.0)


def fuse_evidence(evidence_maps, weights=None, method="weighted",
                  smooth_sigma=0.0, boost_alpha=0.5):
    """Fuse multiple evidence maps into a single prospectivity map.

    Parameters
    ----------
    evidence_maps : list of 2-D arrays, each shape (n_z, n_x), values in [0,1].
    weights : list of floats (one per map).  If None, equal weights.
    method : "weighted" (weighted average), "bayes" (Bayesian product),
             or "boost" (first map is primary, others boost it).
    smooth_sigma : optional Gaussian smoothing of the fused map.
    boost_alpha : boost strength for "boost" method (0=no boost, 1=full).

    Returns
    -------
    fused : 2-D array, same shape, values in [0,1].
    """
    maps = [np.asarray(m, dtype=float) for m in evidence_maps]
    n = len(maps)
    if n == 0:
        raise ValueError("fuse_evidence: no evidence maps provided")
    if weights is None:
        weights = [1.0 / n] * n
    else:
        weights = list(weights)
    wsum = sum(weights)
    weights = [w / wsum for w in weights]

    if method == "bayes":
        # Bayesian product: p = prod(p_i^w_i) / (prod(p_i^w_i) + prod((1-p_i)^w_i))
        log_p = np.zeros_like(maps[0])
        log_1mp = np.zeros_like(maps[0])
        for m, w in zip(maps, weights):
            m_safe = np.clip(m, 1e-10, 1 - 1e-10)
            log_p += w * np.log(m_safe)
            log_1mp += w * np.log(1 - m_safe)
        fused = 1.0 / (1.0 + np.exp(log_1mp - log_p))
    elif method == "boost":
        # Primary map (first) is boosted by secondary maps where they agree.
        # fused = primary * (1 + alpha * sum(secondary_i * weight_i))
        primary = maps[0]
        boost = np.zeros_like(primary)
        for i in range(1, n):
            boost += maps[i] * weights[i] / weights[0] if weights[0] > 0 else maps[i] / n
        fused = primary * (1.0 + boost_alpha * boost)
    else:
        # weighted average
        fused = np.zeros_like(maps[0])
        for m, w in zip(maps, weights):
            fused += w * m

    if smooth_sigma > 0:
        fused = gaussian_filter(fused, sigma=smooth_sigma)

    return np.clip(fused, 0.0, 1.0)


def resample_to_field(arr, field_shape):
    """Resample a 2-D array to the field grid shape via bilinear interpolation."""
    a = np.asarray(arr, dtype=float)
    if a.shape == field_shape:
        return a
    return zoom(a, (field_shape[0] / a.shape[0], field_shape[1] / a.shape[1]),
                order=1)[:field_shape[0], :field_shape[1]]
