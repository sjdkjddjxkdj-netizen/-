"""
High-accuracy inversion engine for petroppo V3.

This module implements a professional-grade 2-D ERT inversion whose forward
operator is the **finite-difference DC resistivity solver**
(:func:`petroppo.simulator.hifwd.forward_ert_fd`) — the same physics used by
RES2DINV and BERT.  The Jacobian (sensitivity matrix) is computed by true
finite-difference perturbation of each model cell through the FD solver, so
the sensitivities are physically correct rather than a Gaussian approximation.

Algorithm
---------
Gauss-Newton with Occam-style smoothness regularisation::

    min  || W_d (d_obs - F(m)) ||^2  +  lambda || W_m (m - m_ref) ||^2

parameterised in log-resistivity so cells stay positive and the problem is
well-conditioned.  At each iteration:

  1. Predict data  d = F(m)  via the FD forward solver.
  2. Build Jacobian  J[i,j] = d(log rho_a_i) / d(log rho_j)  by perturbing
     each cell and re-running the FD solver (cached per source position).
  3. Solve  (J^T W_d^T W_d J + lam W_m^T W_m) dm = J^T W_d^T W_d r.
  4. Line search to guarantee RMSE decrease; cool lambda on success.

Convergence target is the data noise floor (chi-squared ≈ 1).

Performance
-----------
The FD solver caches the secondary-potential field per unique current-electrode
position, so perturbing a single cell only requires re-solving the FD system
once per source (not once per reading).  For typical surveys (a few dozen
unique sources, ~20x10 inversion cells) a full iteration takes seconds.
"""
from __future__ import annotations

import numpy as np

from ..core import EarthModel, InversionResult, get_logger

_log = get_logger("processing.hi_inversion")


class InversionGrid:
    """2-D rectangular inversion mesh.

    Parameters
    ----------
    x_min, x_max : float
        Horizontal extent of the mesh.
    max_depth : float
        Maximum depth of the mesh.
    n_x, n_z : int
        Number of cells in the horizontal and vertical directions.
    """

    def __init__(self, x_min: float, x_max: float, max_depth: float,
                 n_x: int = 20, n_z: int = 10):
        self.x_min = x_min
        self.x_max = x_max
        self.max_depth = max_depth
        self.n_x = n_x
        self.n_z = n_z
        self.n_cells = n_x * n_z
        self.dx = (x_max - x_min) / n_x
        self.dz = max_depth / n_z
        # Cell centre coordinates
        self.xc = x_min + (np.arange(n_x) + 0.5) * self.dx
        self.zc = (np.arange(n_z) + 0.5) * self.dz

    def cell_index(self, ix: int, iz: int) -> int:
        """Flat index for cell (ix, iz)."""
        return ix * self.n_z + iz

    def model_to_2d(self, model_flat: np.ndarray) -> np.ndarray:
        """Reshape a flat model vector to a 2-D grid (n_x, n_z)."""
        return model_flat.reshape(self.n_x, self.n_z)

    def model_from_2d(self, model_2d: np.ndarray) -> np.ndarray:
        """Flatten a 2-D grid to a model vector."""
        return model_2d.flatten()


def _roughness_matrix(grid: InversionGrid) -> np.ndarray:
    """First-order 2-D roughness matrix W_m.

    Each row penalises the difference between horizontally or vertically
    adjacent cells.  Returns the (n_constraints, n_cells) matrix.
    """
    rows = []
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            # Horizontal neighbour
            if ix < grid.n_x - 1:
                r = np.zeros(grid.n_cells)
                r[idx] = 1.0
                r[grid.cell_index(ix + 1, iz)] = -1.0
                rows.append(r)
            # Vertical neighbour
            if iz < grid.n_z - 1:
                r = np.zeros(grid.n_cells)
                r[idx] = 1.0
                r[grid.cell_index(ix, iz + 1)] = -1.0
                rows.append(r)
    if not rows:
        return np.zeros((0, grid.n_cells))
    return np.array(rows)


# ---------------------------------------------------------------------
# FD-based forward operator (the accurate one)
# ---------------------------------------------------------------------

def _model_to_earthmodel(model_log: np.ndarray, grid: InversionGrid,
                         base_model: EarthModel) -> EarthModel:
    """Build an EarthModel whose resistivity field follows the inversion cells.

    We represent the inversion model as a set of rectangular resistivity blocks
    overlaid on the base (background) model.  Each inversion cell becomes a
    thin ``ResistivityBody`` (rectangular box) with the cell's resistivity.
    The FD solver's ``_model_to_grid`` overlays bodies on top of the layered
    background, which is exactly what we want.
    """
    from ..core import EarthModel as _EM, ResistivityBody
    model_phys = np.exp(model_log)
    model_2d = grid.model_to_2d(model_phys)  # (n_x, n_z)
    bodies = []
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            x0 = grid.x_min + ix * grid.dx
            x1 = x0 + grid.dx
            z0 = iz * grid.dz
            z1 = z0 + grid.dz
            cx = 0.5 * (x0 + x1)
            cz = 0.5 * (z0 + z1)
            rho = float(model_2d[ix, iz])
            # rectangular block: semi-axes = half cell
            bodies.append(ResistivityBody(
                cx=cx, cy=0.0, cz=cz,
                rx=grid.dx * 0.5, ry=1.0, rz=grid.dz * 0.5,
                resistivity=rho,
                label=f"cell_{ix}_{iz}",
            ))
    # New model: same background, no original bodies (cells replace them)
    new_model = _EM(
        name=base_model.name + "_inv",
        layers=list(base_model.layers),
        bodies=bodies,
        extent_x=(grid.x_min, grid.x_max),
        extent_y=base_model.extent_y,
        max_depth=grid.max_depth,
        background_resistivity=base_model.background_resistivity,
    )
    return new_model


def _fd_forward_operator(model_log: np.ndarray, grid: InversionGrid,
                         base_model: EarthModel, geometry,
                         fd_nx: int = 80, fd_nz: int = 40) -> np.ndarray:
    """Predict apparent resistivity for every reading via the FD solver.

    Parameters
    ----------
    model_log : flat log-resistivity vector over the inversion grid.
    grid : InversionGrid
    base_model : EarthModel used for layer background.
    geometry : list of (c1, p1, p2, c2, a, a_eff) electrode quadruplets.
    fd_nx, fd_nz : FD mesh resolution (higher = more accurate).
    """
    from ..simulator.hifwd import forward_ert_fd
    earth = _model_to_earthmodel(model_log, grid, base_model)
    readings = forward_ert_fd(earth, geometry, y=0.0, current=1.0,
                              noise=0.0, nx=fd_nx, nz=fd_nz)
    return np.array([r["rho_a"] for r in readings])


def _fd_jacobian(model_log: np.ndarray, grid: InversionGrid,
                 base_model: EarthModel, geometry,
                 fd_nx: int = 80, fd_nz: int = 40,
                 delta: float = 0.1,
                 jac_fd_nx: int | None = None,
                 jac_fd_nz: int | None = None) -> np.ndarray:
    """Compute the Jacobian d(log rho_a)/d(log rho) by FD perturbation.

    For each cell j we perturb log(rho_j) by +delta, re-run the FD solver,
    and form the one-sided finite difference.  The result is converted to
    log-log sensitivity  J[i,j] = d(log rho_a_i)/d(log rho_j)  via the
    chain rule so the Gauss-Newton system is properly scaled.

    For speed, the Jacobian can be computed on a coarser FD mesh
    (``jac_fd_nx``, ``jac_fd_nz``) than the data-generation mesh, since
    sensitivities are smooth and do not require full resolution.
    """
    if jac_fd_nx is None:
        jac_fd_nx = fd_nx
    if jac_fd_nz is None:
        jac_fd_nz = fd_nz
    f0 = _fd_forward_operator(model_log, grid, base_model, geometry,
                              jac_fd_nx, jac_fd_nz)
    f0_log = np.log(np.maximum(f0, 1e-6))
    n_read = len(f0)
    n_cells = grid.n_cells
    J = np.zeros((n_read, n_cells))
    for j in range(n_cells):
        m_pert = model_log.copy()
        m_pert[j] += delta
        f_pert = _fd_forward_operator(m_pert, grid, base_model, geometry,
                                      jac_fd_nx, jac_fd_nz)
        f_pert_log = np.log(np.maximum(f_pert, 1e-6))
        # d(log rho_a) / d(log rho)  ≈  (log f_pert - log f0) / delta
        J[:, j] = (f_pert_log - f0_log) / delta
    return J


# ---------------------------------------------------------------------
# Fast footprint-based operator (fallback / initialisation)
# ---------------------------------------------------------------------

def _footprint_forward(model_log: np.ndarray, grid: InversionGrid,
                       readings: list[dict]) -> np.ndarray:
    """Sensitivity-weighted average forward (fast, approximate).

    Used only for the very first Jacobian estimate and for quick convergence
    checks before switching to the FD operator.
    """
    model = np.exp(model_log)
    model_2d = grid.model_to_2d(model)  # (n_x, n_z)
    pred = np.zeros(len(readings))
    for i, r in enumerate(readings):
        x_mid = r["x_mid"]
        a_eff = r["a"]
        depth = r["depth"]
        sigma_x = max(a_eff, grid.dx)
        sigma_z = max(a_eff * 0.6, grid.dz)
        weights = np.zeros((grid.n_x, grid.n_z))
        for ix in range(grid.n_x):
            for iz in range(grid.n_z):
                dx = grid.xc[ix] - x_mid
                dz = grid.zc[iz] - depth
                if dz < 0:
                    continue
                weights[ix, iz] = (np.exp(-0.5 * (dx / sigma_x) ** 2) *
                                   np.exp(-0.5 * (dz / sigma_z) ** 2))
        ws = weights.sum()
        if ws > 0:
            pred[i] = np.sum(weights * model_2d) / ws
        else:
            pred[i] = np.exp(np.mean(model_log))
    return pred


def invert_ert_hi(readings: list[dict], grid: InversionGrid,
                  obs_rho: np.ndarray, base_model: EarthModel,
                  geometry=None, noise_floor: float = 0.02,
                  ref_resistivity: float = 100.0,
                  max_iter: int = 8, lambda_init: float = 10.0,
                  lambda_decay: float = 0.7,
                  use_fd_operator: bool = True,
                  fd_nx: int = 80, fd_nz: int = 40,
                  jac_fd_nx: int | None = None,
                  jac_fd_nz: int | None = None,
                  jacobian_every: int = 2) -> InversionResult:
    """High-accuracy ERT inversion with the FD forward operator.

    Parameters
    ----------
    readings : list[dict]
        Survey readings with keys x_mid, a, depth, rho_a.
    grid : InversionGrid
        Inversion mesh.
    obs_rho : np.ndarray
        Observed apparent resistivity values.
    base_model : EarthModel
        Background earth model (layers / background resistivity).
    geometry : list, optional
        Electrode quadruplets (c1,p1,p2,c2,a,a_eff).  If None, reconstructed
        from the readings' x_mid / a where possible (best-effort).
    noise_floor : float
        Relative noise level (convergence target: chi^2 ~ 1).
    ref_resistivity : float
        Starting (reference) resistivity for the homogeneous initial model.
    max_iter : int
        Maximum number of Gauss-Newton iterations.
    lambda_init : float
        Initial Marquardt damping parameter.
    lambda_decay : float
        Geometric decay factor for lambda on a successful step.
    use_fd_operator : bool
        If True, use the finite-difference forward operator and numerical
        Jacobian (accurate, slower).  If False, use the fast footprint
        approximation (fast, less accurate).
    fd_nx, fd_nz : int
        FD mesh resolution for the forward operator.
    jacobian_every : int
        Recompute the FD Jacobian every N iterations.

    Returns
    -------
    InversionResult
    """
    n_read = len(readings)
    n_cells = grid.n_cells

    # Reconstruct geometry from readings if not supplied
    if geometry is None:
        geometry = []
        for r in readings:
            a = r["a"]
            x_mid = r["x_mid"]
            # assume symmetric Wenner-like layout around midpoint
            c1 = x_mid - 1.5 * a
            p1 = x_mid - 0.5 * a
            p2 = x_mid + 0.5 * a
            c2 = x_mid + 1.5 * a
            geometry.append((c1, p1, p2, c2, a, a))

    # Log-parameterised model
    log_ref = np.log(ref_resistivity)
    model_log = np.full(n_cells, log_ref)
    m_ref = model_log.copy()

    obs_log = np.log(obs_rho)

    # Data weighting — consistent with log-space residual.
    # For log-parameterised inversion the residual is r = ln(obs) - ln(pred).
    # If the relative data error is `noise_floor` (i.e. obs has std
    # sigma_rho = noise_floor * |obs|), then by error propagation the std of
    # ln(obs) is sigma_log = sigma_rho / |obs| = noise_floor.  Hence the
    # log-space data covariance is C_d = noise_floor^2 * I and the weighting
    # matrix is W_d = (1/noise_floor) * I.  This is the standard formulation
    # used in DC resistivity inversion (e.g. Loke & Barker, Pellerin & Wann).
    sigma_log = float(noise_floor)
    W_d = np.diag(np.full(n_read, 1.0 / sigma_log))
    # Linear-space std retained only for absolute RMSE reporting
    data_std_lin = noise_floor * np.abs(obs_rho) + 1e-6

    # Roughness matrix
    Wm = _roughness_matrix(grid)
    WmT_Wm = Wm.T @ Wm if Wm.shape[0] > 0 else np.zeros((n_cells, n_cells))

    lam = lambda_init
    J_log = None
    rmse_prev = np.inf
    rmse_history: list[float] = []
    it = 0

    # Forward-operator function (FD or footprint)
    if use_fd_operator:
        def F(mlog):
            return _fd_forward_operator(mlog, grid, base_model, geometry,
                                        fd_nx, fd_nz)
    else:
        def F(mlog):
            return _footprint_forward(mlog, grid, readings)

    for it in range(1, max_iter + 1):
        # Predicted data
        pred = F(model_log)
        pred = np.maximum(pred, 1e-6)
        resid = obs_log - np.log(pred)  # log-space residual

        # Jacobian (recompute periodically)
        need_jac = (J_log is None) or (it % jacobian_every == 1)
        if need_jac:
            if use_fd_operator:
                _log.info("Iter %d: computing FD Jacobian (%d cells)...",
                          it, n_cells)
                J_log = _fd_jacobian(model_log, grid, base_model, geometry,
                                     fd_nx, fd_nz, delta=0.1,
                                     jac_fd_nx=jac_fd_nx,
                                     jac_fd_nz=jac_fd_nz)
            else:
                # footprint Jacobian via small perturbation
                f0 = _footprint_forward(model_log, grid, readings)
                f0_log = np.log(np.maximum(f0, 1e-6))
                J_log = np.zeros((n_read, n_cells))
                for j in range(n_cells):
                    mp = model_log.copy()
                    mp[j] += 0.05
                    fp = _footprint_forward(mp, grid, readings)
                    J_log[:, j] = (np.log(np.maximum(fp, 1e-6)) - f0_log) / 0.05

        # Gauss-Newton normal equations
        JtWd = J_log.T @ W_d
        JtWdJ = JtWd @ W_d @ J_log
        A = JtWdJ + lam * WmT_Wm
        rhs = JtWd @ W_d @ resid

        # Regularise diagonal for conditioning
        A += 1e-6 * np.eye(n_cells)
        try:
            dm = np.linalg.solve(A, rhs)
        except np.linalg.LinAlgError:
            dm = np.linalg.lstsq(A, rhs, rcond=None)[0]

        # Step-length control: cap max log-change per iteration
        max_step = 0.6
        max_dm = np.max(np.abs(dm))
        if max_dm > max_step:
            dm = dm * (max_step / max_dm)

        # Line search: try full step, then half, then quarter
        accepted = False
        for alpha in (1.0, 0.5, 0.25):
            m_trial = model_log + alpha * dm
            # bounds in log space (1 .. 100000 ohm.m)
            m_trial = np.clip(m_trial, np.log(1.0), np.log(1e5))
            pred_trial = F(m_trial)
            pred_trial = np.maximum(pred_trial, 1e-6)
            # Chi-squared in log space (consistent with W_d)
            rmse_trial = float(np.sqrt(
                np.mean(((obs_log - np.log(pred_trial)) / sigma_log) ** 2)))
            if rmse_trial < rmse_prev:
                model_log = m_trial
                rmse_prev = rmse_trial
                rmse_history.append(rmse_trial)
                accepted = True
                _log.info("Iter %d: RMSE=%.4f (alpha=%.2f, lambda=%.2f)",
                          it, rmse_trial, alpha, lam)
                break

        if accepted:
            lam *= lambda_decay
            # convergence: chi-squared ~ 1 (at noise floor)
            if rmse_prev < 1.0:
                _log.info("Converged to noise floor at iter %d (RMSE=%.4f)",
                          it, rmse_prev)
                break
        else:
            # reject, increase damping
            lam /= lambda_decay
            rmse_history.append(rmse_prev)
            _log.info("Iter %d: step rejected, lambda -> %.2f", it, lam)
            if lam > 1e6:
                _log.info("Lambda too large, stopping at iter %d", it)
                break

    # Final model & diagnostics
    final_model = np.exp(model_log)
    final_pred = F(model_log)
    final_pred = np.maximum(final_pred, 1e-6)
    rmse_abs = float(np.sqrt(np.mean((obs_rho - final_pred) ** 2)))
    rel_rmse = float(np.sqrt(np.mean(((obs_rho - final_pred) / obs_rho) ** 2)))
    # Chi-squared (normalised) in log space — target ≈ 1.0 at noise floor
    chi2 = float(np.mean(((obs_log - np.log(final_pred)) / sigma_log) ** 2))
    model_norm = float(np.linalg.norm(model_log - m_ref))
    converged = bool(rmse_prev < 1.0)

    model_2d = grid.model_to_2d(final_model)

    _log.info("Inversion complete: %d iters, abs RMSE=%.4f, "
              "rel RMSE=%.4f, chi2=%.4f, converged=%s",
              it, rmse_abs, rel_rmse, chi2, converged)

    # Use scalar cell_size and 3-tuple extent for compatibility with
    # interpretation/viz modules.
    return InversionResult(
        survey_id="hi_inversion",
        model=model_2d,
        rmse=rmse_abs,
        n_iter=it,
        cell_size=grid.dx,
        extent=(grid.x_max - grid.x_min, 0.0, grid.max_depth),
        meta={
            "lambda_final": lam,
            "method": "Gauss-Newton + log-parameterisation + Tikhonov",
            "n_cells": n_cells,
            "n_readings": n_read,
            "noise_floor": noise_floor,
            "fd_mesh": (fd_nx, fd_nz),
            "rmse_history": rmse_history,
            "rel_rmse": rel_rmse,
            "chi2": chi2,
            "converged": converged,
            "model_norm": model_norm,
            "use_fd_operator": use_fd_operator,
        },
    )


def invert_from_model_hi(model: EarthModel, n_electrodes: int = 24,
                         spacing: float = 5.0, config: str = "wenner",
                         noise: float = 0.02, n_x: int = 20, n_z: int = 10,
                         use_fd_operator: bool = True,
                         max_iter: int = 8,
                         fd_nx: int = 80, fd_nz: int = 40) -> InversionResult:
    """End-to-end high-accuracy inversion: FD forward-model → FD invert.

    Generates synthetic ERT data using the high-accuracy FD forward solver,
    then inverts with the numerical-Jacobian Gauss-Newton engine whose
    forward operator is the same FD solver.

    Parameters
    ----------
    model : EarthModel
        The true subsurface model to forward-model and then recover.
    n_electrodes, spacing, config : survey geometry.
    noise : relative noise added to the synthetic data.
    n_x, n_z : inversion-grid resolution.
    use_fd_operator : if True the inversion's forward operator is the FD
        solver (most accurate).  If False, the fast footprint approximation.
    max_iter : Gauss-Newton iterations.
    fd_nx, fd_nz : FD mesh resolution (forward modeling accuracy).
    """
    from ..simulator.forward import wenner_geometry, dipole_dipole_geometry
    from ..simulator.hifwd import forward_ert_fd

    # Generate geometry
    geom_fn = (dipole_dipole_geometry if config == "dipole-dipole"
               else wenner_geometry)
    geometry = geom_fn(n_electrodes, spacing)

    # Forward model with high accuracy (the FD solver)
    rng = np.random.default_rng(42)
    readings = forward_ert_fd(model, geometry, noise=noise, rng=rng,
                              nx=fd_nx, nz=fd_nz)
    obs_rho = np.array([r["rho_a"] for r in readings])

    # Inversion grid spanning the survey
    all_x = [r["x_mid"] for r in readings]
    x_min = min(all_x) - spacing
    x_max = max(all_x) + spacing
    inv_depth = max(spacing * n_electrodes / 3.0, model.max_depth * 0.7)
    grid = InversionGrid(x_min, x_max, inv_depth, n_x, n_z)

    ref_rho = model.background_resistivity
    result = invert_ert_hi(
        readings, grid, obs_rho, base_model=model, geometry=geometry,
        noise_floor=noise, ref_resistivity=ref_rho,
        max_iter=max_iter, use_fd_operator=use_fd_operator,
        fd_nx=fd_nx, fd_nz=fd_nz,
    )
    result.survey_id = model.name
    return result
