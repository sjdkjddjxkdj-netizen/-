"""Geological interpretation of inversion results and survey anomalies.

This module turns numerical results (inverted resistivity images, magnetic/gravity
profiles) into geological meaning: detected bodies, their depth, size, and likely
classification (reservoir, brine, ore, void, etc.).

It implements:
- **Anomaly detection** from inverted models (connected-component thresholding).
- **Body characterization**: centroid, depth, volume, contrast.
- **Depth estimation** from half-width / half-amplitude rules.
- **Classification** using resistivity / density / susceptibility ranges.
- **Interpretation reports** with geological context.
"""
from __future__ import annotations

import numpy as np

from ..core import InversionResult, get_logger

_log = get_logger("processing.interpretation")


# Classification tables (resistivity in ohm.m for ERT)
RESISTIVITY_CLASSES = [
    {"label": "Sea water / Brine", "range": (0.1, 2.0),
     "description": "Very conductive saline fluids."},
    {"label": "Clay / Weathered layer", "range": (2.0, 20.0),
     "description": "Conductive unconsolidated sediments."},
    {"label": "Sand / Aquifer (fresh)", "range": (20.0, 100.0),
     "description": "Moderately resistive saturated sands."},
    {"label": "Limestone / Sandstone", "range": (100.0, 500.0),
     "description": "Resistive consolidated sediments."},
    {"label": "Igneous / Basement", "range": (500.0, 5000.0),
     "description": "Highly resistive crystalline rocks."},
    {"label": "Hydrocarbon reservoir", "range": (500.0, 2000.0),
     "description": "Resistive hydrocarbon-bearing formation."},
    {"label": "Dry sand / Void", "range": (2000.0, 50000.0),
     "description": "Extremely resistive (air-filled or dry)."},
]

# Gravity classification (density contrast in mGal)
GRAVITY_CLASSES = [
    {"label": "Dense intrusion / Ore body", "sign": "positive",
     "description": "Excess mass indicates dense body (ore, mafic intrusion)."},
    {"label": "Salt dome / Sedimentary basin", "sign": "negative",
     "description": "Mass deficit indicates low-density body (salt, basin fill)."},
]

# Magnetic classification (anomaly in nT)
MAGNETIC_CLASSES = [
    {"label": "Magnetic intrusion / Iron ore", "sign": "positive",
     "description": "High susceptibility body (igneous, magnetite)."},
    {"label": "Non-magnetic sedimentary", "sign": "near_zero",
     "description": "Low susceptibility, typical of sedimentary basins."},
]


def classify_resistivity(rho: float) -> dict:
    """Classify a resistivity value into a geological category."""
    for cls in RESISTIVITY_CLASSES:
        lo, hi = cls["range"]
        if lo <= rho < hi:
            return cls
    if rho >= 50000:
        return RESISTIVITY_CLASSES[-1]
    return {"label": "Unknown", "range": (0, 0),
            "description": f"Resistivity {rho:.1f} ohm.m could not be classified."}


def detect_anomalies(inversion: InversionResult,
                     threshold_factor: float = 1.5) -> list[dict]:
    """Detect anomalous bodies in a 2D inverted resistivity model.

    Uses connected-component labeling on cells that deviate from the median
    by more than ``threshold_factor`` times the MAD.

    Returns a list of detected bodies with centroid, extent, and contrast.
    """
    model = inversion.model
    if model.size == 0:
        return []

    nx, nz = model.shape
    median = np.median(model)
    mad = np.median(np.abs(model - median))
    if mad == 0:
        mad = np.std(model) + 1e-9
    threshold = threshold_factor * mad

    # binary mask of anomalous cells (both high and low)
    anomaly_mask = np.abs(model - median) > threshold

    # connected-component labeling (4-connectivity)
    labels = np.zeros_like(model, dtype=int)
    current_label = 0
    components = []

    for i in range(nx):
        for j in range(nz):
            if anomaly_mask[i, j] and labels[i, j] == 0:
                current_label += 1
                # BFS flood fill
                queue = [(i, j)]
                cells = []
                labels[i, j] = current_label
                while queue:
                    ci, cj = queue.pop(0)
                    cells.append((ci, cj))
                    for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        ni, nj = ci + di, cj + dj
                        if (0 <= ni < nx and 0 <= nj < nz and
                                anomaly_mask[ni, nj] and labels[ni, nj] == 0):
                            labels[ni, nj] = current_label
                            queue.append((ni, nj))
                components.append(cells)

    # characterize each component
    cell_size = inversion.cell_size
    max_depth = inversion.extent[2] if len(inversion.extent) >= 3 else 0.0
    dz = max_depth / nz if nz > 0 else cell_size

    bodies = []
    for cells in components:
        if len(cells) < 2:
            continue  # skip tiny clusters
        xs = [c[0] for c in cells]
        zs = [c[1] for c in cells]
        vals = [model[c[0], c[1]] for c in cells]

        mean_rho = float(np.mean(vals))
        contrast = mean_rho / median if median > 0 else 1.0
        centroid_x = float(np.mean(xs)) * cell_size
        centroid_z = float(np.mean(zs)) * dz
        width = (max(xs) - min(xs) + 1) * cell_size
        height = (max(zs) - min(zs) + 1) * dz
        area = len(cells) * cell_size * dz

        # classify
        cls = classify_resistivity(mean_rho)
        anomaly_type = "resistive" if contrast > 1.0 else "conductive"

        bodies.append({
            "id": f"body_{len(bodies)+1}",
            "centroid_x": centroid_x,
            "centroid_z": centroid_z,
            "width": float(width),
            "height": float(height),
            "area": float(area),
            "mean_resistivity": mean_rho,
            "contrast": float(contrast),
            "anomaly_type": anomaly_type,
            "n_cells": len(cells),
            "classification": cls["label"],
            "description": cls["description"],
        })

    _log.info("Detected %d anomalous bodies in inversion result", len(bodies))
    return bodies


def estimate_depth_halfwidth(profile_x: np.ndarray, profile_y: np.ndarray) -> dict:
    """Estimate body depth from anomaly half-width (rule of thumb).

    For a buried sphere, depth ≈ 0.65 × the half-width of the anomaly at
    half-maximum (Stanley, 1977).  For a horizontal cylinder the factor is
    closer to 1.0.  Because the geometry of the source is unknown a priori,
    the factor 0.65 carries significant uncertainty; this function therefore
    reports a **confidence band** rather than a single number.

    This is an approximate, order-of-magnitude estimate — it is **not** a
    rigorous depth-inversion and should not be presented as a precise
    measurement without independent validation.
    """
    if len(profile_y) == 0:
        return {"depth": 0.0, "method": "half-width", "amplitude": 0.0,
                "confidence": "none"}

    amplitude = float(np.max(profile_y) - np.min(profile_y))
    if amplitude == 0:
        return {"depth": 0.0, "method": "half-width", "amplitude": 0.0,
                "confidence": "none"}

    half_max = np.min(profile_y) + amplitude / 2.0
    # find points above half-max
    above = profile_y >= half_max
    if above.sum() < 2:
        return {"depth": 0.0, "method": "half-width", "amplitude": amplitude,
                "confidence": "none"}

    # half-width in x
    idx_above = np.where(above)[0]
    if len(profile_x) > 1:
        dx = float(np.median(np.diff(np.sort(profile_x))))
    else:
        dx = 1.0
    half_width = (idx_above[-1] - idx_above[0]) * dx
    depth = 0.65 * half_width  # rule of thumb for sphere
    # Uncertainty band: sphere (0.65) to cylinder (1.0) geometry range
    depth_min = 0.5 * half_width
    depth_max = 1.0 * half_width

    # Confidence heuristic: more anomaly points above half-max → higher conf
    n_pts = int(above.sum())
    if n_pts >= 8:
        confidence = "moderate"
    elif n_pts >= 4:
        confidence = "low"
    else:
        confidence = "very-low"

    return {
        "depth": float(depth),
        "depth_min": float(depth_min),
        "depth_max": float(depth_max),
        "half_width": float(half_width),
        "amplitude": amplitude,
        "method": "anomaly half-width approximation (0.65 × HW, sphere)",
        "method_note": "Approximate rule of thumb; true depth depends on "
                       "source geometry. Validated against independent data "
                       "before use in reports.",
        "confidence": confidence,
        "n_points_above_halfmax": n_pts,
    }


def classify_gravity_anomaly(anomaly_mgal: float) -> dict:
    """Classify a gravity anomaly."""
    if abs(anomaly_mgal) < 0.1:
        return {"label": "No significant anomaly", "description": "Gravity field is near background."}
    for cls in GRAVITY_CLASSES:
        if anomaly_mgal > 0 and cls["sign"] == "positive":
            return cls
        if anomaly_mgal < 0 and cls["sign"] == "negative":
            return cls
    return {"label": "Unclear", "description": "Anomaly sign is ambiguous."}


def classify_magnetic_anomaly(anomaly_nt: float) -> dict:
    """Classify a magnetic anomaly."""
    if abs(anomaly_nt) < 5:
        return MAGNETIC_CLASSES[1]  # near zero
    for cls in MAGNETIC_CLASSES:
        if anomaly_nt > 0 and cls["sign"] == "positive":
            return cls
    return {"label": "Magnetic low", "description": "Negative magnetic anomaly (remanent or low-susceptibility)."}


def interpret_profile(x: np.ndarray, y: np.ndarray, method: str = "gravity") -> dict:
    """Interpret a 1D potential-field profile (gravity or magnetic).

    Returns peak location, amplitude, half-width depth estimate, and classification.
    """
    if len(y) == 0:
        return {"method": method, "n_points": 0}

    peak_idx = int(np.argmax(np.abs(y - np.median(y))))
    peak_x = float(x[peak_idx])
    peak_y = float(y[peak_idx])
    anomaly_val = peak_y - float(np.median(y))

    depth_est = estimate_depth_halfwidth(x, y - np.median(y))

    if method == "gravity":
        cls = classify_gravity_anomaly(anomaly_val)
    elif method == "magnetic":
        cls = classify_magnetic_anomaly(anomaly_val)
    else:
        cls = {"label": "Unknown method", "description": ""}

    return {
        "method": method,
        "n_points": len(y),
        "peak_x": peak_x,
        "peak_amplitude": anomaly_val,
        "background": float(np.median(y)),
        "depth_estimate": depth_est,
        "classification": cls,
    }


def generate_report(inversion: InversionResult,
                    bodies: list[dict] | None = None) -> str:
    """Generate a human-readable interpretation report from inversion results."""
    if bodies is None:
        bodies = detect_anomalies(inversion)

    meta = getattr(inversion, "meta", {}) or {}
    chi2 = meta.get("chi2")
    rel_rmse = meta.get("rel_rmse")
    converged = meta.get("converged")

    lines = [
        "=== petroppo Interpretation Report ===",
        f"Inversion: {inversion.n_iter} iterations, RMSE = {inversion.rmse:.4f}",
    ]
    if rel_rmse is not None:
        lines.append(f"  Relative RMSE: {rel_rmse:.4f}")
    if chi2 is not None:
        lines.append(f"  Chi-squared (normalised): {chi2:.4f}  "
                     f"(target ≈ 1.0 at noise floor)")
    if converged is not None:
        lines.append(f"  Converged to noise floor: {'yes' if converged else 'no'}")
    lines += [
        f"Grid: {inversion.model.shape[0]} x {inversion.model.shape[1]} cells, "
        f"cell size = {inversion.cell_size:.1f} m",
        f"Depth of investigation: {inversion.extent[2]:.1f} m",
        "",
        "Note: Depth estimates for potential-field anomalies use the "
        "half-width rule of thumb (≈ 0.65 × half-width for a spherical "
        "source).  These are order-of-magnitude approximations and should "
        "be validated against independent data before use in operational "
        "decisions.",
        "",
        f"Detected bodies: {len(bodies)}",
        "",
    ]

    for i, b in enumerate(bodies, 1):
        lines.append(f"  Body {i}: {b['classification']}")
        lines.append(f"    Type: {b['anomaly_type']} (contrast = {b['contrast']:.2f})")
        lines.append(f"    Centroid: x={b['centroid_x']:.1f} m, z={b['centroid_z']:.1f} m")
        lines.append(f"    Dimensions: {b['width']:.1f} m wide x {b['height']:.1f} m deep")
        lines.append(f"    Mean resistivity: {b['mean_resistivity']:.1f} ohm.m")
        lines.append(f"    {b['description']}")
        lines.append("")

    if not bodies:
        lines.append("  No significant anomalous bodies detected.")
        lines.append("  The subsurface appears homogeneous within detection limits.")
        lines.append("")

    lines.append("=== End of Report ===")
    return "\n".join(lines)
