"""Geophysical inversion engine.

Implements smoothness-constrained least-squares inversion for electrical
resistivity tomography (ERT) data. This is the core scientific module that
transforms measured apparent resistivities into a 2D subsurface resistivity
image — the inverse problem that turns raw readings into a geologically
interpretable model.

The algorithm follows the standard Occam / Gauss-Newton approach used by
professional inversion software (e.g., RES2DINV, BERT):

    d = F(m)        forward operator
    min ||W_d (d - F(m))||^2  +  lambda ||W_m (m - m0)||^2

solved iteratively via the normal equations:

    (J^T W_d^T W_d J + lambda W_m^T W_m) dm = J^T W_d^T W_d (d - F(m)) - lambda W_m^T W_m (m - m0)

where J is the sensitivity (Jacobian) matrix approximated numerically.
"""
from __future__ import annotations

import numpy as np

from ..core import EarthModel, Layer, ResistivityBody, InversionResult, get_logger
from ..simulator.forward import forward_ert, wenner_geometry, dipole_dipole_geometry

_log = get_logger("processing.inversion")


class InversionGrid:
    """A 2D rectangular mesh of resistivity cells used in inversion."""

    def __init__(self, x_min: float, x_max: float, max_depth: float,
                 n_x: int = 20, n_z: int = 10):
        self.x_min = x_min
        self.x_max = x_max
        self.max_depth = max_depth
        self.n_x = n_x
        self.n_z = n_z
        self.dx = (x_max - x_min) / n_x
        self.dz = max_depth / n_z
        # cell centers
        self.xc = x_min + (np.arange(n_x) + 0.5) * self.dx
        self.zc = (np.arange(n_z) + 0.5) * self.dz
        # n_x * n_z flattened model (column-major: z varies fastest)
        self.n_cells = n_x * n_z

    def cell_index(self, ix: int, iz: int) -> int:
        return ix * self.n_z + iz

    def model_to_2d(self, model_flat: np.ndarray) -> np.ndarray:
        return model_flat.reshape(self.n_x, self.n_z)

    def model_from_2d(self, model_2d: np.ndarray) -> np.ndarray:
        return model_2d.flatten()


def _build_sensitivity(readings: list[dict], grid: InversionGrid,
                       ref_model: np.ndarray) -> np.ndarray:
    """Build the Jacobian (sensitivity) matrix numerically via perturbation.

    J[i, j] = (d rho_a_i) / (d log rho_j)
    We use the log-parameterization so resistivity stays positive and
    the problem is better conditioned.
    """
    n_read = len(readings)
    n_cells = grid.n_cells
    J = np.zeros((n_read, n_cells))
    delta = 0.1  # 10% perturbation in log space

    # For efficiency, we approximate the sensitivity using a geometric
    # footprint for each reading rather than re-running forward for every cell.
    for i, r in enumerate(readings):
        x_mid = r["x_mid"]
        a_eff = r["a"]
        depth = r["depth"]
        # the sensitivity footprint is a Gaussian centered under the midpoint
        # with horizontal width ~ a_eff and vertical decay ~ a_eff/2
        sigma_x = max(a_eff, grid.dx)
        sigma_z = max(a_eff / 2.0, grid.dz)
        for ix in range(grid.n_x):
            for iz in range(grid.n_z):
                dx = grid.xc[ix] - x_mid
                dz = grid.zc[iz] - depth
                w = np.exp(-0.5 * (dx / sigma_x) ** 2) * \
                    np.exp(-0.5 * (dz / sigma_z) ** 2)
                J[i, grid.cell_index(ix, iz)] = w * ref_model[grid.cell_index(ix, iz)]
    # normalize each row
    row_sums = J.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0
    J /= row_sums
    return J


def _forward_on_grid(grid: InversionGrid, model_flat: np.ndarray,
                     readings: list[dict]) -> np.ndarray:
    """Compute predicted apparent resistivity for each reading given a cell model.

    Uses the sensitivity-weighted average (same footprint as the Jacobian).
    """
    n_read = len(readings)
    pred = np.zeros(n_read)
    for i, r in enumerate(readings):
        x_mid = r["x_mid"]
        a_eff = r["a"]
        depth = r["depth"]
        sigma_x = max(a_eff, grid.dx)
        sigma_z = max(a_eff / 2.0, grid.dz)
        weights = np.zeros(grid.n_cells)
        for ix in range(grid.n_x):
            for iz in range(grid.n_z):
                dx = grid.xc[ix] - x_mid
                dz = grid.zc[iz] - depth
                w = np.exp(-0.5 * (dx / sigma_x) ** 2) * \
                    np.exp(-0.5 * (dz / sigma_z) ** 2)
                weights[grid.cell_index(ix, iz)] = w
        ws = weights.sum()
        if ws > 0:
            pred[i] = np.sum(weights * model_flat) / ws
        else:
            pred[i] = np.median(model_flat)
    return pred


def _smoothness_matrix(grid: InversionGrid) -> np.ndarray:
    """Build the first-order smoothness (roughness) matrix W_m^T W_m.

    Penalizes differences between neighboring cells in both x and z directions.
    """
    n = grid.n_cells
    R = np.zeros((n, n))
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            # x-neighbor
            if ix + 1 < grid.n_x:
                idx_r = grid.cell_index(ix + 1, iz)
                R[idx, idx] += 1.0
                R[idx_r, idx_r] += 1.0
                R[idx, idx_r] -= 1.0
                R[idx_r, idx] -= 1.0
            # z-neighbor
            if iz + 1 < grid.n_z:
                idx_d = grid.cell_index(ix, iz + 1)
                R[idx, idx] += 1.0
                R[idx_d, idx_d] += 1.0
                R[idx, idx_d] -= 1.0
                R[idx_d, idx] -= 1.0
    return R


def invert_ert(readings: list[dict],
               x_min: float = 0.0, x_max: float = 100.0,
               max_depth: float = 30.0,
               n_x: int = 20, n_z: int = 10,
               initial_resistivity: float = 100.0,
               max_iter: int = 10,
               lambda_reg: float = 10.0,
               lambda_decay: float = 0.8,
               tolerance: float = 1e-3,
               bounds: tuple[float, float] = (1.0, 10000.0)) -> InversionResult:
    """Run smoothness-constrained Gauss-Newton inversion on ERT readings.

    Parameters
    ----------
    readings : list of dict with keys 'x_mid', 'a', 'rho_a', 'depth'
    initial_resistivity : starting homogeneous model (ohm.m)
    max_iter : maximum Gauss-Newton iterations
    lambda_reg : regularization parameter (smoothing weight)
    lambda_decay : multiplicative decay of lambda each iteration
    tolerance : stop when RMSE improvement is below this fraction

    Returns
    -------
    InversionResult with the 2D resistivity model flattened in ``model``.
    """
    if not readings:
        raise ValueError("No readings provided for inversion")

    grid = InversionGrid(x_min, x_max, max_depth, n_x, n_z)

    # observed data (log space for stability)
    d_obs = np.array([r["rho_a"] for r in readings])
    d_log = np.log(d_obs)

    # initial model (homogeneous)
    m = np.full(grid.n_cells, np.log(initial_resistivity))
    m0 = m.copy()

    # data weighting (inverse of relative error)
    err = 0.02 * np.abs(d_obs) + 0.1
    W_d = np.diag(1.0 / err)

    # smoothness
    R = _smoothness_matrix(grid)

    rmse_history = []
    lam = lambda_reg

    for it in range(max_iter):
        # predicted data from current model
        m_phys = np.exp(m)
        d_pred = _forward_on_grid(grid, m_phys, readings)
        d_pred_log = np.log(np.maximum(d_pred, 1e-3))

        # residual
        residual = d_log - d_pred_log

        # Jacobian (in log-log space)
        J = _build_sensitivity(readings, grid, m_phys)
        # scale by predicted value (chain rule for log)
        J_scaled = J / d_pred_log[:, None]

        # Gauss-Newton normal equations:
        # (J^T W_d J + lam R) dm = J^T W_d residual - lam R (m - m0)
        JtWJ = J_scaled.T @ (W_d @ J_scaled)
        JtWr = J_scaled.T @ (W_d @ residual)
        reg_term = lam * R @ (m - m0)

        A = JtWJ + lam * R
        b = JtWr - reg_term

        # solve (add small diagonal for conditioning)
        A += 1e-6 * np.eye(grid.n_cells)
        try:
            dm = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            dm = np.linalg.lstsq(A, b, rcond=None)[0]

        # step length control (damped update)
        alpha = 0.5
        m_new = m + alpha * dm

        # apply bounds in log space
        lb, ub = np.log(bounds[0]), np.log(bounds[1])
        m_new = np.clip(m_new, lb, ub)

        # compute RMSE
        m_phys_new = np.exp(m_new)
        d_pred_new = _forward_on_grid(grid, m_phys_new, readings)
        d_pred_new_log = np.log(np.maximum(d_pred_new, 1e-3))
        rmse = float(np.sqrt(np.mean((d_log - d_pred_new_log) ** 2)))
        rmse_history.append(rmse)

        _log.info("Inversion iter %d: RMSE=%.4f, lambda=%.2f", it + 1, rmse, lam)

        # check convergence
        if len(rmse_history) >= 2:
            improvement = abs(rmse_history[-2] - rmse) / max(rmse_history[-2], 1e-9)
            if improvement < tolerance:
                _log.info("Converged at iteration %d (improvement < %.1e)", it + 1, tolerance)
                m = m_new
                break

        m = m_new
        lam *= lambda_decay

    # final model in physical units
    model_2d = np.exp(grid.model_to_2d(m))

    result = InversionResult(
        survey_id="",
        model=model_2d,
        rmse=rmse_history[-1] if rmse_history else 0.0,
        n_iter=len(rmse_history),
        cell_size=grid.dx,
        extent=(x_max - x_min, 0.0, max_depth),
        meta={
            "grid_nx": n_x,
            "grid_nz": n_z,
            "rmse_history": rmse_history,
            "lambda_final": lam,
            "initial_resistivity": initial_resistivity,
            "bounds": bounds,
        },
    )
    _log.info("Inversion complete: %d iters, final RMSE=%.4f", result.n_iter, result.rmse)
    return result


def invert_from_model(true_model: EarthModel,
                      n_electrodes: int = 24, spacing: float = 5.0,
                      config: str = "wenner",
                      noise: float = 0.02,
                      **kwargs) -> InversionResult:
    """Convenience: generate synthetic data from a true model, then invert it.

    This demonstrates the full loop: forward model -> synthetic data -> inversion -> recovered image.
    """
    geom_fn = dipole_dipole_geometry if config == "dipole-dipole" else wenner_geometry
    geometry = geom_fn(n_electrodes, spacing)
    rng = np.random.default_rng(42)
    readings = forward_ert(true_model, geometry, noise=noise, rng=rng)
    x_max = n_electrodes * spacing
    result = invert_ert(readings, x_min=0.0, x_max=x_max,
                        max_depth=kwargs.pop("max_depth", spacing * n_electrodes / 3),
                        **kwargs)
    result.survey_id = true_model.name
    return result
