"""
petroppo V9 — Physics-coupled Joint ERT / Seismic / GPR Inversion
====================================================================

This module implements *physics-coupled* joint inversion of ERT, seismic
first-arrival travel-times, and GPR reflection travel-times on a single
shared mesh, coupled by the **cross-gradient structural constraint**
(Gallardo & Meju, 2003) — the same coupling method used by pyGIMLi for
structural joint inversion.

Design notes
------------
* The ERT forward operator is the validated V8 ``FDEngine`` (FD DC
  resistivity, secondary-potential formulation, LU-reuse Jacobian).
* The seismic forward operator is a **grid-based straight-ray
  tomography** solver (first-arrival travel-time = sum of cell
  slownesses along a straight ray path), not the layered ray tracer in
  ``hifwd.py``.  This is necessary because joint inversion requires a
  forward operator that is sensitive to *every cell* on the shared mesh,
  and the layered tracer is only sensitive to layer interfaces.  The
  straight-ray tomographic model is the standard formulation used in
  travel-time tomography joint inversion (e.g. pyGIMLi refraction
  tomography examples).
* The GPR forward operator is likewise a **grid-based travel-time**
  solver using the EM velocity v = c/sqrt(eps) in each cell along a
  vertical (normal-incidence) reflection path; the data are two-way
  reflection travel-times picked at a set of surface CMP points to a
  fixed reflector depth.  This is sensitive to the permittivity of every
  cell above the reflector along the vertical path.
* Coupling: cross-gradient tau = grad(m1) x grad(m2) (the 2D out-of-plane
  scalar) between each method pair, linearised at each Gauss-Newton
  iteration, with an annealed coupling weight lambda_cg (0 -> 1).

The result is a single shared 2D earth model (resistivity, slowness,
permittivity) whose structural boundaries are consistent across all
three methods without forcing the values to agree — preserving the
independence of evidence that the roadmap demands.

The module is structured in three test-gated sub-stages:
    V9.1 — JointMesh + ERT engine refactor (de-risk)
    V9.2 — two-method joint (ERT + Seismic)
    V9.3 — three-method joint (ERT + Seismic + GPR) + full V9 gate
"""

from __future__ import annotations

import numpy as np
import logging
from dataclasses import dataclass, field
from typing import Optional

_log = logging.getLogger("petroppo.v9.joint")

# Heavy imports deferred / local to keep import-time light.
# V8 engine import:
from .v8_inversion import (
    InversionGrid, FDEngine, _roughness_matrix, _depth_weight,
    _huber_weights, _assemble_laplacian,
)


# =====================================================================
# JointMesh — shared 2-D mesh for all methods
# =====================================================================

class JointMesh(InversionGrid):
    """Shared 2-D rectangular inversion mesh.

    Identical geometry to ``InversionGrid`` (so the V8 ERT engine runs on
    it unchanged) but carries the per-method parameter stacks and the
    petrophysical mappings needed for joint inversion.

    Parameters live as flat log-parameter vectors ordered method-major:
        m = [ log_rho (n_cells) , log_slowness (n_cells) , log_eps (n_cells) ]
    The number of active methods determines how many blocks are present.
    """

    def __init__(self, x_min, x_max, max_depth, n_x=20, n_z=10,
                 methods=("ert", "seismic", "gpr")):
        super().__init__(x_min, x_max, max_depth, n_x, n_z)
        self.methods = tuple(methods)
        self.n_per = {m: self.n_cells for m in self.methods}
        self.n_blocks = len(self.methods)
        self.n_total = self.n_blocks * self.n_cells
        # block offsets
        self.off = {}
        o = 0
        for m in self.methods:
            self.off[m] = o
            o += self.n_cells

    # ---- block accessors -------------------------------------------------
    def block(self, m, model_flat):
        return model_flat[self.off[m]:self.off[m] + self.n_cells]

    def assemble(self, *blocks):
        """Reassemble a full model vector from per-method blocks."""
        assert len(blocks) == self.n_blocks, \
            f"expected {self.n_blocks} blocks, got {len(blocks)}"
        out = np.empty(self.n_total)
        for m, b in zip(self.methods, blocks):
            out[self.off[m]:self.off[m] + self.n_cells] = b
        return out


# =====================================================================
# Cross-gradient coupling
# =====================================================================

def _cell_gradient_matrix(grid):
    """Sparse (centred-difference) horizontal & vertical gradient operators
    on the inversion cells, returning (Gx, Gz) each shape (n_cells, n_cells)
    acting on a flat (ix-major, iz-minor) model vector (matches
    InversionGrid.cell_index ordering ix*n_z + iz)."""
    n = grid.n_cells
    Gx = np.zeros((n, n))
    Gz = np.zeros((n, n))
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            # horizontal (x) centred difference
            if 0 < ix < grid.n_x - 1:
                Gx[idx, grid.cell_index(ix + 1, iz)] = 0.5 / grid.dx
                Gx[idx, grid.cell_index(ix - 1, iz)] = -0.5 / grid.dx
            elif ix == 0:
                Gx[idx, grid.cell_index(1, iz)] = 1.0 / grid.dx
                Gx[idx, grid.cell_index(0, iz)] = -1.0 / grid.dx
            else:
                Gx[idx, grid.cell_index(ix, iz)] = -1.0 / grid.dx
                Gx[idx, grid.cell_index(ix - 1, iz)] = 1.0 / grid.dx
            # vertical (z) centred difference
            if 0 < iz < grid.n_z - 1:
                Gz[idx, grid.cell_index(ix, iz + 1)] = 0.5 / grid.dz
                Gz[idx, grid.cell_index(ix, iz - 1)] = -0.5 / grid.dz
            elif iz == 0:
                Gz[idx, grid.cell_index(ix, 1)] = 1.0 / grid.dz
                Gz[idx, grid.cell_index(ix, 0)] = -1.0 / grid.dz
            else:
                Gz[idx, grid.cell_index(ix, iz)] = -1.0 / grid.dz
                Gz[idx, grid.cell_index(ix, iz - 1)] = 1.0 / grid.dz
    return Gx, Gz


def cross_gradient(m_a, m_b, grid, Gx=None, Gz=None):
    """2-D cross-gradient (out-of-plane scalar) of two property fields.

    tau_i = (dm_a/dx)_i * (dm_b/dz)_i - (dm_a/dz)_i * (dm_b/dx)_i

    Returns a per-cell vector (length n_cells).  tau -> 0 where the two
    fields share a structural boundary (parallel gradients); large where
    their structures disagree.
    """
    if Gx is None or Gz is None:
        Gx, Gz = _cell_gradient_matrix(grid)
    gx_a = Gx @ m_a
    gz_a = Gz @ m_a
    gx_b = Gx @ m_b
    gz_b = Gz @ m_b
    return gx_a * gz_b - gz_a * gx_b


def cross_gradient_jacobians(m_a, m_b, grid, Gx=None, Gz=None):
    """Linearised Jacobians of the cross-gradient w.r.t. each field.

    tau = gx_a*gz_b - gz_a*gx_b
    d tau / d m_a = Gx_diag(gz_b) - Gz_diag(gx_b)   -> (n_cells x n_cells)
    d tau / d m_b = Gz_diag(gx_a) - Gx_diag(gz_a)   -> (n_cells x n_cells)
    """
    if Gx is None or Gz is None:
        Gx, Gz = _cell_gradient_matrix(grid)
    gx_a = Gx @ m_a
    gz_a = Gz @ m_a
    gx_b = Gx @ m_b
    gz_b = Gz @ m_b
    J_a = np.diag(gz_b) @ Gx - np.diag(gx_b) @ Gz
    J_b = np.diag(gx_a) @ Gz - np.diag(gz_a) @ Gx
    return J_a, J_b


# =====================================================================
# Seismic forward: straight-ray travel-time tomography
# =====================================================================

@dataclass
class SeismicSurvey:
    """Shot-receiver geometry for travel-time tomography.

    shots: array of source x-positions (surface)
    receivers: array of receiver x-positions (surface)
    picks: (n_shots, n_receivers) first-arrival travel times (s)
    """
    shots: np.ndarray
    receivers: np.ndarray
    picks: np.ndarray
    noise_floor: float = 0.005  # s


def _ray_paths(shots, receivers, grid):
    """Straight-ray paths through the cell mesh.

    Returns a list of (cells, seg_lengths) for each shot-receiver pair,
    where a straight segment from shot (surface) to receiver (surface)
    is traced and the intersection length with each cell is accumulated.

    For a surface-to-surface straight ray that dips to a max depth, we
    use a simple midpoint-dip parametrisation: the ray is a V-shaped path
    reaching a maximum depth proportional to the offset (a common
    first-approximation in travel-time tomography).  This gives every
    subsurface cell a chance to be sampled, which is what joint inversion
    needs for a non-degenerate Jacobian.
    """
    paths = []
    max_d = grid.max_depth
    for sx in shots:
        for rx in receivers:
            off = abs(rx - sx)
            if off < 1e-6:
                # zero-offset: vertical ray to a small depth and back
                depth = min(grid.dz * 2, max_d)
                cells, lens = _vertical_path((sx + rx) / 2.0, depth, grid)
                paths.append((cells, lens))
                continue
            # V-shaped ray: down from shot to nadir, up to receiver
            nadir_x = (sx + rx) / 2.0
            nadir_z = min(0.5 * off, 0.9 * max_d)
            c1, l1 = _straight_segment(sx, 0.0, nadir_x, nadir_z, grid)
            c2, l2 = _straight_segment(nadir_x, nadir_z, rx, 0.0, grid)
            # merge
            cells = c1 + c2
            lens = l1 + l2
            paths.append((cells, lens))
    return paths


def _straight_segment(x0, z0, x1, z1, grid):
    """Trace a straight segment through the grid, accumulating (cell_idx, length)."""
    n_steps = 200
    xs = np.linspace(x0, x1, n_steps)
    zs = np.linspace(z0, z1, n_steps)
    step_len = np.hypot(x1 - x0, z1 - z0) / (n_steps - 1)
    cells = []
    lens = []
    prev_idx = None
    run = 0.0
    for k in range(n_steps):
        ix = int((xs[k] - grid.x_min) / grid.dx)
        iz = int(zs[k] / grid.dz)
        ix = min(max(ix, 0), grid.n_x - 1)
        iz = min(max(iz, 0), grid.n_z - 1)
        idx = grid.cell_index(ix, iz)
        if idx == prev_idx:
            run += step_len
        else:
            if prev_idx is not None and run > 0:
                cells.append(prev_idx)
                lens.append(run)
            prev_idx = idx
            run = step_len
    if prev_idx is not None and run > 0:
        cells.append(prev_idx)
        lens.append(run)
    return cells, lens


def _vertical_path(x, depth, grid):
    cells, lens = _straight_segment(x, 0.0, x, depth, grid)
    return cells, lens


class SeismicForward:
    """Straight-ray travel-time tomography on the shared mesh.

    Forward: t_pred = sum over cells of (slowness_cell * ray_length_in_cell)
    Jacobian: d t / d log_slowness_j = slowness_j * ray_length_j  (diagonal-ish)
    """

    def __init__(self, survey, grid):
        self.survey = survey
        self.grid = grid
        self.paths = _ray_paths(np.asarray(survey.shots),
                                np.asarray(survey.receivers), grid)
        self.n_data = len(self.paths)
        # precompute path sparse matrix (n_data x n_cells) of lengths
        P = np.zeros((self.n_data, grid.n_cells))
        for i, (cells, lens) in enumerate(self.paths):
            for c, ln in zip(cells, lens):
                P[i, c] += ln
        self.P = P  # path-length matrix

    def forward(self, log_slowness_block):
        slowness = np.exp(log_slowness_block)
        return self.P @ slowness

    def jacobian(self, log_slowness_block):
        slowness = np.exp(log_slowness_block)
        # d t / d log_s = s * P  (since t = P @ s, d t/d s = P, d s/d log s = s)
        return self.P * slowness[np.newaxis, :]


# =====================================================================
# GPR forward: normal-incidence vertical travel-time tomography
# =====================================================================

@dataclass
class GPRSurvey:
    """CMP points and picked two-way travel times to a fixed reflector."""
    cmp_points: np.ndarray        # surface x positions
    twt_picks: np.ndarray         # two-way travel times (s)
    reflector_depth: float        # depth of the target reflector (m)
    noise_floor: float = 1e-9     # s


class GPRForward:
    """Normal-incidence vertical travel-time tomography on the shared mesh.

    For each CMP point, the two-way travel time to ``reflector_depth`` is
        twt = 2 * sum_{cells in vertical column at x} (slowness_em * cell_dz)
    where EM slowness = sqrt(eps)/c.  Each cell above the reflector in the
    CMP's column is sampled, so the Jacobian w.r.t. log(eps) is dense
    within the column.
    """
    C = 2.998e8

    def __init__(self, survey, grid):
        self.survey = survey
        self.grid = grid
        cmp = np.asarray(survey.cmp_points)
        self.n_data = len(cmp)
        # column cell indices per CMP, plus dz
        cols = []
        for x in cmp:
            ix = int((x - grid.x_min) / grid.dx)
            ix = min(max(ix, 0), grid.n_x - 1)
            cells = [grid.cell_index(ix, iz)
                     for iz in range(grid.n_z)
                     if (iz + 0.5) * grid.dz < survey.reflector_depth]
            cols.append(cells)
        self.cols = cols
        # sparse matrix of dz weights
        P = np.zeros((self.n_data, grid.n_cells))
        for i, cells in enumerate(cols):
            for c in cells:
                P[i, c] = 2.0 * grid.dz / self.C  # factor for sqrt(eps)*dz/c
        self.P = P

    def forward(self, log_eps_block):
        eps = np.exp(log_eps_block)
        sqrt_eps = np.sqrt(eps)
        return self.P @ sqrt_eps

    def jacobian(self, log_eps_block):
        eps = np.exp(log_eps_block)
        sqrt_eps = np.sqrt(eps)
        # d twt / d log_eps = P @ (0.5 * sqrt_eps)  (chain rule)
        return self.P * (0.5 * sqrt_eps[np.newaxis, :])


# =====================================================================
# Joint inversion driver
# =====================================================================

@dataclass
class JointResult:
    survey_id: str
    resistivity: np.ndarray   # (n_x, n_z) Ohm.m
    slowness: np.ndarray      # (n_x, n_z) s/m  (None if no seismic)
    velocity: np.ndarray      # (n_x, n_z) m/s  (None if no seismic)
    permittivity: np.ndarray  # (n_x, n_z)      (None if no GPR)
    methods: tuple
    rmse: dict               # per-method final RMSE
    n_iter: int
    meta: dict = field(default_factory=dict)


def invert_joint_v9(
    mesh, base_model,
    ert_geometry=None, ert_obs_rho=None,
    seismic_survey=None, gpr_survey=None,
    *,
    ert_config=None, ref_resistivity=None,
    lambda_init=2.5, lambda_decay=0.65, lambda_min=1e-3,
    lambda_cg_init=0.0, lambda_cg_final=1.0, lambda_cg_ramp_iters=4,
    max_iter=12, robust=True, depth_weight_beta=1.0,
    jacobian_every=2, noise_floor_ert=0.02,
    cg_pairs=None, initial_model=None,
):
    """Physics-coupled joint ERT/Seismic/GPR inversion (V9).

    Runs a block Gauss-Newton over the stacked parameter vector with
    per-method data misfits, per-method smoothness+depth-weighting
    regularisation, and cross-gradient structural coupling between the
    configured method pairs.

    Parameters
    ----------
    mesh : JointMesh
    ert_geometry, ert_obs_rho : ERT survey (Wenner geometry + apparent rho)
    seismic_survey : SeismicSurvey or None
    gpr_survey : GPRSurvey or None
    ert_config : dict with fd_nx, fd_nz for the ERT FD engine
    cg_pairs : list of method pairs to couple, e.g. [('ert','seismic')].
               Default couples all available pairs.
    """
    methods = list(mesh.methods)
    ert_cfg = ert_config or dict(fd_nx=60, fd_nz=30)

    # ---- determine active methods & data -------------------------------
    active = []
    if ert_geometry is not None and ert_obs_rho is not None:
        active.append("ert")
    if seismic_survey is not None:
        active.append("seismic")
    if gpr_survey is not None:
        active.append("gpr")
    if not active:
        raise ValueError("invert_joint_v9: no active method data supplied")

    # ---- cross-gradient pairs among active methods ---------------------
    if cg_pairs is None:
        cg_pairs = []
        for i in range(len(active)):
            for j in range(i + 1, len(active)):
                cg_pairs.append((active[i], active[j]))

    # ---- reference / starting models -----------------------------------
    if ref_resistivity is None:
        ref_resistivity = base_model.background_resistivity

    # ERT start: layered background log-rho
    log_rho0 = np.full(mesh.n_cells, np.log(ref_resistivity))
    for ix in range(mesh.n_x):
        cx = mesh.xc[ix]
        for iz in range(mesh.n_z):
            cz = mesh.zc[iz]
            lay = base_model.layer_at(cz)
            if lay is not None and lay.resistivity:
                log_rho0[mesh.cell_index(ix, iz)] = np.log(lay.resistivity)

    # Seismic start: layer velocities -> slowness
    log_slow0 = None
    if "seismic" in active:
        # default velocities per depth: use layer vp if present else 2000
        slow0 = np.full(mesh.n_cells, 1.0 / 2000.0)
        for ix in range(mesh.n_x):
            for iz in range(mesh.n_z):
                cz = mesh.zc[iz]
                lay = base_model.layer_at(cz)
                vp = lay.vp if (lay and lay.vp) else 2000.0
                slow0[mesh.cell_index(ix, iz)] = 1.0 / vp
        log_slow0 = np.log(slow0)

    # GPR start: layer permittivity
    log_eps0 = None
    if "gpr" in active:
        eps0 = np.full(mesh.n_cells, 6.0)
        for ix in range(mesh.n_x):
            for iz in range(mesh.n_z):
                cz = mesh.zc[iz]
                lay = base_model.layer_at(cz)
                eps = lay.dielectric if (lay and lay.dielectric) else 6.0
                eps0[mesh.cell_index(ix, iz)] = eps
        log_eps0 = np.log(eps0)

    # assemble initial full model
    blocks0 = []
    for m in mesh.methods:
        if m == "ert":
            blocks0.append(log_rho0.copy())
        elif m == "seismic":
            blocks0.append(log_slow0.copy() if log_slow0 is not None
                           else np.zeros(mesh.n_cells))
        elif m == "gpr":
            blocks0.append(log_eps0.copy() if log_eps0 is not None
                           else np.zeros(mesh.n_cells))
    model = mesh.assemble(*blocks0)
    # allow caller to override the starting model (e.g. homogeneous ERT start)
    if initial_model is not None:
        im = np.asarray(initial_model, dtype=float).ravel()
        if im.shape[0] == mesh.n_total:
            model = im.copy()
        elif im.shape[0] == mesh.n_cells:
            # single-block: treat as ERT block, keep other blocks from default
            model = model.copy()
            model[mesh.off["ert"]:mesh.off["ert"] + mesh.n_cells] = im
        else:
            _log.warning("initial_model shape %s does not match n_total=%d or "
                         "n_cells=%d; ignoring", im.shape, mesh.n_total, mesh.n_cells)
    m_ref = model.copy()

    # ---- per-method regularisation -------------------------------------
    Wm = _roughness_matrix(mesh)
    dw = _depth_weight(mesh, beta=depth_weight_beta)
    if Wm.shape[0] > 0:
        Wm_dw = Wm * dw[np.newaxis, :]
        WmT_Wm = Wm_dw.T @ Wm_dw
    else:
        WmT_Wm = np.zeros((mesh.n_cells, mesh.n_cells))

    # block-diagonal regularisation over all methods
    nT = mesh.n_total
    Reg = np.zeros((nT, nT))
    for m in mesh.methods:
        o = mesh.off[m]
        Reg[o:o + mesh.n_cells, o:o + mesh.n_cells] = WmT_Wm

    # ---- forward operators ---------------------------------------------
    ert_engine = None
    seis_fwd = None
    gpr_fwd = None
    if "ert" in active:
        ert_engine = FDEngine(base_model, ert_geometry,
                              fd_nx=ert_cfg.get("fd_nx", 60),
                              fd_nz=ert_cfg.get("fd_nz", 30))
    if "seismic" in active:
        seis_fwd = SeismicForward(seismic_survey, mesh)
    if "gpr" in active:
        gpr_fwd = GPRForward(gpr_survey, mesh)

    # data targets (log-space for ERT; linear for seismic/gpr)
    ert_obs_log = np.log(np.maximum(ert_obs_rho, 1e-6)) if "ert" in active else None
    seis_obs = np.asarray(seismic_survey.picks).ravel() if "seismic" in active else None
    gpr_obs = np.asarray(gpr_survey.twt_picks).ravel() if "gpr" in active else None

    sig_ert = float(noise_floor_ert)
    sig_seis = seismic_survey.noise_floor if seismic_survey else 1e-3
    sig_gpr = gpr_survey.noise_floor if gpr_survey else 1e-9

    # gradient matrices (cached) for cross-gradient
    Gx, Gz = _cell_gradient_matrix(mesh)

    lam = lambda_init
    lam_cg = lambda_cg_init
    rmse_prev = np.inf
    J_blocks = {m: None for m in active}
    it = 0

    for it in range(1, max_iter + 1):
        # ---- per-method residuals + Jacobians --------------------------
        resid_blocks = {}
        for m in active:
            o = mesh.off[m]
            blk = model[o:o + mesh.n_cells]
            if m == "ert":
                ert_engine.factorize(blk, mesh)
                pred = np.maximum(ert_engine.forward(), 1e-6)
                resid_blocks[m] = ert_obs_log - np.log(pred)
            elif m == "seismic":
                pred = seis_fwd.forward(blk)
                resid_blocks[m] = seis_obs - pred
            elif m == "gpr":
                pred = gpr_fwd.forward(blk)
                resid_blocks[m] = gpr_obs - pred

        # robust weights (use ERT residuals mainly; others L2)
        irls_ert = _huber_weights(resid_blocks["ert"], 1.345) if "ert" in active \
            else np.ones(1)

        need_jac = (it == 1) or ((it - 1) % jacobian_every == 0)
        if need_jac:
            for m in active:
                o = mesh.off[m]
                blk = model[o:o + mesh.n_cells]
                if m == "ert":
                    _log.info("Iter %d: ERT LU-Jacobian (%d cells)", it, mesh.n_cells)
                    J_blocks[m] = ert_engine.jacobian(blk, mesh, delta=0.1)
                elif m == "seismic":
                    J_blocks[m] = seis_fwd.jacobian(blk)
                elif m == "gpr":
                    J_blocks[m] = gpr_fwd.jacobian(blk)

        # ---- assemble block normal equations ---------------------------
        # Build full J (n_data_total x nT) and Wd, b
        data_chunks = []
        J_chunks = []
        Wd_chunks = []
        for m in active:
            o = mesh.off[m]
            Jm = J_blocks[m]
            rm = resid_blocks[m]
            nd = len(rm)
            # place Jm in its block column
            Jfull = np.zeros((nd, nT))
            Jfull[:, o:o + mesh.n_cells] = Jm
            J_chunks.append(Jfull)
            data_chunks.append(rm)
            if m == "ert":
                w = irls_ert / sig_ert
            elif m == "seismic":
                w = np.ones(nd) / sig_seis
            elif m == "gpr":
                w = np.ones(nd) / sig_gpr
            Wd_chunks.append(w)

        J_big = np.vstack(J_chunks)
        r_big = np.concatenate(data_chunks)
        Wd_big = np.concatenate(Wd_chunks)
        Wd_mat = np.diag(Wd_big)

        # ---- cross-gradient coupling (linearised) ----------------------
        # For each pair, append tau rows to the system.
        cg_rows = []
        cg_J = []
        cg_w = []
        if lam_cg > 0:
            for (ma, mb) in cg_pairs:
                oa = mesh.off[ma]; ob = mesh.off[mb]
                ba = model[oa:oa + mesh.n_cells]
                bb = model[ob:ob + mesh.n_cells]
                tau = cross_gradient(ba, bb, mesh, Gx, Gz)
                Ja, Jb = cross_gradient_jacobians(ba, bb, mesh, Gx, Gz)
                Jrow = np.zeros((mesh.n_cells, nT))
                Jrow[:, oa:oa + mesh.n_cells] = Ja
                Jrow[:, ob:ob + mesh.n_cells] = Jb
                # ---- normalise cross-gradient rows to unit RMS per cell ----
                # Without normalisation the tau magnitude (~1e-3) is negligible
                # vs the data residuals (~1-5), so the coupling has no effect.
                # Normalising by RMS(tau) makes the CG rows unit-scale, so
                # lam_cg directly controls the data/structure trade-off.
                tau_rms = np.sqrt(np.mean(tau ** 2)) if len(tau) > 0 else 1.0
                if tau_rms < 1e-12:
                    tau_rms = 1.0  # avoid div-by-zero on flat models
                tau_norm = tau / tau_rms
                Jrow_norm = Jrow / tau_rms  # scale Jacobian rows identically
                cg_rows.append(tau_norm)
                cg_J.append(Jrow_norm)
                # coupling weight scales the (normalised) structural rows
                cg_w.append(np.ones(mesh.n_cells) * np.sqrt(lam_cg))

        if cg_rows:
            J_cg = np.vstack(cg_J)
            tau_big = np.concatenate(cg_rows)
            w_cg = np.concatenate(cg_w)
            J_full = np.vstack([J_big, J_cg])
            Wd_full = np.diag(np.concatenate([Wd_big, w_cg]))
            r_full = np.concatenate([r_big, -tau_big])  # minimise ||tau||
        else:
            J_full = J_big
            Wd_full = Wd_mat
            r_full = r_big

        # ---- Gauss-Newton step -----------------------------------------
        JtWd = J_full.T @ Wd_full
        A = JtWd @ Wd_full @ J_full + lam * Reg + 1e-6 * np.eye(nT)
        rhs = JtWd @ Wd_full @ r_full
        try:
            dm = np.linalg.solve(A, rhs)
        except np.linalg.LinAlgError:
            dm = np.linalg.lstsq(A, rhs, rcond=None)[0]

        m_dm = np.max(np.abs(dm))
        if m_dm > 0.6:
            dm = dm * (0.6 / m_dm)

        # ---- line search (ERT data misfit primary) ---------------------
        accepted = False
        rmse_t_prev = rmse_prev
        for alpha in (1.0, 0.5, 0.25, 0.1):
            m_trial = model + alpha * dm
            # clip per-method bounds
            for m in mesh.methods:
                o = mesh.off[m]
                if m == "ert":
                    m_trial[o:o + mesh.n_cells] = np.clip(
                        m_trial[o:o + mesh.n_cells], np.log(1.0), np.log(5000.0))
                elif m == "seismic":
                    # velocity 500..6000 -> slowness 1/6000..1/500
                    m_trial[o:o + mesh.n_cells] = np.clip(
                        m_trial[o:o + mesh.n_cells], np.log(1 / 6000.0),
                        np.log(1 / 500.0))
                elif m == "gpr":
                    m_trial[o:o + mesh.n_cells] = np.clip(
                        m_trial[o:o + mesh.n_cells], np.log(1.0), np.log(80.0))
            # compute combined RMSE (data + cross-gradient penalty)
            rmse_t = _combined_rmse(m_trial, mesh, active, ert_engine,
                                    seis_fwd, gpr_fwd,
                                    ert_obs_log, seis_obs, gpr_obs,
                                    sig_ert, sig_seis, sig_gpr, robust,
                                    cg_pairs=cg_pairs if lam_cg > 0 else None,
                                    lam_cg=lam_cg, Gx=Gx, Gz=Gz)
            if rmse_t < rmse_t_prev:
                model = m_trial
                rmse_prev = rmse_t
                accepted = True
                _log.info("Iter %d: combined RMSE=%.4f (alpha=%.2f, lam=%.3f, lam_cg=%.3f)",
                          it, rmse_t, alpha, lam, lam_cg)
                break

        if accepted:
            lam = max(lam * lambda_decay, lambda_min)
            # anneal cross-gradient weight toward final
            if it <= lambda_cg_ramp_iters:
                lam_cg = lambda_cg_init + (lambda_cg_final - lambda_cg_init) * (it / lambda_cg_ramp_iters)
            else:
                lam_cg = lambda_cg_final
        else:
            lam = lam / lambda_decay
            _log.info("Iter %d: rejected, lam -> %.3f", it, lam)
            if lam > 1e6:
                break

    # ---- final results -------------------------------------------------
    out = {}
    rmse_dict = {}
    for m in active:
        o = mesh.off[m]
        blk = model[o:o + mesh.n_cells]
        g2d = mesh.model_to_2d(np.exp(blk))
        if m == "ert":
            ert_engine.factorize(blk, mesh)
            pred = np.maximum(ert_engine.forward(), 1e-6)
            rmse_dict["ert"] = float(np.sqrt(np.mean((ert_obs_rho - pred) ** 2)))
            out["resistivity"] = g2d
        elif m == "seismic":
            pred = seis_fwd.forward(blk)
            rmse_dict["seismic"] = float(np.sqrt(np.mean((seis_obs - pred) ** 2)))
            out["slowness"] = g2d
            out["velocity"] = 1.0 / g2d
        elif m == "gpr":
            pred = gpr_fwd.forward(blk)
            rmse_dict["gpr"] = float(np.sqrt(np.mean((gpr_obs - pred) ** 2)))
            out["permittivity"] = g2d

    return JointResult(
        survey_id="v9_joint",
        resistivity=out.get("resistivity"),
        slowness=out.get("slowness"),
        velocity=out.get("velocity"),
        permittivity=out.get("permittivity"),
        methods=tuple(active),
        rmse=rmse_dict,
        n_iter=it,
        meta=dict(lambda_final=lam, lambda_cg_final=lam_cg,
                  cg_pairs=cg_pairs, max_iter=max_iter),
    )


def _combined_rmse(model, mesh, active, ert_engine, seis_fwd, gpr_fwd,
                   ert_obs_log, seis_obs, gpr_obs,
                   sig_ert, sig_seis, sig_gpr, robust,
                   cg_pairs=None, lam_cg=0.0, Gx=None, Gz=None):
    """Weighted combined data-misfit RMSE across active methods,
    optionally including the normalised cross-gradient penalty."""
    terms = []
    for m in active:
        o = mesh.off[m]
        blk = model[o:o + mesh.n_cells]
        if m == "ert":
            ert_engine.factorize(blk, mesh)
            pred = np.maximum(ert_engine.forward(), 1e-6)
            r = ert_obs_log - np.log(pred)
            if robust:
                w = _huber_weights(r, 1.345)
            else:
                w = np.ones(len(r))
            terms.append(np.sqrt(np.mean((w * r / sig_ert) ** 2)))
        elif m == "seismic":
            pred = seis_fwd.forward(blk)
            r = seis_obs - pred
            terms.append(np.sqrt(np.mean((r / sig_seis) ** 2)))
        elif m == "gpr":
            pred = gpr_fwd.forward(blk)
            r = gpr_obs - pred
            terms.append(np.sqrt(np.mean((r / sig_gpr) ** 2)))
    data_rmse = float(np.sqrt(np.mean(np.array(terms) ** 2)))
    # add normalised cross-gradient penalty
    if lam_cg > 0 and cg_pairs:
        cg_terms = []
        for (ma, mb) in cg_pairs:
            oa = mesh.off[ma]; ob = mesh.off[mb]
            ba = model[oa:oa + mesh.n_cells]
            bb = model[ob:ob + mesh.n_cells]
            tau = cross_gradient(ba, bb, mesh, Gx, Gz)
            tau_rms = np.sqrt(np.mean(tau ** 2)) if len(tau) > 0 else 1.0
            if tau_rms < 1e-12:
                tau_rms = 1.0
            # normalised tau RMS (unit scale) * sqrt(lam_cg)
            cg_terms.append(np.sqrt(np.mean((tau / tau_rms) ** 2)) * np.sqrt(lam_cg))
        cg_rmse = float(np.sqrt(np.mean(np.array(cg_terms) ** 2)))
        return float(np.sqrt(data_rmse ** 2 + cg_rmse ** 2))
    return data_rmse


# =====================================================================
# Synthetic multi-physics survey generators (for the V9 benchmark)
# =====================================================================

def make_joint_synthetic_field(mesh, base_model,
                               reservoir_x, reservoir_z, reservoir_w,
                               reservoir_h,
                               reservoir_rho=700.0,
                               reservoir_vp=3500.0,
                               reservoir_eps=12.0,
                               background_vp_layer=None,
                               background_eps_layer=None):
    """Build truth property cubes on the shared mesh for joint testing.

    Returns dict with 'rho','velocity','eps' (n_x,n_z) arrays and the
    truth-label grid (1 inside reservoir, 0 outside).
    """
    X, Z = np.meshgrid(mesh.xc, mesh.zc, indexing="ij")
    # base layered resistivity
    rho = np.full_like(X, base_model.background_resistivity, dtype=float)
    vel = np.full_like(X, 2000.0, dtype=float)
    eps = np.full_like(X, 6.0, dtype=float)
    for ix in range(mesh.n_x):
        cx = mesh.xc[ix]
        for iz in range(mesh.n_z):
            cz = mesh.zc[iz]
            lay = base_model.layer_at(cz)
            if lay is not None:
                if lay.resistivity:
                    rho[ix, iz] = lay.resistivity
                if lay.vp:
                    vel[ix, iz] = lay.vp
                if lay.dielectric:
                    eps[ix, iz] = lay.dielectric
    # inject reservoir anomaly
    in_res = ((np.abs(X - reservoir_x) <= reservoir_w / 2.0) &
              (np.abs(Z - reservoir_z) <= reservoir_h / 2.0))
    rho = np.where(in_res, reservoir_rho, rho)
    vel = np.where(in_res, reservoir_vp, vel)
    eps = np.where(in_res, reservoir_eps, eps)
    return dict(rho=rho, velocity=vel, eps=eps,
                truth=in_res.astype(float))


def forward_seismic_truth(velocity_grid, mesh, shots, receivers, noise=0.0, rng=None):
    """Generate seismic picks from a truth velocity cube via straight rays."""
    if rng is None:
        rng = np.random.default_rng()
    slowness = 1.0 / velocity_grid.ravel(order="C")
    # careful: velocity_grid is (n_x,n_z) but mesh indexing is ix*n_z+iz
    # so ravel('C') matches ix-major -> correct.
    paths = _ray_paths(np.asarray(shots), np.asarray(receivers), mesh)
    picks = np.zeros(len(shots) * len(receivers))
    for si, sx in enumerate(shots):
        for ri, rx in enumerate(receivers):
            idx = si * len(receivers) + ri
            cells, lens = paths[idx]
            t = sum(slowness[c] * ln for c, ln in zip(cells, lens))
            picks[idx] = t
    if noise > 0:
        picks += rng.normal(0, noise, picks.shape)
    picks = np.maximum(picks, 1e-5)  # ensure positive travel times
    return picks


def forward_gpr_truth(eps_grid, mesh, cmp_points, reflector_depth, noise=0.0, rng=None):
    """Generate GPR two-way picks from a truth permittivity cube."""
    if rng is None:
        rng = np.random.default_rng()
    C = 2.998e8
    sqrt_eps = np.sqrt(eps_grid)
    picks = np.zeros(len(cmp_points))
    for i, x in enumerate(cmp_points):
        ix = int((x - mesh.x_min) / mesh.dx)
        ix = min(max(ix, 0), mesh.n_x - 1)
        t = 0.0
        for iz in range(mesh.n_z):
            cz = (iz + 0.5) * mesh.dz
            if cz < reflector_depth:
                t += 2.0 * mesh.dz * sqrt_eps[ix, iz] / C
        picks[i] = t
    if noise > 0:
        picks += rng.normal(0, noise, picks.shape)
    return picks
