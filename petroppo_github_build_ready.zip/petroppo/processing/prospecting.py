"""Multi-physics hydrocarbon prospectivity — fusion engine.

This module implements the quantitative integration of multiple geophysical
methods into a single **hydrocarbon prospectivity map**.  This is the key
workflow that turns petroppo from "a collection of forward models" into "a
tool that can indicate where hydrocarbons are likely to be present".

Why multi-physics?
------------------
No single geophysical method uniquely detects hydrocarbons.  Each method
responds to a different physical property:

* **ERT / IP** — hydrocarbon-bearing rocks are resistive (oil & gas are
  insulators); brine is conductive.  A resistive anomaly at reservoir depth
  is a **necessary but not sufficient** indicator.
* **Gravity** — hydrocarbon reservoirs are often low-density (oil ~ 850 kg/m³
  vs brine ~ 1050 kg/m³); a **negative** gravity anomaly can indicate a
  density deficit.
* **Magnetic** — hydrocarbon reservoirs are typically non-magnetic; a
  **magnetic quiet zone** over a sedimentary basin is consistent with
  hydrocarbon potential, while magnetic highs indicate basement / igneous
  sources.
* **Spectral IP** — high chargeability can indicate clay alteration / pyrite
  above a reservoir (a hydrocarbon "halo").

The :class:`FusionEngine` combines normalised evidence from each method using
**weighted Bayesian-like evidence fusion**::

    P(HC) = 1 - prod_i (1 - w_i * E_i)

where ``E_i`` is the normalised evidence (0..1) from method *i* and ``w_i`` is
the data-quality / reliability weight (0..1).  This is the standard
"probability union" / noisy-OR fusion used in mineral prospectivity mapping
(Porfido et al., Carranza 2015).

The :class:`HydrocarbonIndicator` encodes the geophysical signatures of
hydrocarbon-bearing formations as fuzzy membership functions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core import InversionResult, get_logger

_log = get_logger("processing.prospecting")


# --------------------------------------------------------------------- #
#  Hydrocarbon indicator — fuzzy geophysical signatures                 #
# --------------------------------------------------------------------- #
@dataclass
class HydrocarbonIndicator:
    """Fuzzy membership functions for hydrocarbon geophysical signatures.

    Each function maps a physical property value to a [0, 1] evidence score
    where 1 = "strongly consistent with hydrocarbons" and 0 = "inconsistent".

    The defaults are calibrated against published petroleum-geology ranges:

    * Resistivity: reservoir rocks are 100–2000 Ω·m (sweet spot ~ 500 Ω·m).
    * Density contrast: oil-bearing sand is ~ 200 kg/m³ lighter than brine.
    * Magnetic: sedimentary basins are quiet (< 50 nT anomaly).
    * Chargeability (IP): alteration halo 0.05–0.3 (moderate-high).
    """
    # Resistivity membership (trapezoidal: 0 below 50, 1 at 100-2000, 0 above 5000)
    rho_low: float = 50.0
    rho_plateau_lo: float = 100.0
    rho_plateau_hi: float = 2000.0
    rho_high: float = 5000.0
    # Density contrast membership (negative = lighter = hydrocarbon favour)
    dens_favour: float = -150.0   # most favourable density contrast (kg/m³)
    dens_neutral: float = 0.0
    dens_unfavour: float = 300.0
    # Magnetic anomaly (nT): quiet zones are favourable
    mag_quiet: float = 50.0
    # Chargeability (IP): moderate-high is favourable (alteration halo)
    ip_low: float = 0.03
    ip_high: float = 0.3

    def resistivity_evidence(self, rho: float | np.ndarray) -> float | np.ndarray:
        """Fuzzy membership: high for 100–2000 Ω·m (default petroleum play).

        For low-resistivity plays (e.g. gas-charged brine-saturated
        carbonates), use :meth:`adapt_to_wells` to shift the thresholds
        to the data's actual resistivity range before calling this.
        """
        return self._trapezoid(rho, self.rho_low, self.rho_plateau_lo,
                               self.rho_plateau_hi, self.rho_high)

    def adapt_to_wells(self, resistivity_labels: list[tuple[float, int]],
                       percentile_low: float = 25.0,
                       percentile_high: float = 75.0) -> None:
        """Adapt the resistivity thresholds to the play's actual data range.

        Many real petroleum plays (low-saturation gas, heavy oil, fractured
        carbonates) have resistivity well below the classic 100–2000 Ω·m
        oil-sand range.  This method shifts the trapezoid thresholds to the
        data's own distribution so the indicator can discriminate within
        the play's resistivity range.

        Parameters
        ----------
        resistivity_labels : list of (resistivity_ohm_m, label)
            Resistivity values paired with 1=producing / 0=dry labels.
        percentile_low, percentile_high : float
            Percentiles of the *producing-well* resistivity distribution
            used to set the plateau bounds.

        After adaptation, ``resistivity_evidence`` maps the play's
        resistivity range to [0, 1] evidence instead of returning 0 for
        all values below 50 Ω·m.
        """
        res_pos = np.array([r for r, l in resistivity_labels
                            if l == 1 and np.isfinite(r) and r > 0])
        res_neg = np.array([r for r, l in resistivity_labels
                            if l == 0 and np.isfinite(r) and r > 0])
        if res_pos.size < 2 or res_neg.size < 1:
            return  # not enough data to adapt

        # Use log-space for robust percentile estimation
        log_pos = np.log10(res_pos)
        log_neg = np.log10(res_neg)

        p_lo = float(np.percentile(log_pos, percentile_low))
        p_hi = float(np.percentile(log_pos, percentile_high))
        neg_med = float(np.median(log_neg))
        pos_med = float(np.median(log_pos))

        # Plateau: from the 25th to 75th percentile of producing-well R
        plateau_lo = 10 ** p_lo
        plateau_hi = 10 ** p_hi
        # Ramp starts below the dry-well median (so dry wells → low evidence)
        # and ends above the producing-well 75th percentile
        rho_low = 10 ** (min(neg_med, p_lo) - 0.1)
        rho_high = 10 ** (p_hi + 0.5)

        self.rho_low = rho_low
        self.rho_plateau_lo = plateau_lo
        self.rho_plateau_hi = plateau_hi
        self.rho_high = rho_high

        _log.info("Adaptive resistivity indicator: plateau %.2f–%.2f Ω·m, "
                   "ramp %.2f–%.2f Ω·m", plateau_lo, plateau_hi,
                   rho_low, rho_high)

    def density_evidence(self, d_rho: float | np.ndarray) -> float | np.ndarray:
        """Fuzzy membership: high for negative density contrast (light oil)."""
        # map: most favourable at dens_favour, zero at dens_unfavour
        if np.isscalar(d_rho) or isinstance(d_rho, (int, float)):
            x = float(d_rho)
        else:
            x = np.asarray(d_rho)
        # Linear ramp: 1 at dens_favour, 0 at dens_neutral (and negative beyond)
        ev = np.clip((self.dens_neutral - x) /
                     (self.dens_neutral - self.dens_favour), 0.0, 1.0)
        return float(ev) if np.isscalar(d_rho) else ev

    def magnetic_evidence(self, anomaly_nt: float | np.ndarray) -> float | np.ndarray:
        """Fuzzy membership: high for quiet (low-anomaly) zones."""
        if np.isscalar(anomaly_nt) or isinstance(anomaly_nt, (int, float)):
            x = abs(float(anomaly_nt))
        else:
            x = np.abs(np.asarray(anomaly_nt))
        ev = np.clip(1.0 - x / self.mag_quiet, 0.0, 1.0)
        return float(ev) if np.isscalar(anomaly_nt) else ev

    def chargeability_evidence(self, m: float | np.ndarray) -> float | np.ndarray:
        """Fuzzy membership: high for moderate chargeability (alteration halo)."""
        return self._trapezoid(m, 0.0, self.ip_low, self.ip_high, 1.0)

    @staticmethod
    def _trapezoid(x, a, b, c, d):
        """Trapezoidal membership function."""
        if np.isscalar(x) or isinstance(x, (int, float)):
            x = float(x)
            if x <= a or x >= d:
                return 0.0
            if b <= x <= c:
                return 1.0
            if a < x < b:
                return (x - a) / (b - a)
            return (d - x) / (d - c)
        x = np.asarray(x, dtype=float)
        out = np.zeros_like(x)
        out = np.where((x > a) & (x < b), (x - a) / (b - a), out)
        out = np.where((x >= b) & (x <= c), 1.0, out)
        out = np.where((x > c) & (x < d), (d - x) / (d - c), out)
        return out


# --------------------------------------------------------------------- #
#  Prospectivity map                                                    #
# --------------------------------------------------------------------- #
@dataclass
class ProspectivityMap:
    """A 2-D hydrocarbon prospectivity map.

    Attributes
    ----------
    probability : np.ndarray (n_x, n_z)
        Fused hydrocarbon probability [0, 1].
    x_coords, z_coords : np.ndarray
        Cell-centre coordinates.
    contributions : dict[str, np.ndarray]
        Per-method evidence contribution (same shape as probability).
    weights : dict[str, float]
        Reliability weight used for each method.
    indicator : HydrocarbonIndicator
        The fuzzy indicator used.
    meta : dict
    """
    probability: np.ndarray = field(default_factory=lambda: np.empty(0))
    x_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    z_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    contributions: dict[str, np.ndarray] = field(default_factory=dict)
    weights: dict[str, float] = field(default_factory=dict)
    indicator: HydrocarbonIndicator = field(default_factory=HydrocarbonIndicator)
    meta: dict = field(default_factory=dict)

    @property
    def shape(self):
        return self.probability.shape

    def cell_size(self) -> tuple[float, float]:
        if self.x_coords.size > 1:
            dx = float(abs(self.x_coords[1] - self.x_coords[0]))
        else:
            dx = 1.0
        if self.z_coords.size > 1:
            dz = float(abs(self.z_coords[1] - self.z_coords[0]))
        else:
            dz = 1.0
        return dx, dz

    def best_targets(self, n: int = 3, min_prob: float = 0.5) -> list[dict]:
        """Return the top-n prospectivity targets above ``min_prob``."""
        if self.probability.size == 0:
            return []
        nx, nz = self.probability.shape
        # find local maxima above threshold
        flat_idx = np.argsort(self.probability.ravel())[::-1]
        targets: list[dict] = []
        used: list[tuple[int, int]] = []
        for fi in flat_idx:
            ix, iz = divmod(int(fi), nz)
            p = float(self.probability[ix, iz])
            if p < min_prob:
                break
            # skip if too close to an already-selected target
            too_close = any(abs(ix - ux) + abs(iz - uz) < 3
                            for ux, uz in used)
            if too_close:
                continue
            used.append((ix, iz))
            contribs = {k: float(v[ix, iz])
                        for k, v in self.contributions.items()}
            targets.append({
                "x": float(self.x_coords[ix]),
                "z": float(self.z_coords[iz]),
                "probability": p,
                "contributions": contribs,
            })
            if len(targets) >= n:
                break
        return targets


# --------------------------------------------------------------------- #
#  Fusion engine                                                        #
# --------------------------------------------------------------------- #
class FusionEngine:
    """Combine multi-physics evidence into a prospectivity map.

    Parameters
    ----------
    indicator : HydrocarbonIndicator
        Fuzzy signature definitions.
    weights : dict[str, float]
        Reliability weight per method (0..1).  Defaults give ERT the highest
        weight (it directly senses resistivity), then gravity, IP, magnetic.

    The fusion rule is the noisy-OR (probability union)::

        P(HC) = 1 - prod_i (1 - w_i * E_i)

    which is 0 when no method indicates HC and approaches 1 when multiple
    independent methods agree.
    """

    def __init__(self, indicator: HydrocarbonIndicator | None = None,
                 weights: dict[str, float] | None = None):
        self.indicator = indicator or HydrocarbonIndicator()
        self.weights = weights or {
            "ert": 0.45,
            "gravity": 0.25,
            "ip": 0.15,
            "magnetic": 0.15,
        }

    def fuse(self, evidence: dict[str, np.ndarray]) -> np.ndarray:
        """Fuse per-method evidence maps into a single probability map.

        Parameters
        ----------
        evidence : dict[str, np.ndarray]
            Each value is a 2-D array of evidence scores [0, 1] for one
            method.  All arrays must have the same shape.

        Returns
        -------
        np.ndarray — fused probability [0, 1], same shape.
        """
        if not evidence:
            return np.zeros(0)
        shapes = {v.shape for v in evidence.values()}
        if len(shapes) != 1:
            raise ValueError(
                f"All evidence maps must have the same shape; got {shapes}")
        shape = shapes.pop()
        prob = np.zeros(shape)
        contributions: dict[str, np.ndarray] = {}
        for method, ev in evidence.items():
            w = self.weights.get(method, 0.0)
            w_ev = w * np.clip(ev, 0.0, 1.0)
            contributions[method] = w_ev
            prob = 1.0 - (1.0 - prob) * (1.0 - w_ev)
        return np.clip(prob, 0.0, 1.0)

    def fuse_to_map(self, evidence: dict[str, np.ndarray],
                    x_coords: np.ndarray, z_coords: np.ndarray,
                    ) -> ProspectivityMap:
        """Fuse evidence and package into a :class:`ProspectivityMap`."""
        prob = self.fuse(evidence)
        contributions = {k: self.weights.get(k, 0.0) * np.clip(v, 0, 1)
                         for k, v in evidence.items()}
        return ProspectivityMap(
            probability=prob, x_coords=x_coords, z_coords=z_coords,
            contributions=contributions, weights=dict(self.weights),
            indicator=self.indicator,
            meta={"fusion": "noisy-OR", "n_methods": len(evidence)},
        )


# --------------------------------------------------------------------- #
#  Convenience: build evidence from inversion / profile results         #
# --------------------------------------------------------------------- #
def _ert_evidence(inversion: InversionResult,
                  indicator: HydrocarbonIndicator) -> np.ndarray:
    """Build an ERT evidence map from an inverted resistivity model."""
    model = inversion.model
    if model.size == 0:
        return np.zeros(0)
    return np.asarray(indicator.resistivity_evidence(model), dtype=float)


def _gravity_evidence(density_contrast_grid: np.ndarray,
                      indicator: HydrocarbonIndicator) -> np.ndarray:
    """Build a gravity evidence map from a density-contrast model."""
    return np.asarray(indicator.density_evidence(density_contrast_grid),
                      dtype=float)


def _magnetic_evidence(anomaly_grid: np.ndarray,
                       indicator: HydrocarbonIndicator) -> np.ndarray:
    """Build a magnetic evidence map from a magnetic-anomaly model."""
    return np.asarray(indicator.magnetic_evidence(anomaly_grid), dtype=float)


def _ip_evidence(chargeability_grid: np.ndarray,
                 indicator: HydrocarbonIndicator) -> np.ndarray:
    """Build an IP evidence map from a chargeability model."""
    return np.asarray(indicator.chargeability_evidence(chargeability_grid),
                      dtype=float)


def fuse_prospectivity(ert: InversionResult | None = None,
                       gravity_contrast: np.ndarray | None = None,
                       magnetic_anomaly: np.ndarray | None = None,
                       chargeability: np.ndarray | None = None,
                       weights: dict[str, float] | None = None,
                       ) -> ProspectivityMap:
    """High-level convenience: fuse whatever evidence is available.

    Each argument is optional — the fusion works with any subset of methods.
    All provided 2-D arrays are resampled to a common grid (the ERT
    inversion grid, if present; otherwise the largest provided grid).
    """
    indicator = HydrocarbonIndicator()
    engine = FusionEngine(indicator=indicator, weights=weights)

    # Determine the reference grid
    ref_shape = None
    ref_x = None
    ref_z = None
    if ert is not None and ert.model.size > 0:
        nx, nz = ert.model.shape
        ref_shape = (nx, nz)
        dx = ert.cell_size
        max_d = ert.extent[2] if len(ert.extent) >= 3 else 0.0
        dz = max_d / nz if nz else dx
        ref_x = ert.cell_size * (np.arange(nx) + 0.5)
        ref_z = dz * (np.arange(nz) + 0.5)
    else:
        for arr in (gravity_contrast, magnetic_anomaly, chargeability):
            if arr is not None and arr.size > 0:
                ref_shape = arr.shape
                nx, nz = ref_shape
                ref_x = np.arange(nx, dtype=float)
                ref_z = np.arange(nz, dtype=float)
                break

    if ref_shape is None:
        raise ValueError("No evidence provided to fuse_prospectivity")

    def _resample(arr: np.ndarray | None) -> np.ndarray:
        if arr is None:
            return np.zeros(ref_shape)
        if arr.shape == ref_shape:
            return arr.astype(float)
        # nearest-neighbour resample
        from scipy.ndimage import zoom
        zx = ref_shape[0] / arr.shape[0]
        zz = ref_shape[1] / arr.shape[1]
        return zoom(arr, (zx, zz), order=1)[:ref_shape[0], :ref_shape[1]]

    evidence: dict[str, np.ndarray] = {}
    if ert is not None:
        evidence["ert"] = _ert_evidence(ert, indicator)
    if gravity_contrast is not None:
        evidence["gravity"] = _gravity_evidence(
            _resample(gravity_contrast), indicator)
    if magnetic_anomaly is not None:
        evidence["magnetic"] = _magnetic_evidence(
            _resample(magnetic_anomaly), indicator)
    if chargeability is not None:
        evidence["ip"] = _ip_evidence(_resample(chargeability), indicator)

    return engine.fuse_to_map(evidence, ref_x, ref_z)


def hydrocarbon_prospectivity(ert: InversionResult | None = None,
                              gravity_contrast: np.ndarray | None = None,
                              magnetic_anomaly: np.ndarray | None = None,
                              chargeability: np.ndarray | None = None,
                              ) -> ProspectivityMap:
    """Alias for :func:`fuse_prospectivity` (the main user-facing entry)."""
    return fuse_prospectivity(ert=ert, gravity_contrast=gravity_contrast,
                              magnetic_anomaly=magnetic_anomaly,
                              chargeability=chargeability)
