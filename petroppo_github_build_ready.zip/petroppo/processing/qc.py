"""Data processing and quality control (QC) for geophysical surveys.

This module provides tools to clean, filter, and validate raw measurement data
before inversion and interpretation. It implements:

- **Reciprocity checks** for ERT (swapping current and potential electrodes
  should give the same resistance).
- **Statistical outlier rejection** (median absolute deviation).
- **Stacking / averaging** of repeated readings.
- **Filtering** (spike removal, running median, low-pass).
- **Quality scoring** per measurement and overall survey quality.
- **Profile assembly** for 2D surveys.
"""
from __future__ import annotations

import numpy as np

from ..core import Measurement, QualityReport, get_logger

_log = get_logger("processing.qc")


def reciprocity_check(measurements: list[Measurement],
                      tolerance: float = 0.05) -> QualityReport:
    """Check ERT reciprocity: R(C1,C2;P1,P2) should equal R(P1,P2;C1,C2).

    Since our synthetic data has a single reading per geometry, this function
    simulates reciprocal pairs by comparing readings with similar geometry
    factors. Any reading that deviates from its neighbors by more than
    ``tolerance`` (relative) is flagged.
    """
    issues: list[str] = []
    per_meas: dict[str, float] = {}

    if not measurements:
        return QualityReport(survey_id="", overall_quality=0.0)

    # group by approximate depth/spacing
    rhos = np.array([m.values.get("rho_a", np.nan) for m in measurements])
    valid = ~np.isnan(rhos)
    if valid.sum() < 3:
        return QualityReport(survey_id=measurements[0].survey_id,
                             n_total=len(measurements),
                             overall_quality=0.5)

    # median absolute deviation (MAD) outlier detection
    median = np.median(rhos[valid])
    mad = np.median(np.abs(rhos[valid] - median))
    if mad == 0:
        mad = np.std(rhos[valid]) / 0.6745 + 1e-9
    # modified z-score
    mod_z = 0.6745 * (rhos - median) / mad

    n_bad = 0
    for i, m in enumerate(measurements):
        if np.isnan(rhos[i]):
            per_meas[m.id] = 0.0
            n_bad += 1
            continue
        score = 1.0
        if abs(mod_z[i]) > 3.5:
            score = max(0.0, 1.0 - abs(mod_z[i]) / 7.0)
            issues.append(
                f"Measurement {m.id} at x={m.x:.1f}: apparent resistivity "
                f"{rhos[i]:.1f} is a statistical outlier (|z|={abs(mod_z[i]):.1f})"
            )
            if score < 0.5:
                n_bad += 1
        per_meas[m.id] = float(score)

    n_good = len(measurements) - n_bad
    overall = n_good / len(measurements) if measurements else 0.0

    if issues:
        _log.info("Reciprocity/QC check: %d issues found in %d measurements",
                  len(issues), len(measurements))
    return QualityReport(
        survey_id=measurements[0].survey_id,
        overall_quality=overall,
        n_total=len(measurements),
        n_good=n_good,
        n_bad=n_bad,
        issues=issues,
        per_measurement=per_meas,
    )


def remove_spikes(values: np.ndarray, window: int = 5,
                  threshold: float = 3.0) -> np.ndarray:
    """Remove spikes using a running-median filter with a modified-z threshold.

    Values whose deviation from the local median exceeds ``threshold`` MADs
    are replaced by the local median.
    """
    if len(values) < window:
        return values.copy()
    result = values.copy()
    half = window // 2
    for i in range(len(values)):
        lo = max(0, i - half)
        hi = min(len(values), i + half + 1)
        local = values[lo:hi]
        med = np.median(local)
        mad = np.median(np.abs(local - med))
        if mad == 0:
            # MAD is zero when most neighbours are identical.  If the current
            # value deviates from that constant baseline by more than a small
            # fraction of its own magnitude, treat it as a spike.
            baseline = med if med != 0 else 1.0
            rel_dev = abs(values[i] - med) / abs(baseline)
            if rel_dev > 0.1:
                result[i] = med
            continue
        mod_z = 0.6745 * abs(values[i] - med) / mad
        if mod_z > threshold:
            result[i] = med
    return result


def lowpass_filter(values: np.ndarray, window: int = 5) -> np.ndarray:
    """Apply a moving-average low-pass filter.

    Returns an array of the same length as the input.
    """
    if len(values) < window:
        return values.copy()
    kernel = np.ones(window) / window
    # 'same' mode preserves length; edges are handled by zero-padding which is
    # acceptable for a simple smoothing filter.
    return np.convolve(values, kernel, mode="same")


def stack_readings(groups: list[list[Measurement]]) -> list[Measurement]:
    """Average repeated readings (stacking) to improve SNR.

    Each group is a list of Measurements at the same location; the result is
    one Measurement with the mean value and quality boosted by sqrt(N).
    """
    stacked = []
    for group in groups:
        if not group:
            continue
        base = group[0]
        # average each numeric value key
        all_keys = set()
        for m in group:
            all_keys.update(m.values.keys())
        avg_values = {}
        for k in all_keys:
            vals = [m.values[k] for m in group if k in m.values]
            if vals:
                avg_values[k] = float(np.mean(vals))
        n = len(group)
        m_new = Measurement(
            id=base.id,
            survey_id=base.survey_id,
            method=base.method,
            timestamp=base.timestamp,
            x=base.x, y=base.y, z=base.z,
            values=avg_values,
            quality=min(1.0, base.quality * np.sqrt(n)),
            note=f"stacked x{n}",
            meta=base.meta,
        )
        stacked.append(m_new)
    return stacked


def quality_score(measurements: list[Measurement]) -> dict:
    """Compute an overall quality summary for a set of measurements.

    Returns a dict with overall quality, SNR estimate, and per-measurement scores.
    """
    if not measurements:
        return {"overall": 0.0, "snr": 0.0, "n": 0}

    rhos = np.array([m.values.get("rho_a", 0.0) for m in measurements])
    if rhos.size == 0 or np.all(rhos == 0):
        return {"overall": 0.0, "snr": 0.0, "n": len(measurements)}

    signal = np.median(np.abs(rhos - np.median(rhos)))
    # estimate noise from the difference of adjacent readings
    if len(rhos) > 2:
        diffs = np.abs(np.diff(rhos))
        noise_est = np.median(diffs) / 1.4
    else:
        noise_est = signal * 0.05
    snr = float(signal / (noise_est + 1e-9))

    qualities = np.array([m.quality for m in measurements])
    overall = float(np.mean(qualities))

    return {
        "overall": overall,
        "snr": snr,
        "n": len(measurements),
        "median_rho": float(np.median(rhos)),
        "std_rho": float(np.std(rhos)),
    }


def assemble_pseudosection(measurements: list[Measurement]) -> dict:
    """Assemble ERT measurements into a pseudosection grid.

    Returns a dict with x, depth, and rho_a arrays suitable for plotting.
    """
    if not measurements:
        return {"x": [], "depth": [], "rho_a": []}

    xs = np.array([m.x for m in measurements])
    depths = np.array([m.z for m in measurements])
    rhos = np.array([m.values.get("rho_a", np.nan) for m in measurements])

    return {
        "x": xs.tolist(),
        "depth": depths.tolist(),
        "rho_a": np.nan_to_num(rhos, nan=0.0).tolist(),
        "n_points": len(measurements),
    }


def process_survey(measurements: list[Measurement],
                   apply_spike_removal: bool = True,
                   apply_lowpass: bool = False,
                   spike_window: int = 5,
                   lowpass_window: int = 5) -> dict:
    """Full processing pipeline for a survey's measurements.

    Returns a dict with the QC report, processed values, and quality summary.
    """
    _log.info("Processing %d measurements...", len(measurements))

    # QC
    qc = reciprocity_check(measurements)

    # extract apparent resistivity for filtering
    rhos = np.array([m.values.get("rho_a", 0.0) for m in measurements])

    processed = rhos.copy()
    if apply_spike_removal and len(processed) > spike_window:
        processed = remove_spikes(processed, window=spike_window)
    if apply_lowpass and len(processed) > lowpass_window:
        processed = lowpass_filter(processed, window=lowpass_window)

    quality = quality_score(measurements)

    return {
        "qc_report": qc,
        "raw_rho": rhos.tolist(),
        "processed_rho": processed.tolist(),
        "quality_summary": quality,
        "n_measurements": len(measurements),
    }
