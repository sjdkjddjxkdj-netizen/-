"""
petroppo V8 — Fast physics-correct ERT inversion.

Scientific upgrade that replaces the V7 Gaussian-footprint inversion
(which produced ROC-AUC = 0.5, i.e. random — no depth information) with a
true DC-resistivity finite-difference forward operator and a **fast
finite-difference Jacobian with LU factorisation reuse**, plus robust
IRLS norms, adaptive Occam regularisation with depth-weighting, and
linearised posterior uncertainty.

Speed breakthrough
------------------
The existing HI inversion (``hi_inversion.py``) already used the FD
forward operator, but its Jacobian rebuilt the *entire* EarthModel (with
one ResistivityBody per inversion cell) and re-ran ``forward_ert_fd``
from scratch for every cell perturbation — O(n_cells × n_sources) full
FD assemblies, timing out at >100s for a single iteration on a 40x20
grid.

V8 instead works directly on the FD conductivity grid:

* The variable-coefficient Laplacian is assembled once per model and
  **LU-factorised once** (``scipy.sparse.linalg.splu``) — 0.01s for a
  60x30 padded mesh.
* Each source's secondary potential is then a single **back-substitution**
  (0.0004s), so all 32 sources cost ~0.013s.
* For the Jacobian, perturbing one cell changes the conductivity field,
  requiring a Laplacian rebuild + re-factorisation (0.011s) plus 32 back-
  substitutions (0.013s) = **~0.024s per cell**.  A 128-cell Jacobian
  therefore costs ~3s and can be recomputed every iteration.

This makes a *physically correct* ERT inversion — one that actually
resolves depth — fast enough to run inside the petroppo benchmark on
every synthetic field.

Algorithm
---------
Gauss-Newton with Occam-style first-order smoothness regularisation,
log-parameterised in resistivity::

    min  || W_d (ln d_obs - ln F(m)) ||^2  +  lambda || W_m (m - m_ref) ||^2

Per iteration:
  1. Predict data  d = F(m)  via the FD forward solver (LU-cached).
  2. Build Jacobian  J[i,j] = d ln rho_a_i / d ln rho_j  by perturbing
     each cell (fast LU-reuse FD) — recomputed every ``jacobian_every``
     iterations.
  3. IRLS Huber weights on the data residual (robust to outliers).
  4. Solve  (J^T W_d^T W_d J + lam W_m^T W_m) dm = J^T W_d^T W_d r.
  5. Step-length (Marquardt) line search; cool lambda on accept, raise
     on reject; converge when chi-squared ≈ 1 (noise floor).

Uncertainty
-----------
At convergence: linearised posterior covariance
``C_m = (J^T W_d^T W_d J + lam W_m^T W_m)^{-1}`` and resolution matrix
``R = C_m J^T W_d^T W_d J``; their diagonals are returned as per-cell
posterior std-dev and model resolution in ``InversionResult.meta``.
"""
from __future__ import annotations

import numpy as np
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import splu
from scipy.interpolate import RegularGridInterpolator

from ..core import EarthModel, InversionResult, get_logger

_log = get_logger("processing.v8_inversion")


# =====================================================================
# Inversion grid
# =====================================================================

class InversionGrid:
    """2-D rectangular inversion mesh with cell-centre coordinates."""

    def __init__(self, x_min, x_max, max_depth, n_x=20, n_z=10):
        self.x_min = float(x_min)
        self.x_max = float(x_max)
        self.max_depth = float(max_depth)
        self.n_x = int(n_x)
        self.n_z = int(n_z)
        self.n_cells = self.n_x * self.n_z
        self.dx = (self.x_max - self.x_min) / self.n_x
        self.dz = self.max_depth / self.n_z
        self.xc = self.x_min + (np.arange(self.n_x) + 0.5) * self.dx
        self.zc = (np.arange(self.n_z) + 0.5) * self.dz

    def cell_index(self, ix, iz):
        return ix * self.n_z + iz

    def model_to_2d(self, model_flat):
        return model_flat.reshape(self.n_x, self.n_z)


# =====================================================================
# Fast FD engine: Laplacian assembly + LU factorisation + back-sub sources
# =====================================================================

def _assemble_laplacian(sigma_p, dx, dz):
    """Variable-coefficient Laplacian  div(sig grad Vs) on padded grid,
    Dirichlet Vs=0 on outer ring.  Returns csc_matrix.  Vectorised."""
    nz_p, nx_p = sigma_p.shape
    N = nx_p * nz_p

    sig_w = 2.0 * sigma_p[:, 1:] * sigma_p[:, :-1] / (sigma_p[:, 1:] + sigma_p[:, :-1] + 1e-30)
    sig_n = 2.0 * sigma_p[1:, :] * sigma_p[:-1, :] / (sigma_p[1:, :] + sigma_p[:-1, :] + 1e-30)

    from scipy.sparse import lil_matrix
    A = lil_matrix((N, N), dtype=np.float64)

    j_idx = np.arange(1, nz_p - 1)
    i_idx = np.arange(1, nx_p - 1)
    Jp, Ip = np.meshgrid(j_idx, i_idx, indexing="ij")
    rows = (Jp * nx_p + Ip).ravel()
    cols_w = (Jp * nx_p + (Ip - 1)).ravel()
    cols_e = (Jp * nx_p + (Ip + 1)).ravel()
    cols_n = ((Jp - 1) * nx_p + Ip).ravel()
    cols_s = ((Jp + 1) * nx_p + Ip).ravel()

    aw_v = (sig_w[Jp, Ip - 1] / (dx * dx)).ravel()
    ae_v = (sig_w[Jp, Ip] / (dx * dx)).ravel()
    an_v = (sig_n[Jp - 1, Ip] / (dz * dz)).ravel()
    as_v = (sig_n[Jp, Ip] / (dz * dz)).ravel()
    ap_v = aw_v + ae_v + an_v + as_v

    A[rows, rows] = -ap_v
    A[rows, cols_w] = aw_v
    A[rows, cols_e] = ae_v
    A[rows, cols_n] = an_v
    A[rows, cols_s] = as_v

    boundary = np.concatenate([
        np.arange(nz_p) * nx_p,
        np.arange(nz_p) * nx_p + (nx_p - 1),
        np.arange(nx_p),
        (nz_p - 1) * nx_p + np.arange(nx_p),
    ])
    boundary = np.unique(boundary)
    A[boundary, boundary] = 1.0
    return csc_matrix(A)


class FDEngine:
    """Caches FD mesh geometry and the LU factorisation of the Laplacian
    for a given conductivity field, so that all source positions are solved
    by fast back-substitution.  Perturbing the model rebuilds the LU.
    """

    def __init__(self, base_model, geometry, fd_nx=60, fd_nz=30, pad=10):
        all_x = []
        for (c1, p1, p2, c2, _a, _ae) in geometry:
            all_x.extend([c1, p1, p2, c2])
        span = abs(max(all_x) - min(all_x))
        self.x_min = min(all_x) - 0.5 * span - 10.0
        self.x_max = max(all_x) + 0.5 * span + 10.0
        self.max_depth = max(base_model.max_depth, span * 0.6)
        self.fd_nx = fd_nx
        self.fd_nz = fd_nz
        self.pad = pad
        self.fd_xs = np.linspace(self.x_min, self.x_max, fd_nx)
        self.fd_zs = np.linspace(0.0, self.max_depth, fd_nz)
        self.dx = (self.fd_xs[-1] - self.fd_xs[0]) / max(fd_nx - 1, 1)
        self.dz = (self.fd_zs[-1] - self.fd_zs[0]) / max(fd_nz - 1, 1)
        self.sigma_bg = 1.0 / base_model.background_resistivity
        self.rho_bg = base_model.background_resistivity
        # layer background conductivity on the FD grid
        Xf, Zf = np.meshgrid(self.fd_xs, self.fd_zs, indexing="xy")
        self._Xf = Xf
        self._Zf = Zf
        self._layer_sigma = np.full_like(Xf, self.sigma_bg)
        for layer in base_model.layers:
            m = (Zf >= layer.top_depth) & (Zf < layer.bottom_depth)
            if layer.resistivity and layer.resistivity > 0:
                self._layer_sigma[m] = 1.0 / layer.resistivity
        # unique source positions (rounded)
        srcs = []
        for (c1, p1, p2, c2, _a, _ae) in geometry:
            srcs.extend([c1, p2, p1, c2])
        self.unique_src = sorted(set(round(x, 4) for x in srcs))
        self._lu = None
        self._rhs_cache = {}
        self._geometry = geometry

    def _sigma_grid(self, model_log, grid):
        """Build the padded FD conductivity grid for an inversion model."""
        model_phys = np.exp(model_log)
        model_2d = grid.model_to_2d(model_phys)
        sigma = self._layer_sigma.copy()
        Xf, Zf = self._Xf, self._Zf
        for ix in range(grid.n_x):
            x0 = grid.x_min + ix * grid.dx
            x1 = x0 + grid.dx
            for iz in range(grid.n_z):
                z0 = iz * grid.dz
                z1 = z0 + grid.dz
                m = (Xf >= x0) & (Xf < x1) & (Zf >= z0) & (Zf < z1)
                sigma[m] = 1.0 / model_2d[ix, iz]
        return sigma

    def _rhs_for_source(self, x_src, sigma_p):
        """Build the RHS (secondary-potential source term) for a source."""
        nx_p = sigma_p.shape[1]
        Xp = (self.fd_xs[0] - self.pad * self.dx) + self.dx * np.arange(sigma_p.shape[1])
        Zp = (self.fd_zs[0] - self.pad * self.dz) + self.dz * np.arange(sigma_p.shape[0])
        Xp2, Zp2 = np.meshgrid(Xp, Zp, indexing="xy")
        r = np.sqrt((Xp2 - x_src) ** 2 + Zp2 ** 2)
        r = np.maximum(r, 0.5 * min(self.dx, self.dz))
        Vp = self.rho_bg / (2.0 * np.pi * r)
        dsig = sigma_p - self.sigma_bg
        dVp_dx = np.zeros_like(Vp)
        dVp_dz = np.zeros_like(Vp)
        dVp_dx[:, 1:-1] = (Vp[:, 2:] - Vp[:, :-2]) / (2.0 * self.dx)
        dVp_dz[1:-1, :] = (Vp[2:, :] - Vp[:-2, :]) / (2.0 * self.dz)
        fx = dsig * dVp_dx
        fz = dsig * dVp_dz
        rhs = np.zeros_like(Vp)
        rhs[:, 1:-1] -= (fx[:, 2:] - fx[:, :-2]) / (2.0 * self.dx)
        rhs[1:-1, :] -= (fz[2:, :] - fz[:-2, :]) / (2.0 * self.dz)
        # Dirichlet boundary
        nz_p, nx_p = sigma_p.shape
        boundary = np.concatenate([
            np.arange(nz_p) * nx_p,
            np.arange(nz_p) * nx_p + (nx_p - 1),
            np.arange(nx_p),
            (nz_p - 1) * nx_p + np.arange(nx_p),
        ])
        boundary = np.unique(boundary)
        b = rhs.ravel().copy()
        b[boundary] = 0.0
        return b

    def factorize(self, model_log, grid):
        """Build padded conductivity, assemble + LU-factor the Laplacian,
        and precompute RHS for every unique source.  Call once per model."""
        sigma = self._sigma_grid(model_log, grid)
        nz, nx = sigma.shape
        sig_p = np.full((nz + 2 * self.pad, nx + 2 * self.pad), self.sigma_bg)
        sig_p[self.pad:self.pad + nz, self.pad:self.pad + nx] = sigma
        A = _assemble_laplacian(sig_p, self.dx, self.dz)
        self._lu = splu(A)
        self._sig_p = sig_p
        self._rhs_cache = {}
        for xs in self.unique_src:
            self._rhs_cache[xs] = self._rhs_for_source(xs, sig_p)

    def _secondary(self, x_src):
        """Secondary potential on the UNPADDED grid for a source."""
        xs = round(x_src, 4)
        b = self._rhs_cache[xs]
        Vs_flat = self._lu.solve(b)
        nz, nx = self.fd_nz, self.fd_nx
        pad = self.pad
        Vs_padded = Vs_flat.reshape(nz + 2 * pad, nx + 2 * pad)
        return Vs_padded[pad:pad + nz, pad:pad + nx]

    def forward(self, geometry=None):
        """Predict apparent resistivity for every quadrupole."""
        geometry = geometry or self._geometry
        results = np.zeros(len(geometry))
        sec_cache = {}
        def _Vs(x_src):
            k = round(x_src, 4)
            if k not in sec_cache:
                sec_cache[k] = self._secondary(x_src)
            return sec_cache[k]
        rho_bg = self.rho_bg
        for i, (c1, p1, p2, c2, a, a_eff) in enumerate(geometry):
            # total potential = primary(analytical) + secondary(FD interpolated)
            def Vtot(x_src, x_obs):
                r = max(abs(x_obs - x_src), 1e-9)
                Vp = rho_bg / (2.0 * np.pi * r)
                Vs = _Vs(x_src)
                interp = RegularGridInterpolator((self.fd_zs, self.fd_xs), Vs,
                                                 bounds_error=False, fill_value=0.0)
                return Vp + float(interp([[0.0, x_obs]])[0])
            dV = (Vtot(c1, p1) - Vtot(c1, p2)) - (Vtot(c2, p1) - Vtot(c2, p2))
            r_c1p1 = abs(p1 - c1); r_c1p2 = abs(p2 - c1)
            r_c2p1 = abs(p1 - c2); r_c2p2 = abs(p2 - c2)
            denom = (1.0 / max(r_c1p1, 1e-9) - 1.0 / max(r_c1p2, 1e-9)
                     - 1.0 / max(r_c2p1, 1e-9) + 1.0 / max(r_c2p2, 1e-9))
            K = 2.0 * np.pi / max(abs(denom), 1e-9)
            rho_a = K * dV
            results[i] = abs(rho_a) if rho_a < 0 else rho_a
        return results

    def jacobian(self, model_log, grid, delta=0.1):
        """FD-perturbation Jacobian J[i,j] = d ln rho_a_i / d ln rho_j
        using LU reuse: perturb one cell -> rebuild+refactor -> solve all
        sources via back-sub.  Fast (~0.024s/cell)."""
        self.factorize(model_log, grid)
        f0 = np.maximum(self.forward(), 1e-6)
        f0l = np.log(f0)
        n_read = len(self._geometry)
        J = np.zeros((n_read, grid.n_cells))
        for j in range(grid.n_cells):
            mp = model_log.copy()
            mp[j] += delta
            self.factorize(mp, grid)
            fp = np.maximum(self.forward(), 1e-6)
            J[:, j] = (np.log(fp) - f0l) / delta
        # restore base factorisation
        self.factorize(model_log, grid)
        return J


# =====================================================================
# Roughness + depth-weighting
# =====================================================================

def _roughness_matrix(grid):
    rows = []
    for ix in range(grid.n_x):
        for iz in range(grid.n_z):
            idx = grid.cell_index(ix, iz)
            if ix < grid.n_x - 1:
                r = np.zeros(grid.n_cells)
                r[idx] = 1.0; r[grid.cell_index(ix + 1, iz)] = -1.0
                rows.append(r)
            if iz < grid.n_z - 1:
                r = np.zeros(grid.n_cells)
                r[idx] = 1.0; r[grid.cell_index(ix, iz + 1)] = -1.0
                rows.append(r)
    return np.array(rows) if rows else np.zeros((0, grid.n_cells))


def _depth_weight(grid, beta=1.0):
    z = grid.zc + grid.dz
    w = (z / max(z.max(), 1e-9)) ** beta
    return np.tile(w[np.newaxis, :], (grid.n_x, 1)).ravel()


def _huber_weights(resid, delta=1.345):
    abs_r = np.abs(resid)
    return np.where(abs_r <= delta, 1.0, delta / np.maximum(abs_r, 1e-12))


# =====================================================================
# Main V8 inversion
# =====================================================================

def invert_ert_v8(readings, grid, obs_rho, base_model, geometry=None,
                  noise_floor=0.02, ref_resistivity=None,
                  max_iter=10, lambda_init=10.0, lambda_decay=0.7,
                  lambda_min=1e-3, fd_nx=60, fd_nz=30,
                  robust=True, depth_weight_beta=1.0,
                  jacobian_every=2, compute_uncertainty=True,
                  initial_model=None):
    """V8 ERT inversion: FD forward + fast LU-reuse FD Jacobian + robust
    IRLS + adaptive Occam regularisation + depth weighting + uncertainty.

    ``initial_model`` : optional flat log-rho vector to start from (e.g.
        the layered background).  If None, starts from the layered
        background conductivity (NOT a homogeneous half-space) so the
        secondary field and sensitivities are non-degenerate.
    """
    if geometry is None:
        geometry = []
        for r in readings:
            a = r["a"]; xm = r["x_mid"]
            geometry.append((xm - 1.5 * a, xm - 0.5 * a, xm + 0.5 * a,
                             xm + 1.5 * a, a, a))
    if ref_resistivity is None:
        ref_resistivity = base_model.background_resistivity

    n_read = len(readings)
    n_cells = grid.n_cells

    # Initial model = layered background mapped onto inversion cells
    # (gives non-zero secondary field -> non-degenerate sensitivities).
    if initial_model is None:
        model_log = np.full(n_cells, np.log(ref_resistivity))
        for ix in range(grid.n_x):
            cx = grid.xc[ix]
            for iz in range(grid.n_z):
                cz = grid.zc[iz]
                lay = base_model.layer_at(cz)
                if lay is not None and lay.resistivity:
                    model_log[grid.cell_index(ix, iz)] = np.log(lay.resistivity)
    else:
        model_log = np.array(initial_model, dtype=float).copy()
    m_ref = model_log.copy()
    obs_log = np.log(np.maximum(obs_rho, 1e-6))
    sigma_log = float(noise_floor)

    Wm = _roughness_matrix(grid)
    dw = _depth_weight(grid, beta=depth_weight_beta)
    if Wm.shape[0] > 0:
        Wm_dw = Wm * dw[np.newaxis, :]
        WmT_Wm = Wm_dw.T @ Wm_dw
    else:
        WmT_Wm = np.zeros((n_cells, n_cells))

    engine = FDEngine(base_model, geometry, fd_nx=fd_nx, fd_nz=fd_nz)
    lam = lambda_init
    J = None
    rmse_prev = np.inf
    rmse_history = []
    irls_w = np.ones(n_read)
    it = 0

    for it in range(1, max_iter + 1):
        engine.factorize(model_log, grid)
        pred = np.maximum(engine.forward(), 1e-6)
        resid = obs_log - np.log(pred)
        if robust:
            irls_w = _huber_weights(resid, 1.345)
        Wd = np.diag(irls_w / sigma_log)

        need_jac = (J is None) or ((it - 1) % jacobian_every == 0)
        if need_jac:
            _log.info("Iter %d: LU-reuse FD Jacobian (%d cells)", it, n_cells)
            J = engine.jacobian(model_log, grid, delta=0.1)

        JtWd = J.T @ Wd
        A = JtWd @ Wd @ J + lam * WmT_Wm + 1e-6 * np.eye(n_cells)
        rhs = JtWd @ Wd @ resid
        try:
            dm = np.linalg.solve(A, rhs)
        except np.linalg.LinAlgError:
            dm = np.linalg.lstsq(A, rhs, rcond=None)[0]

        m_dm = np.max(np.abs(dm))
        if m_dm > 0.6:
            dm = dm * (0.6 / m_dm)

        accepted = False
        for alpha in (1.0, 0.5, 0.25, 0.1):
            m_trial = np.clip(model_log + alpha * dm, np.log(1.0), np.log(5000.0))
            engine.factorize(m_trial, grid)
            pred_t = np.maximum(engine.forward(), 1e-6)
            r_t = obs_log - np.log(pred_t)
            w_t = _huber_weights(r_t, 1.345) if robust else np.ones(n_read)
            rmse_t = float(np.sqrt(np.mean((w_t * r_t / sigma_log) ** 2)))
            if rmse_t < rmse_prev:
                model_log = m_trial
                rmse_prev = rmse_t
                irls_w = w_t
                rmse_history.append(rmse_t)
                accepted = True
                _log.info("Iter %d: RMSE=%.4f (alpha=%.2f, lam=%.3f)",
                          it, rmse_t, alpha, lam)
                break

        if accepted:
            lam = max(lam * lambda_decay, lambda_min)
            # only declare convergence after the model has had a chance to
            # develop anomalies (min 3 iterations); otherwise the layered
            # background already fits and we'd stop without recovering the
            # reservoir body.
            if rmse_prev < 1.0 and it >= 3:
                _log.info("Converged to noise floor at iter %d", it)
                break
        else:
            lam = lam / lambda_decay
            rmse_history.append(rmse_prev)
            _log.info("Iter %d: rejected, lam -> %.3f", it, lam)
            if lam > 1e6:
                break

    # Final
    engine.factorize(model_log, grid)
    final_pred = np.maximum(engine.forward(), 1e-6)
    rmse_abs = float(np.sqrt(np.mean((obs_rho - final_pred) ** 2)))
    rel_rmse = float(np.sqrt(np.mean(((obs_rho - final_pred) / obs_rho) ** 2)))
    chi2 = float(np.mean(((obs_log - np.log(final_pred)) / sigma_log) ** 2))

    posterior_std = np.full(n_cells, np.nan)
    resolution = np.full(n_cells, np.nan)
    if compute_uncertainty and J is not None:
        Wd_f = np.diag(irls_w / sigma_log)
        JtWdJ_f = J.T @ Wd_f @ Wd_f @ J
        S = JtWdJ_f + lam * WmT_Wm + 1e-6 * np.eye(n_cells)
        try:
            Sinv = np.linalg.inv(S)
            posterior_std = np.sqrt(np.maximum(np.diag(Sinv), 0.0))
            R = Sinv @ JtWdJ_f
            resolution = np.clip(np.diag(R), 0.0, 1.0)
        except np.linalg.LinAlgError:
            pass

    model_2d = grid.model_to_2d(np.exp(model_log))
    _log.info("V8 complete: %d iters, abs RMSE=%.3f, rel RMSE=%.3f, chi2=%.3f",
              it, rmse_abs, rel_rmse, chi2)

    return InversionResult(
        survey_id="v8_inversion",
        model=model_2d,
        rmse=rmse_abs,
        n_iter=it,
        cell_size=grid.dx,
        extent=(grid.x_max - grid.x_min, 0.0, grid.max_depth),
        meta={
            "method": "V8-FD-LU-GN",
            "robust": robust,
            "lambda_final": lam,
            "n_cells": n_cells,
            "n_readings": n_read,
            "noise_floor": noise_floor,
            "fd_mesh": (fd_nx, fd_nz),
            "rmse_history": rmse_history,
            "rel_rmse": rel_rmse,
            "chi2": chi2,
            "converged": bool(rmse_prev < 1.0),
            "posterior_std": posterior_std.reshape(grid.n_x, grid.n_z),
            "resolution": resolution.reshape(grid.n_x, grid.n_z),
            "depth_weight_beta": depth_weight_beta,
        },
    )


def invert_from_model_v8(model, n_electrodes=24, spacing=5.0,
                         config="wenner", noise=0.02,
                         n_x=20, n_z=10, max_iter=10,
                         fd_nx=60, fd_nz=30, robust=True,
                         depth_weight_beta=1.0):
    """End-to-end V8 inversion: FD forward-model the truth, then invert
    with the fast LU-reuse FD-Jacobian engine."""
    from ..simulator.forward import wenner_geometry, dipole_dipole_geometry
    from ..simulator.hifwd import forward_ert_fd

    geom_fn = (dipole_dipole_geometry if config == "dipole-dipole"
               else wenner_geometry)
    geometry = geom_fn(n_electrodes, spacing)

    rng = np.random.default_rng(42)
    readings = forward_ert_fd(model, geometry, noise=noise, rng=rng,
                              nx=fd_nx, nz=fd_nz)
    obs_rho = np.array([r["rho_a"] for r in readings])

    all_x = [r["x_mid"] for r in readings]
    x_min = min(all_x) - spacing
    x_max = max(all_x) + spacing
    inv_depth = max(spacing * n_electrodes / 3.0, model.max_depth * 0.7)
    grid = InversionGrid(x_min, x_max, inv_depth, n_x, n_z)

    result = invert_ert_v8(
        readings, grid, obs_rho, base_model=model, geometry=geometry,
        noise_floor=noise, ref_resistivity=model.background_resistivity,
        max_iter=max_iter, fd_nx=fd_nx, fd_nz=fd_nz,
        robust=robust, depth_weight_beta=depth_weight_beta,
    )
    result.survey_id = model.name
    return result


# =====================================================================
# V8 resistivity-evidence (contrast-aware)
# =====================================================================

def v8_resistivity_evidence(rho_grid, plateau_lo=200.0, plateau_hi=5000.0,
                            low=50.0, high=10000.0,
                            use_contrast=True, contrast_fraction=0.5,
                            depth_weighting=False, z_coords=None,
                            smooth_sigma=0.0, min_depth=8.0):
    """V8 hydrocarbon evidence from an inverted resistivity grid.

    V7's ``HydrocarbonIndicator.resistivity_evidence`` uses an absolute
    trapezoid (50 / 100-2000 / 5000 Ω·m) which, on a layered earth whose
    mid-layer is already ~120 Ω·m, scores the background as "hydrocarbon-
    favourable" and washes out the reservoir contrast — this is a key
    reason V7 ERT-only AUC was 0.5.

    V8 produces a *physically recovered* model, so we score the
    **resistivity anomaly** (contrast above the local background) rather
    than the absolute value.  The background is estimated as a robust
    low percentile of the model (the median of the non-anomalous cells),
    and the evidence is a trapezoid on ``rho - contrast_fraction*background``
    shifted so that only cells genuinely more resistive than their
    surroundings score high.

    V8.1 enhancements for wide-gap performance:
    - ``depth_weighting``: suppresses near-surface artefacts (the inversion
      often produces small spurious anomalies at z<8m that dominate the
      argmax).  Cells above ``min_depth`` are damped; deeper cells keep
      full weight.
    - ``smooth_sigma``: Gaussian smoothing of the evidence map to merge
      split anomaly peaks into a single centroid (reduces location error).
    - ``z_coords``: 1-D array of cell-center depths (required for depth
      weighting).

    Parameters
    ----------
    rho_grid : 2-D inverted resistivity (Ω·m), shape (n_z, n_x).
    use_contrast : if True, score the anomaly; if False, fall back to the
        absolute trapezoid (V7-compatible).
    depth_weighting : suppress shallow artefacts.
    smooth_sigma : Gaussian sigma (in cells) for evidence smoothing.
    """
    rho = np.asarray(rho_grid, dtype=float)
    if use_contrast:
        bg = float(np.percentile(rho, 40))
        anom = rho - contrast_fraction * bg
        lo = max(low - contrast_fraction * bg, 1.0)
        pl = max(plateau_lo - contrast_fraction * bg, lo + 1.0)
        ph = plateau_hi
        hi = high
    else:
        anom = rho
        lo, pl, ph, hi = low, plateau_lo, plateau_hi, high
    prob = _trapezoid(anom, lo, pl, ph, hi)

    # V8.1: depth weighting — suppress near-surface artefacts
    if depth_weighting and z_coords is not None:
        zc = np.asarray(z_coords, dtype=float)
        # ramp: 0 above min_depth, 1 below min_depth+10
        ramp = np.clip((zc - min_depth) / 10.0, 0.0, 1.0)
        prob = prob * ramp[:, np.newaxis]

    # V8.1: Gaussian smoothing to merge split peaks
    if smooth_sigma > 0:
        from scipy.ndimage import gaussian_filter
        prob = gaussian_filter(prob, sigma=smooth_sigma)

    return np.clip(prob, 0.0, 1.0)


def _trapezoid(x, a, b, c, d):
    """Piecewise-linear trapezoidal membership: 0 below a, 1 on [b,c], 0 above d."""
    x = np.asarray(x, dtype=float)
    out = np.zeros_like(x)
    m1 = (x >= a) & (x < b)
    out[m1] = (x[m1] - a) / max(b - a, 1e-12)
    m2 = (x >= b) & (x <= c)
    out[m2] = 1.0
    m3 = (x > c) & (x <= d)
    out[m3] = (d - x[m3]) / max(d - c, 1e-12)
    return np.clip(out, 0.0, 1.0)
