"""Well-log calibration — tie field geophysics to borehole outcomes.

This module is the bridge that makes petroppo a *calibrated* system
rather than a heuristic one.  It ingests well data (logs + oil-show
labels), extracts the geophysical evidence *at each well location* from
the inversion grids, and trains the :class:`CalibrationState` used by
the :class:`BayesianProspectivityEngine`.

The scientific logic
--------------------
A well is the ground truth: it either encountered movable hydrocarbons
(label = 1) or it was dry (label = 0).  Each well sits at a surface
position ``(x, y)`` and penetrates a depth interval.  For each well we
extract, from every available inversion grid, the evidence score at the
well's subsurface location — e.g. the inverted resistivity at the
reservoir target depth.  These ``(evidence_per_method, label)`` pairs
are exactly what :func:`fit_calibration` needs to learn how informative
each method really is *for this play*.

Without this step the prospectivity engine is an uncalibrated heuristic.
With it, the posterior ``P`` is a defensible, validated probability.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core import get_logger
from .prospecting import HydrocarbonIndicator
from .bayesian import (
    CalibrationState, fit_calibration, BayesianProspectivityEngine,
)

_log = get_logger("processing.wellcal")


@dataclass
class WellLog:
    """A single borehole with logs and an outcome label.

    Attributes
    ----------
    name : str
        Well identifier.
    x, y : float
        Surface position (local grid coords, same frame as the inversions).
    target_depth : float
        Depth of the exploration target (reservoir interval centre).
    label : int
        1 = producing / oil-show positive, 0 = dry.
    logs : dict[str, np.ndarray]
        Optional down-hole logs keyed by property name
        ('resistivity','density','gamma','neutron','oil_show').
        Values are arrays sampled at ``log_depths``.
    log_depths : np.ndarray
        Depths (m) corresponding to ``logs`` entries.
    """
    name: str
    x: float
    y: float
    target_depth: float
    label: int
    logs: dict[str, np.ndarray] = field(default_factory=dict)
    log_depths: np.ndarray = field(default_factory=lambda: np.empty(0))

    def log_at_target(self, prop: str) -> float | None:
        """Return the log value nearest to ``target_depth``."""
        if prop not in self.logs or self.log_depths.size == 0:
            return None
        vals = np.asarray(self.logs[prop], dtype=float)
        idx = int(np.argmin(np.abs(self.log_depths - self.target_depth)))
        v = vals[idx]
        return None if np.isnan(v) else float(v)


# --------------------------------------------------------------------- #
#  Extracting evidence at well locations                                #
# --------------------------------------------------------------------- #
def extract_well_evidence(wells: list[WellLog], *,
                          ert: np.ndarray | None = None,
                          ert_x: np.ndarray | None = None,
                          ert_z: np.ndarray | None = None,
                          gravity_contrast: np.ndarray | None = None,
                          magnetic_anomaly: np.ndarray | None = None,
                          chargeability: np.ndarray | None = None,
                          seismic_velocity: np.ndarray | None = None,
                          indicator: HydrocarbonIndicator | None = None,
                          ) -> list[dict[str, float]]:
    """Extract per-method evidence scores at each well location.

    Each inversion grid is a 2-D ``(nx, nz)`` array over ``ert_x``
    (horizontal, m) and ``ert_z`` (depth, m, increasing downward).  For
    a well at ``(x, target_depth)`` we bilinearly sample the grid, map
    the physical property through the fuzzy indicator, and return the
    evidence score.  Wells outside the grid get ``NaN`` for that method
    (so ``fit_calibration`` can handle missing methods gracefully).
    """
    indicator = indicator or HydrocarbonIndicator()
    grids: dict[str, tuple[np.ndarray, callable]] = {}
    if ert is not None and ert_x is not None and ert_z is not None:
        grids["ert"] = (np.asarray(ert, dtype=float),
                        indicator.resistivity_evidence)
    if gravity_contrast is not None:
        grids["gravity"] = (np.asarray(gravity_contrast, dtype=float),
                            indicator.density_evidence)
    if magnetic_anomaly is not None:
        grids["magnetic"] = (np.asarray(magnetic_anomaly, dtype=float),
                             indicator.magnetic_evidence)
    if chargeability is not None:
        grids["ip"] = (np.asarray(chargeability, dtype=float),
                       indicator.chargeability_evidence)
    if seismic_velocity is not None:
        v = np.asarray(seismic_velocity, dtype=float)
        def sev_e(x):
            return indicator._trapezoid(x, 1500.0, 2500.0, 4200.0, 5500.0)
        grids["seismic"] = (v, sev_e)

    out: list[dict[str, float]] = []
    for w in wells:
        ev: dict[str, float] = {}
        for m, (grid, fn) in grids.items():
            gx = ert_x if ert_x is not None else np.arange(grid.shape[0])
            gz = ert_z if ert_z is not None else np.arange(grid.shape[1])
            val = _bilinear(grid, gx, gz, w.x, w.target_depth)
            if val is None or np.isnan(val):
                ev[m] = float("nan")
            else:
                e = fn(val)
                ev[m] = float(np.asarray(e).ravel()[0])
        out.append(ev)
    return out


def _bilinear(grid: np.ndarray, xs: np.ndarray, zs: np.ndarray,
              x: float, z: float) -> float | None:
    """Bilinear sample of a 2-D grid at (x, z).  Returns None if outside."""
    nx, nz = grid.shape
    xs = np.asarray(xs, dtype=float)
    zs = np.asarray(zs, dtype=float)
    if x < xs[0] or x > xs[-1] or z < zs[0] or z > zs[-1]:
        return None
    ix = int(np.searchsorted(xs, x) - 1)
    ix = max(0, min(ix, nx - 2))
    iz = int(np.searchsorted(zs, z) - 1)
    iz = max(0, min(iz, nz - 2))
    x0, x1 = xs[ix], xs[ix + 1]
    z0, z1 = zs[iz], zs[iz + 1]
    tx = (x - x0) / (x1 - x0) if x1 != x0 else 0.0
    tz = (z - z0) / (z1 - z0) if z1 != z0 else 0.0
    v = (grid[ix, iz] * (1 - tx) * (1 - tz)
         + grid[ix + 1, iz] * tx * (1 - tz)
         + grid[ix, iz + 1] * (1 - tx) * tz
         + grid[ix + 1, iz + 1] * tx * tz)
    return float(v)


# --------------------------------------------------------------------- #
#  Full calibration workflow                                            #
# --------------------------------------------------------------------- #
def calibrate_from_wells(wells: list[WellLog], *,
                         ert: np.ndarray | None = None,
                         ert_x: np.ndarray | None = None,
                         ert_z: np.ndarray | None = None,
                         gravity_contrast: np.ndarray | None = None,
                         magnetic_anomaly: np.ndarray | None = None,
                         chargeability: np.ndarray | None = None,
                         seismic_velocity: np.ndarray | None = None,
                         indicator: HydrocarbonIndicator | None = None,
                         ) -> CalibrationState:
    """End-to-end: extract evidence at wells → fit calibration.

    Returns a :class:`CalibrationState` with ``is_calibrated=True`` and
    learned per-method reliabilities, suitable for passing to
    :class:`BayesianProspectivityEngine`.
    """
    if not wells:
        raise ValueError("calibrate_from_wells: no wells supplied")
    ev = extract_well_evidence(
        wells, ert=ert, ert_x=ert_x, ert_z=ert_z,
        gravity_contrast=gravity_contrast, magnetic_anomaly=magnetic_anomaly,
        chargeability=chargeability, seismic_velocity=seismic_velocity,
        indicator=indicator)
    labels = np.array([w.label for w in wells], dtype=float)
    state = fit_calibration(ev, labels)
    _log.info("Calibrated from %d wells: %s", state.n_wells, state.metrics)
    return state


def make_engine_from_wells(wells: list[WellLog], *,
                           ert: np.ndarray | None = None,
                           ert_x: np.ndarray | None = None,
                           ert_z: np.ndarray | None = None,
                           gravity_contrast: np.ndarray | None = None,
                           magnetic_anomaly: np.ndarray | None = None,
                           chargeability: np.ndarray | None = None,
                           seismic_velocity: np.ndarray | None = None,
                           indicator: HydrocarbonIndicator | None = None,
                           ) -> BayesianProspectivityEngine:
    """Convenience: calibrate then return a ready-to-use engine."""
    state = calibrate_from_wells(
        wells, ert=ert, ert_x=ert_x, ert_z=ert_z,
        gravity_contrast=gravity_contrast, magnetic_anomaly=magnetic_anomaly,
        chargeability=chargeability, seismic_velocity=seismic_velocity,
        indicator=indicator)
    return BayesianProspectivityEngine(calibration=state, indicator=indicator)


# --------------------------------------------------------------------- #
#  Cross-validation: PROVE the calibration generalises                  #
# --------------------------------------------------------------------- #
def cross_validate_wells(wells: list[WellLog], *,
                         ert: np.ndarray | None = None,
                         ert_x: np.ndarray | None = None,
                         ert_z: np.ndarray | None = None,
                         gravity_contrast: np.ndarray | None = None,
                         magnetic_anomaly: np.ndarray | None = None,
                         chargeability: np.ndarray | None = None,
                         seismic_velocity: np.ndarray | None = None,
                         indicator: HydrocarbonIndicator | None = None,
                         k: int = 5,
                         ) -> dict[str, float]:
    """k-fold leave-out cross-validation of the calibration.

    For each fold, fit on k-1 wells and predict the held-out well's
    probability.  Aggregate predictions across folds and report Brier,
    log-loss, ROC-AUC, and accuracy.  This is the *honest* test that the
    learned reliabilities generalise, not just memorise the wells.
    """
    from .bayesian import _evaluate
    wells = list(wells)
    n = len(wells)
    if n < 3:
        raise ValueError("cross_validate_wells: need ≥3 wells")
    k = min(k, n)
    # deterministic fold assignment
    rng = np.random.default_rng(42)
    idx = rng.permutation(n)
    folds = np.array_split(idx, k)

    all_preds = np.zeros(n)
    all_labels = np.array([w.label for w in wells], dtype=float)

    for fold in folds:
        train = [wells[i] for i in range(n) if i not in fold]
        test = [wells[i] for i in fold]
        ev_train = extract_well_evidence(
            train, ert=ert, ert_x=ert_x, ert_z=ert_z,
            gravity_contrast=gravity_contrast,
            magnetic_anomaly=magnetic_anomaly,
            chargeability=chargeability,
            seismic_velocity=seismic_velocity, indicator=indicator)
        labels_train = np.array([w.label for w in train], dtype=float)
        state = fit_calibration(ev_train, labels_train)
        engine = BayesianProspectivityEngine(calibration=state,
                                             indicator=indicator)
        ev_test = extract_well_evidence(
            test, ert=ert, ert_x=ert_x, ert_z=ert_z,
            gravity_contrast=gravity_contrast,
            magnetic_anomaly=magnetic_anomaly,
            chargeability=chargeability,
            seismic_velocity=seismic_velocity, indicator=indicator)
        methods = state.default_methods()
        for j, w in enumerate(test):
            lo = state.prior_logit
            for m, cal in methods.items():
                if m in ev_test[j] and not np.isnan(ev_test[j][m]):
                    lo += cal.llr(ev_test[j][m])
            all_preds[w_idx(wells, w)] = 1.0 / (1.0 + np.exp(-lo))

    brier = float(np.mean((all_preds - all_labels) ** 2))
    eps = 1e-12
    ll = -float(np.mean(all_labels * np.log(all_preds + eps)
                        + (1 - all_labels) * np.log(1 - all_preds + eps)))
    from .bayesian import _roc_auc
    auc = _roc_auc(all_labels, all_preds)
    acc = float(np.mean((all_preds >= 0.5).astype(float) == all_labels))
    return {"brier": brier, "log_loss": ll, "roc_auc": auc,
            "accuracy": acc, "n_wells": n, "k_folds": k}


def w_idx(wells: list[WellLog], w: WellLog) -> int:
    for i, ww in enumerate(wells):
        if ww.name == w.name:
            return i
    return 0
