"""Simulator layer — virtual earth and forward modeling."""
from .scenarios import (
    SCENARIOS, get_scenario, scenario_descriptions,
    layered_model, reservoir_model, faulted_model,
    anticline_model, salt_dome_model, aquifer_model, mineral_vein_model,
)
from .forward import (
    forward_ert, forward_spectral, forward_magnetic, forward_gravity,
    forward_gpr, forward_seismic,
    wenner_geometry, dipole_dipole_geometry,
)
from .hifwd import (
    forward_ert_fd, forward_gravity_prism, forward_magnetic_prism,
    forward_gpr_ray, forward_seismic_ray,
)
from .grid import electrode_layout, survey_grid_points, total_measurements_estimate
from .engine import SimulationEngine, get_engine
from .ert3d import (
    EarthModel3D, forward_ert_3d, invert_ert_3d, Inversion3DResult,
)
from .mpinv import (
    PrismModel, GravityInversionResult, MagneticInversionResult,
    invert_gravity, invert_magnetic,
    forward_gpr_fdt, forward_seismic_tomography,
    invert_seismic_tomography, SeismicTomographyResult,
)
from .synthetic_fields import (
    SyntheticField, make_synthetic_reservoir_field,
    score_prospectivity_vs_truth,
)
from .physics_solvers import (
    gpr_fdtd_2d, seismic_fd_2d, pick_first_breaks,
    GPRFDTDResult, SeismicFDResult,
)

__all__ = [
    "SCENARIOS", "get_scenario", "scenario_descriptions",
    "layered_model", "reservoir_model", "faulted_model",
    "anticline_model", "salt_dome_model", "aquifer_model", "mineral_vein_model",
    # approximate forward models
    "forward_ert", "forward_spectral", "forward_magnetic", "forward_gravity",
    "forward_gpr", "forward_seismic",
    "wenner_geometry", "dipole_dipole_geometry",
    # high-accuracy forward models
    "forward_ert_fd", "forward_gravity_prism", "forward_magnetic_prism",
    "forward_gpr_ray", "forward_seismic_ray",
    # 3-D ERT
    "EarthModel3D", "forward_ert_3d", "invert_ert_3d", "Inversion3DResult",
    # multi-physics inversion
    "PrismModel", "GravityInversionResult", "MagneticInversionResult",
    "invert_gravity", "invert_magnetic",
    "forward_gpr_fdt", "forward_seismic_tomography",
    "invert_seismic_tomography", "SeismicTomographyResult",
    "electrode_layout", "survey_grid_points", "total_measurements_estimate",
    "SimulationEngine", "get_engine",
    # V7 synthetic fields & validation helpers
    "SyntheticField", "make_synthetic_reservoir_field",
    "score_prospectivity_vs_truth",
    # V7 high-fidelity physics solvers
    "gpr_fdtd_2d", "seismic_fd_2d", "pick_first_breaks",
    "GPRFDTDResult", "SeismicFDResult",
]
