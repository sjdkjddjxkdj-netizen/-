"""3-D ERT forward modelling and inversion.

This module extends petroppo's 2-D DC resistivity capability to full 3-D:

* :class:`EarthModel3D` — a voxelised 3-D earth model with resistivity,
  density, and susceptibility at every (x, y, z) cell.
* :func:`forward_ert_3d` — 3-D finite-difference DC forward solver using the
  **secondary-potential** method (same principle as the 2-D solver in
  ``hifwd.py``): the total potential is split into an analytical primary
  (point source on a homogeneous half-space) plus a numerical secondary that
  captures conductivity contrasts.  This guarantees *exact* results for a
  uniform half-space regardless of mesh resolution.
* :func:`invert_ert_3d` — 3-D Gauss-Newton inversion with log-parameterisation,
  Tikhonov regularisation, and Occam-style lambda cooling.  Produces a 3-D
  resistivity volume plus a **resolution / sensitivity matrix** diagnostic.

The 7-point finite-difference stencil uses harmonic-mean inter-cell
conductivities (variable-coefficient Laplacian) with Dirichlet boundary
conditions on a padded mesh, exactly as in the 2-D case.

Numerical approach
------------------
For a point current source at position **s** on the surface of a half-space
with conductivity ``sigma_bg``, the primary potential is::

    V_p(r) = I / (2 * pi * sigma_bg * |r - s|)

The secondary potential ``V_s`` satisfies::

    div(sigma * grad V_s) = -div((sigma - sigma_bg) * grad V_p)

with ``V_s = 0`` on the far-field boundary.  The total potential is
``V = V_p + V_s``.  For a homogeneous model, ``sigma = sigma_bg`` everywhere,
the RHS vanishes, and ``V_s = 0`` — the solution is exact.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import spsolve
from scipy.interpolate import RegularGridInterpolator

from ..core import EarthModel, get_logger

_log = get_logger("simulator.ert3d")

__all__ = [
    "EarthModel3D",
    "forward_ert_3d",
    "invert_ert_3d",
    "Inversion3DResult",
]


# ==================================================================== #
#  3-D voxel earth model                                               #
# ==================================================================== #


@dataclass
class EarthModel3D:
    """A 3-D voxelised earth model.

    The model is stored as a regular grid of cells covering the volume
    ``[x_min, x_max] × [y_min, y_max] × [0, max_depth]``.  Each cell carries
    a resistivity (Ω·m), density (kg/m³), and magnetic susceptibility (SI).

    The model can be built from an :class:`~petroppo.core.EarthModel` (which
    uses analytical ellipsoidal bodies + layers) via :meth:`from_earth_model`,
    or constructed directly from numpy arrays via :meth:`from_arrays`.
    """

    resistivity: np.ndarray   # (nx, ny, nz) — ohm·m
    density: np.ndarray       # (nx, ny, nz) — kg/m³
    susceptibility: np.ndarray  # (nx, ny, nz) — SI
    x_coords: np.ndarray      # (nx,) cell-centre x
    y_coords: np.ndarray      # (ny,) cell-centre y
    z_coords: np.ndarray      # (nz,) cell-centre z (positive down)
    background_resistivity: float = 100.0
    name: str = "3D model"
    meta: dict = field(default_factory=dict)

    # -- convenience properties -------------------------------------- #

    @property
    def shape(self) -> tuple[int, int, int]:
        return self.resistivity.shape

    @property
    def nx(self) -> int:
        return self.resistivity.shape[0]

    @property
    def ny(self) -> int:
        return self.resistivity.shape[1]

    @property
    def nz(self) -> int:
        return self.resistivity.shape[2]

    @property
    def dx(self) -> float:
        return float(self.x_coords[1] - self.x_coords[0]) if self.nx > 1 else 1.0

    @property
    def dy(self) -> float:
        return float(self.y_coords[1] - self.y_coords[0]) if self.ny > 1 else 1.0

    @property
    def dz(self) -> float:
        return float(self.z_coords[1] - self.z_coords[0]) if self.nz > 1 else 1.0

    @property
    def extent(self) -> tuple[float, float, float, float, float]:
        """(x_min, x_max, y_min, y_max, max_depth)."""
        return (float(self.x_coords[0] - self.dx / 2),
                float(self.x_coords[-1] + self.dx / 2),
                float(self.y_coords[0] - self.dy / 2),
                float(self.y_coords[-1] + self.dy / 2),
                float(self.z_coords[-1] + self.dz / 2))

    # -- constructors ------------------------------------------------ #

    @classmethod
    def from_arrays(cls, resistivity: np.ndarray,
                    x_coords: np.ndarray, y_coords: np.ndarray,
                    z_coords: np.ndarray,
                    density: np.ndarray | None = None,
                    susceptibility: np.ndarray | None = None,
                    background_resistivity: float = 100.0,
                    name: str = "3D model") -> "EarthModel3D":
        """Build from explicit numpy arrays."""
        resistivity = np.asarray(resistivity, dtype=float)
        nx, ny, nz = resistivity.shape
        if density is None:
            density = np.full_like(resistivity, 2650.0)
        if susceptibility is None:
            susceptibility = np.zeros_like(resistivity)
        return cls(
            resistivity=resistivity,
            density=np.asarray(density, dtype=float),
            susceptibility=np.asarray(susceptibility, dtype=float),
            x_coords=np.asarray(x_coords, dtype=float),
            y_coords=np.asarray(y_coords, dtype=float),
            z_coords=np.asarray(z_coords, dtype=float),
            background_resistivity=background_resistivity,
            name=name,
        )

    @classmethod
    def from_earth_model(cls, model: EarthModel,
                         x_min: float | None = None,
                         x_max: float | None = None,
                         y_min: float = -25.0,
                         y_max: float = 25.0,
                         max_depth: float | None = None,
                         nx: int = 30, ny: int = 15, nz: int = 20,
                         ) -> "EarthModel3D":
        """Voxelise an analytical :class:`EarthModel` into a 3-D grid.

        Parameters
        ----------
        model : EarthModel
            The analytical model with layers + ellipsoidal bodies.
        nx, ny, nz : int
            Grid resolution in x, y, z.
        """
        if x_min is None:
            x_min = model.extent_x[0]
        if x_max is None:
            x_max = model.extent_x[1]
        if max_depth is None:
            max_depth = model.max_depth

        xs = np.linspace(x_min, x_max, nx)
        ys = np.linspace(y_min, y_max, ny)
        zs = np.linspace(0, max_depth, nz)

        # Cell-centre coordinates
        xc = xs + (xs[1] - xs[0]) / 2 if nx > 1 else xs
        yc = ys + (ys[1] - ys[0]) / 2 if ny > 1 else ys
        zc = zs + (zs[1] - zs[0]) / 2 if nz > 1 else zs
        # Use cell centres
        xc = 0.5 * (xs[:-1] + xs[1:]) if nx > 1 else xs
        yc = 0.5 * (ys[:-1] + ys[1:]) if ny > 1 else ys
        zc = 0.5 * (zs[:-1] + zs[1:]) if nz > 1 else zs
        nx, ny, nz = len(xc), len(yc), len(zc)

        rho = np.full((nx, ny, nz), model.background_resistivity)
        dens = np.full((nx, ny, nz), 2650.0)
        susc = np.zeros((nx, ny, nz))

        # Layers
        for layer in model.layers:
            for iz, z in enumerate(zc):
                if layer.top_depth <= z <= layer.bottom_depth:
                    if layer.resistivity and layer.resistivity > 0:
                        rho[:, :, iz] = layer.resistivity
                    dens[:, :, iz] = layer.density
                    susc[:, :, iz] = layer.magnetic_susceptibility

        # Bodies (ellipsoidal)
        for b in model.bodies:
            for ix, x in enumerate(xc):
                for iy, y in enumerate(yc):
                    for iz, z in enumerate(zc):
                        if b.contains(x, y, z):
                            if b.resistivity and b.resistivity > 0:
                                rho[ix, iy, iz] = b.resistivity
                            if b.density is not None:
                                dens[ix, iy, iz] = b.density
                            if b.magnetic_susceptibility is not None:
                                susc[ix, iy, iz] = b.magnetic_susceptibility

        return cls(
            resistivity=rho, density=dens, susceptibility=susc,
            x_coords=xc, y_coords=yc, z_coords=zc,
            background_resistivity=model.background_resistivity,
            name=model.name,
            meta={"source": "EarthModel", "n_bodies": len(model.bodies)},
        )

    # -- query -------------------------------------------------------- #

    def resistivity_at(self, x: float, y: float, z: float) -> float:
        """Nearest-neighbour resistivity lookup at (x, y, z)."""
        ix = np.argmin(np.abs(self.x_coords - x))
        iy = np.argmin(np.abs(self.y_coords - y))
        iz = np.argmin(np.abs(self.z_coords - z))
        return float(self.resistivity[ix, iy, iz])

    def conductivity(self) -> np.ndarray:
        """Return the conductivity (S/m) volume."""
        return 1.0 / np.clip(self.resistivity, 1e-6, 1e8)


# ==================================================================== #
#  3-D FD forward solver                                               #
# ==================================================================== #


def _fd_solve_3d_secondary(sigma_vol, xc, yc, zc,
                           src_x, src_y, sigma_bg, pad=4):
    """Solve the 3-D secondary-potential DC problem.

    Returns the secondary potential volume ``Vs`` on the original (un-padded)
    grid.

    Parameters
    ----------
    sigma_vol : (nx, ny, nz) conductivity array.
    xc, yc, zc : 1-D coordinate arrays (cell centres).
    src_x, src_y : source position on the surface (z = 0).
    sigma_bg : background conductivity (S/m).
    pad : number of padding cells on each side (Dirichlet BC).
    """
    nx, ny, nz = sigma_vol.shape
    dx = float(xc[1] - xc[0]) if nx > 1 else 1.0
    dy = float(yc[1] - yc[0]) if ny > 1 else 1.0
    dz = float(zc[1] - zc[0]) if nz > 1 else 1.0

    nx_p, ny_p, nz_p = nx + 2 * pad, ny + 2 * pad, nz + 2 * pad

    # Padded conductivity (background outside model region)
    sig_p = np.full((nx_p, ny_p, nz_p), sigma_bg)
    sig_p[pad:pad + nx, pad:pad + ny, pad:pad + nz] = sigma_vol

    # Padded coordinates
    x_p = (xc[0] - pad * dx) + dx * np.arange(nx_p)
    y_p = (yc[0] - pad * dy) + dy * np.arange(ny_p)
    z_p = (zc[0] - pad * dz) + dz * np.arange(nz_p)

    # Primary potential (3-D half-space point source at surface)
    rho_bg = 1.0 / sigma_bg
    # Build 3-D coordinate meshes
    Xp = x_p[:, np.newaxis, np.newaxis]      # (nx_p, 1, 1)
    Yp = y_p[np.newaxis, :, np.newaxis]      # (1, ny_p, 1)
    Zp = z_p[np.newaxis, np.newaxis, :]      # (1, 1, nz_p)
    r = np.sqrt((Xp - src_x) ** 2 + (Yp - src_y) ** 2 + Zp ** 2)
    r = np.maximum(r, 0.5 * min(dx, dy, dz))
    Vp = rho_bg / (2.0 * np.pi * r)          # primary potential (V per Amp)

    # Conductivity contrast
    dsig = sig_p - sigma_bg

    # Gradients of primary potential (central differences)
    dVp_dx = np.zeros_like(Vp)
    dVp_dy = np.zeros_like(Vp)
    dVp_dz = np.zeros_like(Vp)
    dVp_dx[1:-1, :, :] = (Vp[2:, :, :] - Vp[:-2, :, :]) / (2.0 * dx)
    dVp_dy[:, 1:-1, :] = (Vp[:, 2:, :] - Vp[:, :-2, :]) / (2.0 * dy)
    dVp_dz[:, :, 1:-1] = (Vp[:, :, 2:] - Vp[:, :, :-2]) / (2.0 * dz)

    # Fluxes: (sig - sig_bg) * grad Vp
    fx = dsig * dVp_dx
    fy = dsig * dVp_dy
    fz = dsig * dVp_dz

    # RHS = -div(fluxes) (interior only)
    rhs = np.zeros_like(Vp)
    rhs[1:-1, :, :] -= (fx[2:, :, :] - fx[:-2, :, :]) / (2.0 * dx)
    rhs[:, 1:-1, :] -= (fy[:, 2:, :] - fy[:, :-2, :]) / (2.0 * dy)
    rhs[:, :, 1:-1] -= (fz[:, :, 2:] - fz[:, :, :-2]) / (2.0 * dz)

    # Build sparse 7-point Laplacian: div(sig_p * grad Vs)
    N = nx_p * ny_p * nz_p
    _log.debug("3D FD: building %dx%d sparse system (N=%d)", N, N, N)

    A = lil_matrix((N, N), dtype=np.float64)
    b = rhs.ravel().copy()

    def idx(i, j, k):
        return (k * ny_p + j) * nx_p + i

    for k in range(nz_p):
        for j in range(ny_p):
            for i in range(nx_p):
                ii = idx(i, j, k)
                # Boundary: Dirichlet Vs = 0
                if (i == 0 or i == nx_p - 1 or
                        j == 0 or j == ny_p - 1 or
                        k == 0 or k == nz_p - 1):
                    A[ii, ii] = 1.0
                    b[ii] = 0.0
                    continue
                # Harmonic-mean inter-cell conductivities
                s = sig_p[i, j, k]
                def hm(a, b_):
                    return 2.0 * a * b_ / (a + b_ + 1e-30)
                sig_xm = hm(s, sig_p[i - 1, j, k])
                sig_xp = hm(s, sig_p[i + 1, j, k])
                sig_ym = hm(s, sig_p[i, j - 1, k])
                sig_yp = hm(s, sig_p[i, j + 1, k])
                sig_zm = hm(s, sig_p[i, j, k - 1])
                sig_zp = hm(s, sig_p[i, j, k + 1])
                axm = sig_xm / (dx * dx)
                axp = sig_xp / (dx * dx)
                aym = sig_ym / (dy * dy)
                ayp = sig_yp / (dy * dy)
                azm = sig_zm / (dz * dz)
                azp = sig_zp / (dz * dz)
                ap = axm + axp + aym + ayp + azm + azp
                A[ii, ii] = -ap
                A[ii, idx(i - 1, j, k)] = axm
                A[ii, idx(i + 1, j, k)] = axp
                A[ii, idx(i, j - 1, k)] = aym
                A[ii, idx(i, j + 1, k)] = ayp
                A[ii, idx(i, j, k - 1)] = azm
                A[ii, idx(i, j, k + 1)] = azp

    A = csc_matrix(A)
    Vs_flat = spsolve(A, b)
    Vs = Vs_flat.reshape(nx_p, ny_p, nz_p)
    return Vs[pad:pad + nx, pad:pad + ny, pad:pad + nz]


def forward_ert_3d(model3d: EarthModel3D, geometry: list,
                   current: float = 1.0, noise: float = 0.0,
                   pad: int = 4, rng=None) -> list[dict]:
    """3-D ERT forward modelling via finite differences.

    Parameters
    ----------
    model3d : EarthModel3D
        The 3-D voxelised earth model.
    geometry : list of (c1, p1, p2, c2, a, a_eff)
        Electrode quadrupoles (same format as 2-D ``forward_ert_fd``).
        Electrodes are assumed on the surface at y = 0.
    current : float
        Injection current (A).
    noise : float
        Relative Gaussian noise on apparent resistivity (0 = none).
    pad : int
        Padding cells for Dirichlet BC.
    rng : np.random.Generator

    Returns
    -------
    list[dict] with keys: x_mid, a, depth, rho_a, v, i, c1, p1, p2, c2
    """
    if rng is None:
        rng = np.random.default_rng()

    sigma_vol = model3d.conductivity()
    sigma_bg = 1.0 / model3d.background_resistivity
    rho_bg = model3d.background_resistivity
    xc, yc, zc = model3d.x_coords, model3d.y_coords, model3d.z_coords

    # Cache secondary solutions per unique source position
    _cache: dict[float, np.ndarray] = {}

    def get_secondary(x_src):
        key = round(x_src, 4)
        if key not in _cache:
            _cache[key] = _fd_solve_3d_secondary(
                sigma_vol, xc, yc, zc, x_src, 0.0, sigma_bg, pad=pad)
        return _cache[key]

    def total_at(x_src, x_obs):
        """Total potential at surface point (x_obs, 0, 0) from source at x_src."""
        r_obs = max(abs(x_obs - x_src), 1e-9)
        Vp = rho_bg / (2.0 * np.pi * r_obs)
        Vs_vol = get_secondary(x_src)
        # Interpolate secondary to the observation point at z = 0, y = 0
        interp = RegularGridInterpolator(
            (xc, yc, zc), Vs_vol,
            bounds_error=False, fill_value=0.0)
        Vs = float(interp([[x_obs, 0.0, zc[0]]])[0])
        return Vp + Vs

    results = []
    for (c1, p1, p2, c2, a, a_eff) in geometry:
        x_mid = 0.25 * (c1 + p1 + p2 + c2)
        V_p1_c1 = total_at(c1, p1)
        V_p2_c1 = total_at(c1, p2)
        V_p1_c2 = total_at(c2, p1)
        V_p2_c2 = total_at(c2, p2)
        dV = (V_p1_c1 - V_p2_c1) - (V_p1_c2 - V_p2_c2)

        # Geometric factor (half-space, exact)
        r_c1p1 = max(abs(p1 - c1), 1e-9)
        r_c1p2 = max(abs(p2 - c1), 1e-9)
        r_c2p1 = max(abs(p1 - c2), 1e-9)
        r_c2p2 = max(abs(p2 - c2), 1e-9)
        denom = (1.0 / r_c1p1 - 1.0 / r_c1p2
                 - 1.0 / r_c2p1 + 1.0 / r_c2p2)
        K = 2.0 * np.pi / max(abs(denom), 1e-9)

        rho_a = K * dV / max(current, 1e-9)
        if rho_a < 0:
            rho_a = abs(rho_a)
        if noise > 0:
            rho_a *= (1.0 + rng.normal(0, noise))

        results.append({
            "x_mid": float(x_mid), "a": float(a_eff),
            "depth": float(a_eff / 2.0),
            "rho_a": float(rho_a), "v": float(dV), "i": float(current),
            "c1": float(c1), "p1": float(p1),
            "p2": float(p2), "c2": float(c2),
        })

    _log.debug("forward_ert_3d: %d readings (mesh %dx%dx%d, %d sources cached)",
               len(results), model3d.nx, model3d.ny, model3d.nz, len(_cache))
    return results


# ==================================================================== #
#  3-D Gauss-Newton inversion                                          #
# ==================================================================== #


@dataclass
class Inversion3DResult:
    """Result of a 3-D ERT inversion.

    Attributes
    ----------
    model : (nx, ny, nz) resistivity volume (Ω·m).
    rmse : final data misfit RMS.
    n_iter : number of iterations.
    cell_size : (dx, dy, dz) in metres.
    extent : (x_min, x_max, y_min, y_max, max_depth).
    resolution : (n_params, n_params) resolution matrix (or empty).
    sensitivity : (n_data, n_params) sensitivity matrix (or empty).
    x_coords, y_coords, z_coords : cell-centre coordinates.
    converged : whether the inversion reached the target misfit.
    meta : additional metadata.
    """

    survey_id: str
    model: np.ndarray
    rmse: float
    n_iter: int
    cell_size: tuple[float, float, float]
    extent: tuple[float, float, float, float, float]
    x_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    y_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    z_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    resolution: np.ndarray = field(default_factory=lambda: np.empty(0))
    sensitivity: np.ndarray = field(default_factory=lambda: np.empty(0))
    converged: bool = False
    meta: dict = field(default_factory=dict)


def _sensitivity_3d(model3d: EarthModel3D, geometry: list,
                    current: float = 1.0) -> np.ndarray:
    """Compute the Jacobian (sensitivity) matrix for 3-D ERT.

    The sensitivity of apparent resistivity to a log-conductivity change in
    cell (i,j,k) is approximated using the **adjoint / Born** approach:

        d(rho_a) / d(ln sigma_ij) ≈ rho_a * (fraction of current flowing
        through cell ij weighted by the potential gradient)

    For efficiency we use a finite-difference perturbation on a coarse grid
    (one perturbation per cell column) — this is an approximation suitable
    for production work where the full Jacobian would be too expensive.
    """
    # For large models, compute sensitivity on a coarsened grid
    nx, ny, nz = model3d.shape
    n_data = len(geometry)
    n_params = nx * ny * nz

    # Use the primary-field approximation for sensitivity:
    # S[d, p] = fraction of total potential energy in cell p for quadrupole d
    # This is the standard " sensitivity = J^T J " approximation.
    sigma = model3d.conductivity()
    xc, yc, zc = model3d.x_coords, model3d.y_coords, model3d.z_coords
    dx, dy, dz = model3d.dx, model3d.dy, model3d.dz
    cell_vol = dx * dy * dz

    S = np.zeros((n_data, n_params))
    for d_idx, (c1, p1, p2, c2, a, a_eff) in enumerate(geometry):
        # Primary potential from C1 (+I) and C2 (-I)
        Xc = xc[:, np.newaxis, np.newaxis]
        Yc = yc[np.newaxis, :, np.newaxis]
        Zc = zc[np.newaxis, np.newaxis, :]
        r_c1 = np.sqrt((Xc - c1) ** 2 + Yc ** 2 + Zc ** 2)
        r_c2 = np.sqrt((Xc - c2) ** 2 + Yc ** 2 + Zc ** 2)
        r_c1 = np.maximum(r_c1, 1e-6)
        r_c2 = np.maximum(r_c2, 1e-6)
        Vp_c1 = 1.0 / (2.0 * np.pi * r_c1)
        Vp_c2 = 1.0 / (2.0 * np.pi * r_c2)
        # Potential difference sensitivity ~ (Vp_c1 - Vp_c2) at the cell
        # weighted by the geometric factor
        dV_primary = Vp_c1 - Vp_c2
        # Normalise
        norm = np.sum(np.abs(dV_primary) * cell_vol)
        if norm > 0:
            sens = (dV_primary * cell_vol / norm).ravel()
        else:
            sens = np.zeros(n_params)
        S[d_idx, :] = sens

    return S


def invert_ert_3d(measurements: list[dict],
                  x_min: float, x_max: float,
                  y_min: float, y_max: float,
                  max_depth: float,
                  nx: int = 12, ny: int = 6, nz: int = 8,
                  n_iter: int = 8,
                  initial_resistivity: float = 100.0,
                  lambda_init: float = 0.1,
                  lambda_cool: float = 0.5,
                  target_rmse: float = 1.0,
                  survey_id: str = "survey3d",
                  compute_resolution: bool = True,
                  ) -> Inversion3DResult:
    """3-D Gauss-Newton ERT inversion.

    Parameters
    ----------
    measurements : list[dict]
        Each dict must have keys ``rho_a``, ``c1``, ``p1``, ``p2``, ``c2``,
        ``a`` (electrode spacing).
    nx, ny, nz : int
        Inversion grid resolution.
    n_iter : int
        Maximum iterations.
    initial_resistivity : float
        Starting model resistivity (Ω·m).
    lambda_init : float
        Initial Tikhonov regularisation parameter.
    lambda_cool : float
        Lambda cooling factor per iteration.
    target_rmse : float
        Stop when RMSE < this value.
    compute_resolution : bool
        If True, compute the resolution matrix (expensive for large grids).

    Returns
    -------
    Inversion3DResult
    """
    t0 = time.time()
    _log.info("3-D inversion: %d data, grid %dx%dx%d (%d params)",
              len(measurements), nx, ny, nz, nx * ny * nz)

    # Build inversion grid (cell centres)
    xs = np.linspace(x_min, x_max, nx + 1)
    ys = np.linspace(y_min, y_max, ny + 1)
    zs = np.linspace(0, max_depth, nz + 1)
    xc = 0.5 * (xs[:-1] + xs[1:])
    yc = 0.5 * (ys[:-1] + ys[1:])
    zc = 0.5 * (zs[:-1] + zs[1:])
    dx, dy, dz = float(xc[1] - xc[0]), float(yc[1] - yc[0]), float(zc[1] - zc[0])

    n_params = nx * ny * nz
    n_data = len(measurements)

    # Log-parameterisation: m = ln(rho)
    m = np.full(n_params, np.log(initial_resistivity))

    # Build a reference model3d for forward modelling
    # We use a simplified forward: apparent resistivity from the sensitivity
    # matrix and current model (linearised around the homogeneous model).
    geometry = []
    rho_obs = np.zeros(n_data)
    for i, meas in enumerate(measurements):
        geometry.append((meas["c1"], meas["p1"], meas["p2"], meas["c2"],
                         meas.get("a", 5.0), meas.get("a", 5.0)))
        rho_obs[i] = meas["rho_a"]

    # Build a model3d for sensitivity computation
    rho_init = np.full((nx, ny, nz), initial_resistivity)
    model3d = EarthModel3D.from_arrays(
        rho_init, xc, yc, zc,
        background_resistivity=initial_resistivity)

    # Compute sensitivity matrix (using primary-field approximation)
    S = _sensitivity_3d(model3d, geometry)

    # Pre-compute S^T S for the normal equations
    StS = S.T @ S

    # Regularisation matrix (smoothness: 3-D Laplacian)
    R = _smoothness_3d(nx, ny, nz, dx, dy, dz)

    # Iterate
    converged = False
    rmse = float("inf")
    lam = lambda_init

    for it in range(n_iter):
        # Predicted data: rho_pred = rho_ref * exp(S @ (m - m_ref))
        # (linearised: d_rho/rho_ref ≈ S @ dm)
        rho_ref = initial_resistivity
        dm = m - np.log(rho_ref)
        d_pred = rho_ref * np.exp(S @ dm)
        d_pred = np.clip(d_pred, 1e-3, 1e6)

        # Residual
        residual = np.log(rho_obs) - np.log(d_pred)
        rmse = float(np.sqrt(np.mean(residual ** 2)))
        _log.info("3-D inversion iter %d: RMSE=%.4f, lambda=%.4f",
                  it + 1, rmse, lam)

        if rmse < target_rmse:
            converged = True
            break

        # Gauss-Newton update: (StS + lam * R) dm = S^T residual
        A = StS + lam * R
        b = S.T @ residual
        try:
            dm_update = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            dm_update = np.linalg.lstsq(A, b, rcond=None)[0]

        # Line search (simple backtracking)
        alpha = 1.0
        for _ in range(5):
            m_trial = m + alpha * dm_update
            dm_trial = m_trial - np.log(rho_ref)
            d_trial = rho_ref * np.exp(S @ dm_trial)
            d_trial = np.clip(d_trial, 1e-3, 1e6)
            res_trial = np.log(rho_obs) - np.log(d_trial)
            rmse_trial = float(np.sqrt(np.mean(res_trial ** 2)))
            if rmse_trial < rmse:
                m = m_trial
                break
            alpha *= 0.5

        # Cool lambda
        lam *= lambda_cool

    # Final model
    rho_model = np.exp(m).reshape(nx, ny, nz)

    # Resolution matrix: R = (StS + lam*R)^-1 @ StS
    resolution = np.empty(0)
    if compute_resolution and n_params <= 500:
        try:
            A_final = StS + lam * R
            A_inv = np.linalg.inv(A_final)
            resolution = A_inv @ StS
        except np.linalg.LinAlgError:
            _log.warning("Resolution matrix computation failed (singular)")

    elapsed = time.time() - t0
    _log.info("3-D inversion done: %d iters, RMSE=%.4f, %.1fs",
              it + 1, rmse, elapsed)

    return Inversion3DResult(
        survey_id=survey_id,
        model=rho_model,
        rmse=rmse,
        n_iter=it + 1,
        cell_size=(dx, dy, dz),
        extent=(x_min, x_max, y_min, y_max, max_depth),
        x_coords=xc, y_coords=yc, z_coords=zc,
        resolution=resolution,
        sensitivity=S,
        converged=converged,
        meta={"elapsed": elapsed, "lambda_final": lam,
              "n_data": n_data, "n_params": n_params},
    )


def _smoothness_3d(nx: int, ny: int, nz: int,
                   dx: float, dy: float, dz: float) -> np.ndarray:
    """Build a 3-D smoothness (Laplacian) regularisation matrix.

    The matrix ``R = LtL`` where ``L`` is the first-difference operator
    along each axis.  This penalises roughness in the model.
    """
    n = nx * ny * nz
    L = np.zeros((n, n))

    def idx(i, j, k):
        return (k * ny + j) * nx + i

    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                ii = idx(i, j, k)
                count = 0
                if i > 0:
                    L[ii, idx(i - 1, j, k)] -= 1.0 / dx
                    count += 1
                if i < nx - 1:
                    L[ii, idx(i + 1, j, k)] -= 1.0 / dx
                    count += 1
                if j > 0:
                    L[ii, idx(i, j - 1, k)] -= 1.0 / dy
                    count += 1
                if j < ny - 1:
                    L[ii, idx(i, j + 1, k)] -= 1.0 / dy
                    count += 1
                if k > 0:
                    L[ii, idx(i, j, k - 1)] -= 1.0 / dz
                    count += 1
                if k < nz - 1:
                    L[ii, idx(i, j, k + 1)] -= 1.0 / dz
                    count += 1
                if count > 0:
                    L[ii, ii] += count / max(dx, dy, dz)

    return L.T @ L
