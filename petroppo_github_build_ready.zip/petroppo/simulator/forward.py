"""Forward modeling for all geophysical methods.

ERT uses sensitivity functions for electrode configurations to produce
realistic apparent resistivity that responds to deep bodies at larger spacings.

Spectral IP uses the Cole-Cole complex resistivity model.

Magnetic, Gravity, GPR, and Seismic forward models compute the physical
response of the earth model at each measurement point.
"""
from __future__ import annotations

import numpy as np

from ..core import EarthModel, get_logger

_log = get_logger("simulator.forward")


def _electrode_positions(n: int, spacing: float, start: float = 0.0) -> np.ndarray:
    """Positions of n electrodes on a line with constant spacing."""
    return start + spacing * np.arange(n)


# ======================================================================
# ERT — Electrical Resistivity Tomography
# ======================================================================

def wenner_geometry(n_electrodes: int, spacing: float):
    """Generate Wenner alpha configurations: (C1,P1,P2,C2) for each reading.

    Wenner alpha: equal spacing a between the four electrodes.
    Produces (n-3) readings per level, plus multi-level readings.
    """
    quads = []
    x = _electrode_positions(n_electrodes, spacing)
    for i in range(n_electrodes - 3):
        c1, p1, p2, c2 = x[i], x[i + 1], x[i + 2], x[i + 3]
        a = spacing
        level = i
        a_eff = (level + 1) * a
        quads.append((c1, p1, p2, c2, a, a_eff))
    # deeper levels (Wenner multi-level)
    for level in range(2, max(2, n_electrodes // 3)):
        a = level * spacing
        for i in range(n_electrodes - 3 * level):
            c1, p1, p2, c2 = x[i], x[i + level], x[i + 2 * level], x[i + 3 * level]
            quads.append((c1, p1, p2, c2, a, a))
    return quads


def dipole_dipole_geometry(n_electrodes: int, spacing: float):
    """Generate Dipole-Dipole configurations: (C1,C2,P1,P2) with increasing n factor."""
    quads = []
    x = _electrode_positions(n_electrodes, spacing)
    a = spacing
    for n_factor in range(1, max(2, n_electrodes // 3)):
        for i in range(n_electrodes - 3 - (n_factor - 1) * 2):
            c1, c2 = x[i], x[i + 1]
            p1, p2 = x[i + 1 + n_factor], x[i + 2 + n_factor]
            depth = a * n_factor / 3.0
            quads.append((c1, c2, p1, p2, a, depth))
    return quads


def _wenner_sensitivity(x: float, z: float, c1: float, p1: float,
                        p2: float, c2: float) -> float:
    """Wenner sensitivity at point (x,z) below the surface.

    Uses mirror-image approximation for half-space simulation.
    Sensitivity concentrates between electrodes and decays with depth.
    """
    if z <= 0:
        return 0.0

    def dist2(xe, ze):
        return (x - xe) ** 2 + (z - ze) ** 2

    r_c1 = np.sqrt(dist2(c1, 0.0))
    r_c2 = np.sqrt(dist2(c2, 0.0))
    r_p1 = np.sqrt(dist2(p1, 0.0))
    r_p2 = np.sqrt(dist2(p2, 0.0))
    eps = 1e-9
    mid = 0.25 * (c1 + p1 + p2 + c2)
    horiz = np.exp(-((x - mid) ** 2) / (0.5 * (c2 - c1) ** 2 + eps))
    depth_factor = np.exp(-z / max(0.5 * (c2 - c1), eps))
    dipole = abs((1.0 / (r_c1 + eps) - 1.0 / (r_c2 + eps)) *
                 (1.0 / (r_p1 + eps) - 1.0 / (r_p2 + eps)))
    return float(horiz * depth_factor * (0.5 * dipole + 0.5))


def forward_ert(model: EarthModel, geometry, y: float = 0.0,
                current: float = 1.0, noise: float = 0.0,
                rng=None) -> list[dict]:
    """Compute forward ERT readings on an earth model.

    Parameters
    ----------
    model : EarthModel
    geometry : list of (c1,p1,p2,c2,a,a_eff)
    y : northing of the survey line
    current : injected current (amperes)
    noise : relative noise level
    rng : random generator (None -> numpy default)

    Returns
    -------
    list[dict] : each reading has keys: x_mid, a, depth, rho_a, v, i
    """
    if rng is None:
        rng = np.random.default_rng()

    nz = 40
    zgrid = np.linspace(0.0, model.max_depth, nz)

    results = []
    for (c1, p1, p2, c2, a, a_eff) in geometry:
        x_mid = 0.25 * (c1 + p1 + p2 + c2)
        weights = []
        rhos = []
        for z in zgrid:
            w = _wenner_sensitivity(x_mid, z, c1, p1, p2, c2)
            if w <= 0:
                continue
            rho = model.resistivity_at(x_mid, y, z)
            weights.append(w)
            rhos.append(rho)
        if not weights:
            rho_a = model.background_resistivity
        else:
            w = np.array(weights)
            r = np.array(rhos)
            rho_a = float(np.sum(w * r) / np.sum(w))
        if noise > 0:
            rho_a *= (1.0 + rng.normal(0, noise))
        v = rho_a * current / (2.0 * np.pi * max(a_eff, 1e-9))
        if noise > 0:
            v *= (1.0 + rng.normal(0, noise * 0.5))
        results.append({
            "x_mid": float(x_mid), "a": float(a_eff),
            "depth": float(a_eff / 2.0),
            "rho_a": float(rho_a), "v": float(v), "i": float(current),
        })
    _log.debug("forward_ert: %d readings", len(results))
    return results


# ======================================================================
# Spectral IP — Cole-Cole model
# ======================================================================

def forward_spectral(model: EarthModel, x: float, y: float, a: float,
                     frequencies, current: float = 1.0,
                     chargeability: float = 0.05, noise: float = 0.0,
                     rng=None) -> list[dict]:
    """Spectral IP forward model using Cole-Cole complex resistivity.

    Z(f) = rho0 * [1 - m * (1 - 1/(1+(i*w*tau)^c))]
    where w = 2*pi*f.

    Parameters
    ----------
    chargeability : m (0..1)
    """
    if rng is None:
        rng = np.random.default_rng()
    rho0 = model.resistivity_at(x, y, a / 2.0)
    tau = 0.1     # time constant
    c = 0.5       # Cole-Cole exponent
    m = chargeability
    out = []
    for f in frequencies:
        w = 2 * np.pi * f
        z_complex = 1.0 - m * (1.0 - 1.0 / (1.0 + (1j * w * tau) ** c))
        Z = rho0 * z_complex
        mag = abs(Z)
        phase = np.angle(Z, deg=True)
        if noise > 0:
            mag *= (1.0 + rng.normal(0, noise))
            phase += rng.normal(0, noise * 30.0)
        out.append({
            "freq": float(f), "rho_a": float(mag), "phase": float(phase),
            "i": current, "a": a, "x": x, "y": y,
        })
    return out


# ======================================================================
# Magnetic — total field anomaly
# ======================================================================

def forward_magnetic(model: EarthModel, x_points: np.ndarray, y: float = 0.0,
                     background_field: float = 47000.0,
                     noise: float = 0.0, rng=None) -> list[dict]:
    """Compute magnetic total-field anomaly along a profile.

    Uses a simplified prism-anomaly approximation for each body.
    """
    if rng is None:
        rng = np.random.default_rng()
    results = []
    for x in x_points:
        anomaly = 0.0
        for b in model.bodies:
            # simplified vertical prism anomaly
            dx = x - b.cx
            dy = y - b.cy
            r2 = dx * dx + dy * dy + b.cz * b.cz
            if r2 < 1e-6:
                r2 = 1e-6
            # anomaly proportional to susceptibility contrast (approx)
            susc_contrast = 0.01  # assume body has higher susceptibility
            anomaly += susc_contrast * 50000.0 * (b.rz / np.sqrt(r2))
        b_total = background_field + anomaly
        if noise > 0:
            b_total += rng.normal(0, noise * 5.0)
        results.append({"x": float(x), "y": float(y),
                        "b_total": float(b_total),
                        "anomaly": float(anomaly)})
    return results


# ======================================================================
# Gravity — Bouguer anomaly
# ======================================================================

def forward_gravity(model: EarthModel, x_points: np.ndarray, y: float = 0.0,
                    noise: float = 0.0, rng=None) -> list[dict]:
    """Compute gravity anomaly (mGal) along a profile.

    Uses a simplified sphere/excess-mass approximation for each body.
    """
    if rng is None:
        rng = np.random.default_rng()
    G = 6.674e-11  # gravitational constant
    results = []
    for x in x_points:
        g_anomaly = 0.0
        for b in model.bodies:
            dx = x - b.cx
            dy = y - b.cy
            r2 = dx * dx + dy * dy + b.cz * b.cz
            if r2 < 1e-6:
                r2 = 1e-6
            r = np.sqrt(r2)
            # excess mass proportional to body volume * density contrast
            vol = (4.0 / 3.0) * np.pi * b.rx * b.ry * b.rz
            d_rho = 500.0  # assumed density contrast (kg/m³)
            dm = vol * d_rho
            # vertical component of gravity anomaly in mGal
            g_anomaly += 1e5 * G * dm * b.cz / (r2 * r)  # convert to mGal
        if noise > 0:
            g_anomaly += rng.normal(0, noise * 0.1)
        results.append({"x": float(x), "y": float(y),
                        "g": float(g_anomaly)})
    return results


# ======================================================================
# GPR — Ground Penetrating Radar
# ======================================================================

def forward_gpr(model: EarthModel, x: float, y: float,
                max_depth: float = 20.0, n_samples: int = 256,
                frequency: float = 100e6, noise: float = 0.0,
                rng=None) -> dict:
    """Compute a GPR trace (radargram) at a single location.

    Returns a time-domain trace with reflections from layer boundaries
    and body interfaces based on dielectric contrasts.
    """
    if rng is None:
        rng = np.random.default_rng()

    eps0 = 8.854e-12
    c = 3e8  # speed of light

    # Build velocity model from dielectric permittivity
    depths = [0.0]
    vels = []
    eps_list = []
    for lay in model.layers:
        eps = lay.dielectric
        v = c / np.sqrt(max(eps, 1.0))
        depths.append(lay.bottom_depth)
        vels.append(v)
        eps_list.append(eps)
    # background
    if not vels:
        vels = [c / np.sqrt(6.0)]
        depths = [0.0, max_depth]
        eps_list = [6.0]

    # reflection coefficients at interfaces
    refs = []
    for i in range(len(eps_list) - 1):
        eps1, eps2 = eps_list[i], eps_list[i + 1]
        r = (np.sqrt(eps1) - np.sqrt(eps2)) / (np.sqrt(eps1) + np.sqrt(eps2))
        refs.append(r)

    # two-way travel times for layer boundaries
    twt_boundaries = [0.0]
    for i in range(len(vels)):
        thickness = depths[i + 1] - depths[i]
        twt_boundaries.append(twt_boundaries[-1] + 2.0 * thickness / vels[i])

    # time samples
    t_max = twt_boundaries[-1] * 1.2 if twt_boundaries else 200e-9
    t = np.linspace(0, max(t_max, 100e-9), n_samples)

    # Ricker wavelet
    t0 = 1.0 / frequency
    wavelet = (1.0 - 2.0 * (np.pi * frequency * (t - t0)) ** 2) * \
              np.exp(-(np.pi * frequency * (t - t0)) ** 2)

    # construct trace by convolving reflections
    trace = np.zeros(n_samples)
    for i, ref in enumerate(refs):
        if abs(ref) < 1e-6:
            continue
        # shift wavelet to twt boundary
        idx = int(twt_boundaries[i + 1] / t[1]) if t[1] > 0 else 0
        shifted = np.zeros(n_samples)
        n_w = min(len(wavelet), n_samples - idx)
        if n_w > 0:
            shifted[idx:idx + n_w] = wavelet[:n_w]
        trace += ref * shifted

    # body reflections (approximate)
    for b in model.bodies:
        eps_body = 4.0  # assumed
        eps_host = eps_list[0] if eps_list else 6.0
        r_body = (np.sqrt(eps_host) - np.sqrt(eps_body)) / \
                 (np.sqrt(eps_host) + np.sqrt(eps_body))
        # travel time to body center (use first layer velocity)
        v0 = vels[0] if vels else c / np.sqrt(6.0)
        twt_body = 2.0 * b.cz / v0
        idx = int(twt_body / t[1]) if t[1] > 0 else 0
        shifted = np.zeros(n_samples)
        n_w = min(len(wavelet), n_samples - idx)
        if n_w > 0:
            shifted[idx:idx + n_w] = wavelet[:n_w]
        trace += 0.5 * abs(r_body) * shifted

    if noise > 0:
        trace += rng.normal(0, noise * 0.01, n_samples)

    return {
        "x": float(x), "y": float(y),
        "trace": trace.tolist(),
        "time": t.tolist(),
        "n_samples": n_samples,
        "frequency": frequency,
        "twt_boundaries": twt_boundaries,
    }


# ======================================================================
# Seismic Refraction
# ======================================================================

def forward_seismic(model: EarthModel, shot_x: float, y: float,
                    receivers: np.ndarray, noise: float = 0.0,
                    rng=None) -> list[dict]:
    """Compute seismic refraction first-arrival times.

    Uses a layered velocity model with head-wave (refraction) arrivals.
    """
    if rng is None:
        rng = np.random.default_rng()

    results = []
    for rx in receivers:
        # direct arrival (layer 1 velocity)
        if model.layers:
            v1 = model.layers[0].vp
        else:
            v1 = 2000.0
        t_direct = abs(rx - shot_x) / v1

        # head-wave arrivals from deeper layers
        t_head_list = [t_direct]
        cum_depth = 0.0
        for i, lay in enumerate(model.layers[1:], 1):
            vi = lay.vp
            # critical angle
            sin_ic = v1 / vi if vi > v1 else 1.0
            if sin_ic >= 1.0:
                continue
            cos_ic = np.sqrt(1.0 - sin_ic ** 2)
            # down-going + up-going through upper layers
            t_down_up = 0.0
            for j in range(i):
                vj = model.layers[j].vp
                thickness = model.layers[j].bottom_depth - model.layers[j].top_depth
                t_down_up += 2.0 * thickness * cos_ic / vj
            # head-wave travel along layer i
            x_crit = 2.0 * sum(
                (model.layers[j].bottom_depth - model.layers[j].top_depth) * sin_ic /
                np.sqrt(1 - sin_ic ** 2) / model.layers[j].vp
                for j in range(i) if model.layers[j].vp > 0
            )
            x_eff = max(abs(rx - shot_x) - x_crit, 0)
            t_head = t_down_up + x_eff / vi
            t_head_list.append(t_head)

        t_first = min(t_head_list)
        if noise > 0:
            t_first += rng.normal(0, noise * 0.001)

        results.append({
            "x": float(rx), "y": float(y),
            "shot_x": float(shot_x),
            "t_first": float(t_first),
            "offset": float(abs(rx - shot_x)),
        })
    return results
