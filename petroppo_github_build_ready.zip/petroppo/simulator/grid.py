"""Survey grid design — generate electrode positions and measurement points."""
from __future__ import annotations

import numpy as np

from ..core import Survey, get_logger

_log = get_logger("simulator.grid")


def electrode_layout(survey: Survey, line_index: int = 0):
    """Generate electrode positions for a survey line.

    Returns: dict with 'x' (np.ndarray), 'y' (float), 'spacing'
    """
    n = survey.n_electrodes
    a = survey.grid_spacing
    y = line_index * a
    x = np.arange(n) * a
    return {"x": x, "y": float(y), "spacing": a}


def survey_grid_points(survey: Survey) -> list[tuple[float, float]]:
    """Measurement grid points (x,y) for all survey lines."""
    pts = []
    a = survey.grid_spacing
    for line in range(survey.n_lines):
        y = line * a
        for i in range(survey.n_electrodes):
            pts.append((float(i * a), float(y)))
    return pts


def total_measurements_estimate(survey: Survey) -> int:
    """Estimate total readings (Wenner multi-level)."""
    n = survey.n_electrodes
    levels = max(1, n // 3)
    per_line = sum(max(0, n - 3 * lvl) for lvl in range(1, levels + 1))
    return per_line * survey.n_lines
