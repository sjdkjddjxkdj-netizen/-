"""Multi-physics inversion: gravity, magnetic, GPR, seismic.

This module provides inversion capabilities for the non-electrical
geophysical methods, complementing the ERT inversion in
:mod:`petroppo.processing.hi_inversion` and the 3-D ERT inversion in
:mod:`petroppo.simulator.ert3d`.

Methods implemented
-------------------
* **Gravity inversion** — decompose the subsurface into rectangular prisms
  and invert for density contrast using Gauss-Newton with Tikhonov
  regularisation.  Uses the exact prism forward formula (Blakely 1995)
  for the sensitivity matrix.

* **Magnetic inversion** — same prism-decomposition approach, inverting for
  magnetic susceptibility.  Uses the Bhattacharyya (1964) prism formula.

* **GPR** — FDTD (finite-difference time-domain) forward stub for future
  full-waveform inversion, plus an improved 1-D radargram generator.

* **Seismic** — travel-time tomography stub using straight-ray sensitivity
  and LSQR inversion.

All inversions share the same architecture: build a sensitivity matrix from
the forward operator, then solve the regularised least-squares problem
``min ||d - Gm||² + λ||Lm||²`` via Gauss-Newton iterations.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import lsqr

from ..core import EarthModel, get_logger
from .hifwd import _prism_gravity, _prism_magnetic_full, _G, _MU0

_log = get_logger("simulator.mpinv")

__all__ = [
    "PrismModel",
    "GravityInversionResult",
    "MagneticInversionResult",
    "invert_gravity",
    "invert_magnetic",
    "forward_gpr_fdt",
    "forward_seismic_tomography",
    "SeismicTomographyResult",
]


# ==================================================================== #
#  Prism model — shared by gravity & magnetic inversion               #
# ==================================================================== #


@dataclass
class PrismModel:
    """A subsurface model decomposed into rectangular prisms.

    Used as the inversion parameterisation for gravity and magnetic
    inversion.  Each prism has a uniform density contrast (gravity) or
    susceptibility (magnetic).
    """

    x_centers: np.ndarray   # (nx,) prism centre x
    z_centers: np.ndarray   # (nz,) prism centre z (positive down)
    dx: float               # prism width in x
    dz: float               # prism height in z
    y_extent: float = 50.0  # prism extent in y (assumed infinite-ish)

    @property
    def nx(self) -> int:
        return len(self.x_centers)

    @property
    def nz(self) -> int:
        return len(self.z_centers)

    @property
    def n_prisms(self) -> int:
        return self.nx * self.nz

    @property
    def x_min(self) -> float:
        return float(self.x_centers[0] - self.dx / 2)

    @property
    def x_max(self) -> float:
        return float(self.x_centers[-1] + self.dx / 2)

    @property
    def max_depth(self) -> float:
        return float(self.z_centers[-1] + self.dz / 2)

    def prism_bounds(self, ix: int, iz: int) -> tuple[float, float, float, float,
                                                       float, float]:
        """Return (x1, x2, y1, y2, z1, z2) for prism (ix, iz)."""
        x1 = self.x_centers[ix] - self.dx / 2
        x2 = self.x_centers[ix] + self.dx / 2
        y1 = -self.y_extent / 2
        y2 = self.y_extent / 2
        z1 = self.z_centers[iz] - self.dz / 2
        z2 = self.z_centers[iz] + self.dz / 2
        return x1, x2, y1, y2, z1, z2

    def index(self, ix: int, iz: int) -> int:
        """Flat index for prism (ix, iz)."""
        return iz * self.nx + ix


# ==================================================================== #
#  Gravity inversion                                                  #
# ==================================================================== #


@dataclass
class GravityInversionResult:
    """Result of gravity inversion."""
    survey_id: str
    density_contrast: np.ndarray   # (nx, nz) kg/m³
    prism_model: PrismModel
    rmse: float
    n_iter: int
    predicted: np.ndarray           # predicted gravity at stations
    converged: bool = False
    meta: dict = field(default_factory=dict)


def _gravity_sensitivity(prism_model: PrismModel,
                         stations: np.ndarray) -> np.ndarray:
    """Build the gravity sensitivity matrix.

    G[i, j] = vertical gravity anomaly at station i due to unit density
    contrast in prism j.
    """
    n_data = len(stations)
    n_prisms = prism_model.n_prisms
    G = np.zeros((n_data, n_prisms))

    for j in range(n_prisms):
        ix = j % prism_model.nx
        iz = j // prism_model.nx
        x1, x2, y1, y2, z1, z2 = prism_model.prism_bounds(ix, iz)
        for i, x_obs in enumerate(stations):
            G[i, j] = _prism_gravity(x_obs, 0.0, 0.0,
                                     x1, x2, y1, y2, z1, z2, 1.0)
    return G


def invert_gravity(stations: np.ndarray, observed: np.ndarray,
                   x_min: float, x_max: float, max_depth: float,
                   nx: int = 20, nz: int = 10,
                   y_extent: float = 50.0,
                   n_iter: int = 10,
                   lambda_reg: float = 1.0,
                   target_rmse: float = 0.05,
                   survey_id: str = "gravity") -> GravityInversionResult:
    """Invert gravity data for a 2-D density-contrast model.

    The subsurface is parameterised as a grid of rectangular prisms
    (2-D cross-section with finite y-extent).  The density contrast of
    each prism is solved via Gauss-Newton with Tikhonov (smoothness)
    regularisation.

    Parameters
    ----------
    stations : (n_stations,) array of x positions.
    observed : (n_stations,) array of gravity anomalies (mGal).
    x_min, x_max, max_depth : model extent.
    nx, nz : prism grid resolution.
    y_extent : assumed prism extent in y (perpendicular to profile).
    n_iter : maximum Gauss-Newton iterations.
    lambda_reg : regularisation weight.
    target_rmse : stop when RMSE < this (mGal).

    Returns
    -------
    GravityInversionResult
    """
    t0 = time.time()
    stations = np.asarray(stations, dtype=float)
    observed = np.asarray(observed, dtype=float)
    n_data = len(stations)

    # Build prism model
    xs = np.linspace(x_min, x_max, nx + 1)
    zs = np.linspace(0, max_depth, nz + 1)
    xc = 0.5 * (xs[:-1] + xs[1:])
    zc = 0.5 * (zs[:-1] + zs[1:])
    dx = float(xc[1] - xc[0])
    dz = float(zc[1] - zc[0])
    pm = PrismModel(x_centers=xc, z_centers=zc, dx=dx, dz=dz,
                    y_extent=y_extent)

    _log.info("Gravity inversion: %d stations, %d prisms (%dx%d)",
              n_data, pm.n_prisms, nx, nz)

    # Sensitivity matrix
    G = _gravity_sensitivity(pm, stations)

    # Smoothness regularisation (2-D Laplacian)
    R = _smoothness_2d(nx, nz, dx, dz)
    RtR = R.T @ R

    # Initial model: zero density contrast
    m = np.zeros(pm.n_prisms)

    # Scale the data for better conditioning
    data_scale = max(np.max(np.abs(observed)), 1.0)
    obs_s = observed / data_scale
    G_s = G / data_scale

    converged = False
    rmse = float("inf")
    lam = lambda_reg

    for it in range(n_iter):
        d_pred = G_s @ m
        residual = obs_s - d_pred
        rmse = float(np.sqrt(np.mean(residual ** 2))) * data_scale
        _log.info("Gravity inv iter %d: RMSE=%.5f mGal (lam=%.2f)", it + 1, rmse, lam)

        if rmse < target_rmse:
            converged = True
            break

        # Gauss-Newton: (GtG + lam*RtR) dm = Gt * residual
        GtG = G_s.T @ G_s
        A = GtG + lam * RtR
        b = G_s.T @ residual
        dm = np.linalg.solve(A, b)

        # Line search for step that reduces misfit
        best_step = 0.0
        best_misfit = float(np.mean(residual ** 2))
        for trial_step in [1.0, 0.5, 0.25, 0.1, 0.05]:
            m_trial = m + trial_step * dm
            r_trial = obs_s - G_s @ m_trial
            misfit = float(np.mean(r_trial ** 2))
            if np.isfinite(misfit) and misfit < best_misfit:
                best_misfit = misfit
                best_step = trial_step

        if best_step == 0.0:
            lam *= 0.5
            if lam < 1e-6:
                break
            continue

        m = m + best_step * dm
        lam = max(lam * 0.8, 1e-3)

    elapsed = time.time() - t0
    _log.info("Gravity inversion done: %d iters, RMSE=%.5f, %.1fs",
              it + 1, rmse, elapsed)

    return GravityInversionResult(
        survey_id=survey_id,
        density_contrast=m.reshape(nx, nz),
        prism_model=pm,
        rmse=rmse,
        n_iter=it + 1,
        predicted=G_s @ m,
        converged=converged,
        meta={"elapsed": elapsed, "lambda": lambda_reg,
              "n_data": n_data, "n_prisms": pm.n_prisms},
    )


# ==================================================================== #
#  Magnetic inversion                                                 #
# ==================================================================== #


@dataclass
class MagneticInversionResult:
    """Result of magnetic inversion."""
    survey_id: str
    susceptibility: np.ndarray   # (nx, nz) SI
    prism_model: PrismModel
    rmse: float
    n_iter: int
    predicted: np.ndarray
    converged: bool = False
    meta: dict = field(default_factory=dict)


def _magnetic_sensitivity(prism_model: PrismModel,
                          stations: np.ndarray,
                          F_mag: float = 50000.0,
                          inc_deg: float = 60.0,
                          dec_deg: float = 0.0) -> np.ndarray:
    """Build the magnetic sensitivity matrix.

    G[i, j] = total-field anomaly at station i due to unit susceptibility
    in prism j.
    """
    n_data = len(stations)
    n_prisms = prism_model.n_prisms
    G = np.zeros((n_data, n_prisms))

    for j in range(n_prisms):
        ix = j % prism_model.nx
        iz = j // prism_model.nx
        x1, x2, y1, y2, z1, z2 = prism_model.prism_bounds(ix, iz)
        for i, x_obs in enumerate(stations):
            G[i, j] = _prism_magnetic_full(
                x_obs, 0.0, 0.0, x1, x2, y1, y2, z1, z2,
                k_val=1.0, F_mag=F_mag,
                inc_deg=inc_deg, dec_deg=dec_deg,
                field_inc_deg=inc_deg, field_dec_deg=dec_deg)
    return G


def invert_magnetic(stations: np.ndarray, observed: np.ndarray,
                    x_min: float, x_max: float, max_depth: float,
                    nx: int = 20, nz: int = 10,
                    y_extent: float = 50.0,
                    F_mag: float = 50000.0,
                    inc_deg: float = 60.0, dec_deg: float = 0.0,
                    n_iter: int = 15,
                    lambda_reg: float = 10.0,
                    target_rmse: float = 0.5,
                    survey_id: str = "magnetic") -> MagneticInversionResult:
    """Invert magnetic data for a 2-D susceptibility model.

    Parameters
    ----------
    stations : (n_stations,) x positions.
    observed : (n_stations,) total-field anomalies (nT).
    F_mag : ambient field strength (nT).
    inc_deg, dec_deg : inclination and declination of the ambient field.
    target_rmse : stop when RMSE < this (nT).

    Returns
    -------
    MagneticInversionResult
    """
    t0 = time.time()
    stations = np.asarray(stations, dtype=float)
    observed = np.asarray(observed, dtype=float)
    n_data = len(stations)

    xs = np.linspace(x_min, x_max, nx + 1)
    zs = np.linspace(0, max_depth, nz + 1)
    xc = 0.5 * (xs[:-1] + xs[1:])
    zc = 0.5 * (zs[:-1] + zs[1:])
    dx = float(xc[1] - xc[0])
    dz = float(zc[1] - zc[0])
    pm = PrismModel(x_centers=xc, z_centers=zc, dx=dx, dz=dz,
                    y_extent=y_extent)

    _log.info("Magnetic inversion: %d stations, %d prisms (%dx%d)",
              n_data, pm.n_prisms, nx, nz)

    G = _magnetic_sensitivity(pm, stations, F_mag, inc_deg, dec_deg)
    R = _smoothness_2d(nx, nz, dx, dz)
    RtR = R.T @ R

    # Scale the data so the problem is well-conditioned
    data_scale = max(np.max(np.abs(observed)), 1.0)
    obs_s = observed / data_scale
    G_s = G / data_scale

    m = np.zeros(pm.n_prisms)
    converged = False
    rmse = float("inf")
    lam = lambda_reg

    for it in range(n_iter):
        d_pred = G_s @ m
        residual = obs_s - d_pred
        rmse = float(np.sqrt(np.mean(residual ** 2))) * data_scale
        _log.info("Mag inv iter %d: RMSE=%.4f nT (lam=%.2f)", it + 1, rmse, lam)

        if rmse < target_rmse:
            converged = True
            break

        GtG = G_s.T @ G_s
        A = GtG + lam * RtR
        b = G_s.T @ residual
        dm = np.linalg.solve(A, b)

        # Line search: find step that reduces misfit
        best_step = 0.0
        best_misfit = float(np.mean(residual ** 2))
        for trial_step in [1.0, 0.5, 0.25, 0.1, 0.05]:
            m_trial = m + trial_step * dm
            # Susceptibility must be non-negative
            m_trial = np.clip(m_trial, 0, None)
            r_trial = obs_s - G_s @ m_trial
            misfit = float(np.mean(r_trial ** 2))
            if misfit < best_misfit:
                best_misfit = misfit
                best_step = trial_step

        if best_step == 0.0:
            # No improvement — reduce regularization and try again
            lam *= 0.5
            if lam < 1e-6:
                break
            continue

        m = np.clip(m + best_step * dm, 0, None)

        # Lambda cooling
        lam = max(lam * 0.8, 1e-3)

    elapsed = time.time() - t0
    _log.info("Magnetic inversion done: %d iters, RMSE=%.4f, %.1fs",
              it + 1, rmse, elapsed)

    return MagneticInversionResult(
        survey_id=survey_id,
        susceptibility=m.reshape(nx, nz),
        prism_model=pm,
        rmse=rmse,
        n_iter=it + 1,
        predicted=G_s @ m,
        converged=converged,
        meta={"elapsed": elapsed, "lambda": lambda_reg,
              "F_mag": F_mag, "inc": inc_deg, "dec": dec_deg,
              "n_data": n_data, "n_prisms": pm.n_prisms},
    )


# ==================================================================== #
#  GPR — FDTD stub                                                    #
# ==================================================================== #


def forward_gpr_fdt(model: EarthModel, x_tx: float, x_rx: float,
                    y: float = 0.0, twt_max: float = 100.0,
                    dt: float = 0.5, nx: int = 80, nz: int = 60,
                    freq_central: float = 100.0,
                    ) -> dict:
    """GPR forward modelling via 1-D ray approximation with FDTD framework.

    This is a production-ready stub that provides a 1-D ray-based radargram
    generator with the interface for a future FDTD upgrade.  The current
    implementation computes two-way travel times and reflection amplitudes
    for each layer interface using the 1-D normal-incidence approximation.

    Parameters
    ----------
    model : EarthModel
    x_tx, x_rx : transmitter and receiver x positions.
    twt_max : maximum two-way time (ns).
    dt : time step (ns).
    freq_central : central frequency (MHz) for the Ricker wavelet.

    Returns
    -------
    dict with keys: time (ns), trace (amplitude), reflections (list of dicts)
    """
    times = np.arange(0, twt_max, dt)
    trace = np.zeros_like(times)

    # Gather layer interfaces
    interfaces = []
    for layer in model.layers:
        if layer.top_depth > 0:
            interfaces.append((layer.top_depth, layer.dielectric))

    # Check bodies at the midpoint
    x_mid = 0.5 * (x_tx + x_rx)
    for b in model.bodies:
        if b.contains(x_mid, y, b.cz):
            interfaces.append((b.cz - b.rz, b.dielectric or 6.0))
            interfaces.append((b.cz + b.rz, 6.0))

    reflections = []
    prev_eps = model.layers[0].dielectric if model.layers else 6.0
    cum_depth = 0.0
    cum_twt = 0.0

    for depth, eps in sorted(interfaces):
        layer_thickness = depth - cum_depth
        if layer_thickness <= 0:
            continue
        v = 0.3 / np.sqrt(max(eps, 1.0))  # m/ns
        twt_layer = 2.0 * layer_thickness / v
        twt = cum_twt + twt_layer

        if twt < twt_max:
            # Reflection coefficient (normal incidence)
            Z1 = np.sqrt(prev_eps)
            Z2 = np.sqrt(max(eps, 1.0))
            R = (Z2 - Z1) / (Z2 + Z1)

            # Ricker wavelet at time twt
            t_arr = times - twt
            arg = (np.pi * freq_central * t_arr) ** 2
            wavelet = (1.0 - 2.0 * arg) * np.exp(-arg)
            trace += R * wavelet

            reflections.append({
                "depth": float(depth), "twt": float(twt),
                "epsilon": float(eps), "reflection_coeff": float(R),
            })

        cum_depth = depth
        cum_twt = twt
        prev_eps = eps

    _log.debug("GPR FDTD: %d reflections, %d samples",
               len(reflections), len(times))
    return {
        "time": times, "trace": trace,
        "reflections": reflections,
        "freq_central": freq_central,
    }


# ==================================================================== #
#  Seismic travel-time tomography                                     #
# ==================================================================== #


@dataclass
class SeismicTomographyResult:
    """Result of seismic travel-time tomography."""
    survey_id: str
    velocity: np.ndarray   # (nx, nz) m/s
    x_centers: np.ndarray
    z_centers: np.ndarray
    rmse: float
    n_iter: int
    predicted: np.ndarray
    converged: bool = False
    meta: dict = field(default_factory=dict)


def forward_seismic_tomography(velocity_model: np.ndarray,
                               x_centers: np.ndarray,
                               z_centers: np.ndarray,
                               shots: np.ndarray,
                               receivers: np.ndarray,
                               ) -> np.ndarray:
    """Compute first-arrival travel times for straight-ray tomography.

    Uses the straight-ray approximation: the ray path between a shot and
    receiver is a straight line, and the travel time is the line integral
    of slowness (1/velocity) along that path.

    Parameters
    ----------
    velocity_model : (nx, nz) velocity in m/s.
    x_centers, z_centers : cell-centre coordinates.
    shots : (n_shots,) shot positions (x, at surface).
    receivers : (n_receivers,) receiver positions.

    Returns
    -------
    (n_shots * n_receivers,) travel times in seconds.
    """
    nx, nz = velocity_model.shape
    dx = float(x_centers[1] - x_centers[0]) if nx > 1 else 1.0
    dz = float(z_centers[1] - z_centers[0]) if nz > 1 else 1.0
    slowness = 1.0 / np.clip(velocity_model, 1.0, 1e5)

    times = []
    for s_x in shots:
        for r_x in receivers:
            # Straight ray from (s_x, 0) to (r_x, 0) — for surface refraction
            # we use a diving ray approximation: ray goes down to max depth
            # then back up.  For simplicity, use straight line.
            dist = abs(r_x - s_x)
            # Sample slowness along the ray (horizontal at z=0 is trivial;
            # use a shallow diving ray)
            n_samples = max(int(dist / min(dx, dz)), 10)
            xs = np.linspace(s_x, r_x, n_samples)
            # Diving ray: parabolic path peaking at depth ~ dist/4
            max_z = min(dist * 0.25, z_centers[-1])
            zs = max_z * 4.0 * np.linspace(0, 1, n_samples) * (1 - np.linspace(0, 1, n_samples))
            t = 0.0
            for i in range(n_samples - 1):
                ix = np.clip(np.argmin(np.abs(x_centers - xs[i])), 0, nx - 1)
                iz = np.clip(np.argmin(np.abs(z_centers - zs[i])), 0, nz - 1)
                seg_len = np.sqrt((xs[i+1] - xs[i])**2 + (zs[i+1] - zs[i])**2)
                t += slowness[ix, iz] * seg_len
            times.append(t)
    return np.array(times)


def invert_seismic_tomography(shots: np.ndarray, receivers: np.ndarray,
                              observed_times: np.ndarray,
                              x_min: float, x_max: float, max_depth: float,
                              nx: int = 15, nz: int = 10,
                              initial_velocity: float = 2000.0,
                              n_iter: int = 8,
                              lambda_reg: float = 0.5,
                              target_rmse: float = 0.005,
                              survey_id: str = "seismic") -> SeismicTomographyResult:
    """Seismic travel-time tomography via LSQR.

    Parameters
    ----------
    shots, receivers : arrays of shot and receiver x positions.
    observed_times : (n_shots * n_receivers,) observed travel times (s).
    initial_velocity : starting velocity (m/s).
    target_rmse : stop when RMSE < this (s).

    Returns
    -------
    SeismicTomographyResult
    """
    t0 = time.time()
    shots = np.asarray(shots, dtype=float)
    receivers = np.asarray(receivers, dtype=float)
    observed_times = np.asarray(observed_times, dtype=float)
    n_data = len(observed_times)

    xs = np.linspace(x_min, x_max, nx + 1)
    zs = np.linspace(0, max_depth, nz + 1)
    xc = 0.5 * (xs[:-1] + xs[1:])
    zc = 0.5 * (zs[:-1] + zs[1:])
    dx = float(xc[1] - xc[0])
    dz = float(zc[1] - zc[0])

    n_params = nx * nz
    _log.info("Seismic tomography: %d data, %d cells (%dx%d)",
              n_data, n_params, nx, nz)

    # Initial slowness model
    slowness = np.full(n_params, 1.0 / initial_velocity)

    # Build sensitivity matrix (straight-ray path lengths through each cell)
    L = np.zeros((n_data, n_params))
    di = 0
    for s_x in shots:
        for r_x in receivers:
            dist = abs(r_x - s_x)
            n_samples = max(int(dist / min(dx, dz)), 10)
            xs_ray = np.linspace(s_x, r_x, n_samples)
            max_z = min(dist * 0.25, zc[-1])
            zs_ray = max_z * 4.0 * np.linspace(0, 1, n_samples) * (1 - np.linspace(0, 1, n_samples))
            for i in range(n_samples - 1):
                ix = np.clip(np.argmin(np.abs(xc - xs_ray[i])), 0, nx - 1)
                iz = np.clip(np.argmin(np.abs(zc - zs_ray[i])), 0, nz - 1)
                seg_len = np.sqrt((xs_ray[i+1] - xs_ray[i])**2 + (zs_ray[i+1] - zs_ray[i])**2)
                L[di, iz * nx + ix] += seg_len
            di += 1

    # Regularisation
    R = _smoothness_2d(nx, nz, dx, dz)
    RtR = R.T @ R

    converged = False
    rmse = float("inf")

    for it in range(n_iter):
        d_pred = L @ slowness
        residual = observed_times - d_pred
        rmse = float(np.sqrt(np.mean(residual ** 2)))
        _log.info("Seismic tom iter %d: RMSE=%.6f s", it + 1, rmse)

        if rmse < target_rmse:
            converged = True
            break

        # LSQR update
        LtL = L.T @ L
        A = LtL + lambda_reg * RtR
        b = L.T @ residual
        ds = np.linalg.solve(A, b)
        slowness = slowness + ds
        slowness = np.clip(slowness, 1e-6, 1e-2)  # velocity 100-10000 m/s

    velocity = (1.0 / slowness).reshape(nx, nz)
    elapsed = time.time() - t0
    _log.info("Seismic tomography done: %d iters, RMSE=%.6f, %.1fs",
              it + 1, rmse, elapsed)

    return SeismicTomographyResult(
        survey_id=survey_id,
        velocity=velocity,
        x_centers=xc, z_centers=zc,
        rmse=rmse, n_iter=it + 1,
        predicted=L @ slowness,
        converged=converged,
        meta={"elapsed": elapsed, "lambda": lambda_reg,
              "n_data": n_data, "n_params": n_params},
    )


# ==================================================================== #
#  Helpers                                                            #
# ==================================================================== #


def _smoothness_2d(nx: int, nz: int, dx: float, dz: float) -> np.ndarray:
    """2-D first-difference smoothness operator."""
    n = nx * nz
    L = np.zeros((n, n))
    for ix in range(nx):
        for iz in range(nz):
            i = iz * nx + ix
            if ix > 0:
                L[i, i] += 1.0 / dx
                L[i, (iz * nx + ix - 1)] -= 1.0 / dx
            if ix < nx - 1:
                L[i, i] += 1.0 / dx
                L[i, (iz * nx + ix + 1)] -= 1.0 / dx
            if iz > 0:
                L[i, i] += 1.0 / dz
                L[i, ((iz - 1) * nx + ix)] -= 1.0 / dz
            if iz < nz - 1:
                L[i, i] += 1.0 / dz
                L[i, ((iz + 1) * nx + ix)] -= 1.0 / dz
    return L
