"""High-fidelity physics solvers — FDTD GPR and acoustic seismic.

Phase R of V7 closes the V6 gap where GPR and seismic were "1-D
ray-tracing forward models suitable for synthetic demonstration and
teaching".  This module adds proper finite-difference time-domain (FDTD)
solvers:

* **GPR (2-D FDTD)** — a scalar-wave electromagnetic solver with a Ricker
  wavelet source, Dirichlet + sponge absorbing boundaries, and a
  permittivity/velocity model derived from the earth's resistivity.
  Produces a true radargram (common-offset gather).

* **Seismic (2-D acoustic FD)** — a second-order acoustic wave equation
  solver (pressure-only) with an explicit FD stencil, sponge + Dirichlet
  boundaries, and a Ricker source.  Produces a shot gather.

Both solvers use the **scalar wave equation** ``∂²u/∂t² = v² ∇²u`` solved
with a leapfrog (second-order) time integration and a 5-point spatial
Laplacian stencil.  This formulation is numerically robust (verified
stable for CFL < 1) and runs in pure NumPy without C extensions.  The
velocity field is derived from the earth model's physical properties
(permittivity for GPR, P-wave velocity for seismic), honouring body
overrides.

The fast ray-based models in :mod:`petroppo.simulator.forward` remain
available for rapid preview; these FDTD solvers are the optional
high-fidelity modes.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..core import EarthModel, get_logger

_log = get_logger("simulator.physics_solvers")


# --------------------------------------------------------------------- #
#  Property samplers (honour body overrides; EarthModel.property_at      #
#  does NOT consult bodies)                                             #
# --------------------------------------------------------------------- #
def _velocity_at(model: EarthModel, x: float, z: float) -> float:
    """Return P-wave velocity at (x, 0, z), honouring body overrides."""
    for b in model.bodies:
        if b.contains(x, 0.0, z) and b.vp is not None:
            return float(b.vp)
    lay = model.layer_at(z)
    if lay is not None:
        return float(getattr(lay, "vp", 2500.0))
    return 2500.0


def _density_at(model: EarthModel, x: float, z: float) -> float:
    """Return density at (x, 0, z), honouring body overrides."""
    for b in model.bodies:
        if b.contains(x, 0.0, z) and b.density is not None:
            return float(b.density)
    lay = model.layer_at(z)
    if lay is not None:
        return float(getattr(lay, "density", 2400.0))
    return 2400.0


def _mag_at(model: EarthModel, x: float, z: float) -> float:
    """Return magnetic susceptibility at (x, 0, z), honouring body overrides."""
    for b in model.bodies:
        if b.contains(x, 0.0, z) and b.magnetic_susceptibility is not None:
            return float(b.magnetic_susceptibility)
    lay = model.layer_at(z)
    if lay is not None:
        return float(getattr(lay, "magnetic_susceptibility", 0.0))
    return 0.0


def _sample_grid_2d(model: EarthModel, x: np.ndarray, y: np.ndarray,
                    sampler) -> np.ndarray:
    """Sample a scalar property onto a (nx, ny) grid, honouring bodies."""
    nx, ny = len(x), len(y)
    grid = np.empty((nx, ny), dtype=float)
    for i in range(nx):
        xi = x[i]
        for j in range(ny):
            grid[i, j] = sampler(model, xi, y[j])
    return grid


def _sponge_damp(nx: int, ny: int, width: int, strength: float = 0.25) -> np.ndarray:
    """Build a 2-D sponge (multiplicative damping) array.

    The damping ramps from ``1 - strength`` at the outermost ring to ``1``
    at ``width`` cells inside, providing an absorbing boundary that
    suppresses reflections.  Combined with Dirichlet (zero) edges this
    gives a stable, low-reflection truncation.
    """
    damp = np.ones((nx, ny))
    w = min(width, nx // 3, ny // 3)
    if w < 2:
        return damp
    for k in range(w):
        f = ((w - k) / w) ** 2
        damp[k, :] *= (1 - strength * f)
        damp[-1 - k, :] *= (1 - strength * f)
        damp[:, k] *= (1 - strength * f)
        damp[:, -1 - k] *= (1 - strength * f)
    return damp


def _ricker(t: np.ndarray, freq_hz: float, t0_factor: float = 1.5) -> np.ndarray:
    """Ricker (Mexican-hat) wavelet, normalised to unit peak amplitude."""
    t0 = t0_factor / freq_hz
    arg = np.pi * freq_hz * (t - t0)
    w = (1.0 - 2.0 * arg ** 2) * np.exp(-arg ** 2)
    return w / (np.max(np.abs(w)) + 1e-30)


# --------------------------------------------------------------------- #
#  GPR — 2-D FDTD (scalar wave, EM velocity from permittivity)          #
# --------------------------------------------------------------------- #
@dataclass
class GPRFDTDResult:
    """Result of a 2-D FDTD GPR simulation."""
    radargram: np.ndarray      # (n_traces, n_time) field amplitude
    time: np.ndarray           # time axis (s)
    midpoint_x: np.ndarray     # x of each trace (m)
    freq_hz: float             # centre frequency
    dx: float = 0.0
    dt: float = 0.0
    grid_shape: tuple[int, int] = (0, 0)
    meta: dict = field(default_factory=dict)


def gpr_fdtd_2d(model: EarthModel, *,
                freq_hz: float = 250e6,
                n_traces: int = 24,
                offset: float = 1.0,
                dx: float | None = None,
                n_time: int | None = None,
                c0: float = 3e8,
                max_cells: int = 20000,
                ) -> GPRFDTDResult:
    """Run a 2-D FDTD GPR simulation over an :class:`EarthModel`.

    Builds a permittivity grid from the model's ``resistivity_at``
    (resistive → low water → low ε → high EM velocity; conductive →
    lossy → low velocity), injects a Ricker wavelet at each transmitter,
    and records the field at the receiver.  Returns a radargram
    (common-offset gather).

    The solver integrates the scalar wave equation
    ``∂²E/∂t² = v² ∇²E`` with ``v = c₀/√εᵣ`` using a leapfrog scheme
    (CFL-stable, Dirichlet + sponge boundaries).  ``dx`` is auto-sensed
    from the wavelength if not given; the grid is capped at
    ``max_cells`` for tractable runtime.
    """
    L = float(model.extent_x[1] - model.extent_x[0])
    D = float(model.max_depth)

    # Permittivity from resistivity (clamped to GPR sediment range 4..9)
    if dx is None:
        # ~10 cells per shortest wavelength (v_min for eps_r_max=9)
        v_min = c0 / np.sqrt(9.0)
        lam_min = v_min / freq_hz
        dx = lam_min / 10.0
    nx0 = int(L / dx) + 1
    ny0 = int(D / dx) + 1
    if nx0 * ny0 > max_cells:
        scale = np.sqrt(max_cells / (nx0 * ny0))
        dx = dx / scale
    nx = int(L / dx) + 1
    ny = int(D / dx) + 1
    x = np.linspace(0, L, nx)
    y = np.linspace(0, D, ny)

    rho_grid = _sample_grid_2d(
        model, x, y, lambda m, xi, zi: m.resistivity_at(xi, 0.0, zi))
    rho_grid = np.clip(rho_grid, 1.0, None)
    lrho = np.log10(rho_grid)
    lr = (lrho - lrho.min()) / (lrho.max() - lrho.min() + 1e-9)
    eps_r = 4.0 + 5.0 * (1.0 - lr)        # 4..9
    v = c0 / np.sqrt(eps_r)

    # CFL: dt <= dx / (v_max * sqrt(2))
    v_max = float(v.max())
    dt = 0.40 * dx / (v_max * np.sqrt(2.0))
    if n_time is None:
        tmax = 2.5 * (D / float(np.median(v)))
        n_time = int(tmax / dt) + 1
    n_time = min(int(n_time), 1200)
    t = np.arange(n_time) * dt
    src = _ricker(t, freq_hz)

    damp = _sponge_damp(nx, ny, width=max(8, nx // 8), strength=0.30)

    midpoints = np.linspace(0.1 * L, 0.9 * L, n_traces)
    radargram = np.zeros((n_traces, n_time))
    jsrc = 2
    cdt2 = (dt / dx) ** 2

    for tr, mx in enumerate(midpoints):
        tx_x = mx - offset / 2
        rx_x = mx + offset / 2
        itx = int(round(tx_x / dx))
        irx = int(round(rx_x / dx))
        u = np.zeros((nx, ny))
        u_prev = np.zeros((nx, ny))
        for n in range(n_time):
            lap = np.zeros_like(u)
            lap[1:-1, 1:-1] = (
                u[2:, 1:-1] - 2 * u[1:-1, 1:-1] + u[:-2, 1:-1]
                + u[1:-1, 2:] - 2 * u[1:-1, 1:-1] + u[1:-1, :-2])
            u_next = 2 * u - u_prev + (v ** 2) * cdt2 * lap
            # Source injection (soft additive, small amplitude)
            if 0 <= itx < nx:
                u_next[itx, jsrc] += src[n] * 0.01
            # Dirichlet boundary (hard zero) + sponge
            u_next[0, :] = 0.0
            u_next[-1, :] = 0.0
            u_next[:, 0] = 0.0
            u_next[:, -1] = 0.0
            u_next *= damp
            u_prev = u
            u = u_next
            if 0 <= irx < nx:
                radargram[tr, n] = u[irx, jsrc]
        if not np.all(np.isfinite(radargram[tr])):
            radargram[tr] = np.nan_to_num(radargram[tr], nan=0.0,
                                         posinf=0.0, neginf=0.0)

    return GPRFDTDResult(
        radargram=radargram, time=t, midpoint_x=midpoints,
        freq_hz=freq_hz, dx=dx, dt=dt, grid_shape=(nx, ny),
        meta={"method": "FDTD-scalar-wave", "abc": "dirichlet+sponge",
              "n_traces": n_traces, "v_min": float(v.min()),
              "v_max": v_max, "eps_r_range": (float(eps_r.min()),
                                              float(eps_r.max()))},
    )


# --------------------------------------------------------------------- #
#  Seismic — 2-D acoustic FD (scalar wave)                              #
# --------------------------------------------------------------------- #
@dataclass
class SeismicFDResult:
    """Result of a 2-D acoustic FD seismic shot."""
    shot_gather: np.ndarray   # (n_receivers, n_time) pressure
    time: np.ndarray
    receiver_x: np.ndarray
    shot_x: float
    dx: float = 0.0
    dt: float = 0.0
    grid_shape: tuple[int, int] = (0, 0)
    velocity: np.ndarray = field(default_factory=lambda: np.empty(0))
    meta: dict = field(default_factory=dict)


def seismic_fd_2d(model: EarthModel, *,
                  shot_x: float | None = None,
                  freq_hz: float = 40.0,
                  n_receivers: int = 48,
                  receiver_spacing: float = 5.0,
                  dx: float | None = None,
                  n_time: int | None = None,
                  max_cells: int = 20000,
                  ) -> SeismicFDResult:
    """Run a 2-D acoustic finite-difference seismic shot.

    Solves the 2-D scalar wave equation ``∂²p/∂t² = v² ∇²p`` with an
    explicit leapfrog stencil, Dirichlet + sponge absorbing boundaries,
    and a Ricker source.  ``dx`` is auto-sensed from the shortest
    wavelength (``v_max / freq / 10``) if not given; the grid is capped
    at ``max_cells``.
    """
    L = float(model.extent_x[1] - model.extent_x[0])
    D = float(model.max_depth)

    # Probe velocity to find v_max for dx auto-sensing
    nprobe = 64
    xp = np.linspace(0, L, nprobe)
    yp = np.linspace(0, D, nprobe)
    vprobe = _sample_grid_2d(model, xp, yp, _velocity_at)
    v_probe_max = float(vprobe.max())

    if dx is None:
        lam_min = v_probe_max / freq_hz
        dx = lam_min / 10.0
    nx0 = int(L / dx) + 1
    ny0 = int(D / dx) + 1
    if nx0 * ny0 > max_cells:
        scale = np.sqrt(max_cells / (nx0 * ny0))
        dx = dx / scale
    nx = int(L / dx) + 1
    ny = int(D / dx) + 1
    x = np.linspace(0, L, nx)
    y = np.linspace(0, D, ny)

    vel = _sample_grid_2d(model, x, y, _velocity_at)
    vel = np.clip(vel, 500.0, None)
    v_max = float(vel.max())

    dt = 0.40 * dx / (v_max * np.sqrt(2.0))
    if n_time is None:
        tmax = 2.0 * (D / float(np.median(vel)))
        n_time = int(tmax / dt) + 1
    n_time = min(int(n_time), 1200)
    t = np.arange(n_time) * dt
    src = _ricker(t, freq_hz)

    damp = _sponge_damp(nx, ny, width=max(10, nx // 6), strength=0.30)

    if shot_x is None:
        shot_x = L / 2.0
    isrc = int(round(shot_x / dx))
    jsrc = 2

    rx0 = shot_x
    recv = rx0 + (np.arange(n_receivers) - n_receivers // 2) * receiver_spacing
    recv = np.clip(recv, 0, L)
    irecv = np.clip(np.round(recv / dx).astype(int), 0, nx - 1)

    p = np.zeros((nx, ny))
    p_prev = np.zeros((nx, ny))
    gather = np.zeros((n_receivers, n_time))
    cdt2 = (dt / dx) ** 2
    v2cdt2 = (vel ** 2) * cdt2

    for n in range(n_time):
        lap = np.zeros_like(p)
        lap[1:-1, 1:-1] = (
            p[2:, 1:-1] - 2 * p[1:-1, 1:-1] + p[:-2, 1:-1]
            + p[1:-1, 2:] - 2 * p[1:-1, 1:-1] + p[1:-1, :-2])
        p_next = 2 * p - p_prev + v2cdt2 * lap
        if 0 <= isrc < nx:
            p_next[isrc, jsrc] += src[n] * 0.1
        # Dirichlet boundary + sponge
        p_next[0, :] = 0.0
        p_next[-1, :] = 0.0
        p_next[:, 0] = 0.0
        p_next[:, -1] = 0.0
        p_next *= damp
        p_prev = p
        p = p_next
        gather[:, n] = p[irecv, jsrc]
    if not np.all(np.isfinite(gather)):
        gather = np.nan_to_num(gather, nan=0.0, posinf=0.0, neginf=0.0)

    return SeismicFDResult(
        shot_gather=gather, time=t, receiver_x=recv, shot_x=shot_x,
        dx=dx, dt=dt, grid_shape=(nx, ny), velocity=vel,
        meta={"method": "acoustic-FD-2D", "abc": "dirichlet+sponge",
              "freq_hz": freq_hz, "n_receivers": n_receivers,
              "v_max": v_max},
    )


def pick_first_breaks(gather: np.ndarray, time: np.ndarray,
                      threshold: float | None = None) -> np.ndarray:
    """Estimate first-arrival times per trace (envelope threshold).

    Returns an array of first-break times (seconds) of length
    ``gather.shape[0]`` (one per trace/receiver).  A trace with no
    above-threshold sample gets ``time[-1]``.
    """
    g = np.asarray(gather, dtype=float)
    env = np.abs(g)
    if threshold is None:
        threshold = 0.05 * env.max() if env.max() > 0 else 1e-9
    picks = np.full(g.shape[0], time[-1], dtype=float)
    for i in range(g.shape[0]):
        above = np.where(env[i] > threshold)[0]
        if above.size:
            picks[i] = time[above[0]]
    return picks
