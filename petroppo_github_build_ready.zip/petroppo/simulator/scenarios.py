"""Virtual earth models — build ready-made scenarios and generate random models."""
from __future__ import annotations

from ..core import EarthModel, Layer, ResistivityBody


def layered_model() -> EarthModel:
    """Simple layered model (topsoil / sediment / bedrock)."""
    return EarthModel(
        name="Layered",
        layers=[
            Layer("Topsoil", 0.0, 3.0, 80.0, density=1800,
                  magnetic_susceptibility=0.0001, vp=800, vs=400,
                  dielectric=10.0, color="#8B7355"),
            Layer("Sediment", 3.0, 25.0, 30.0, density=2200,
                  magnetic_susceptibility=0.0005, vp=2200, vs=1300,
                  dielectric=8.0, color="#C9A66B"),
            Layer("Bedrock", 25.0, 80.0, 500.0, density=2700,
                  magnetic_susceptibility=0.002, vp=4500, vs=2600,
                  dielectric=5.0, color="#6E6E6E"),
        ],
        extent_x=(0.0, 200.0),
        extent_y=(0.0, 0.0),
        max_depth=80.0,
        background_resistivity=100.0,
    )


def reservoir_model() -> EarthModel:
    """Model with a resistive reservoir (e.g., gas/oil layer) within a structural trap."""
    m = layered_model()
    m.name = "Reservoir"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=20.0,
            rx=30.0, ry=10.0, rz=8.0,
            resistivity=800.0,
            label="reservoir",
        ),
        # Conductive body (brine) nearby
        ResistivityBody(
            cx=160.0, cy=0.0, cz=15.0,
            rx=15.0, ry=10.0, rz=6.0,
            resistivity=5.0,
            label="brine",
        ),
    ]
    return m


def faulted_model() -> EarthModel:
    """Model with a fault zone represented by a resistivity displacement."""
    m = layered_model()
    m.name = "Faulted"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=30.0,
            rx=4.0, ry=100.0, rz=40.0,
            resistivity=20.0,
            label="fault_zone",
        ),
    ]
    return m


def anticline_model() -> EarthModel:
    """Anticline structural trap — resistive arch in sediment layer."""
    m = layered_model()
    m.name = "Anticline"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=18.0,
            rx=50.0, ry=20.0, rz=10.0,
            resistivity=400.0,
            label="anticline_core",
        ),
    ]
    return m


def salt_dome_model() -> EarthModel:
    """Salt dome — highly resistive intrusive body rising through sediments."""
    m = layered_model()
    m.name = "Salt Dome"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=25.0,
            rx=20.0, ry=20.0, rz=25.0,
            resistivity=1000.0,
            label="salt_dome",
        ),
    ]
    return m


def aquifer_model() -> EarthModel:
    """Aquifer — conductive water-bearing body."""
    m = layered_model()
    m.name = "Aquifer"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=10.0,
            rx=40.0, ry=15.0, rz=5.0,
            resistivity=15.0,
            label="aquifer",
        ),
    ]
    return m


def mineral_vein_model() -> EarthModel:
    """Mineral vein — narrow highly conductive body (e.g., massive sulfides)."""
    m = layered_model()
    m.name = "Mineral Vein"
    m.bodies = [
        ResistivityBody(
            cx=100.0, cy=0.0, cz=25.0,
            rx=6.0, ry=80.0, rz=30.0,
            resistivity=2.0,
            label="mineral_vein",
        ),
    ]
    return m


# Registry of ready-made scenarios
SCENARIOS: dict[str, EarthModel] = {
    "layered": layered_model(),
    "reservoir": reservoir_model(),
    "faulted": faulted_model(),
    "anticline": anticline_model(),
    "salt_dome": salt_dome_model(),
    "aquifer": aquifer_model(),
    "mineral_vein": mineral_vein_model(),
}


def get_scenario(name: str) -> EarthModel:
    """Return a deep copy of the named scenario."""
    if name not in SCENARIOS:
        raise KeyError(f"Unknown scenario: {name}. Available: {list(SCENARIOS)}")
    import copy
    return copy.deepcopy(SCENARIOS[name])


def scenario_descriptions() -> dict[str, str]:
    """Human-readable descriptions of each scenario."""
    return {
        "layered": "Simple three-layer model: topsoil, sediment, bedrock",
        "reservoir": "Resistive hydrocarbon reservoir with a brine body nearby",
        "faulted": "Vertical fault zone with conductive displacement",
        "anticline": "Anticline structural trap with a resistive core",
        "salt_dome": "Highly resistive salt dome intruding through sediments",
        "aquifer": "Conductive water-bearing aquifer near the surface",
        "mineral_vein": "Narrow highly conductive mineral vein (massive sulfides)",
    }
