"""Synthetic well & truth-known dataset generator for self-validation.

petroppo must be able to **prove itself**: given a synthetic earth
with a known reservoir (ground truth), generate wells (some hitting oil,
some dry), run the full geophysics → inversion → Bayesian prospectivity
pipeline, and show that the predicted probabilities match reality
(calibrated) and that the ranked targets include the real reservoir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core import EarthModel, ResistivityBody, Layer, get_logger
from ..processing.wellcal import WellLog

_log = get_logger("simulator.synthetic_fields")


@dataclass
class SyntheticField:
    """A truth-known synthetic field for validation."""
    model: EarthModel
    reservoir_body: ResistivityBody
    reservoir_cells: np.ndarray
    wells: list[WellLog] = field(default_factory=list)
    truth_label_grid: np.ndarray = field(default_factory=lambda: np.empty(0))
    x_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    z_coords: np.ndarray = field(default_factory=lambda: np.empty(0))
    meta: dict = field(default_factory=dict)


def _profile_length(model: EarthModel) -> float:
    return float(model.extent_x[1] - model.extent_x[0])


def _x0(model: EarthModel) -> float:
    return float(model.extent_x[0])


def make_synthetic_reservoir_field(
    *,
    profile_length: float = 200.0,
    max_depth: float = 80.0,
    nx: int = 40,
    nz: int = 20,
    reservoir_x: float = 100.0,
    reservoir_z: float = 35.0,
    reservoir_w: float = 50.0,
    reservoir_h: float = 16.0,
    reservoir_rho: float = 700.0,
    n_oil_wells: int = 6,
    n_dry_wells: int = 10,
    seed: int = 7,
) -> SyntheticField:
    """Build a synthetic field with a known buried reservoir.

    The reservoir is an ellipsoidal resistive body (oil is resistive)
    embedded in a layered sedimentary background.  Wells are placed:
    some whose target depth falls *inside* the reservoir (label=1, oil)
    and some outside (label=0, dry).
    """
    rng = np.random.default_rng(seed)

    layers = [
        Layer("Sediment-1", 0.0, 25.0, 30.0, density=2100,
              magnetic_susceptibility=0.0004, vp=2200, vs=1200,
              dielectric=9.0, color="#C9A66B"),
        Layer("Sediment-2", 25.0, 55.0, 120.0, density=2350,
              magnetic_susceptibility=0.0008, vp=3000, vs=1700,
              dielectric=7.0, color="#B8954B"),
        Layer("Basement", 55.0, max_depth, 500.0, density=2650,
              magnetic_susceptibility=0.0015, vp=4800, vs=2700,
              dielectric=5.0, color="#6E6E6E"),
    ]
    reservoir = ResistivityBody(
        cx=reservoir_x, cy=0.0, cz=reservoir_z,
        rx=reservoir_w / 2.0, ry=20.0, rz=reservoir_h / 2.0,
        resistivity=reservoir_rho,
        label="reservoir",
        density=2000.0,           # oil-bearing sand lighter than brine
        magnetic_susceptibility=0.0003,
        vp=3200.0,
        chargeability=0.12,
    )
    model = EarthModel(
        name="synthetic_reservoir",
        layers=layers,
        bodies=[reservoir],
        extent_x=(0.0, profile_length),
        extent_y=(0.0, 0.0),
        max_depth=max_depth,
        background_resistivity=100.0,
    )

    dx = profile_length / nx
    dz = max_depth / nz
    xs = dx * (np.arange(nx) + 0.5)
    zs = dz * (np.arange(nz) + 0.5)
    X, Z = np.meshgrid(xs, zs, indexing="ij")
    # truth: cells whose centre is inside the reservoir ellipsoid
    truth = np.zeros((nx, nz))
    for i in range(nx):
        for j in range(nz):
            if reservoir.contains(xs[i], 0.0, zs[j]):
                truth[i, j] = 1.0

    # wells
    wells: list[WellLog] = []
    oil_xs = rng.uniform(reservoir_x - reservoir_w / 2.0 + 3,
                         reservoir_x + reservoir_w / 2.0 - 3, n_oil_wells)
    for i, x in enumerate(oil_xs):
        td = float(rng.uniform(reservoir_z - reservoir_h / 2.0 + 2,
                               reservoir_z + reservoir_h / 2.0 - 2))
        wells.append(_make_well(x, td, 1, rng, reservoir, layers,
                                name=f"oil-{i+1}"))
    dry_xs = rng.uniform(5, profile_length - 5, n_dry_wells)
    for i, x in enumerate(dry_xs):
        in_res_x = abs(x - reservoir_x) <= reservoir_w / 2.0
        if in_res_x:
            td = float(rng.choice([
                rng.uniform(8, reservoir_z - reservoir_h / 2.0 - 3),
                rng.uniform(reservoir_z + reservoir_h / 2.0 + 3,
                            max_depth - 5),
            ]))
        else:
            td = float(rng.uniform(12, max_depth - 5))
        wells.append(_make_well(x, td, 0, rng, reservoir, layers,
                                name=f"dry-{i+1}"))

    return SyntheticField(
        model=model, reservoir_body=reservoir, reservoir_cells=truth,
        wells=wells, truth_label_grid=truth,
        x_coords=xs, z_coords=zs,
        meta={"seed": seed, "reservoir_rho": reservoir_rho,
              "profile_length": profile_length, "max_depth": max_depth},
    )


def _make_well(x: float, td: float, label: int, rng,
               reservoir: ResistivityBody, layers: list[Layer],
               name: str) -> WellLog:
    """Generate a well with synthetic logs consistent with the earth model."""
    n = 50
    maxd = max(td + 5, 70.0)
    depths = np.linspace(2.0, maxd, n)

    def _bg(depth, prop):
        for L in layers:
            if L.top_depth <= depth < L.bottom_depth:
                return float(getattr(L, prop))
        return float(getattr(layers[-1], prop))

    rho = np.array([_bg(d, "resistivity") for d in depths], dtype=float)
    den = np.array([_bg(d, "density") for d in depths], dtype=float)
    gr = np.array([60 + 25 * np.sin(d / 12.0) for d in depths], dtype=float)
    vel = np.array([_bg(d, "vp") for d in depths], dtype=float)
    # if well penetrates reservoir at this x, spike the logs
    in_res_x = abs(x - reservoir.cx) <= reservoir.rx
    if in_res_x:
        res_z = reservoir.cz
        res_h = reservoir.rz * 2
        mask = (depths >= res_z - res_h / 2) & (depths <= res_z + res_h / 2)
        if mask.any():
            rho[mask] = reservoir.resistivity
            if reservoir.density is not None:
                den[mask] = reservoir.density
            if reservoir.vp is not None:
                vel[mask] = reservoir.vp
    rho = rho * (1 + 0.05 * rng.standard_normal(n))
    den = den + 25 * rng.standard_normal(n)
    vel = vel * (1 + 0.03 * rng.standard_normal(n))
    gr = gr + 8 * rng.standard_normal(n)
    return WellLog(name=name, x=float(x), y=0.0, target_depth=float(td),
                   label=int(label),
                   logs={"resistivity": rho, "density": den,
                         "gamma": gr, "velocity": vel},
                   log_depths=depths)


def score_prospectivity_vs_truth(probability: np.ndarray,
                                 truth: np.ndarray,
                                 mask: np.ndarray | None = None,
                                 ) -> dict[str, float]:
    """Score a predicted probability map against the known truth grid."""
    p = np.clip(np.asarray(probability, dtype=float).ravel(), 0.0, 1.0)
    y = np.asarray(truth, dtype=float).ravel()
    if mask is not None:
        m = np.asarray(mask, dtype=bool).ravel()
        p, y = p[m], y[m]
    if y.size == 0 or p.size == 0:
        return {"roc_auc": 0.5, "brier": 0.25, "accuracy": 0.0, "n": 0}
    from ..validation.metrics import roc_auc, brier_score, accuracy
    return {"roc_auc": float(roc_auc(p, y)), "brier": float(brier_score(p, y)),
            "accuracy": float(accuracy(p, y)), "n": int(y.size)}
