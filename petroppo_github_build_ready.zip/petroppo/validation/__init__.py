"""Validation framework — prove petroppo works against known truth.

This package is what makes petroppo *honest*: instead of asserting
"10/10 actual oil detection", it runs the full pipeline against
synthetic fields with known reservoirs and reports objective metrics
(ROC-AUC, Brier score, reliability, target-recovery).  If the metrics
are good, the claim is justified; if not, the system says so.

Modules
-------
* ``self_validation`` — end-to-end: synthetic field → forward → invert →
  Bayesian prospectivity → score against truth.  Produces a
  :class:`ValidationReport`.
* ``metrics`` — Brier, ROC-AUC, reliability diagram, target recovery.
"""
from .self_validation import (
    ValidationReport, run_self_validation, quick_validation,
    TARGET_HIT_THRESHOLD,
)
from .metrics import (
    brier_score, log_loss, roc_auc, accuracy, reliability_diagram,
    target_recovery, mean_prediction_calibration,
)

__all__ = [
    "ValidationReport", "run_self_validation", "quick_validation",
    "TARGET_HIT_THRESHOLD",
    "brier_score", "log_loss", "roc_auc", "accuracy",
    "reliability_diagram", "target_recovery", "mean_prediction_calibration",
]
