"""Forecast verification metrics for probabilistic hydrocarbon prediction.

These are the standard probabilistic-forecast verification metrics used
in meteorology and exploration risk assessment, applied to petroppo's
posterior probability maps.

A *well-calibrated* system is one where, across many cells (or wells),
the predicted probability matches the empirical frequency of
hydrocarbons.  A *sharp* system makes confident predictions near 0 or 1.
A *discriminating* system ranks true positives above true negatives
(ROC-AUC).  Brier combines calibration and sharpness.
"""
from __future__ import annotations

import numpy as np


def _flatten(p, y, mask=None):
    p = np.clip(np.asarray(p, dtype=float).ravel(), 0.0, 1.0)
    y = np.asarray(y, dtype=float).ravel()
    if mask is not None:
        m = np.asarray(mask, dtype=bool).ravel()
        p, y = p[m], y[m]
    return p, y


def brier_score(predictions, labels, mask=None) -> float:
    """Mean squared error of probabilistic forecasts (0=perfect, 0.25=random)."""
    p, y = _flatten(predictions, labels, mask)
    if p.size == 0:
        return 0.25
    return float(np.mean((p - y) ** 2))


def log_loss(predictions, labels, mask=None, eps: float = 1e-12) -> float:
    """Negative log-likelihood of the labels under the forecast (lower=better)."""
    p, y = _flatten(predictions, labels, mask)
    if p.size == 0:
        return 0.7
    return float(-np.mean(y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps)))


def roc_auc(predictions, labels, mask=None) -> float:
    """Rank-based ROC-AUC (0.5=random, 1.0=perfect discrimination).

    Uses the Mann-Whitney U statistic with average ranks for ties.  When every
    prediction is identical (no discrimination whatsoever) the AUC is exactly
    0.5, matching the standard convention that a non-informative forecast has
    AUC = 0.5.
    """
    p, y = _flatten(predictions, labels, mask)
    n1 = float(np.sum(y == 1))
    n0 = float(np.sum(y == 0))
    if n1 == 0 or n0 == 0:
        return 0.5
    # Degenerate case: all predictions identical -> no discrimination -> 0.5
    if np.unique(p).size == 1:
        return 0.5
    order = np.argsort(p)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(p) + 1)
    # average ranks for ties
    # (group by equal p, assign mean rank)
    sp = p[order]
    i = 0
    while i < len(sp):
        j = i
        while j < len(sp) and sp[j] == sp[i]:
            j += 1
        if j - i > 1:
            mean_r = (ranks[order][i:j].mean())
            ranks[order][i:j] = mean_r
        i = j
    sum_r = float(np.sum(ranks[y == 1]))
    auc = (sum_r - n1 * (n1 + 1) / 2.0) / (n1 * n0)
    return float(np.clip(auc, 0.0, 1.0))


def accuracy(predictions, labels, mask=None, threshold: float = 0.5) -> float:
    """Fraction correct at the given decision threshold."""
    p, y = _flatten(predictions, labels, mask)
    if p.size == 0:
        return 0.0
    return float(np.mean((p >= threshold).astype(float) == y))


def reliability_diagram(predictions, labels, n_bins: int = 10, mask=None):
    """Reliability diagram: predicted bin vs empirical frequency."""
    p, y = _flatten(predictions, labels, mask)
    if p.size == 0:
        return {"centres": np.linspace(0, 1, n_bins),
                "frequency": np.zeros(n_bins),
                "counts": np.zeros(n_bins, dtype=int),
                "perfect": np.linspace(0, 1, n_bins)}
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    centres = 0.5 * (bins[:-1] + bins[1:])
    freq = np.zeros(n_bins)
    counts = np.zeros(n_bins, dtype=int)
    for i in range(n_bins):
        lo, hi = bins[i], bins[i + 1]
        m = (p >= lo) & (p < hi) if i < n_bins - 1 else (p >= lo) & (p <= hi)
        if m.sum() > 0:
            freq[i] = float(y[m].mean())
            counts[i] = int(m.sum())
    return {"centres": centres, "frequency": freq, "counts": counts,
            "perfect": centres.copy()}


def target_recovery(probability, truth, reservoir_mask,
                    x_coords=None, z_coords=None,
                    n_targets: int = 5) -> dict:
    """Did the top-N predicted targets fall inside the true reservoir?

    Returns the fraction of top-N targets that hit the reservoir, the
    best (max) probability inside the reservoir, and the mean probability
    inside vs outside the reservoir (a discrimination measure).
    """
    prob = np.asarray(probability, dtype=float)
    truth = np.asarray(truth, dtype=float)
    mask = np.asarray(reservoir_mask, dtype=bool)
    if prob.shape != truth.shape:
        return {"hit_rate": 0.0, "best_in_reservoir": 0.0,
                "mean_inside": 0.0, "mean_outside": 0.0, "n_targets": n_targets}
    # top-N cells
    flat = np.argsort(prob.ravel())[::-1][:n_targets]
    nx, nz = prob.shape
    hits = 0
    for fi in flat:
        ix, iz = divmod(int(fi), nz)
        if mask[ix, iz]:
            hits += 1
    return {
        "hit_rate": hits / n_targets,
        "best_in_reservoir": float(prob[mask].max()) if mask.any() else 0.0,
        "mean_inside": float(prob[mask].mean()) if mask.any() else 0.0,
        "mean_outside": float(prob[~mask].mean()) if (~mask).any() else 0.0,
        "n_targets": n_targets,
        "n_hits": hits,
    }


def mean_prediction_calibration(predictions, labels, mask=None) -> float:
    """|mean predicted P − empirical base rate| (0=perfectly calibrated base)."""
    p, y = _flatten(predictions, labels, mask)
    if p.size == 0:
        return 0.0
    return float(abs(p.mean() - y.mean()))
