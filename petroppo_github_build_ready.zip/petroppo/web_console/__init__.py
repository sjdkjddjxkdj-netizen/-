"""
petroppo V35 — Web Console UI
================================

A Microsoft Office-style console interface for petroppo V35, rendered entirely
in HTML5 Canvas with a ribbon-toolbar layout, project explorer sidebar,
properties panel, and a live AI Copilot panel.

The console supports six industry-standard color maps for 3D, 2D, and 1D
seismic visualisations:

    * Seismic Blue-White-Red   (default diverging)
    * Grayscale                (publication)
    * Rainbow                  (attribute maps)
    * HSV                      (cyclic / phase)
    * Geo-Orange               (petroppo brand)
    * Red-White-Blue           (reverse diverging)

Usage
-----
    from petroppo.web_console import launch_console
    launch_console()          # opens the console in the default browser

Or from the command line:

    python -m petroppo.web_console.launch
"""

__version__ = "35.0.0"

# Lazy imports — avoids RuntimeWarning when running `python -m petroppo.web_console.launch`
def __getattr__(name):
    if name == "launch_console":
        from .launch import launch_console
        return launch_console
    if name == "WebConsoleServer":
        from .launch import WebConsoleServer
        return WebConsoleServer
    raise AttributeError(f"module 'petroppo.web_console' has no attribute {name!r}")

__all__ = ["launch_console", "WebConsoleServer"]
