/* =========================================================================
   PetroScan V35 — Console UI JavaScript
   Handles: icon injection, tab switching, tree, context menu,
            canvas rendering, properties, AI copilot, status bar,
            color maps for 3D / 2D / 1D views
   ========================================================================= */

(function() {
'use strict';

/* ---------- 0. COLOR MAPS (3D / 2D / 1D) ----------
   Each color map is a function: value (-1..+1) → [r,g,b]
   The "Color Map" dropdown in Properties controls which map is active.
   Different view types (3D volume, 2D section, 1D log) all use the
   active color map so colors are consistent across views.
   ------------------------------------------------------------------ */
var ColorMaps = {
    'Seismic Blue-White-Red': {
        label: 'Seismic Blue-White-Red',
        // Standard seismic: blue for negative, white at zero, red for positive
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            if (v >= 0) {
                // white → red
                return [255, Math.round(255 - v * 255), Math.round(255 - v * 255)];
            } else {
                // white → blue
                var a = -v;
                return [Math.round(255 - a * 255), Math.round(255 - a * 255), 255];
            }
        }
    },
    'Grayscale': {
        label: 'Grayscale',
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            var g = Math.round(128 + v * 127);
            return [g, g, g];
        }
    },
    'Rainbow': {
        label: 'Rainbow',
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            var t = (v + 1) / 2; // 0..1
            var h = (1 - t) * 240; // 240(blue) → 0(red)
            return hslToRgb(h, 0.85, 0.5);
        }
    },
    'HSV': {
        label: 'HSV',
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            var t = (v + 1) / 2;
            var h = t * 300; // red → magenta
            return hslToRgb(h, 0.9, 0.55);
        }
    },
    'Geo-Orange': {
        label: 'Geo-Orange',
        // PetroScan-branded: white → pale orange → orange → dark orange
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            if (v >= 0) {
                // white → orange (#ED7D31)
                return [Math.round(255 - v * 18), Math.round(255 - v * 130), Math.round(255 - v * 210)];
            } else {
                var a = -v;
                // white → dark blue-gray (#44546A)
                return [Math.round(255 - a * 187), Math.round(255 - a * 171), Math.round(255 - a * 157)];
            }
        }
    },
    'Red-White-Blue': {
        label: 'Red-White-Blue',
        // Reversed seismic (common in some workflows)
        fn: function(v) {
            v = Math.max(-1, Math.min(1, v));
            if (v >= 0) {
                var a = v;
                return [Math.round(255 - a * 255), Math.round(255 - a * 255), 255];
            } else {
                var a2 = -v;
                return [255, Math.round(255 - a2 * 255), Math.round(255 - a2 * 255)];
            }
        }
    }
};

function hslToRgb(h, s, l) {
    h /= 360;
    var r, g, b;
    if (s === 0) { r = g = b = l; }
    else {
        var hue2rgb = function(p, q, t) {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1/6) return p + (q - p) * 6 * t;
            if (t < 1/2) return q;
            if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
            return p;
        };
        var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        var p = 2 * l - q;
        r = hue2rgb(p, q, h + 1/3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1/3);
    }
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

// Active color map name (controlled by the Properties dropdown)
var activeColorMap = 'Seismic Blue-White-Red';

function getColorMap() {
    return ColorMaps[activeColorMap] || ColorMaps['Seismic Blue-White-Red'];
}

function mapColor(v) {
    var rgb = getColorMap().fn(v);
    return 'rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')';
}

function mapColorRGBA(v, alpha) {
    var rgb = getColorMap().fn(v);
    return 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + alpha + ')';
}

// Build a CSS gradient string from the active color map (for the on-screen colorbar)
function colorMapGradientCSS(direction) {
    direction = direction || 'to bottom';
    var stops = [];
    var n = 20;
    for (var i = 0; i <= n; i++) {
        var v = 1 - (i / n) * 2; // +1 at top → -1 at bottom
        var rgb = getColorMap().fn(v);
        stops.push('rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ') ' + Math.round(i / n * 100) + '%');
    }
    return 'linear-gradient(' + direction + ', ' + stops.join(', ') + ')';
}

// Update the on-screen colorbar to match the active color map
function updateColorbar() {
    var cb = document.querySelector('.colorbar-gradient');
    if (cb) cb.style.background = colorMapGradientCSS('to bottom');
}

/* ---------- 1. ICON INJECTION ---------- */
function injectIcons() {
    document.querySelectorAll('[data-icon]').forEach(function(el) {
        var name = el.getAttribute('data-icon');
        if (Icons[name]) {
            el.innerHTML = Icons[name];
        }
    });
    // Title bar logo
    var logo = document.getElementById('titleLogo');
    if (logo && Icons.logo) logo.innerHTML = Icons.logo;
    // Window control icons
    var winMin = document.getElementById('winMin');
    if (winMin) winMin.innerHTML = Icons.minimize;
    var winMax = document.getElementById('winMax');
    if (winMax) winMax.innerHTML = Icons.maximize;
    var winClose = document.getElementById('winClose');
    if (winClose) winClose.innerHTML = Icons.close;
    var winUser = document.getElementById('winUser');
    if (winUser) winUser.innerHTML = Icons.user;
}

/* ---------- 2. TOOLTIP SYSTEM ---------- */
var tooltip = document.getElementById('tooltip');
var tooltipTimer = null;

document.addEventListener('mouseover', function(e) {
    var target = e.target.closest('[data-tooltip]');
    if (!target) return;
    clearTimeout(tooltipTimer);
    tooltipTimer = setTimeout(function() {
        tooltip.textContent = target.getAttribute('data-tooltip');
        var rect = target.getBoundingClientRect();
        tooltip.style.left = (rect.left + rect.width / 2) + 'px';
        tooltip.style.top = (rect.bottom + 4) + 'px';
        tooltip.classList.add('tooltip-visible');
    }, 400);
});

document.addEventListener('mouseout', function(e) {
    if (e.target.closest('[data-tooltip]')) {
        clearTimeout(tooltipTimer);
        tooltip.classList.remove('tooltip-visible');
    }
});

/* ---------- 3. TAB SWITCHING (Ribbon) ---------- */
var tabs = document.querySelectorAll('.ttab');
var panes = document.querySelectorAll('.ribbon-pane');

tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
        var target = tab.getAttribute('data-tab');
        tabs.forEach(function(t) { t.classList.remove('active'); });
        panes.forEach(function(p) { p.classList.remove('active'); });
        tab.classList.add('active');
        var pane = document.querySelector('.ribbon-pane[data-pane="' + target + '"]');
        if (pane) pane.classList.add('active');
    });
});

/* ---------- 4. PROJECT TREE ---------- */
var treeData = [
    {
        label: 'North Sea Project V35', icon: 'folderOpen', open: true, children: [
            {
                label: 'Seismic Volumes', icon: 'folder', open: true, children: [
                    { label: 'NorthSea_3D.sgy', icon: 'seismic', type: 'volume' },
                    { label: 'Shallow_Gas.sgy', icon: 'seismic', type: 'volume' },
                    { label: 'Deep_Carbonates.sgy', icon: 'seismic', type: 'volume' }
                ]
            },
            {
                label: 'Well Data', icon: 'folder', open: true, children: [
                    { label: 'Well-A1.las', icon: 'well', type: 'well' },
                    { label: 'Well-B2.las', icon: 'well', type: 'well' },
                    { label: 'Well-C3.las', icon: 'well', type: 'well' },
                    { label: 'Well-D4.las', icon: 'well', type: 'well' }
                ]
            },
            {
                label: 'Horizons', icon: 'folder', open: true, children: [
                    { label: 'Top Reservoir', icon: 'horizon', type: 'horizon' },
                    { label: 'Base Reservoir', icon: 'horizon', type: 'horizon' },
                    { label: 'Top Seal', icon: 'horizon', type: 'horizon' }
                ]
            },
            {
                label: 'Faults', icon: 'folder', open: false, children: [
                    { label: 'Fault-1', icon: 'fault', type: 'fault' },
                    { label: 'Fault-2', icon: 'fault', type: 'fault' }
                ]
            },
            {
                label: 'Interpretation', icon: 'folder', open: false, children: [
                    { label: 'Coherence Volume', icon: 'coherence', type: 'attr' },
                    { label: 'RMS Attribute', icon: 'attribute', type: 'attr' },
                    { label: 'AI Impedance', icon: 'impedance', type: 'attr' }
                ]
            },
            {
                label: 'Models', icon: 'folder', open: false, children: [
                    { label: '3D Grid Model', icon: 'grid', type: 'model' },
                    { label: 'Property: Porosity', icon: 'property', type: 'model' },
                    { label: 'Property: Saturation', icon: 'property', type: 'model' }
                ]
            },
            {
                label: 'Reservoir', icon: 'folder', open: false, children: [
                    { label: 'Volumetric Analysis', icon: 'volumetric', type: 'res' },
                    { label: 'Flow Simulation', icon: 'simulation', type: 'res' }
                ]
            },
            {
                label: 'Exports', icon: 'folder', open: false, children: [
                    { label: 'RESQML Export', icon: 'resqml', type: 'export' },
                    { label: 'WITSML Export', icon: 'witsml', type: 'export' }
                ]
            }
        ]
    }
];

function buildTree(nodes, container, level) {
    level = level || 0;
    nodes.forEach(function(node) {
        var div = document.createElement('div');
        div.className = 'tree-node' + (node.open ? ' open' : '');
        div.style.paddingLeft = (12 + level * 16) + 'px';

        var row = document.createElement('div');
        row.className = 'tree-row';

        if (node.children) {
            var chevron = document.createElement('span');
            chevron.className = 'tree-chevron';
            chevron.innerHTML = Icons.chevronRight;
            chevron.addEventListener('click', function(e) {
                e.stopPropagation();
                div.classList.toggle('open');
            });
            row.appendChild(chevron);
        } else {
            var spacer = document.createElement('span');
            spacer.className = 'tree-chevron-spacer';
            row.appendChild(spacer);
        }

        var iconSpan = document.createElement('span');
        iconSpan.className = 'tree-icon';
        iconSpan.innerHTML = Icons[node.icon] || Icons.folder;
        row.appendChild(iconSpan);

        var label = document.createElement('span');
        label.className = 'tree-label';
        label.textContent = node.label;
        row.appendChild(label);

        div.appendChild(row);

        // Right-click context menu
        row.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            showContextMenu(e.clientX, e.clientY, node);
        });

        // Click select
        row.addEventListener('click', function() {
            document.querySelectorAll('.tree-row.selected').forEach(function(r) {
                r.classList.remove('selected');
            });
            row.classList.add('selected');
        });

        if (node.children) {
            var childContainer = document.createElement('div');
            childContainer.className = 'tree-children';
            buildTree(node.children, childContainer, level + 1);
            div.appendChild(childContainer);
        }

        container.appendChild(div);
    });
}

var projectTree = document.getElementById('projectTree');
if (projectTree) buildTree(treeData, projectTree, 0);

/* ---------- 5. CONTEXT MENU ---------- */
var ctxMenu = document.getElementById('contextMenu');

function showContextMenu(x, y, node) {
    ctxMenu.style.left = x + 'px';
    ctxMenu.style.top = y + 'px';
    ctxMenu.classList.add('ctx-visible');
}

document.addEventListener('click', function() {
    ctxMenu.classList.remove('ctx-visible');
});

ctxMenu.addEventListener('click', function(e) {
    e.stopPropagation();
    var item = e.target.closest('.ctx-item');
    if (item) {
        var action = item.getAttribute('data-action');
        showToast('Context action: ' + action);
    }
    ctxMenu.classList.remove('ctx-visible');
});

/* ---------- 6. TOAST NOTIFICATION ---------- */
var toastEl = null;
function showToast(msg) {
    if (toastEl) toastEl.remove();
    toastEl = document.createElement('div');
    toastEl.className = 'toast';
    toastEl.innerHTML = '<span>' + Icons.check + '</span> ' + msg;
    document.body.appendChild(toastEl);
    requestAnimationFrame(function() {
        toastEl.classList.add('toast-visible');
    });
    setTimeout(function() {
        if (toastEl) {
            toastEl.classList.remove('toast-visible');
            setTimeout(function() { if (toastEl) toastEl.remove(); }, 300);
        }
    }, 2500);
}

/* ---------- 7. RIBBON TOOL BUTTONS ---------- */
document.querySelectorAll('.rbtn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var tool = btn.getAttribute('data-tool');
        var label = btn.querySelector('.rbtn-label');
        showToast('Activated: ' + (label ? label.textContent.replace(/\n/g, ' ') : tool));
        btn.classList.add('rbtn-pressed');
        setTimeout(function() { btn.classList.remove('rbtn-pressed'); }, 200);
        if (tool === 'run') simulateProgress('Running computation…');
        if (tool === 'inversion') simulateProgress('Running acoustic inversion…');
        if (tool === 'simulation') simulateProgress('Running flow simulation…');
        if (tool === 'ai' || tool === 'aiCopilot') openAICopilot();
    });
});

/* Canvas toolbar buttons */
document.querySelectorAll('.cv-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.cv-btn').forEach(function(b) { b.classList.remove('active'); });
        btn.classList.add('active');
        var view = btn.getAttribute('data-view');
        renderView(view);
    });
});

document.querySelectorAll('.cv-icon-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var tool = btn.getAttribute('data-tool');
        showToast('View tool: ' + tool);
        if (tool === 'zoomIn') zoomCanvas(1.1);
        if (tool === 'zoomOut') zoomCanvas(0.9);
    });
});

/* ---------- 8. CANVAS 3D RENDERING ---------- */
var canvas = document.getElementById('viz3d');
var ctx = canvas.getContext('2d');
var zoomLevel = 1.0;
var rotation = 0;
var currentView = '3d';

function resizeCanvas() {
    var container = document.getElementById('canvasContainer');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
    renderView(currentView);
}

window.addEventListener('resize', resizeCanvas);

function renderView(view) {
    currentView = view || currentView;
    var w = canvas.width;
    var h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    if (view === '3d' || !view) {
        render3DView(w, h);
    } else if (view === 'inline' || view === 'crossline') {
        renderSeismicSection(w, h);
    } else if (view === 'map') {
        renderTimeSlice(w, h);
    } else if (view === 'well') {
        renderWellSection(w, h);
    } else if (view === 'log1d') {
        render1DLogView(w, h);
    }
}

function render3DView(w, h) {
    var cx = w / 2, cy = h / 2;
    var scale = Math.min(w, h) * 0.32 * zoomLevel;

    // Background grid
    ctx.strokeStyle = '#E7E6E6';
    ctx.lineWidth = 1;
    for (var i = 0; i <= 20; i++) {
        var x = (w / 20) * i;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
        var y = (h / 20) * i;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }

    // 3D cube (isometric seismic volume)
    var rot = rotation;
    var cosR = Math.cos(rot), sinR = Math.sin(rot);

    // Volume box vertices
    var pts = [
        [-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],
        [-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]
    ];
    var projected = pts.map(function(p) {
        var x = p[0] * cosR - p[2] * sinR;
        var z = p[0] * sinR + p[2] * cosR;
        var y = p[1];
        return [cx + x * scale, cy + y * scale - z * scale * 0.3];
    });

    // Draw volume faces — colored by active color map (3D volume rendering)
    var faces = [
        [0,1,2,3],[4,5,6,7],[0,1,5,4],[2,3,7,6],[1,2,6,5],[0,3,7,4]
    ];
    // Face amplitudes for color mapping (simulated seismic reflector strength)
    var faceAmps = [0.6, -0.4, 0.3, -0.2, 0.8, -0.5];
    faces.forEach(function(f, i) {
        ctx.beginPath();
        ctx.moveTo(projected[f[0]][0], projected[f[0]][1]);
        ctx.lineTo(projected[f[1]][0], projected[f[1]][1]);
        ctx.lineTo(projected[f[2]][0], projected[f[2]][1]);
        ctx.lineTo(projected[f[3]][0], projected[f[3]][1]);
        ctx.closePath();
        // Fill with color-mapped amplitude at ~35% opacity (3D volume style)
        ctx.fillStyle = mapColorRGBA(faceAmps[i], 0.28);
        ctx.fill();
        ctx.strokeStyle = mapColor(faceAmps[i]);
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = 0.6;
        ctx.stroke();
        ctx.globalAlpha = 1.0;
    });

    // Draw seismic wiggle traces on front face — colored by color map
    ctx.lineWidth = 0.8;
    var nTraces = 30;
    for (var t = 0; t < nTraces; t++) {
        var tx = projected[0][0] + (projected[1][0] - projected[0][0]) * (t / nTraces);
        var topY = projected[0][1] + (projected[3][1] - projected[0][1]) * 0;
        var botY = projected[0][1] + (projected[3][1] - projected[0][1]) * 1;
        ctx.beginPath();
        for (var s = 0; s <= 80; s++) {
            var py = topY + (botY - topY) * (s / 80);
            var wiggle = Math.sin(s * 0.4 + t * 0.5) * 6 * Math.exp(-Math.abs(s - 40) * 0.05);
            // Color each sample by its amplitude value (-1..+1)
            var amp = Math.sin(s * 0.4 + t * 0.5) * Math.exp(-Math.abs(s - 40) * 0.05);
            if (s === 0) {
                ctx.moveTo(tx + wiggle, py);
            } else {
                ctx.lineTo(tx + wiggle, py);
            }
        }
        ctx.strokeStyle = mapColorRGBA(0.5, 0.5);
        ctx.stroke();
    }

    // Well trajectories
    var wells = [
        { x: -0.4, z: -0.3 }, { x: 0.3, z: 0.2 }, { x: 0.1, z: -0.5 }
    ];
    wells.forEach(function(well) {
        var wx = cx + (well.x * cosR - well.z * sinR) * scale;
        var wz = (well.x * sinR + well.z * cosR) * scale;
        ctx.strokeStyle = '#ED7D31';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(wx, cy - scale * 0.8);
        ctx.lineTo(wx, cy + scale * 0.8 - wz * 0.3);
        ctx.stroke();
        // Wellhead marker
        ctx.fillStyle = '#FFC000';
        ctx.beginPath();
        ctx.arc(wx, cy - scale * 0.8, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#C55A11';
        ctx.lineWidth = 1;
        ctx.stroke();
    });

    // Horizon surface (curved line across volume)
    ctx.strokeStyle = '#44546A';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (var hi = 0; hi <= 50; hi++) {
        var hx = -1 + 2 * (hi / 50);
        var hz = 0;
        var wx2 = cx + (hx * cosR - hz * sinR) * scale;
        var wy2 = cy + (-0.15 + Math.sin(hi * 0.15) * 0.08) * scale - hz * scale * 0.3;
        if (hi === 0) ctx.moveTo(wx2, wy2);
        else ctx.lineTo(wx2, wy2);
    }
    ctx.stroke();

    // Title overlay
    ctx.fillStyle = 'rgba(68,84,106,0.6)';
    ctx.font = '600 14px Segoe UI';
    ctx.fillText('3D Volume — NorthSea_3D.sgy', 16, 28);
    ctx.font = '11px Segoe UI';
    ctx.fillStyle = 'rgba(68,84,106,0.5)';
    ctx.fillText('Inlines: 1–500  ·  Xlines: 1–400  ·  Samples: 1000  ·  4 wells', 16, 46);
}

function renderSeismicSection(w, h) {
    // Wiggly seismic section
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    var topMargin = 50;
    var leftMargin = 60;
    var plotW = w - leftMargin - 30;
    var plotH = h - topMargin - 40;

    // Trace axis labels
    ctx.fillStyle = '#44546A';
    ctx.font = '10px Segoe UI';
    ctx.fillText('Inline', leftMargin + plotW / 2 - 20, topMargin - 15);
    ctx.save();
    ctx.translate(15, topMargin + plotH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('TWT (ms)', -25, 5);
    ctx.restore();

    // Grid
    ctx.strokeStyle = '#E7E6E6';
    ctx.lineWidth = 0.5;
    for (var gx = 0; gx <= 10; gx++) {
        var x = leftMargin + (plotW / 10) * gx;
        ctx.beginPath(); ctx.moveTo(x, topMargin); ctx.lineTo(x, topMargin + plotH); ctx.stroke();
    }
    for (var gy = 0; gy <= 8; gy++) {
        var y = topMargin + (plotH / 8) * gy;
        ctx.beginPath(); ctx.moveTo(leftMargin, y); ctx.lineTo(leftMargin + plotW, y); ctx.stroke();
    }

    // Seismic traces — 2D section colored by active color map
    // Positive amplitudes filled (variable area), negative left as wiggle outline
    var nTraces = 80;
    for (var t = 0; t < nTraces; t++) {
        var tx = leftMargin + (plotW / (nTraces - 1)) * t;
        var amp = Math.sin(t * 0.08) * 0.3;

        // First pass: compute wiggle and fill positive peaks with color map
        for (var s = 0; s <= 200; s++) {
            var py = topMargin + (plotH / 200) * s;
            var reflector = Math.sin(s * 0.08 + t * 0.05) * 12 * Math.exp(-Math.abs(s - 80) * 0.02)
                          + Math.sin(s * 0.15 + t * 0.1) * 8 * Math.exp(-Math.abs(s - 140) * 0.03);
            var wiggle = (reflector + amp * 5);
            // Normalized amplitude for color mapping
            var normAmp = Math.max(-1, Math.min(1, wiggle / 18));

            // Variable area fill: fill positive amplitudes with color map color
            if (wiggle > 0) {
                ctx.fillStyle = mapColor(normAmp);
                ctx.fillRect(tx, py - 1, wiggle, 2);
            } else {
                // Negative amplitudes filled with a faded version of the color map
                ctx.fillStyle = mapColorRGBA(normAmp, 0.35);
                ctx.fillRect(tx + wiggle, py - 1, -wiggle, 2);
            }
        }

        // Second pass: wiggle trace outline
        ctx.strokeStyle = mapColorRGBA(0.4, 0.6);
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        for (var s2 = 0; s2 <= 200; s2++) {
            var py2 = topMargin + (plotH / 200) * s2;
            var reflector2 = Math.sin(s2 * 0.08 + t * 0.05) * 12 * Math.exp(-Math.abs(s2 - 80) * 0.02)
                           + Math.sin(s2 * 0.15 + t * 0.1) * 8 * Math.exp(-Math.abs(s2 - 140) * 0.03);
            var wiggle2 = (reflector2 + amp * 5);
            if (s2 === 0) ctx.moveTo(tx + wiggle2, py2);
            else ctx.lineTo(tx + wiggle2, py2);
        }
        ctx.stroke();
    }

    // Title
    ctx.fillStyle = '#44546A';
    ctx.font = '600 14px Segoe UI';
    ctx.fillText(currentView === 'inline' ? 'Inline Section — IL 250' : 'Crossline Section — XL 200', 16, 28);
}

function renderTimeSlice(w, h) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
    var cx = w / 2, cy = h / 2;
    var rad = Math.min(w, h) * 0.35;

    // Time slice as colored map — uses active color map
    for (var py = 0; py < h; py += 4) {
        for (var px = 0; px < w; px += 4) {
            var dx = (px - cx) / rad;
            var dy = (py - cy) / rad;
            var d = Math.sqrt(dx*dx + dy*dy);
            if (d > 1.2) continue;
            var val = Math.sin(dx * 8) * Math.cos(dy * 6) * Math.exp(-d * 1.5);
            // Map value through active color map
            var rgb = getColorMap().fn(val);
            ctx.fillStyle = 'rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')';
            ctx.fillRect(px, py, 4, 4);
        }
    }

    // Border
    ctx.strokeStyle = '#44546A';
    ctx.lineWidth = 2;
    ctx.strokeRect(cx - rad * 1.2, cy - rad * 1.2, rad * 2.4, rad * 2.4);

    // Well markers
    var wells = [[-0.3, -0.2], [0.2, 0.3], [0.1, -0.4], [-0.1, 0.1]];
    wells.forEach(function(wl) {
        var wx = cx + wl[0] * rad;
        var wy = cy + wl[1] * rad;
        ctx.fillStyle = '#ED7D31';
        ctx.beginPath(); ctx.arc(wx, wy, 6, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#C55A11'; ctx.lineWidth = 1.5; ctx.stroke();
    });

    ctx.fillStyle = '#44546A';
    ctx.font = '600 14px Segoe UI';
    ctx.fillText('Time Slice — 1500 ms', 16, 28);
}

function renderWellSection(w, h) {
    // 1D Well Log display — each well has multiple log tracks
    // Log curves are colored by the active color map (amplitude-based)
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
    var topM = 55, leftM = 70;
    var nWells = 4;
    var wellW = (w - leftM - 30) / nWells;

    var wellNames = ['Well-A1', 'Well-B2', 'Well-C3', 'Well-D4'];
    // Each well gets a track width for its log curves
    var trackW = wellW * 0.6;

    for (var wi = 0; wi < nWells; wi++) {
        var wx = leftM + wellW * wi + (wellW - trackW) / 2;
        var trackLeft = wx;
        var trackRight = wx + trackW;
        var trackCenter = (trackLeft + trackRight) / 2;

        // Track background
        ctx.fillStyle = 'rgba(231,230,230,0.3)';
        ctx.fillRect(trackLeft, topM, trackW, h - topM - 40);

        // Track border
        ctx.strokeStyle = '#D9D9D9';
        ctx.lineWidth = 1;
        ctx.strokeRect(trackLeft, topM, trackW, h - topM - 40);

        // Center line
        ctx.strokeStyle = '#E7E6E6';
        ctx.lineWidth = 0.5;
        ctx.beginPath(); ctx.moveTo(trackCenter, topM); ctx.lineTo(trackCenter, h - 40); ctx.stroke();

        // Generate log curve data (gamma ray style with different character per well)
        var nSamples = 200;
        var curveData = [];
        for (var s = 0; s <= nSamples; s++) {
            var baseFreq = 0.08 + wi * 0.02;
            var curve = Math.sin(s * baseFreq + wi * 1.5) * 0.5
                      + Math.sin(s * 0.05) * 0.25
                      + Math.sin(s * 0.2 + wi) * 0.15;
            // Add some sharp peaks (sand/shale boundaries)
            if (s > 60 && s < 70) curve += 0.4;
            if (s > 120 && s < 128) curve -= 0.35;
            curveData.push(Math.max(-1, Math.min(1, curve)));
        }

        // Fill the log curve with color map (variable density — 1D style)
        for (var s2 = 0; s2 < nSamples; s2++) {
            var py = topM + ((h - topM - 40) / nSamples) * s2;
            var py2 = topM + ((h - topM - 40) / nSamples) * (s2 + 1);
            var val = curveData[s2];
            // Map value to x position within track
            var xOff = val * (trackW / 2);
            var fillX = trackCenter + xOff;

            // Fill from center to curve value with color-mapped color
            if (val >= 0) {
                ctx.fillStyle = mapColorRGBA(val, 0.45);
                ctx.fillRect(trackCenter, py, xOff, py2 - py);
            } else {
                ctx.fillStyle = mapColorRGBA(val, 0.45);
                ctx.fillRect(fillX, py, -xOff, py2 - py);
            }
        }

        // Draw the log curve line on top (colored by color map)
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (var s3 = 0; s3 <= nSamples; s3++) {
            var py3 = topM + ((h - topM - 40) / nSamples) * s3;
            var val3 = curveData[s3];
            var xOff3 = val3 * (trackW / 2);
            if (s3 === 0) ctx.moveTo(trackCenter + xOff3, py3);
            else ctx.lineTo(trackCenter + xOff3, py3);
        }
        ctx.strokeStyle = mapColor(0.85);
        ctx.stroke();

        // Well track line (vertical)
        ctx.strokeStyle = '#44546A';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(trackLeft, topM); ctx.lineTo(trackLeft, h - 40); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(trackRight, topM); ctx.lineTo(trackRight, h - 40); ctx.stroke();

        // Well name header
        ctx.fillStyle = '#44546A';
        ctx.font = '600 11px Segoe UI';
        ctx.textAlign = 'center';
        ctx.fillText(wellNames[wi], trackCenter, topM - 22);
        ctx.font = '9px Segoe UI';
        ctx.fillStyle = '#808080';
        ctx.fillText('GR (gAPI)', trackCenter, topM - 8);
        ctx.textAlign = 'left';
    }

    // Depth axis (left side)
    ctx.fillStyle = '#44546A';
    ctx.font = '10px Segoe UI';
    for (var d = 0; d <= 10; d++) {
        var dy = topM + ((h - topM - 40) / 10) * d;
        ctx.fillText((d * 300) + 'm', 8, dy + 4);
        ctx.strokeStyle = '#E7E6E6';
        ctx.lineWidth = 0.5;
        ctx.beginPath(); ctx.moveTo(40, dy); ctx.lineTo(w - 20, dy); ctx.stroke();
    }

    // Title
    ctx.fillStyle = '#44546A';
    ctx.font = '600 14px Segoe UI';
    ctx.fillText('Well Section — 4 Wells · Color Map: ' + activeColorMap, 16, 28);

    // Color map mini-bar in corner
    var mbX = w - 80, mbY = 12, mbW = 60, mbH = 10;
    for (var i = 0; i < mbW; i++) {
        var v = 1 - (i / mbW) * 2;
        var rgb = getColorMap().fn(v);
        ctx.fillStyle = 'rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')';
        ctx.fillRect(mbX + i, mbY, 1, mbH);
    }
    ctx.strokeStyle = '#D9D9D9';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(mbX, mbY, mbW, mbH);
}

function render1DLogView(w, h) {
    // 1D Log display — single well with multiple log tracks side by side
    // Each track shows a different log curve (GR, Resistivity, Density, Sonic)
    // All colored by the active color map
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    var topM = 60, leftM = 90, bottomM = 50;
    var plotH = h - topM - bottomM;
    var nTracks = 4;
    var trackGap = 8;
    var totalTracksW = w - leftM - 20;
    var trackW = (totalTracksW - trackGap * (nTracks - 1)) / nTracks;

    var trackNames = ['Gamma Ray', 'Resistivity', 'Density', 'Sonic'];
    var trackUnits = ['gAPI', 'ohm·m', 'g/cc', 'us/ft'];
    var trackRanges = [[0, 150], [0.2, 100], [1.9, 2.8], [40, 140]];

    var nSamples = 300;

    // Well name
    ctx.fillStyle = '#44546A';
    ctx.font = '600 14px Segoe UI';
    ctx.fillText('Well-A1 · 1D Log Display · Color Map: ' + activeColorMap, 16, 28);
    ctx.font = '10px Segoe UI';
    ctx.fillStyle = '#808080';
    ctx.fillText('Depth: 0 – 3000 m · 4 log tracks', 16, 44);

    for (var ti = 0; ti < nTracks; ti++) {
        var tx = leftM + ti * (trackW + trackGap);

        // Track background
        ctx.fillStyle = 'rgba(231,230,230,0.25)';
        ctx.fillRect(tx, topM, trackW, plotH);

        // Track border
        ctx.strokeStyle = '#D9D9D9';
        ctx.lineWidth = 1;
        ctx.strokeRect(tx, topM, trackW, plotH);

        // Track header
        ctx.fillStyle = '#44546A';
        ctx.font = '600 11px Segoe UI';
        ctx.textAlign = 'center';
        ctx.fillText(trackNames[ti], tx + trackW / 2, topM - 18);
        ctx.font = '9px Segoe UI';
        ctx.fillStyle = '#808080';
        ctx.fillText(trackUnits[ti], tx + trackW / 2, topM - 6);
        ctx.textAlign = 'left';

        // Center line
        ctx.strokeStyle = '#E7E6E6';
        ctx.lineWidth = 0.5;
        ctx.beginPath(); ctx.moveTo(tx + trackW / 2, topM); ctx.lineTo(tx + trackW / 2, topM + plotH); ctx.stroke();

        // Generate log data with different character per track
        var curveData = [];
        for (var s = 0; s <= nSamples; s++) {
            var val;
            if (ti === 0) {
                // Gamma Ray — base + sand/shale cycles
                val = Math.sin(s * 0.04) * 0.3 + Math.sin(s * 0.15) * 0.15;
                if (s > 80 && s < 100) val += 0.4; // sand
                if (s > 180 && s < 200) val -= 0.3; // shale
            } else if (ti === 1) {
                // Resistivity — logarithmic character
                val = Math.sin(s * 0.03) * 0.4 + Math.sin(s * 0.12) * 0.2;
                if (s > 80 && s < 100) val += 0.5; // hydrocarbon
            } else if (ti === 2) {
                // Density — smooth gradient
                val = Math.cos(s * 0.02) * 0.25 + Math.sin(s * 0.08) * 0.1;
            } else {
                // Sonic — slower cycles
                val = Math.sin(s * 0.025) * 0.35 + Math.cos(s * 0.07) * 0.15;
            }
            curveData.push(Math.max(-1, Math.min(1, val)));
        }

        // Fill curve with color map (variable density 1D display)
        for (var s2 = 0; s2 < nSamples; s2++) {
            var py = topM + (plotH / nSamples) * s2;
            var py2 = topM + (plotH / nSamples) * (s2 + 1);
            var val2 = curveData[s2];
            var xOff = val2 * (trackW / 2);
            var centerX = tx + trackW / 2;

            if (val2 >= 0) {
                ctx.fillStyle = mapColorRGBA(val2, 0.5);
                ctx.fillRect(centerX, py, xOff, py2 - py);
            } else {
                ctx.fillStyle = mapColorRGBA(val2, 0.5);
                ctx.fillRect(centerX + xOff, py, -xOff, py2 - py);
            }
        }

        // Curve line
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (var s3 = 0; s3 <= nSamples; s3++) {
            var py3 = topM + (plotH / nSamples) * s3;
            var val3 = curveData[s3];
            var xOff3 = val3 * (trackW / 2);
            if (s3 === 0) ctx.moveTo(tx + trackW / 2 + xOff3, py3);
            else ctx.lineTo(tx + trackW / 2 + xOff3, py3);
        }
        ctx.strokeStyle = mapColor(0.9);
        ctx.stroke();

        // Track scale labels (min/max)
        ctx.fillStyle = '#808080';
        ctx.font = '8px Segoe UI';
        ctx.textAlign = 'right';
        ctx.fillText(trackRanges[ti][1], tx + trackW - 3, topM + 10);
        ctx.fillText(trackRanges[ti][0], tx + trackW - 3, topM + plotH - 3);
        ctx.textAlign = 'left';
    }

    // Depth axis
    ctx.fillStyle = '#44546A';
    ctx.font = '10px Segoe UI';
    for (var d = 0; d <= 10; d++) {
        var dy = topM + (plotH / 10) * d;
        ctx.fillText((d * 300) + 'm', 12, dy + 4);
        ctx.strokeStyle = '#E7E6E6';
        ctx.lineWidth = 0.5;
        ctx.beginPath(); ctx.moveTo(40, dy); ctx.lineTo(w - 10, dy); ctx.stroke();
    }

    // Color map legend bar at top right
    var lbX = w - 100, lbY = 12, lbW = 80, lbH = 8;
    for (var i = 0; i < lbW; i++) {
        var v = 1 - (i / lbW) * 2;
        var rgb = getColorMap().fn(v);
        ctx.fillStyle = 'rgb(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ')';
        ctx.fillRect(lbX + i, lbY, 1, lbH);
    }
    ctx.strokeStyle = '#D9D9D9';
    ctx.lineWidth = 0.5;
    ctx.strokeRect(lbX, lbY, lbW, lbH);
    ctx.fillStyle = '#808080';
    ctx.font = '8px Segoe UI';
    ctx.textAlign = 'right';
    ctx.fillText('+', lbX - 2, lbY + 7);
    ctx.fillText('−', lbX + lbW + 8, lbY + 7);
    ctx.textAlign = 'left';
}

function zoomCanvas(factor) {
    zoomLevel *= factor;
    zoomLevel = Math.max(0.3, Math.min(3, zoomLevel));
    renderView(currentView);
}

// Mouse interaction for rotation
var isDragging = false, lastX = 0;
canvas.addEventListener('mousedown', function(e) {
    if (currentView === '3d') {
        isDragging = true;
        lastX = e.clientX;
        canvas.style.cursor = 'grabbing';
    }
});
document.addEventListener('mousemove', function(e) {
    if (isDragging) {
        rotation += (e.clientX - lastX) * 0.01;
        lastX = e.clientX;
        render3DView(canvas.width, canvas.height);
    }
    // Update coordinate readout
    var rect = canvas.getBoundingClientRect();
    if (e.clientX > rect.left && e.clientX < rect.right && e.clientY > rect.top && e.clientY < rect.bottom) {
        var il = Math.round(1 + ((e.clientX - rect.left) / rect.width) * 500);
        var xl = Math.round(1 + ((e.clientY - rect.top) / rect.height) * 400);
        var twt = Math.round(((e.clientY - rect.top) / rect.height) * 3000);
        updateCoords(il, xl, twt);
    }
});
document.addEventListener('mouseup', function() {
    isDragging = false;
    canvas.style.cursor = 'default';
});

/* ---------- 9. PROPERTIES PANEL ---------- */
document.querySelectorAll('.prop-section-header').forEach(function(header) {
    header.addEventListener('click', function() {
        var targetId = header.getAttribute('data-toggle');
        var body = document.getElementById(targetId);
        if (body) {
            body.style.display = body.style.display === 'none' ? '' : 'none';
            header.classList.toggle('collapsed');
        }
    });
});

// Slider value updates
var sliders = [
    ['opacitySlider', 'opacityVal', '%'],
    ['clipSlider', 'clipVal', ''],
    ['inlineSlider', 'inlineVal', ''],
    ['crosslineSlider', 'crosslineVal', ''],
    ['tsliceSlider', 'tsliceVal', '']
];
sliders.forEach(function(s) {
    var slider = document.getElementById(s[0]);
    var val = document.getElementById(s[1]);
    if (slider && val) {
        slider.addEventListener('input', function() {
            val.textContent = slider.value + (s[2] || '');
            if (s[0] === 'inlineSlider') {
                document.getElementById('coordIL').textContent = slider.value;
                document.getElementById('sbIL').textContent = slider.value;
                renderView(currentView);
            }
            if (s[0] === 'crosslineSlider') {
                document.getElementById('coordXL').textContent = slider.value;
                document.getElementById('sbXL').textContent = slider.value;
            }
            if (s[0] === 'tsliceSlider') {
                document.getElementById('coordTWT').textContent = slider.value;
                document.getElementById('sbTWT').textContent = slider.value;
            }
        });
    }
});

// Layer checkboxes
document.querySelectorAll('.layer-item input[type="checkbox"]').forEach(function(cb) {
    cb.addEventListener('change', function() {
        var label = cb.parentElement.querySelector('.layer-label').textContent;
        showToast((cb.checked ? 'Enabled' : 'Disabled') + ': ' + label);
        renderView(currentView);
    });
});

// Color Map dropdown — changes colors for 3D / 2D / 1D views
document.querySelectorAll('.prop-select').forEach(function(sel) {
    sel.addEventListener('change', function() {
        // Check if this is the Color Map dropdown
        var firstOption = sel.options[0] ? sel.options[0].text : '';
        if (firstOption.indexOf('Seismic Blue') >= 0 || firstOption.indexOf('Grayscale') >= 0) {
            activeColorMap = sel.value;
            updateColorbar();
            renderView(currentView);
            showToast('Color Map: ' + activeColorMap);
        }
        // Check if this is the Volume dropdown
        if (firstOption.indexOf('.sgy') >= 0) {
            showToast('Volume: ' + sel.value);
            renderView(currentView);
        }
        // Check if this is the Attribute dropdown
        if (firstOption.indexOf('RMS') >= 0 || firstOption.indexOf('Amplitude') >= 0) {
            showToast('Attribute: ' + sel.value);
        }
    });
});

// Properties panel collapse
var propCollapse = document.getElementById('propCollapse');
var propPanel = document.getElementById('propertiesPanel');
if (propCollapse && propPanel) {
    propCollapse.addEventListener('click', function() {
        propPanel.classList.toggle('properties-collapsed');
    });
}

/* ---------- 10. AI COPILOT ---------- */
var aiChat = document.getElementById('aiChat');
var aiInput = document.getElementById('aiInput');
var aiSend = document.getElementById('aiSend');

function openAICopilot() {
    var aiSection = document.querySelector('.prop-section-ai .prop-section-header');
    if (aiSection && document.getElementById('prop-ai').style.display === 'none') {
        aiSection.click();
    }
}

var aiResponses = [
    "Based on the seismic data, I recommend running acoustic impedance inversion to identify potential reservoir zones. The RMS amplitude map suggests a channel system at 1500ms TWT.",
    "I've analyzed 4 well logs in the project. Well-A1 shows the best porosity (18-22%) in the target interval. I suggest using it as a calibration well for inversion.",
    "The coherence attribute reveals two major fault systems: one NW-SE trending and one NE-SW. These compartmentalize the reservoir — consider this in your volumetric analysis.",
    "For uncertainty analysis, I recommend running Monte Carlo with 1000 realizations. Based on the available data, P50 reserves estimate is ~42 MMbbl with P10/P90 range of 28-61 MMbbl.",
    "The 3D model shows a stratigraphic trap in the western block. I suggest creating a cross-section through Inline 250 to verify the seal integrity.",
    "Performance optimization: I can parallelize the inversion across 8 CPU cores. Estimated time reduction: 73%. The V35 chunked I/O system handles volumes up to 50GB efficiently.",
    "I've detected a potential AVO class III anomaly in the southern part of the survey. This bright spot at ~1800ms could indicate a gas-charged reservoir. Recommend further analysis."
];

function addAIMessage(text, isUser) {
    var msg = document.createElement('div');
    msg.className = 'ai-msg ' + (isUser ? 'ai-msg-user' : 'ai-msg-bot');
    if (!isUser) {
        var icon = document.createElement('span');
        icon.className = 'ai-msg-icon';
        icon.innerHTML = Icons.ai;
        msg.appendChild(icon);
    }
    var textEl = document.createElement('span');
    textEl.className = 'ai-msg-text';
    textEl.textContent = text;
    msg.appendChild(textEl);
    aiChat.appendChild(msg);
    aiChat.scrollTop = aiChat.scrollHeight;
}

function sendAIMessage() {
    var text = aiInput.value.trim();
    if (!text) return;
    addAIMessage(text, true);
    aiInput.value = '';
    // Simulate AI response
    setTimeout(function() {
        var resp = aiResponses[Math.floor(Math.random() * aiResponses.length)];
        addAIMessage(resp, false);
    }, 800 + Math.random() * 600);
}

if (aiSend) aiSend.addEventListener('click', sendAIMessage);
if (aiInput) {
    aiInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') sendAIMessage();
    });
}

/* ---------- 11. STATUS BAR — live updates ---------- */
function updateCoords(il, xl, twt) {
    document.getElementById('coordIL').textContent = il;
    document.getElementById('coordXL').textContent = xl;
    document.getElementById('coordTWT').textContent = twt;
    document.getElementById('sbIL').textContent = il;
    document.getElementById('sbXL').textContent = xl;
    document.getElementById('sbTWT').textContent = twt;
}

function updateStatus() {
    // Animate memory and CPU
    var mem = 3.8 + Math.random() * 1.2;
    var cpu = 18 + Math.round(Math.random() * 15);
    document.getElementById('statusMem').textContent = mem.toFixed(1);
    document.getElementById('statusCpu').textContent = cpu;
}
setInterval(updateStatus, 2000);

/* ---------- 12. PROGRESS SIMULATION ---------- */
function simulateProgress(label) {
    var bar = document.getElementById('statusProgressBar');
    var lbl = document.getElementById('statusProgressLabel');
    lbl.textContent = label;
    bar.style.width = '0%';
    var pct = 0;
    var timer = setInterval(function() {
        pct += Math.random() * 8 + 2;
        if (pct >= 100) {
            pct = 100;
            bar.style.width = '100%';
            lbl.textContent = 'Complete';
            clearInterval(timer);
            setTimeout(function() {
                bar.style.width = '100%';
                lbl.textContent = 'Idle';
            }, 1500);
        } else {
            bar.style.width = pct + '%';
        }
    }, 200);
}

/* ---------- 13. TREE SEARCH ---------- */
var treeSearch = document.getElementById('treeSearch');
if (treeSearch) {
    treeSearch.addEventListener('input', function() {
        var q = treeSearch.value.toLowerCase();
        document.querySelectorAll('.tree-node').forEach(function(node) {
            var label = node.querySelector('.tree-label');
            if (!label) return;
            var match = label.textContent.toLowerCase().indexOf(q) >= 0;
            if (q === '') {
                node.style.display = '';
            } else {
                node.style.display = match ? '' : 'none';
            }
        });
    });
}

/* ---------- 14. WINDOW CONTROL BUTTONS ---------- */
var winClose = document.getElementById('winClose');
if (winClose) {
    winClose.addEventListener('click', function() {
        showToast('PetroScan V35 — Close (demo)');
    });
}
var winMin = document.getElementById('winMin');
if (winMin) {
    winMin.addEventListener('click', function() {
        showToast('Minimize (demo)');
    });
}
var winMax = document.getElementById('winMax');
if (winMax) {
    winMax.addEventListener('click', function() {
        showToast('Maximize (demo)');
    });
}

/* ---------- 15. KEYBOARD SHORTCUTS ---------- */
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        showToast('Project saved');
    }
    if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        showToast('Undo');
    }
    if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        showToast('Open project');
    }
    if (e.key === 'F1') {
        e.preventDefault();
        openAICopilot();
    }
});

/* ---------- INIT ---------- */
injectIcons();
updateColorbar();
setTimeout(function() {
    resizeCanvas();
    // Auto-rotate 3D view slowly for visual appeal (first few seconds)
    var autoRot = 0;
    var autoTimer = setInterval(function() {
        autoRot += 0.003;
        rotation = autoRot;
        if (currentView === '3d') render3DView(canvas.width, canvas.height);
        if (autoRot > 0.8) clearInterval(autoTimer);
    }, 50);
}, 100);

})();
