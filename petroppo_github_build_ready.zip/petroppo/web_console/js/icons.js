// =========================================================================
// PetroScan V35 — SVG Icon Library
// All icons are inline SVG strings for use in the console UI
// Style: Microsoft Fluent Design — clean, outline + fill hybrid
// =========================================================================

const Icons = {
    // ---------- PetroScan Logo ----------
    logo: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" stroke="#ED7D31" stroke-width="2" fill="#FBE5D6"/>
        <path d="M12 2L3 7l9 5 9-5-9-5z" stroke="#ED7D31" stroke-width="2" fill="none"/>
        <circle cx="12" cy="12" r="3" fill="#ED7D31"/>
        <path d="M7 9.5v5M17 9.5v5M12 7v10" stroke="#C55A11" stroke-width="1.5" opacity="0.5"/>
    </svg>`,

    // ---------- File Operations ----------
    new: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9z"/>
        <path d="M14 3v6h6M10 13h4M10 17h4"/>
    </svg>`,

    open: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/>
    </svg>`,

    save: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M17 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V7l-4-4z"/>
        <path d="M7 3v6h8V3M7 21v-8h10v8"/>
    </svg>`,

    export: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 3v12M8 7l4-4 4 4M5 15v4a2 2 0 002 2h10a2 2 0 002-2v-4"/>
    </svg>`,

    import: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 15V3M8 11l4 4 4-4M5 15v4a2 2 0 002 2h10a2 2 0 002-2v-4"/>
    </svg>`,

    print: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M6 9V3h12v6M6 18H4a2 2 0 01-2-2v-4a2 2 0 012-2h16a2 2 0 012 2v4a2 2 0 01-2 2h-2"/>
        <rect x="6" y="14" width="12" height="8" rx="1"/>
    </svg>`,

    // ---------- Seismic Operations ----------
    seismic: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M2 12h2l2-6 3 12 3-18 3 12 2-6 2 6h3"/>
    </svg>`,

    horizon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 8c4 0 6-3 10-3s6 3 8 3M3 14c4 0 6-3 10-3s6 3 8 3M3 20c4 0 6-3 10-3s6 3 8 3"/>
    </svg>`,

    fault: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 2v8M12 14v8M4 10l4-2M16 16l4-2M4 16l4-2M16 10l4-2"/>
        <path d="M10 12l4 0" stroke="currentColor" stroke-width="3"/>
    </svg>`,

    well: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M9 2v6l-3 3v11M15 2v6l3 3v11M9 8h6"/>
        <circle cx="12" cy="2" r="1.5" fill="currentColor"/>
    </svg>`,

    volume: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="3" width="18" height="18" rx="1"/>
        <path d="M3 9h18M3 15h18M9 3v18M15 3v18" opacity="0.4"/>
        <rect x="9" y="9" width="6" height="6" fill="currentColor" opacity="0.3"/>
    </svg>`,

    coherence: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="8" cy="12" r="4"/>
        <circle cx="16" cy="12" r="4"/>
        <path d="M8 12h8" stroke-dasharray="2 2"/>
    </svg>`,

    attribute: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 17l5-5 4 4 8-8M14 8h5v5"/>
    </svg>`,

    // ---------- Inversion ----------
    inversion: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M4 20c4-2 6-8 8-8s4 6 8 8"/>
        <path d="M4 4c4 2 6 8 8 8s4-6 8-8" opacity="0.4"/>
        <path d="M12 12v8" stroke-dasharray="2 2"/>
    </svg>`,

    impedance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 6h4l3 8 3-12 3 8 2-4h3"/>
    </svg>`,

    uncertainty: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="9"/>
        <path d="M9 9c0-1.5 1.5-2.5 3-2.5s3 1 3 2.5-1.5 2-3 2.5v1.5M12 17v.5"/>
    </svg>`,

    // ---------- Reservoir ----------
    reservoir: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="6" width="18" height="12" rx="1"/>
        <path d="M3 10h18M3 14h18M8 6v12M14 6v12" opacity="0.4"/>
        <circle cx="8" cy="12" r="1" fill="currentColor"/>
        <circle cx="14" cy="12" r="1" fill="currentColor"/>
    </svg>`,

    simulation: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="3"/>
        <path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3"/>
    </svg>`,

    volumetric: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 3l9 5v8l-9 5-9-5V8z"/>
        <path d="M12 3v18M3 8l9 5 9-5" opacity="0.5"/>
    </svg>`,

    // ---------- Modeling ----------
    modeling: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 20l6-12 4 6 3-4 5 10z"/>
        <path d="M3 20h18" opacity="0.4"/>
    </svg>`,

    grid: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="3" width="18" height="18" rx="1"/>
        <path d="M3 9h18M3 15h18M9 3v18M15 3v18" opacity="0.5"/>
    </svg>`,

    property: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="4" y="4" width="16" height="16" rx="2"/>
        <path d="M9 9h6v6H9z" fill="currentColor" opacity="0.2"/>
        <path d="M9 9v6M12 9v6M15 9v6" opacity="0.4"/>
    </svg>`,

    crossSection: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M4 4l16 16M4 20L20 4" opacity="0.3"/>
        <rect x="8" y="8" width="8" height="8" rx="1"/>
    </svg>`,

    // ---------- Platform / Infrastructure ----------
    viz3d: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 2L3 7v10l9 5 9-5V7z"/>
        <path d="M12 2v20M3 7l9 5 9-5M3 17l9-5 9 5" opacity="0.4"/>
    </svg>`,

    performance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 12a9 9 0 1118 0"/>
        <path d="M12 12l4-4"/>
        <circle cx="12" cy="12" r="1.5" fill="currentColor"/>
    </svg>`,

    collaboration: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="9" cy="8" r="3"/>
        <circle cx="17" cy="10" r="2.5"/>
        <path d="M3 20c0-3.5 3-6 6-6s6 2.5 6 6M14 20c0-2 1.5-4 3-4s3 2 3 4"/>
    </svg>`,

    cloud: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M7 18a5 5 0 010-10 6 6 0 0111-1 4 4 0 011 8H7z"/>
        <path d="M12 14v4M10 16l2-2 2 2" opacity="0.5"/>
    </svg>`,

    security: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 2L4 6v6c0 5 3.5 8 8 10 4.5-2 8-5 8-10V6z"/>
        <path d="M9 12l2 2 4-4"/>
    </svg>`,

    integration: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="3" width="8" height="8" rx="1"/>
        <rect x="13" y="13" width="8" height="8" rx="1"/>
        <path d="M11 7h6a2 2 0 012 2v4"/>
    </svg>`,

    multimodal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="8" cy="8" r="4"/>
        <rect x="12" y="12" width="8" height="8" rx="1"/>
        <path d="M8 12v4M12 8h4" stroke-dasharray="1.5 1.5"/>
    </svg>`,

    diagnostics: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 12h4l2-7 4 14 2-7h6"/>
    </svg>`,

    // ---------- AI ----------
    ai: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="5" y="5" width="14" height="14" rx="3"/>
        <circle cx="9" cy="10" r="1.5" fill="currentColor"/>
        <circle cx="15" cy="10" r="1.5" fill="currentColor"/>
        <path d="M9 15c1.5 1 4.5 1 6 0"/>
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3" opacity="0.4"/>
    </svg>`,

    aiCopilot: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 3l2 5 5 1-4 4 1 5-4-2-4 2 1-5-4-4 5-1z"/>
        <circle cx="12" cy="12" r="1.5" fill="currentColor"/>
    </svg>`,

    // ---------- View Operations ----------
    zoomIn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="11" cy="11" r="7"/>
        <path d="M11 8v6M8 11h6M21 21l-4.35-4.35"/>
    </svg>`,

    zoomOut: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="11" cy="11" r="7"/>
        <path d="M8 11h6M21 21l-4.35-4.35"/>
    </svg>`,

    pan: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 2v8M12 14v8M2 12h8M14 12h8" opacity="0.4"/>
        <path d="M9 5l3-3 3 3M9 19l3 3 3-3M5 9l-3 3 3 3M19 9l3 3-3 3"/>
    </svg>`,

    rotate: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M21 12a9 9 0 11-3-6.7L21 8"/>
        <path d="M21 3v5h-5"/>
    </svg>`,

    fit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M4 8V4h4M20 8V4h-4M4 16v4h4M20 16v4h-4"/>
        <rect x="8" y="8" width="8" height="8" rx="1" opacity="0.3"/>
    </svg>`,

    slice: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="3" width="18" height="18" rx="1"/>
        <path d="M3 12h18" stroke="currentColor" stroke-width="2.5"/>
    </svg>`,

    colorbar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="4" y="3" width="6" height="18" rx="1" fill="url(#cbGrad)"/>
        <defs><linearGradient id="cbGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#ED7D31"/><stop offset="50%" stop-color="#FFC000"/><stop offset="100%" stop-color="#4472C4"/>
        </linearGradient></defs>
        <path d="M12 6h8M12 12h8M12 18h8"/>
    </svg>`,

    measure: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 12l9-9 9 9-9 9z" opacity="0.3"/>
        <path d="M7 12h10M12 7v10" stroke-dasharray="2 2"/>
    </svg>`,

    // ---------- Data Formats ----------
    segy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M4 4h16v16H4z" opacity="0.3"/>
        <path d="M6 12c2-4 4 4 6 0s4 4 6 0"/>
    </svg>`,

    las: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9z"/>
        <path d="M14 3v6h6M8 13l2 4 2-4 2 4 2-4"/>
    </svg>`,

    resqml: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M4 4h16v16H4z" opacity="0.2"/>
        <path d="M4 4l16 16M20 4L4 20" opacity="0.3"/>
        <rect x="9" y="9" width="6" height="6" rx="1"/>
    </svg>`,

    witsml: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M9 2v6l-3 3v11M15 2v6l3 3v11"/>
        <path d="M6 14h12M6 18h12" opacity="0.4"/>
    </svg>`,

    // ---------- Tree Icons ----------
    folder: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/>
    </svg>`,

    folderOpen: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v1H5l-2 8V7z"/>
        <path d="M3 17l2-7h17l-2 7a1 1 0 01-1 1H4a1 1 0 01-1-1z" opacity="0.5"/>
    </svg>`,

    // ---------- Status Bar ----------
    memory: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="6" width="18" height="12" rx="1"/>
        <path d="M7 6v-2M11 6v-2M15 6v-2M19 6v-2M7 18v2M11 18v2M15 18v2M19 18v2" opacity="0.5"/>
    </svg>`,

    cpu: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="6" y="6" width="12" height="12" rx="1"/>
        <rect x="9" y="9" width="6" height="6" rx="0.5" fill="currentColor" opacity="0.2"/>
        <path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3" opacity="0.5"/>
    </svg>`,

    database: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <ellipse cx="12" cy="5" rx="8" ry="3"/>
        <path d="M4 5v6c0 1.5 3.5 3 8 3s8-1.5 8-3V5M4 11v6c0 1.5 3.5 3 8 3s8-1.5 8-3v-6"/>
    </svg>`,

    coordinates: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="10" r="3"/>
        <path d="M12 2a8 8 0 00-8 8c0 6 8 12 8 12s8-6 8-12a8 8 0 00-8-8z"/>
    </svg>`,

    // ---------- Window Controls ----------
    minimize: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M5 12h14"/>
    </svg>`,

    maximize: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="5" y="5" width="14" height="14" rx="1"/>
    </svg>`,

    close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M6 6l12 12M18 6L6 18"/>
    </svg>`,

    settings: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="3"/>
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" opacity="0.5"/>
    </svg>`,

    help: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="9"/>
        <path d="M9 9c0-1.5 1.5-2.5 3-2.5s3 1 3 2.5-1.5 2-3 2.5v1.5M12 17v.5"/>
    </svg>`,

    undo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M9 14l-5-5 5-5M4 9h11a5 5 0 010 10h-3"/>
    </svg>`,

    redo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M15 14l5-5-5-5M20 9H9a5 5 0 000 10h3"/>
    </svg>`,

    refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M21 12a9 9 0 11-3-6.7L21 8"/>
        <path d="M21 3v5h-5"/>
    </svg>`,

    run: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M5 4l14 8-14 8z" fill="currentColor" opacity="0.2"/>
        <path d="M5 4l14 8-14 8z"/>
    </svg>`,

    stop: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" opacity="0.2"/>
        <rect x="6" y="6" width="12" height="12" rx="1"/>
    </svg>`,

    chart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 20h18M7 20v-8M12 20V8M17 20v-12"/>
    </svg>`,

    table: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="4" width="18" height="16" rx="1"/>
        <path d="M3 10h18M3 15h18M9 4v16M15 4v16" opacity="0.5"/>
    </svg>`,

    layers: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 2L3 7l9 5 9-5z" opacity="0.6"/>
        <path d="M3 12l9 5 9-5M3 17l9 5 9-5" opacity="0.3"/>
    </svg>`,

    filter: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 5h18l-7 8v5l-4 2v-7z"/>
    </svg>`,

    history: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M3 12a9 9 0 109-9 9 9 0 00-7 3.5L3 8"/>
        <path d="M3 4v4h4M12 7v5l3 2"/>
    </svg>`,

    lock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="5" y="11" width="14" height="10" rx="1"/>
        <path d="M8 11V7a4 4 0 018 0v4"/>
    </svg>`,

    user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="8" r="4"/>
        <path d="M4 20c0-4 4-7 8-7s8 3 8 7"/>
    </svg>`,

    globe: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="12" cy="12" r="9"/>
        <path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18" opacity="0.5"/>
    </svg>`,

    download: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 3v12M8 11l4 4 4-4M5 21h14"/>
    </svg>`,

    upload: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 21V9M8 13l4-4 4 4M5 3h14"/>
    </svg>`,

    search: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <circle cx="11" cy="11" r="7"/>
        <path d="M21 21l-4.35-4.35"/>
    </svg>`,

    chevronRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M9 6l6 6-6 6"/>
    </svg>`,

    check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M5 12l5 5 9-9"/>
    </svg>`,

    warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M12 3l10 18H2z"/>
        <path d="M12 10v5M12 18v.5" stroke-width="2.5"/>
    </svg>`,
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Icons;
}
