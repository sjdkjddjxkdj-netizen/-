#!/usr/bin/env python3
"""
petroppo V35 — Web Console Launcher
=====================================

Starts a lightweight local HTTP server that serves the petroppo V35 console
UI (HTML5 Canvas ribbon interface) and opens it in the default web browser.

Usage
-----
    from petroppo.web_console import launch_console
    launch_console()

    # or with custom settings
    launch_console(host="127.0.0.1", port=8899, open_browser=True)

Command line:

    python -m petroppo.web_console.launch
    python -m petroppo.web_console.launch --port 9000 --no-browser
"""

import os
import sys
import argparse
import threading
import http.server
import socketserver
import webbrowser
from functools import partial

__version__ = "35.0.0"

# Directory containing index.html, css/, js/
_CONSOLE_DIR = os.path.dirname(os.path.abspath(__file__))


class WebConsoleServer:
    """A simple HTTP server that serves the petroppo V35 console UI."""

    def __init__(self, host="127.0.0.1", port=8899, console_dir=None):
        self.host = host
        self.port = port
        self.console_dir = console_dir or _CONSOLE_DIR
        self._server = None
        self._thread = None

    def _make_handler(self):
        """Create a request handler that serves files from the console directory."""
        handler = http.server.SimpleHTTPRequestHandler
        return partial(handler, directory=self.console_dir)

    def start(self, blocking=True):
        """Start the HTTP server. If blocking=True, runs forever (Ctrl+C to stop)."""
        handler_factory = self._make_handler()
        self._server = socketserver.TCPServer((self.host, self.port), handler_factory)
        self._server.allow_reuse_address = True
        url = f"http://{self.host}:{self.port}/index.html"
        print(f"petroppo V35 Console running at  {url}")
        print(f"Serving from: {self.console_dir}")
        print("Press Ctrl+C to stop.\n")
        if blocking:
            try:
                self._server.serve_forever()
            except KeyboardInterrupt:
                print("\nShutting down petroppo V35 Console...")
                self._server.shutdown()
        else:
            self._thread = threading.Thread(
                target=self._server.serve_forever, daemon=True
            )
            self._thread.start()
        return url

    def stop(self):
        """Stop the HTTP server."""
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None


def launch_console(host="127.0.0.1", port=8899, open_browser=True):
    """
    Launch the petroppo V35 web console UI.

    Parameters
    ----------
    host : str
        The host address to bind to (default: 127.0.0.1).
    port : int
        The port number (default: 8899).
    open_browser : bool
        Whether to open the console in the default web browser (default: True).

    Returns
    -------
    str
        The URL where the console is accessible.
    """
    url = f"http://{host}:{port}/index.html"

    if open_browser:
        # Open browser after a short delay so the server is ready
        def _open():
            import time
            time.sleep(0.5)
            webbrowser.open(url)
        threading.Thread(target=_open, daemon=True).start()

    server = WebConsoleServer(host=host, port=port)
    server.start(blocking=True)
    return url


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(
        description="Launch the petroppo V35 Web Console UI"
    )
    parser.add_argument(
        "--host", default="127.0.0.1", help="Host address (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=8899, help="Port number (default: 8899)"
    )
    parser.add_argument(
        "--no-browser", action="store_true", help="Do not open the browser automatically"
    )
    args = parser.parse_args()

    launch_console(
        host=args.host, port=args.port, open_browser=not args.no_browser
    )


if __name__ == "__main__":
    main()
